# User / Inventory Management Service

A Spring Boot service that manages users, orders, and oversell-safe stock
reservations for an inventory domain. Stock reservations use pessimistic and
optimistic locking with idempotent retries to prevent overselling under
concurrent load.

## Tech Stack

- Java 21 (LTS)
- Spring Boot 3.2.x (Web, Data JPA, Validation, Security, Actuator)
- PostgreSQL 15+ with Hibernate
- Maven build
- SpringDoc OpenAPI (Swagger UI)

## Running

Start the service with the Maven wrapper:

```bash
./mvnw spring-boot:run
```

Once the application is up and SpringDoc is active, the interactive API
documentation (Swagger UI) is available at:

```
/swagger-ui.html
```

## API Endpoints

All endpoints are versioned under `/api/v1/`. Request and response bodies are
JSON with camelCase field names.

| Method | Path | Description | Request Body | Response |
|---|---|---|---|---|
| POST | /api/v1/users/register | Register a new user | RegisterUserRequest | 201 Created, RegisterUserResponse |
| POST | /api/v1/orders | Place a new order | PlaceOrderRequest | 201 Created, OrderResponse |
| GET | /api/v1/orders/{id} | Get an order by id | - | 200 OK, OrderResponse |
| GET | /api/v1/orders/number/{orderNumber} | Get an order by order number | - | 200 OK, OrderResponse |
| GET | /api/v1/orders/{id}/description | Get an order's description by id | - | 200 OK, order description text |
| DELETE | /api/v1/orders/{id} | Delete an order by id | - | 204 No Content |
| POST | /api/v1/stock-reservations | Create a stock reservation (Location header; optional `Idempotency-Key` and `X-Request-ID` headers) | CreateReservationRequest | 201 Created, ReservationResponse |
| POST | /api/v1/inventory/reservations | Create a stock reservation (Location header; optional `Idempotency-Key` and `X-Request-ID` headers) | CreateReservationRequest | 201 Created, ReservationResponse |
| DELETE | /api/v1/inventory/reservations/{reservationId} | Release a reservation; idempotent on already-released (optional `Idempotency-Key`, `X-Request-ID`) | - | 200 OK, ReleaseResponse |
| DELETE | /api/v1/inventory/reservations/by-order/{orderId} | Release the active reservation for an order; idempotent (optional `Idempotency-Key`, `X-Request-ID`) | - | 200 OK, ReleaseResponse |
| GET | /api/v1/inventory/products/{productId}/stock | Get the current stock level for a product | - | 200 OK, StockLevelDTO |
| POST | /api/v1/inventory/products/stock/batch | Get stock levels for a batch of products | List&lt;UUID&gt; | 200 OK, List&lt;StockLevelDTO&gt; |
| POST | /api/v1/inventory/bulk-update | Bulk stock update, all-or-nothing (optional `Idempotency-Key`, `X-Request-ID`) | BulkUpdateRequest | 200 OK, BulkUpdateResponse |
