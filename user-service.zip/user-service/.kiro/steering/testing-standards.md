---
inclusion: always
---

# Testing Standards

## Test Pyramid

Every feature must have tests at all three levels:

1. **Unit tests** — test individual classes in isolation with Mockito
2. **Controller tests** — test REST layer with MockMvc (no real database)
3. **Integration tests** — test the full stack with real PostgreSQL via Testcontainers

Aim for: 70% unit tests, 20% controller tests, 10% integration tests.

## Naming Convention

All test methods must follow this pattern:

```
methodName_stateUnderTest_expectedBehaviour
```

Examples:
```java
register_withValidRequest_returns201Created()
register_withDuplicateEmail_returns409Conflict()
register_withMissingFirstName_returns400WithFieldError()
findById_whenUserNotFound_throwsUserNotFoundException()
```

Do not use vague names like `testRegister()` or `happyPath()`.

## AAA Pattern

Every unit test must follow the Arrange-Act-Assert pattern with blank lines 
between sections and comments marking each section:

```java
@Test
void register_withValidRequest_returns201Created() {
    // Arrange
    RegisterUserRequest request = RegisterUserRequest.builder()
        .firstName("Jane")
        .lastName("Smith")
        .email("jane@example.com")
        .password("SecurePass123!")
        .build();
    
    User savedUser = User.builder()
        .id(1L)
        .firstName("Jane")
        .lastName("Smith")
        .email("jane@example.com")
        .createdAt(Instant.now())
        .build();
    
    when(userRepository.existsByEmail("jane@example.com")).thenReturn(false);
    when(userRepository.save(any(User.class))).thenReturn(savedUser);

    // Act
    RegisterUserResponse response = userService.register(request);

    // Assert
    assertThat(response.id()).isEqualTo(1L);
    assertThat(response.email()).isEqualTo("jane@example.com");
    verify(userRepository).save(any(User.class));
}
```

## Testcontainers Rules

- Always use `@Testcontainers` and `@Container` annotations (not manual lifecycle)
- Use a shared container across all integration tests in a class with `static`
- Never hardcode ports — use `container.getMappedPort(5432)`
- Use `@DynamicPropertySource` to inject container config into Spring context
- Use `localstack` for all AWS service integration tests (never call real AWS from tests)

Standard integration test setup:

```java
@SpringBootTest
@Testcontainers
@Transactional
class UserServiceIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15-alpine")
        .withDatabaseName("testdb")
        .withUsername("test")
        .withPassword("test");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired
    private UserService userService;

    // tests here
}
```

## Test Data

- Never use production data in tests
- Use realistic but fake data (real-looking names, valid email formats)
- Use `@BeforeEach` to reset state between tests
- Do not share mutable state between test methods