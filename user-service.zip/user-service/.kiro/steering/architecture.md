---
inclusion: always
---

# Architecture Standards

## Tech Stack

This project uses the following technology stack. Do not suggest alternatives 
unless explicitly asked.

| Layer | Technology | Version |
|---|---|---|
| Language | Java | 21 (LTS) |
| Framework | Spring Boot | 3.2.x |
| Database | PostgreSQL | 15+ |
| DB Migration | Flyway | Managed by Spring Boot |
| ORM | Spring Data JPA with Hibernate | Managed by Spring Boot |
| Messaging | Amazon SQS | AWS SDK v2 |
| Testing | JUnit 5 + Mockito + Testcontainers | Managed by Spring Boot |
| Build | Maven | 3.9+ |
| API Docs | SpringDoc OpenAPI (Swagger UI) | 2.x |
## Primary Key Strategy

All entities use **UUID** as the primary key with the following pattern:

```java
@Id
@GeneratedValue(strategy = GenerationType.UUID)
@Column(columnDefinition = "UUID")
private UUID id;
```

Benefits:
- Globally unique identifiers across services
- No need for centralized ID generation
- Better for distributed systems and microservices
- Prevents enumeration attacks

## Project Structure

Follow strict layered architecture. Every feature must have all four layers:

```
src/
  main/
    java/
      com/hexaware/[service]/
        controller/     ← REST controllers only — no business logic
        service/        ← All business logic lives here
        repository/     ← Spring Data JPA interfaces only
        entity/         ← JPA entities
        dto/            ← Request and response DTOs (separate classes)
        exception/      ← Custom exception classes
        config/         ← Spring configuration classes
  test/
    java/
      com/hexaware/[service]/
        controller/     ← Controller tests (MockMvc)
        service/        ← Service unit tests (Mockito)
        integration/    ← Full-stack integration tests (Testcontainers)
```

## Approved Libraries

Only use libraries from this list. Do not add new dependencies without 
discussion. If you need something not on this list, say so and explain why.

- `spring-boot-starter-web` — REST controllers
- `spring-boot-starter-data-jpa` — JPA and Hibernate
- `spring-boot-starter-validation` — Bean Validation (Jakarta)
- `spring-boot-starter-security` — Spring Security
- `spring-boot-starter-actuator` — Health checks and metrics
- `postgresql` — PostgreSQL JDBC driver
- `flyway-core` — Database schema migrations (versioned SQL), managed by Spring Boot. All schema changes MUST go through Flyway migrations — never via `hibernate.ddl-auto` (kept on `validate`) or manual SQL against the database
- `flyway-database-postgresql` — Flyway PostgreSQL support module (required by the Flyway Maven plugin for standalone `flyway:*` goals), pinned to the Spring Boot–managed Flyway version
- `software.amazon.awssdk:sqs` — AWS SQS SDK v2
- `lombok` — Boilerplate reduction (@Data, @Builder, @RequiredArgsConstructor)
- `springdoc-openapi-starter-webmvc-ui` — OpenAPI / Swagger UI
- `mapstruct` — DTO ↔ Entity mapping (do not use manual mapping code)
- `testcontainers` — Integration test infrastructure
- `testcontainers:postgresql` — PostgreSQL Testcontainer
- `testcontainers:localstack` — AWS LocalStack for SQS integration tests

## Forbidden Patterns

Never use these patterns — if you see them in existing code, flag them:

- ❌ `@Autowired` on fields — always use constructor injection
- ❌ Business logic in `@Controller` or `@RestController` classes
- ❌ Direct SQL strings in service or controller classes (use JPA repositories)
- ❌ `System.out.println` — use `@Slf4j` and `log.info()` / `log.debug()`
- ❌ Catching and swallowing exceptions (`catch (Exception e) {}`)
- ❌ Storing passwords or secrets in plain text or in `.properties` files committed to Git
- ❌ `Optional.get()` without an `.isPresent()` check — use `.orElseThrow()`
- ❌ `@Transactional` on `@RestController` classes — put it on the service layer