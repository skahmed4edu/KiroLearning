---
inclusion: manual
name: doc-sync
description: End-of-session documentation sync — updates Javadoc, README endpoint table, and SpringDoc OpenAPI annotations for everything changed on the current branch. Run manually before pushing.
---

# Documentation Sync

Perform an end-of-session documentation sync for this branch.

## Steps

1. Run `git diff main...HEAD --name-only` to get all changed files in this branch
2. For each changed Java file: check if all public methods have accurate Javadoc,
   check if any method signature changed so Javadoc needs updating, add or update
   Javadoc where needed
3. For each changed controller file: check if SpringDoc `@Operation` and
   `@ApiResponse` annotations are present for all endpoints, add any that are
   missing
4. Read README.md and compare its API Endpoints table to the current controller
   files: add missing endpoints, remove endpoints that no longer exist, update
   descriptions for endpoints that changed

## Rules

- Before making any changes, present a plan listing exactly what you intend to
  change in each file and wait for the developer to type "yes" to proceed
- Never change business logic — documentation only
- Skip trivial getters and setters
- After completing, report exactly what was changed, file by file