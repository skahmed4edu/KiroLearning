---
inclusion: always
---

# API Design Standards

## URL Conventions

All REST endpoints must follow these rules:

- Base path: `/api/v1/` (all endpoints are versioned)
- Resource names are **plural nouns** — never verbs
- Use kebab-case for multi-word resource names

| ✅ Correct | ❌ Wrong |
|---|---|
| `GET /api/v1/users` | `GET /api/v1/getUsers` |
| `POST /api/v1/users` | `POST /api/v1/user/create` |
| `GET /api/v1/users/{id}` | `GET /api/v1/users/getById/{id}` |
| `PUT /api/v1/users/{id}` | `PUT /api/v1/updateUser/{id}` |
| `DELETE /api/v1/users/{id}` | `DELETE /api/v1/users/delete/{id}` |
| `POST /api/v1/stock-reservations` | `POST /api/v1/stockReservation` |

## HTTP Status Codes

Use the correct status code for every response:

| Situation | Status Code |
|---|---|
| Successful read | `200 OK` |
| Successful creation | `201 Created` with `Location` header |
| Successful delete | `204 No Content` |
| Validation error (missing/invalid fields) | `400 Bad Request` |
| Unauthenticated | `401 Unauthorized` |
| Insufficient permissions | `403 Forbidden` |
| Resource not found | `404 Not Found` |
| Business rule conflict (e.g. duplicate) | `409 Conflict` |
| Server error | `500 Internal Server Error` |

## Request and Response Format

All requests and responses use JSON with camelCase field names.

**Successful creation response (201):**
```json
{
  "id": 42,
  "createdAt": "2024-01-15T09:45:00Z",
  "... other resource fields"
}
```

**Location header on creation:**
```
Location: /api/v1/users/42
```

**400 Bad Request (validation errors):**
```json
{
  "status": 400,
  "error": "Validation Failed",
  "timestamp": "2024-01-15T09:45:00Z",
  "errors": [
    {
      "field": "email",
      "message": "must be a valid email address"
    },
    {
      "field": "firstName",
      "message": "must not be blank"
    }
  ]
}
```

**404 Not Found:**
```json
{
  "status": 404,
  "error": "Not Found",
  "message": "User with id 42 not found",
  "timestamp": "2024-01-15T09:45:00Z"
}
```

**409 Conflict:**
```json
{
  "status": 409,
  "error": "Conflict",
  "message": "A user with email 'jane@example.com' already exists",
  "timestamp": "2024-01-15T09:45:00Z"
}
```

## Pagination

All list endpoints that may return more than 20 results must support pagination:

```
GET /api/v1/users?page=0&size=20&sort=createdAt,desc
```

Response format for paginated endpoints:
```json
{
  "content": [ ... ],
  "totalElements": 150,
  "totalPages": 8,
  "size": 20,
  "number": 0,
  "first": true,
  "last": false
}
```

Use Spring Data's `Pageable` and `Page<T>` — do not implement pagination manually.

## Versioning

The current API version is `v1`. When breaking changes are needed:
- Create a `v2` package alongside `v1`
- Do not modify or delete v1 endpoints until all consumers have migrated
- Document the migration path in the OpenAPI spec