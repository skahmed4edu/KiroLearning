---
name: commit-standards
description: Write a Conventional Commits compliant commit message for staged changes. Use when preparing a git commit, writing a commit message, or reviewing staged changes before committing.
---

## Commit Message Process

### Step 1 — Analyse staged changes
Run a mental diff of the staged files. Identify:
- The primary change type
- The scope (which module or feature is affected)
- Whether this is a breaking change

### Step 2 — Select the correct type

| Type | Use when |
|---|---|
| `feat` | A new feature visible to the user or downstream consumers |
| `fix` | A bug fix |
| `refactor` | Code restructure with no behaviour change |
| `test` | Adding or updating tests only |
| `docs` | Documentation only |
| `chore` | Build scripts, CI config, dependency updates |
| `perf` | Performance improvement |
| `spec` | Specification artefacts (requirements/design/tasks) — no implementation code |

### Step 3 — Write the commit message

Follow this format exactly:

    <type>(<scope>): <imperative summary under 72 chars>

    [Optional body — explain WHY, not WHAT. Wrap at 72 chars.]

    [Optional footer]
    BREAKING CHANGE: <description if applicable>
    Refs: #<issue-number if applicable>

### Examples

    feat(inventory): add low-stock threshold alert endpoint

    Adds GET /api/v1/stock/alerts that returns all items where
    current available quantity falls below the configured minimum
    threshold.

    Refs: #42

    fix(reservation): prevent double-booking on concurrent requests

    Adds optimistic locking (@Version) to the ProductStock entity to
    reject concurrent save operations on the same record.

    Refs: #67

### Step 4 — Output

Produce the complete commit message inside a code block so it can be copied directly.
Then ask: "Would you like me to run `git commit -m` with this message?"