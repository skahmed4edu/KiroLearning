# Architecture Conventions — Reservation Management Service

## Package Structure

    src/main/java/com/hexaware/[service]/
    ├── controller/     # REST controllers only — no business logic
    ├── service/        # All business logic lives here
    ├── repository/     # Spring Data JPA interfaces only
    ├── entity/         # JPA entities
    ├── dto/             # Request and response DTOs (separate classes)
    ├── exception/       # Custom exception classes
    └── config/          # Spring configuration classes

## Naming Conventions
- Controllers: `[Resource]Controller.java` (e.g. `StockController.java`)
- Services: `[Resource]Service.java`
- Repositories: `[Resource]Repository.java` (extends `JpaRepository`)
- DTOs: `[Resource]Request.java` / `[Resource]Response.java`

## Error Response Format

All error responses use this shape (see api-design.md for the full reference):

    {
      "status": 400,
      "error": "Validation Failed",
      "timestamp": "2024-01-15T09:45:00Z",
      "errors": [ { "field": "...", "message": "..." } ]
    }

## Dependency Rules
- `controller/` may depend on `service/` — never directly on `repository/`
- `service/` must not depend on `controller/`
- `repository/` returns entities; mapping to DTOs happens in `service/`