---
name: spring-code-review
description: Review Spring Boot Java code for correctness, security, test coverage, and alignment with project architecture. Use when reviewing a class, controller, service, repository, or any Java file before committing or raising a PR.
---

## Review Checklist

When activated, work through each section below in order.
Reference the files in `references/` for detailed standards.

### 1. Architecture Alignment
- Does this class belong to the correct layer (controller / service / repository)?
- Are dependencies injected via constructor (not field injection)?
- Is there any business logic inside a `@Controller` or `@RestController`? If yes, flag it.
- Does the class follow the package structure defined in `references/architecture-conventions.md`?

### 2. REST API Standards (Controllers only)
- Are HTTP status codes correct? (`201 Created` for POST, `204 No Content` for DELETE)
- Are all endpoints annotated with `@Operation` for OpenAPI documentation?
- Is request body validated with `@Valid` and `@NotNull` / `@NotBlank`?
- Are error responses returned in the project's standard error format (status/error/timestamp/errors — see `references/architecture-conventions.md`), not an ad-hoc shape?

### 3. Service Layer Standards
- Is `@Transactional` applied at the service level, not the controller or repository?
- Are checked exceptions wrapped in a domain-specific `RuntimeException`?
- Is there no direct use of `EntityManager`? (Use Spring Data repositories.)

### 4. Security
- Are any SQL queries constructed via string concatenation? (Flag immediately — SQL injection risk.)
- Is sensitive data (passwords, tokens) logged anywhere?
- Are endpoints appropriately secured (check `SecurityConfig`)?

### 5. Test Coverage
- Does each public method have a corresponding unit test?
- Do test methods follow the methodName_stateUnderTest_expectedBehaviour convention?
- Are tests using `@ExtendWith(MockitoExtension.class)` (not Spring context) for unit tests?
- Is there at least one integration test for each `@RestController`?

### 6. Output Format

After completing the review, produce a structured report:

    ## Code Review Report — [ClassName]

    ### ✅ Passed
    - List items that meet standards

    ### ⚠️ Warnings (non-blocking)
    - List items to improve before next sprint

    ### ❌ Blockers (must fix before PR merge)
    - List critical issues with line references

    ### Suggested next prompt
    "Fix the blockers in [ClassName] and re-run the spring-code-review skill."