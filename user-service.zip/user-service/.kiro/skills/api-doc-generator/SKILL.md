---
name: api-doc-generator
description: Generate OpenAPI documentation annotations and Markdown endpoint summaries for Spring Boot REST controllers and methods. Use when adding a new endpoint, updating an API method signature, or preparing API documentation for a release.
---

## Documentation Generation Process

### Step 1 — Analyse the method signature
Identify:
- HTTP method and path (`@GetMapping`, `@PostMapping`, etc.) — confirm it's under the versioned `/api/v1/` base path per api-design.md
- Path variables and request parameters
- Request body type (if any)
- Return type and possible HTTP status codes

### Step 2 — Add SpringDoc OpenAPI annotations

Add these annotations to the method:

    @Operation(
        summary = "[One-line description of what the endpoint does]",
        description = "[2-3 sentences. Include business context, not just technical details.]"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Success — [describe the response body]"),
        @ApiResponse(responseCode = "400", description = "Validation error — [describe when this occurs]"),
        @ApiResponse(responseCode = "404", description = "Not found — [describe when this occurs]"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })

Use `@Parameter(description = "...")` for every `@PathVariable` and `@RequestParam`.

### Step 3 — Generate Markdown endpoint card

After annotating the code, produce a Markdown endpoint card in this format:

    ## [HTTP Method] [Path]

    **Summary:** [One-line summary]

    **Description:** [2-3 sentences from the @Operation description]

    ### Request
    | Parameter | Type | Required | Description |
    |---|---|---|---|
    | (list path variables, query params, body fields) |

    ### Response
    | Status | Description |
    |---|---|
    | 200 | [success description] |
    | 400 | [validation error] |
    | 404 | [not found] |

    ### Example Request
    (bash)
    curl -X [METHOD] "http://localhost:8080/api/v1/[path]" \
      -H "Content-Type: application/json" \
      -d '[example JSON body if applicable]'

    ### Example Response
    (json)
    [example response JSON]

Append this card to `docs/api-reference.md`. If the file doesn't exist, create it with a heading:
`# Inventory Management Service — API Reference`