# Implementation Plan: Stock Reservation Feature

## Overview

This implementation plan breaks down the Stock Reservation feature into discrete, testable tasks. The feature adds inventory management capabilities to the existing Order Service with atomic reservation handling, automatic expiration, and concurrent-safe operations. All tasks follow the design patterns established in the existing codebase (JPA/Hibernate, Spring Boot, PostgreSQL).

**Key Implementation Phases:**
1. Database schema and entity models
2. Repository layer with lock-safe queries
3. Stock management services (query, update, bulk operations)
4. Reservation services (create, release with idempotency)
5. Background expiration job
6. REST API endpoints
7. Integration with Order Service
8. Monitoring and observability
9. Configuration management
10. Comprehensive testing

---

## Phase 1: Database Setup and Entity Models

- [x] 1. Set up database schema and migrations
  - Create PostgreSQL DDL migrations for products, reservations, history, and audit tables
  - Implement all constraints: stock invariants, FK relationships, unique indexes
  - Use Flyway or Liquibase for version-controlled migrations
  - Ensure row-level locking support with proper indexes
  - _Requirements: 6.1, 6.5_
  - _Complexity: Medium_

- [x] 2. Create Product entity and value objects
  - Implement `Product` JPA entity with stock fields (totalStock, availableStock, reservedStock)
  - Add `@Version` annotation for optimistic locking with lock_version field
  - Implement stock invariant constraint at entity level
  - Create builder pattern for entity construction
  - Add custom queries for pessimistic locking (SELECT...FOR UPDATE NOWAIT)
  - _Requirements: 1.1, 1.3, 6.1, 6.6_
  - _Complexity: Small_

  - [x] 2.1 Write unit tests for Product entity
    - Test stock invariant validation (availableStock >= 0, reservedStock >= 0)
    - Test immutability of createdAt field
    - Test version field increments on update
    - _Requirements: 1.3_

- [x] 3. Create Reservation entity with status lifecycle
  - Implement `Reservation` JPA entity with ReservationStatus enum (ACTIVE, RELEASED, EXPIRED, CANCELLED)
  - Add fields for idempotency key, expiration tracking, timestamps
  - Establish ManyToOne relationship with Product entity
  - Add indexes for query performance (order_id, product_id, status, expiration_time)
  - Implement lazy loading for Product reference
  - _Requirements: 2.5, 2.6, 2.7, 3.2, 3.3_
  - _Complexity: Small_

  - [x] 3.1 Write unit tests for Reservation entity
    - Test status transitions (ACTIVE → RELEASED, ACTIVE → EXPIRED)
    - Test expiration time calculation
    - Test immutability of orderId and productId fields
    - _Requirements: 3.2, 3.3_

- [x] 4. Create audit entities (ReservationHistory and StockAuditLog)
  - Implement `ReservationHistory` entity to track status changes
  - Implement `StockAuditLog` entity to track stock operations
  - Add indexes for efficient queries by timestamp and operation type
  - Establish FK relationships with Reservation and Product
  - _Requirements: 8.1, 8.3_
  - _Complexity: Small_

---

## Phase 2: Repository Layer and Lock-Safe Queries

- [x] 5. Create ProductRepository with pessimistic locking queries
  - Extend JpaRepository for CRUD operations
  - Implement `findByIdWithLock(UUID id)` using SELECT...FOR UPDATE NOWAIT
  - Implement `findByIdWithLockSkipLocked(UUID id)` with SKIP LOCKED clause
  - Implement `findBySku(String sku)` for product lookup
  - Implement batch query method for multiple products
  - Add custom @Query annotations with native SQL for locking strategies
  - _Requirements: 1.1, 6.1, 6.6, 6.8_
  - _Complexity: Medium_

  - [x] 5.1 Write unit tests for ProductRepository locking queries
    - Test NOWAIT behavior raises LockAcquisitionFailedException when locked
    - Test SKIP LOCKED returns alternative products when locked
    - Test concurrent access to same product via locking methods
    - _Requirements: 6.6, 6.8_

- [x] 6. Create ReservationRepository with status-aware queries
  - Extend JpaRepository for CRUD operations
  - Implement `findByOrderId(UUID orderId)` with locking
  - Implement `findByIdWithLock(UUID id)` for pessimistic locking
  - Implement `findExpiredReservations(LocalDateTime now)` query
  - Implement `findActiveReservationsByProductId(UUID productId)` for stock calculation
  - Implement `findByIdempotencyKeyAndOrderId(String key, UUID orderId)` for deduplication
  - Add custom queries for batch expiration processing
  - _Requirements: 2.5, 3.1, 4.1, 4.6_
  - _Complexity: Medium_

  - [x] 6.1 Write unit tests for ReservationRepository queries
    - Test expiration query returns only ACTIVE reservations past TTL
    - Test active reservations query filters by status
    - Test idempotency key lookup prevents duplicate reservations
    - Test locking queries raise appropriate exceptions
    - _Requirements: 2.5, 4.1_

---

## Phase 3: Stock Management Services

- [x] 7. Create StockQueryService for retrieving stock levels
  - Implement method `getStockLevel(UUID productId)` → StockLevelDTO
  - Calculate available stock = totalStock - sum(activeReservations)
  - Return DTO with totalStock, availableStock, reservedStock, activeReservation count
  - Implement batch query `getStockLevels(List<UUID> productIds)` → List<StockLevelDTO>
  - Add performance optimization: cache results if updated_at within last 1 second
  - Add response time logging (P50, P95, P99 percentiles)
  - _Requirements: 1.1, 1.3, 1.5, 8.5_
  - _Complexity: Small_

  - [x] 7.1 Write property tests for stock calculation
    - **Property 1: Available stock invariant**
    - **Validates: Requirements 1.3**
    - availableStock = totalStock - sum(activeReservations) must hold
    
  - [x] 7.2 Write unit tests for StockQueryService
    - Test getStockLevel returns correct calculated values
    - Test batch query returns accurate values for multiple products
    - Test non-existent product raises exception
    - Test response time under 100ms for 99th percentile
    - _Requirements: 1.1, 1.4_

- [x] 8. Create StockUpdateService for bulk stock updates
  - Implement `bulkUpdateStock(List<BulkStockUpdate> updates)` → BulkUpdateResult
  - Validate all entries before applying changes (all-or-nothing semantics)
  - Check: no invalid product IDs, no negative quantities, new stock >= reserved stock
  - Process locks in consistent order (by product ID ascending) to prevent deadlocks
  - Use optimistic locking with retry logic (max 3 retries with exponential backoff)
  - Limit batch size to INVENTORY_BULK_UPDATE_MAX_SIZE (default 1000)
  - Log bulk operations with timestamp and product list
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 6.8_
  - _Complexity: Large_

  - [x] 8.1 Write property tests for bulk update consistency
    - **Property 2: Invariant after bulk update**
    - **Validates: Requirements 5.1, 5.8**
    - After bulk update: totalStock_new > 0 AND availableStock_new >= 0
    - AND for each product: availableStock_new = totalStock_new - sum(activeReservations)
    
    - [x] 8.2 Write property test for bulk update idempotence
      - **Property 3: Metamorphic property**
      - **Validates: Requirements 5.1**
      - Bulk updating N products sequentially produces identical results to bulk updating all N in one operation
    
  - [x] 8.3 Write unit tests for StockUpdateService
    - Test successful bulk update updates all products
    - Test invalid product ID fails entire batch with no partial updates
    - Test negative quantity fails entire batch
    - Test new stock < reserved stock fails with INVALID_STOCK_AFTER_RESERVATIONS
    - Test batch size limit (max 1000 products)
    - Test lock ordering prevents deadlocks under concurrent updates
    - Test optimistic locking retry logic with version conflicts
    - _Requirements: 5.1, 5.2, 5.3, 5.7, 5.8, 6.8_

- [x] 9. Implement deadlock prevention for concurrent bulk updates
  - Create `DeadlockPreventionUtil` with consistent lock ordering
  - Implement `sortProductsByIdForLocking(List<UUID> productIds)` → sorted list
  - Add lock acquisition timeout configuration (INVENTORY_LOCK_TIMEOUT_SECONDS)
  - Document lock ordering strategy in code comments
  - _Requirements: 6.8_
  - _Complexity: Small_

---

## Phase 4: Reservation Creation Service

- [x] 10. Create ReservationService with atomic create operation
  - Implement `createReservation(CreateReservationRequest) → ReservationResponse`
  - Support idempotency via Idempotency-Key header processing
  - Step 1: Check idempotency key for duplicate detection
  - Step 2: Acquire row-level lock on product using pessimistic locking (FOR UPDATE NOWAIT)
  - Step 3: Validate available stock >= requested quantity
  - Step 4: Create reservation record with ACTIVE status and expiration time
  - Step 5: Update product: decrement availableStock, increment reservedStock
  - Step 6: Log to stock_audit_log with timestamp and request context
  - Use @Transactional with READ_COMMITTED isolation level
  - Implement exponential backoff retry logic for OptimisticLockingFailureException (max 3 retries)
  - Handle LockAcquisitionFailedException → return HTTP 503 LOCK_TIMEOUT
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 6.1, 6.2, 6.5_
  - _Complexity: Large_

  - [x] 10.1 Write property tests for reservation creation invariants
    - **Property 4: Stock decrement invariant**
    - **Validates: Requirements 2.3, 2.4**
    - availableStock_after = availableStock_before - reservedQuantity
    
    - [x] 10.2 Write property test for metamorphic reservation behavior
      - **Property 5: Metamorphic property**
      - **Validates: Requirements 2.3**
      - If two reservations created sequentially for same product:
      - second_available = first_available - first_quantity
    
    - [x] 10.3 Write property test for error idempotence
      - **Property 6: Error condition idempotence**
      - **Validates: Requirements 2.2**
      - Attempting to reserve > available stock produces error and leaves stock unchanged
    
  - [x] 10.4 Write unit tests for ReservationService create
    - Test successful reservation creation with sufficient stock
    - Test insufficient stock returns HTTP 409 with available stock in response
    - Test idempotent retry returns same reservation without duplicate creation
    - Test concurrent creation attempts on same product (only one succeeds)
    - Test lock timeout returns HTTP 503 with retry hint
    - Test version conflict triggers exponential backoff retry
    - Test expiration time calculated as now + TTL_MINUTES
    - Test stock audit log entry created
    - Test reservation linked to order ID
    - _Requirements: 2.1-2.7, 6.1, 6.2_

- [~] 11. Create request/response DTOs for reservation operations
  - Implement `CreateReservationRequest` DTO
  - Implement `ReservationResponse` DTO
  - Implement `ReservationErrorResponse` DTO with available stock for retries
  - Implement `BulkUpdateRequest` and `BulkUpdateResponse` DTOs
  - Add JSR-303 validation annotations (@NotNull, @Positive, @Max, etc.)
  - _Requirements: 2.1, 7.5, 7.8_
  - _Complexity: Small_

---

## Phase 5: Reservation Release Service with Idempotency

- [x] 12. Create ReservationReleaseService with idempotent operations
  - Implement `releaseReservation(UUID reservationId, String idempotencyKey) → ReleaseResponse`
  - Support idempotency: releasing already-RELEASED reservation returns success
  - Support release by orderId: `releaseReservationByOrderId(UUID orderId, String idempotencyKey)`
  - Step 1: Look up reservation by ID or orderId (with lock)
  - Step 2: Validate reservation status (ACTIVE or RELEASED for idempotency)
  - Step 3: If status is RELEASED, return success (idempotent)
  - Step 4: If status is not ACTIVE, return HTTP 409 RESERVATION_ALREADY_PROCESSED
  - Step 5: Acquire row-level lock on Product
  - Step 6: Update product: increment availableStock, decrement reservedStock
  - Step 7: Update reservation: status = RELEASED, released_at = now
  - Step 8: Insert into reservation_history
  - Step 9: Log to stock_audit_log
  - Use @Transactional with READ_COMMITTED isolation level
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 6.5_
  - _Complexity: Large_

  - [x] 12.1 Write property tests for reservation release invariants
    - **Property 7: Stock restore invariant**
    - **Validates: Requirements 3.3**
    - availableStock_after = availableStock_before + reservedQuantity
    
    - [x] 12.2 Write property test for round-trip consistency
      - **Property 8: Round-trip property**
      - **Validates: Requirements 3.4**
      - Create reservation then release it returns available stock to original value
    
    - [x] 12.3 Write property test for idempotent release
      - **Property 9: Idempotence property**
      - **Validates: Requirements 3.7**
      - Releasing same reservation multiple times produces same final state
    
    - [x] 12.4 Write property test for error conditions
      - **Property 10: Error condition**
      - **Validates: Requirements 3.5**
      - Attempting to release non-existent reservation produces error and leaves stock unchanged
    
  - [x] 12.5 Write unit tests for ReservationReleaseService
    - Test successful release of ACTIVE reservation
    - Test idempotent release of already-RELEASED reservation returns success
    - Test release of EXPIRED reservation returns HTTP 409
    - Test release of non-existent reservation returns HTTP 404
    - Test release by orderId finds and releases correct reservation
    - Test concurrent release attempts on same reservation (one succeeds, one gets idempotent response)
    - Test stock audit log entry created for each release
    - Test reservation_history record created
    - Test lock timeout returns HTTP 503
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

---

## Phase 6: Reservation Expiration Background Job

- [x] 13. Create ReservationExpirationScheduler scheduled task
  - Implement `ProcessExpiredReservations` scheduled task
  - Configure scheduled execution via @Scheduled with fixedDelayString
  - Use INVENTORY_EXPIRATION_CHECK_INTERVAL_SECONDS config (default 60 seconds)
  - Query ACTIVE reservations where expiration_time <= now() with batch limit (1000)
  - Group expired reservations by product_id for batch processing
  - For each product: acquire lock, update stock, update reservation status, log changes
  - Implement idempotence: if already EXPIRED, skip processing
  - Log batch processing statistics (count, products affected, duration)
  - Emit metrics: reservations.expired.count, reservations.expired.products, reservations.expiration.errors
  - Handle lock acquisition failures gracefully (skip product, continue next)
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.8, 8.1, 8.3_
  - _Complexity: Large_

  - [x] 13.1 Write property tests for expiration processing
    - **Property 11: Expiration stock restoration invariant**
    - **Validates: Requirements 4.2**
    - After expiration: availableStock_after = availableStock_before + reservedQuantity
    
    - [x] 13.2 Write property test for metamorphic expiration
      - **Property 12: Metamorphic property**
      - **Validates: Requirements 4.1**
      - Number of EXPIRED reservations = number of reservations where (createdAt + TTL) < currentTime
    
    - [x] 13.3 Write property test for expiration idempotence
      - **Property 13: Idempotence property**
      - **Validates: Requirements 4.1**
      - Expiring same reservation multiple times results in same final state
    
    - [x] 13.4 Write property test for concurrent operations
      - **Property 14: Confluence property**
      - **Validates: Requirements 6.4**
      - Concurrent expiration and release operations don't violate invariants
    
  - [x] 13.5 Write unit tests for ReservationExpirationScheduler
    - Test expiration marks ACTIVE reservations as EXPIRED
    - Test expiration restores stock for expired reservations
    - Test expiration processes multiple products atomically
    - Test expiration skips non-ACTIVE reservations
    - Test batch processing limits to 1000 per cycle
    - Test lock timeout on one product doesn't block other products
    - Test metrics emitted with correct counts
    - Test concurrent expirations on same product processed serially
    - _Requirements: 4.1-4.6, 4.8_

  - [x] 13.6 Write integration tests for expiration job
    - Create multiple reservations with past expiration times
    - Let scheduler run
    - Verify reservations marked EXPIRED and stock restored
    - Verify no double-restoration on subsequent runs (idempotence)
    - _Requirements: 4.1, 4.2_

- [~] 14. Create SchedulerHealthCheck component
  - Track last successful execution time and next scheduled execution
  - Implement health indicator showing scheduler status
  - Expose metrics for success rate and error rate
  - Log execution duration and batch statistics
  - _Requirements: 8.7_
  - _Complexity: Small_

---

## Phase 7: REST API Endpoints

- [ ] 15. Create InventoryController with reservation endpoints
  - Implement `POST /api/v1/inventory/reservations` → create reservation
  - Implement `DELETE /api/v1/inventory/reservations/{reservationId}` → release reservation
  - Implement `DELETE /api/v1/inventory/reservations/by-order/{orderId}` → release by order ID
  - Implement `GET /api/v1/inventory/products/{productId}/stock` → get stock level
  - Implement `POST /api/v1/inventory/products/stock/batch` → batch stock query
  - Implement `POST /api/v1/inventory/bulk-update` → bulk stock update
  - Add Idempotency-Key header processing on all POST/DELETE operations
  - Extract and set correlation IDs (X-Request-ID) for tracing
  - Add request/response logging with @Aspect or filter
  - _Requirements: 2.1, 3.1, 1.1, 1.5, 5.1, 7.5, 7.6, 7.7_
  - _Complexity: Medium_

  - [-] 15.1 Write unit tests for InventoryController endpoints
    - Test POST /reservations creates reservation with valid request
    - Test POST /reservations returns 409 INSUFFICIENT_STOCK with available stock
    - Test POST /reservations returns 503 LOCK_TIMEOUT with retry hint
    - Test DELETE /reservations/{id} releases reservation
    - Test DELETE /reservations/{id} idempotent on already-released
    - Test DELETE /reservations/by-order/{orderId} finds and releases reservation
    - Test GET /products/{id}/stock returns stock level
    - Test POST /products/stock/batch returns levels for multiple products
    - Test POST /bulk-update updates all products or fails all
    - Test all endpoints validate Idempotency-Key header
    - _Requirements: 2.1, 3.1, 1.1, 1.5, 5.1_

  - [-] 15.2 Write integration tests for API endpoints
    - Test end-to-end flow: create order → reserve stock → cancel order → release stock
    - Test concurrent API calls to same product
    - Test error responses include proper HTTP status and error codes
    - Test response times meet performance requirements
    - _Requirements: 1.4, 2.1, 3.1_

---

## Phase 8: Error Handling and Validation

- [ ] 16. Create GlobalExceptionHandler for inventory errors
  - Extend existing GlobalExceptionHandler to handle inventory exceptions
  - Create custom exceptions:
    - `InsufficientStockException` → HTTP 409
    - `ReservationNotFoundException` → HTTP 404
    - `ReservationAlreadyReleasedException` → HTTP 409 (idempotent)
    - `LockTimeoutException` → HTTP 503 with retry hint
    - `InvalidBulkUpdateException` → HTTP 400
    - `InvalidStockAfterReservationsException` → HTTP 409
  - Return standardized error response with error code, message, details, timestamp, requestId
  - Log errors with context (order ID, product ID, etc.)
  - Expose retry hints in error response for retryable errors
  - _Requirements: 2.2, 3.5, 3.6, 3.7, 5.2, 5.3, 5.7, 6.7_
  - _Complexity: Medium_

  - [-] 16.1 Write unit tests for exception handling
    - Test each custom exception type returns correct HTTP status
    - Test error response includes all required fields
    - Test non-retryable errors don't include retry hint
    - Test retryable errors include retry hint
    - _Requirements: 2.2, 3.5, 5.2, 5.3, 6.7_

- [~] 17. Create input validation layer
  - Implement JSR-303 validation on all DTOs
  - Create custom validator for bulk update requests (max 1000 items)
  - Create custom validator for product IDs (must exist in database)
  - Create custom validator for quantity fields (positive integers)
  - Add validation exception handler in GlobalExceptionHandler
  - _Requirements: 5.2, 5.3, 5.6_
  - _Complexity: Small_

---

## Phase 9: Configuration Management

- [ ] 18. Create InventoryConfiguration class
  - Load configuration from environment variables and application.properties
  - Define configurable parameters:
    - INVENTORY_RESERVATION_TTL_MINUTES (default: 15, range: 1-1440)
    - INVENTORY_EXPIRATION_CHECK_INTERVAL_SECONDS (default: 60, range: 10-300)
    - INVENTORY_BULK_UPDATE_MAX_SIZE (default: 1000, range: 1-10000)
    - INVENTORY_LOCK_TIMEOUT_SECONDS (default: 30, range: 5-300)
    - INVENTORY_MAX_RESERVATIONS_PER_SECOND (default: 10000)
    - INVENTORY_IDEMPOTENCY_KEY_RETENTION_DAYS (default: 1)
    - INVENTORY_DB_CONNECTION_POOL_SIZE (default: 20)
  - Validate configuration on startup (fail if invalid ranges)
  - Expose configuration via properties with @ConfigurationProperties
  - Add logging of loaded configuration on startup
  - _Requirements: 4.4, 4.5, 4.7_
  - _Complexity: Small_

  - [~] 18.1 Write unit tests for configuration loading
    - Test configuration loads from environment variables
    - Test configuration loads from application.properties
    - Test configuration validation rejects invalid values
    - Test default values when not configured
    - _Requirements: 4.4, 4.5, 4.7_

---

## Phase 10: Monitoring, Logging, and Health Checks

- [~] 19. Create monitoring and metrics infrastructure
  - Use Micrometer for metrics collection
  - Implement custom metrics:
    - `inventory.reservations.total` (counter of all reservations)
    - `inventory.reservations.active` (gauge of ACTIVE reservations)
    - `inventory.reservations.expired` (counter of EXPIRED reservations)
    - `inventory.reservations.released` (counter of RELEASED reservations)
    - `inventory.operations.duration` (timer for operation latencies)
    - `inventory.stock.available` (gauge per product)
    - `inventory.stock.reserved` (gauge per product)
    - `inventory.errors.lock_timeout` (counter of lock timeouts)
    - `inventory.errors.insufficient_stock` (counter of insufficient stock errors)
  - Add @Timed annotations to service methods
  - Expose metrics via Prometheus endpoint
  - _Requirements: 8.2, 8.5_
  - _Complexity: Medium_

- [ ] 20. Create comprehensive logging
  - Add structured logging with SLF4J to all service methods
  - Log operation type, timestamp, product ID, quantity, user context
  - Log error conditions with stack traces and context
  - Log expiration batch processing statistics
  - Add correlation ID (X-Request-ID) to all logs for tracing
  - Implement log levels: DEBUG for detailed flow, INFO for operations, WARN for recoverable issues, ERROR for failures
  - _Requirements: 8.1, 8.3, 8.4, 8.6_
  - _Complexity: Medium_

  - [~] 20.1 Write unit tests for logging
    - Test all operations logged with correct level and context
    - Test error logging includes stack traces
    - _Requirements: 8.1, 8.6_

- [ ] 21. Create InventoryHealthController with health check endpoints
  - Implement `GET /api/v1/inventory/health` → health status
  - Check database connectivity
  - Check reservation expiration job status (last run, next run, success rate)
  - Return UP/DOWN status with component-level details
  - Include responseTime for each component
  - Return detailed diagnostics in health response
  - _Requirements: 8.7_
  - _Complexity: Small_

  - [~] 21.1 Write unit tests for health checks
    - Test health endpoint returns UP when all components healthy
    - Test health endpoint includes database status
    - Test health endpoint includes scheduler status
    - Test health endpoint returns DOWN when database unavailable
    - _Requirements: 8.7_

---

## Phase 11: Integration with Order Service

- [ ] 22. Update OrderService to integrate with InventoryService
  - Modify `placeOrder(PlaceOrderRequest)` to:
    - Extract product and quantity from order
    - Call InventoryService.createReservation() before confirming order
    - If reservation fails with INSUFFICIENT_STOCK, return error to user
    - If reservation succeeds, store reservationId in Order entity
    - If reservation fails with LOCK_TIMEOUT, return 503 with retry hint
  - Add reservationId field to Order entity
  - Add reservationId field to OrderResponse DTO
  - Update OrderResponse to include reservation details
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_
  - _Complexity: Medium_

  - [~] 22.1 Write integration tests for Order-Inventory integration
    - Test place order reserves stock successfully
    - Test place order fails if insufficient stock
    - Test place order fails if lock timeout
    - Test cancel order releases reservation
    - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [ ] 23. Update OrderService to handle cancellation with reservation release
  - Modify order cancellation logic to:
    - Look up reservation ID from order
    - Call InventoryService.releaseReservation(reservationId)
    - Handle idempotent release (if already released, succeed silently)
    - Handle non-existent reservation (log warning, continue)
    - Update order status after release succeeds
  - Add error handling for release failures
  - _Requirements: 7.3, 3.1, 3.2, 3.7_
  - _Complexity: Small_

  - [~] 23.1 Write integration tests for cancellation with release
    - Test cancel order releases reservation and restores stock
    - Test cancel order idempotent (multiple cancellations succeed)
    - _Requirements: 7.3, 3.1_

---

## Phase 12: Concurrency and Edge Case Testing

- [ ] 24. Create concurrency test suite
  - Implement concurrent reservation tests:
    - 100 concurrent threads reserving from same product
    - Verify only one succeeds if stock = 1
    - Verify correct number succeed if stock = 50
    - Verify no overselling occurs
  - Implement concurrent release tests:
    - Concurrent releases of different reservations
    - Concurrent release and expiration on same product
  - Implement concurrent bulk update tests:
    - Concurrent bulk updates locking products in consistent order
    - Verify no deadlocks occur
    - Verify final stock state is correct
  - Use JUnit 5 @ParameterizedTest with different concurrency levels
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.6_
  - _Complexity: Large_

  - [~] 24.1 Write property-based concurrency tests
    - **Property 15: Invariant under concurrency**
    - **Validates: Requirements 6.1, 6.3, 6.4**
    - Even under concurrent operations: availableStock >= 0
    - AND sum(reservations) + availableStock = totalStock
    - **Property 16: Confluence property**
    - **Validates: Requirements 6.4**
    - Final stock state identical regardless of concurrent operation order

- [~] 25. Write edge case tests
  - Test reservation with quantity = 0 (should fail validation)
  - Test reservation with quantity > totalStock (should fail with insufficient stock)
  - Test releasing already-expired reservation (should fail)
  - Test releasing already-cancelled reservation (should fail)
  - Test bulk update with 0 products (should fail validation)
  - Test bulk update with 1001 products (should fail with size limit)
  - Test stock level query for non-existent product (should return 404)
  - Test idempotent key collision with different order IDs
  - Test reservation expiration at exact TTL boundary
  - _Requirements: 2.2, 3.5, 3.6, 5.2, 5.3, 5.6_
  - _Complexity: Medium_

---

## Phase 13: Documentation and Final Integration

- [~] 26. Create comprehensive documentation
  - Document API endpoints with examples (OpenAPI/Swagger spec)
  - Document configuration parameters and valid ranges
  - Document error codes and recovery strategies
  - Document metrics and monitoring setup
  - Document database schema and entity relationships
  - Document concurrency model and locking strategy
  - Create architecture diagram in README
  - Create deployment guide with migration steps
  - _Complexity: Medium_

- [~] 27. Database migration setup
  - Create initial migration: schema, tables, indexes, constraints
  - Create test fixtures migration for integration tests
  - Verify migrations work on clean database
  - Verify migrations are idempotent
  - Document migration strategy in README
  - _Complexity: Small_

- [ ] 28. Final integration checkpoint
  - Run full test suite (unit, integration, property-based tests)
  - Verify all requirements mapped to tasks
  - Verify all properties validated by tests
  - Verify no orphaned code or integration gaps
  - Verify performance meets requirements (100ms for queries, 200ms for create, 5s for bulk)
  - Verify concurrency/thread safety under load
  - Perform code review against design document
  - _Complexity: Large_

  - [~] 28.1 Write end-to-end integration tests
    - Complete workflow: place order → reserve stock → expire reservation → check stock
    - Complete workflow: place order → cancel order → verify reservation released
    - Concurrent order placement with stock exhaustion
    - Bulk restock followed by mass order placement
    - _Requirements: All_

---

## Notes

### Testing Strategy

- **Unit Tests**: Test individual components in isolation with mocks
- **Integration Tests**: Test multiple components together with real database (H2 or testcontainers)
- **Property-Based Tests**: Use fast-check (Java) or Hypothesis patterns to verify correctness properties
- **Concurrency Tests**: Verify no overselling or race conditions under load
- **Edge Case Tests**: Cover boundary conditions and error paths

### Optional vs. Required Tasks

Tasks marked with `*` are optional test sub-tasks that can be skipped for faster MVP:
- Property-based tests (exploratory verification)
- Some unit test coverage (if tight deadline)
- Full integration test suite (if prioritizing speed)

Core implementation tasks (unmarked) must be completed.

### Complexity Estimates

- **Small**: 2-4 hours (straightforward, well-defined scope)
- **Medium**: 4-8 hours (multiple concerns, moderate complexity)
- **Large**: 8-16 hours (complex logic, multiple edge cases, concurrency concerns)

### Requirements Traceability

Each task is tagged with requirements it satisfies. All 8 main requirements + 4 configuration parameters are covered by implementation tasks.

### Correctness Properties Validation

14 distinct correctness properties are distributed across implementation and test tasks, covering:
- Stock invariants (available >= 0, total = available + reserved)
- Round-trip consistency (reserve → release → restore)
- Idempotence (repeating operations produces same state)
- Metamorphic properties (sequential vs. batch operations equivalent)
- Confluence (concurrent operations independent of order)
- Error condition safety (errors leave stock unchanged)

---

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.0", "2.0", "3.0"] },
    { "id": 1, "tasks": ["2.1", "3.1", "4.0", "5.0", "6.0"] },
    { "id": 2, "tasks": ["5.1", "6.1", "7.0", "8.0"] },
    { "id": 3, "tasks": ["7.1", "7.2", "8.1", "8.2", "8.3", "9.0"] },
    { "id": 4, "tasks": ["10.0", "11.0", "12.0"] },
    { "id": 5, "tasks": ["10.1", "10.2", "10.3", "10.4", "12.1", "12.2", "12.3", "12.4", "12.5"] },
    { "id": 6, "tasks": ["13.0", "14.0"] },
    { "id": 7, "tasks": ["13.1", "13.2", "13.3", "13.4", "13.5", "13.6"] },
    { "id": 8, "tasks": ["15.0", "16.0", "17.0"] },
    { "id": 9, "tasks": ["15.1", "15.2", "16.1", "17.0"] },
    { "id": 10, "tasks": ["18.0", "19.0", "20.0", "21.0"] },
    { "id": 11, "tasks": ["18.1", "20.1", "21.1"] },
    { "id": 12, "tasks": ["22.0", "23.0"] },
    { "id": 13, "tasks": ["22.1", "23.1"] },
    { "id": 14, "tasks": ["24.0", "24.1", "25.0"] },
    { "id": 15, "tasks": ["26.0", "27.0", "28.0"] },
    { "id": 16, "tasks": ["28.1"] }
  ]
}
```
