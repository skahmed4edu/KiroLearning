# Database Migration Verification Guide

This document provides step-by-step instructions for verifying that the Flyway migrations for the Stock Reservation Feature work correctly on a clean database.

## Prerequisites

- PostgreSQL 12+ installed and running
- Access to PostgreSQL CLI (`psql`)
- Maven installed
- The user-service project built and ready to run

## Verification Steps

### Step 1: Create a Clean Test Database

```bash
# Connect to PostgreSQL as admin
psql -U postgres

# Create test database
CREATE DATABASE user_service_test;

# Exit psql
\q
```

### Step 2: Configure Application for Test Database

Create or update a test profile configuration:

**File**: `src/main/resources/application-test.properties`

```properties
spring.application.name=user-service
spring.datasource.url=jdbc:postgresql://localhost:5432/user_service_test
spring.datasource.username=postgres
spring.datasource.password=Welcome@123
spring.datasource.driver-class-name=org.postgresql.Driver
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
spring.jpa.hibernate.ddl-auto=validate
spring.flyway.enabled=true
spring.flyway.locations=classpath:db/migration
spring.flyway.baseline-on-migrate=true
spring.flyway.baseline-version=0
spring.flyway.validate-on-migrate=true
logging.level.root=INFO
logging.level.com.hexaware=DEBUG
logging.level.org.flywaydb=DEBUG
```

### Step 3: Run Migrations via Application Startup

```bash
# Navigate to project directory
cd c:\Training\user-service

# Build the project
.\mvnw clean package -DskipTests

# Run with test profile to trigger migrations
.\mvnw spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=test"
```

**Expected Output:**
```
...
Flyway is enabled: true
Flyway Version: 11.14.1
Creating schemas: [public]
Current version of schema "public": 0
Migrating schema "public" to version 1 - Create inventory schema
Migrating schema "public" to version 2 - Add inventory test fixtures
Successfully validated 2 migrations (execution time 00:00.234s)
Successfully ran 2 migrations (execution time 00:00.456s)
...
```

### Step 4: Verify Schema Creation

```bash
# Connect to test database
psql -U postgres -d user_service_test

# List all tables (should see products, reservations, etc.)
\dt

# Expected output:
#   public | flyway_schema_history   | table
#   public | products                | table
#   public | reservations            | table
#   public | reservation_history     | table
#   public | stock_audit_log         | table

# List indexes (should see all index_names starting with idx_)
\di

# Verify migration history
SELECT version, description, success, execution_time FROM flyway_schema_history;

# Expected output:
#  version |        description       | success | execution_time
# ---------+--------------------------+---------+----------------
#        1 | Create inventory schema  |    t    |            100
#        2 | Add inventory test f...  |    t    |             50
```

### Step 5: Verify Constraints and Indexes

```bash
# Connect to test database
psql -U postgres -d user_service_test

# Check products table structure
\d products

# Expected output includes:
#   Column           | Type     | Collation | Nullable | Default
#  -----------------+----------+-----------+----------+---------
#   id              | uuid     |           | not null | gen_random_uuid()
#   sku             | character|           | not null |
#   name            | character|           | not null |
#   total_stock     | bigint   |           | not null |
#   reserved_stock  | bigint   |           | not null | 0
#   available_stock | bigint   |           | not null |
#   version         | bigint   |           | not null | 0
#   lock_version    | bigint   |           | not null | 0
#   updated_at      | timestamp|           | not null | CURRENT_TIMESTAMP
#   created_at      | timestamp|           | not null | CURRENT_TIMESTAMP
# Constraints:
#   "products_pkey" PRIMARY KEY, btree (id)
#   "stock_invariant" CHECK (total_stock = available_stock + reserved_stock)
#   plus other CHECK constraints and UNIQUE constraint on sku

# Check constraints on products table
SELECT constraint_name, constraint_type FROM information_schema.table_constraints 
WHERE table_name = 'products';

# Expected constraints:
#   products_pkey                    | PRIMARY KEY
#   products_sku_key                 | UNIQUE
#   stock_invariant                  | CHECK
#   plus other CHECK constraints

# Verify indexes were created
SELECT indexname FROM pg_indexes WHERE tablename = 'products';

# Expected indexes:
#   products_pkey
#   idx_product_sku
#   idx_product_updated_at

# Test stock invariant constraint (should fail)
INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock)
VALUES ('TEST-001', 'Test Product', 100, 50, 40);
# Expected: ERROR: new row for relation "products" violates check constraint

# Test stock invariant constraint (should succeed)
INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock)
VALUES ('TEST-002', 'Test Product', 100, 50, 50);
# Expected: INSERT 0 1

# Clean up test data
DELETE FROM products WHERE sku LIKE 'TEST-%';
```

### Step 6: Verify Foreign Key Relationships

```bash
# Check reservation table structure
\d reservations

# Expected output includes:
#   Foreign-key constraints:
#       "reservations_product_id_fkey" FOREIGN KEY (product_id) 
#       REFERENCES products(id) ON DELETE RESTRICT

# Verify ON DELETE RESTRICT behavior
-- Try to delete a product that has reservations
-- (first create test data)
INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock)
VALUES ('TEST-003', 'Test Product', 100, 50, 50);

INSERT INTO reservations (order_id, product_id, quantity, expiration_time)
VALUES ('123e4567-e89b-12d3-a456-426614174000', 
        (SELECT id FROM products WHERE sku = 'TEST-003'), 
        10, CURRENT_TIMESTAMP + INTERVAL '15 minutes');

-- Try to delete the product (should fail due to FK constraint)
DELETE FROM products WHERE sku = 'TEST-003';
# Expected: ERROR: update or delete on table "products" violates 
#           foreign key constraint on table "reservations"

-- Clean up
DELETE FROM reservations WHERE order_id = '123e4567-e89b-12d3-a456-426614174000';
DELETE FROM products WHERE sku = 'TEST-003';
```

### Step 7: Verify Audit Tables

```bash
# Verify reservation_history table was created
\d reservation_history

# Check CASCADE delete behavior
INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock)
VALUES ('TEST-004', 'Test Product', 100, 50, 50);

INSERT INTO reservations (order_id, product_id, quantity, expiration_time)
VALUES ('223e4567-e89b-12d3-a456-426614174000', 
        (SELECT id FROM products WHERE sku = 'TEST-004'), 
        10, CURRENT_TIMESTAMP + INTERVAL '15 minutes');

INSERT INTO reservation_history 
(reservation_id, order_id, product_id, quantity, old_status, new_status, reason)
SELECT id, order_id, product_id, quantity, NULL, 'ACTIVE', 'Created'
FROM reservations WHERE order_id = '223e4567-e89b-12d3-a456-426614174000';

-- Delete reservation (history should cascade delete)
DELETE FROM reservations WHERE order_id = '223e4567-e89b-12d3-a456-426614174000';

-- Verify history was deleted
SELECT COUNT(*) FROM reservation_history;
# Expected: 0 (or reduced count if other records exist)

-- Clean up products
DELETE FROM products WHERE sku = 'TEST-004';
```

### Step 8: Verify Stock Audit Log

```bash
# Verify stock_audit_log table and indexes
\d stock_audit_log

# Expected indexes:
#   idx_stock_audit_log_product_id
#   idx_stock_audit_log_executed_at

# Test creating an audit log entry
INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock)
VALUES ('TEST-005', 'Test Product', 100, 0, 100);

INSERT INTO stock_audit_log 
(product_id, operation_type, quantity_change, available_stock_before, available_stock_after, request_id)
SELECT id, 'RESERVE', -10, 100, 90, 'req-001'
FROM products WHERE sku = 'TEST-005';

-- Verify the entry was created
SELECT operation_type, quantity_change, available_stock_before, available_stock_after 
FROM stock_audit_log 
WHERE request_id = 'req-001';

# Expected:
#  operation_type | quantity_change | available_stock_before | available_stock_after
#  ---------------+-----------------+------------------------+----------------------
#  RESERVE        |              -10|                      100|                     90

-- Clean up
DELETE FROM stock_audit_log WHERE request_id = 'req-001';
DELETE FROM products WHERE sku = 'TEST-005';
```

### Step 9: Verify Migration Idempotency

Flyway prevents re-running the same migration by tracking applied migrations in `flyway_schema_history`.

```bash
# Check migration history table
SELECT * FROM flyway_schema_history;

# Attempt to re-run the application with migrations
# (should see "schema is up-to-date" message)
.\mvnw spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=test"

# Expected output:
# Flyway is enabled: true
# Migrating schema "public" to version 1 - Create inventory schema
# Schema "public" is up-to-date. No migration necessary.
```

### Step 10: Clean Up Test Database

```bash
# After verification is complete, remove test database
psql -U postgres -c "DROP DATABASE user_service_test;"
```

## Migration Syntax Validation

The migration file `V1__Create_inventory_schema.sql` uses standard PostgreSQL DDL syntax:

### Syntax Highlights

1. **UUID Support**
   ```sql
   id UUID PRIMARY KEY DEFAULT gen_random_uuid()
   ```
   - Uses PostgreSQL's built-in UUID generation

2. **CHECK Constraints**
   ```sql
   CONSTRAINT stock_invariant CHECK (total_stock = available_stock + reserved_stock)
   ```
   - Database-enforced stock invariant

3. **Foreign Keys with ON DELETE**
   ```sql
   FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
   ```
   - Prevents accidental orphaning of reservations

4. **Indexes for Performance**
   ```sql
   CREATE INDEX idx_product_sku ON products(sku);
   ```
   - Supports O(log n) lookups and prevents deadlocks

## Troubleshooting

### Migration Fails with "Already Applied"

If you get an error that a migration is already applied:
```
Current version of schema "public": 2
This version is already applied by a previous migration
```

Solution: Either keep the database state or manually reset:
```bash
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;
```

### Lock Timeout Errors During Testing

If you get lock timeout errors when running manual tests:
```
ERROR: canceling statement due to lock timeout
```

Solution: Ensure previous transactions are committed:
```bash
psql -U postgres -d user_service_test -c "SELECT * FROM pg_stat_activity;"
```

### Constraint Violation When Inserting Test Data

If CHECK constraints fail when inserting test data:

Make sure the stock invariant is satisfied:
```sql
-- WRONG: total_stock (100) != available_stock (50) + reserved_stock (40)
INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock)
VALUES ('TEST', 'Test', 100, 50, 40);  -- FAILS

-- CORRECT: total_stock (100) = available_stock (50) + reserved_stock (50)
INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock)
VALUES ('TEST', 'Test', 100, 50, 50);  -- SUCCEEDS
```

## Performance Verification

To verify performance characteristics:

```bash
# Check index usage
EXPLAIN ANALYZE
SELECT * FROM products WHERE sku = 'PROD-001';

# Expected: Index Scan on idx_product_sku

# Check query performance for reservations by order ID
EXPLAIN ANALYZE
SELECT * FROM reservations WHERE order_id = '123e4567-e89b-12d3-a456-426614174000';

# Expected: Index Scan on idx_reservation_order_id
```

## Summary

After completing all steps:

✅ All tables created with correct schema
✅ All constraints enforced at database level
✅ All indexes created for performance
✅ Foreign key relationships enforced
✅ Audit tables capturing changes
✅ Migrations are version-controlled and immutable
✅ Migrations can be re-applied without errors

The database schema is now ready for the Inventory Management Service implementation.
