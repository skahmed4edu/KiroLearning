# User Registration API

## Overview

This document describes the User Registration feature implemented for the User Service application.

## Features

- **User Registration Endpoint**: `POST /api/v1/users/register`
- **Password Security**: BCrypt hashing using Spring Security
- **Email Validation**: Validates email format and uniqueness
- **Input Validation**: Field-level validation with detailed error messages
- **Error Handling**: Comprehensive exception handling with appropriate HTTP status codes

## Project Structure

```
src/main/java/com/hexaware/
├── config/
│   └── SecurityConfig.java          # BCryptPasswordEncoder bean configuration
├── controller/
│   └── UserController.java          # REST controller with /register endpoint
├── dto/
│   ├── RegisterUserRequest.java     # Request DTO with validation annotations
│   └── RegisterUserResponse.java    # Response DTO with user details
├── entity/
│   └── User.java                    # JPA entity with timestamps
├── exception/
│   ├── EmailAlreadyExistsException.java  # Custom exception for duplicate email
│   ├── ErrorResponse.java           # Error response DTO
│   └── GlobalExceptionHandler.java  # Central exception handler
├── repository/
│   └── UserRepository.java          # JPA repository with email queries
└── service/
    └── UserService.java             # Business logic for registration
```

## Endpoint Specification

### POST /api/v1/users/register

**Description**: Register a new user

**Request Body**:
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "password": "SecurePass123"
}
```

**Request Validation**:
- `firstName`: Required, 1-100 characters
- `lastName`: Required, 1-100 characters
- `email`: Required, valid email format, unique in database
- `password`: Required, minimum 8 characters

**Successful Response (201 Created)**:
```json
{
  "id": 1,
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "createdAt": "2026-10-03T15:22:22"
}
```

**Validation Error (400 Bad Request)**:
```json
{
  "timestamp": "2026-10-03T15:22:22",
  "status": 400,
  "message": "Validation failed",
  "errors": {
    "email": "Email should be valid",
    "password": "Password must be at least 8 characters"
  }
}
```

**Email Already Exists (409 Conflict)**:
```json
{
  "timestamp": "2026-10-03T15:22:22",
  "status": 409,
  "message": "Email already exists: john.doe@example.com"
}
```

## Database Configuration

The application uses PostgreSQL. Configure in `application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/user_service_db
spring.datasource.username=postgres
spring.datasource.password=postgres
```

The `users` table is created automatically via Hibernate (ddl-auto=update).

### Users Table Schema

```sql
CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP,
  CONSTRAINT uk_users_email UNIQUE(email)
);
```

## Security Features

1. **Password Hashing**: All passwords are hashed using BCrypt before storage
2. **Email Uniqueness**: Database-level constraint enforces unique emails
3. **Input Validation**: All inputs validated before processing
4. **Error Information**: Sensitive information (passwords) never returned in responses

## Testing the Endpoint

### Using cURL

**Success Case**:
```bash
curl -X POST http://localhost:8080/api/v1/users/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@example.com",
    "password": "SecurePass123"
  }'
```

**Validation Error**:
```bash
curl -X POST http://localhost:8080/api/v1/users/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "invalid-email",
    "password": "short"
  }'
```

**Duplicate Email**:
```bash
# Second request with same email as first
curl -X POST http://localhost:8080/api/v1/users/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Jane",
    "lastName": "Smith",
    "email": "john.doe@example.com",
    "password": "AnotherPass123"
  }'
```

### Using Postman

1. Set request method to `POST`
2. URL: `http://localhost:8080/api/v1/users/register`
3. Headers: `Content-Type: application/json`
4. Body (JSON):
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "password": "SecurePass123"
}
```

## Building and Running

### Build
```bash
./mvnw clean install
```

### Run
```bash
./mvnw spring-boot:run
```

The application will start on `http://localhost:8080`

## Dependencies

Key dependencies used:
- `spring-boot-starter-data-jpa`: JPA/Hibernate ORM
- `spring-boot-starter-security`: BCrypt password encoding
- `spring-boot-starter-validation`: Bean validation (JSR-303)
- `spring-boot-starter-webmvc`: REST controller support
- `postgresql`: PostgreSQL JDBC driver
- `lombok`: Reduce boilerplate code
