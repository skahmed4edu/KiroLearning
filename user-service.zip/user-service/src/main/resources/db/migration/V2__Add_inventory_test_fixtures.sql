-- Test Fixtures for Stock Reservation Feature
-- This migration adds sample test data for development and testing
-- These fixtures demonstrate the schema and validate constraints

INSERT INTO products (sku, name, total_stock, reserved_stock, available_stock, created_at, updated_at)
VALUES 
    ('PROD-001', 'Widget A', 100, 0, 100, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('PROD-002', 'Widget B', 50, 0, 50, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('PROD-003', 'Gadget X', 25, 0, 25, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (sku) DO NOTHING;
