-- Add remark column to products table
-- ============================================================================
-- Adds a mandatory free-text remark/notes field to each product.
--
-- Why a DEFAULT is required:
--   The products table is already populated (see V2 test fixtures and any
--   production rows). Adding a NOT NULL column with no default would fail,
--   because PostgreSQL cannot populate the new column for existing rows.
--   We add the column WITH a default empty string so existing rows are
--   backfilled atomically and the NOT NULL constraint holds immediately.
--
-- Note on the default:
--   The column-level DEFAULT ('') is kept so future inserts that omit the
--   column still satisfy NOT NULL. If the application should always supply a
--   remark explicitly, drop the default in a later migration once all writers
--   provide a value.
-- ============================================================================
ALTER TABLE products
    ADD COLUMN IF NOT EXISTS remark VARCHAR(500) NOT NULL DEFAULT '';
