-- Stock Reservation Feature - Initial Database Schema
-- This migration creates the core inventory management tables
-- with all constraints, indexes, and row-level locking support

-- ============================================================================
-- Products Table
-- ============================================================================
-- Stores product definitions and current stock levels
-- Constraints:
--   - totalStock > 0 (at least 1 unit must be defined)
--   - availableStock >= 0 (cannot go negative)
--   - reservedStock >= 0 (cannot go negative)
--   - totalStock = availableStock + reservedStock (INVARIANT)
-- Indexes support:
--   - SKU-based lookups for product queries
--   - Updated_at for timestamp-based ordering and expiration logic
-- Version field for optimistic locking at application level
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    total_stock BIGINT NOT NULL CHECK (total_stock > 0),
    reserved_stock BIGINT NOT NULL DEFAULT 0 CHECK (reserved_stock >= 0),
    available_stock BIGINT NOT NULL CHECK (available_stock >= 0),
    version BIGINT NOT NULL DEFAULT 0,
    lock_version BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stock_invariant CHECK (total_stock = available_stock + reserved_stock)
);

-- Indexes for query performance and row-level locking
CREATE INDEX idx_product_sku ON products(sku);
CREATE INDEX idx_product_updated_at ON products(updated_at);

-- ============================================================================
-- Reservations Table
-- ============================================================================
-- Stores reservation records linked to orders
-- Statuses: ACTIVE (stock reserved), RELEASED (manually released), 
--           EXPIRED (TTL exceeded), CANCELLED (reserved for future use)
-- Row-level locking with FOR UPDATE NOWAIT pattern
-- Indexes support:
--   - order_id: direct lookup by order for release operations
--   - product_id: find all reservations for a product
--   - status: filter for expiration checks and analytics
--   - expiration_time: for batch expiration queries
--   - idempotency_key: detect duplicate reservation requests
CREATE TABLE reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    quantity BIGINT NOT NULL CHECK (quantity > 0),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    expiration_time TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    released_at TIMESTAMP,
    expired_at TIMESTAMP,
    idempotency_key VARCHAR(100),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
);

CREATE INDEX idx_reservation_order_id ON reservations(order_id);
CREATE INDEX idx_reservation_product_id ON reservations(product_id);
CREATE INDEX idx_reservation_status ON reservations(status);
CREATE INDEX idx_reservation_expiration_time ON reservations(expiration_time);
CREATE INDEX idx_reservation_created_at ON reservations(created_at);
CREATE INDEX idx_reservation_idempotency_key ON reservations(idempotency_key);

-- ============================================================================
-- Reservation History Table (Audit Log)
-- ============================================================================
-- Tracks all status changes to reservations for compliance and debugging
-- Stores the state transition (old_status → new_status) with reason
-- ON DELETE CASCADE to clean up history when reservations are removed
CREATE TABLE reservation_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reservation_id UUID NOT NULL,
    order_id UUID NOT NULL,
    product_id UUID NOT NULL,
    quantity BIGINT NOT NULL,
    old_status VARCHAR(20),
    new_status VARCHAR(20) NOT NULL,
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reason VARCHAR(255),
    FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
);

CREATE INDEX idx_reservation_history_reservation_id ON reservation_history(reservation_id);
CREATE INDEX idx_reservation_history_changed_at ON reservation_history(changed_at);

-- ============================================================================
-- Stock Audit Log Table
-- ============================================================================
-- Tracks all stock operations (RESERVE, RELEASE, BULK_UPDATE, etc.)
-- Records before/after stock levels for complete audit trail
-- Enables reconciliation and debugging of stock discrepancies
-- Indexes for querying by product and timestamp for analytics
CREATE TABLE stock_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    operation_type VARCHAR(50) NOT NULL,
    quantity_change BIGINT NOT NULL,
    available_stock_before BIGINT NOT NULL,
    available_stock_after BIGINT NOT NULL,
    executed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    request_id VARCHAR(100),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE INDEX idx_stock_audit_log_product_id ON stock_audit_log(product_id);
CREATE INDEX idx_stock_audit_log_executed_at ON stock_audit_log(executed_at);
