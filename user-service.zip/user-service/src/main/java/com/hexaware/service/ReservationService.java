package com.hexaware.service;

import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.dto.ReservationErrorResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.JpaOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.LockTimeoutException;
import jakarta.persistence.PessimisticLockException;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

/**
 * Service for managing stock reservations with atomic operations.
 * 
 * DESIGN OVERVIEW:
 * ================
 * This service implements atomic reservation creation that prevents overselling
 * through pessimistic locking, optimistic locking with retry, and comprehensive
 * validation. Supports idempotent operations via idempotency keys.
 * 
 * KEY RESPONSIBILITIES:
 * 1. Atomic reservation creation with pessimistic locking
 *    - Acquire exclusive lock on Product row (SELECT...FOR UPDATE NOWAIT)
 *    - Validate available stock >= requested quantity
 *    - Create reservation record with ACTIVE status
 *    - Update product stock atomically
 *    - Log audit trail
 * 
 * 2. Idempotency support via idempotency key
 *    - Check if reservation already exists for same idempotency key
 *    - If exists and ACTIVE: return same reservation (idempotent)
 *    - If exists and not ACTIVE: return error
 *    - Prevents duplicate reservations on network retries
 * 
 * 3. Comprehensive error handling
 *    - Lock timeout (503 Service Unavailable): client should retry
 *    - Insufficient stock (409 Conflict): return available stock for retry logic
 *    - Version conflicts (optimistic locking): retry with exponential backoff
 *    - Validation errors (400 Bad Request): client input is invalid
 * 
 * 4. Expiration time management
 *    - Calculate expiration time as: now + RESERVATION_TTL_MINUTES
 *    - Store in reservation record for background expiration job
 *    - Configurable TTL via environment variable
 * 
 * 5. Comprehensive logging with correlation IDs
 *    - Log all operations with request context
 *    - Use correlation ID (X-Request-ID) for distributed tracing
 *    - Track performance metrics
 * 
 * ALGORITHM:
 * ==========
 * createReservation(CreateReservationRequest) → ReservationResponse or error
 * 
 * BEGIN TRANSACTION (ISOLATION LEVEL: READ_COMMITTED)
 * 
 *   STEP 1: Check for idempotent retry (duplicate detection)
 *   - IF idempotencyKey provided:
 *       - Query: SELECT FROM reservations WHERE idempotency_key = key AND order_id = orderId
 *       - Lock: FOR UPDATE NOWAIT
 *       - IF found:
 *           - IF status == ACTIVE: COMMIT and RETURN reservation (idempotent success)
 *           - IF status == RELEASED: COMMIT and RETURN error (already processed)
 *           - ELSE: COMMIT and RETURN error (invalid state)
 * 
 *   STEP 2: Acquire exclusive lock on Product row
 *   - Query: SELECT * FROM products WHERE id = productId
 *   - Lock: FOR UPDATE NOWAIT
 *   - Exception handling:
 *       - IF LockAcquisitionFailedException: ROLLBACK and RETURN HTTP 503 LOCK_TIMEOUT
 *       - IF PessimisticLockException: ROLLBACK and RETURN HTTP 503 LOCK_TIMEOUT
 * 
 *   STEP 3: Validate available stock >= requested quantity
 *   - IF product.availableStock < quantity:
 *       - ROLLBACK
 *       - RETURN HTTP 409 INSUFFICIENT_STOCK with available stock details
 * 
 *   STEP 4: Create reservation record
 *   - now = NOW()
 *   - expirationTime = now + RESERVATION_TTL_MINUTES
 *   - reservation = new Reservation(
 *       id: generate UUID,
 *       orderId: request.orderId,
 *       product: product,
 *       quantity: request.quantity,
 *       status: ACTIVE,
 *       expirationTime: expirationTime,
 *       createdAt: now,
 *       idempotencyKey: request.idempotencyKey
 *     )
 *   - reservationRepository.save(reservation)
 * 
 *   STEP 5: Update product stock (decrement available, increment reserved)
 *   - product.availableStock -= quantity
 *   - product.reservedStock += quantity
 *   - product.version += 1 (automatic via @Version)
 *   - product.updatedAt = now
 *   - productRepository.save(product)
 *   - Exception handling:
 *       - IF OptimisticLockingFailureException: ROLLBACK and RETRY with backoff
 * 
 *   STEP 6: Log to stock_audit_log
 *   - INSERT INTO stock_audit_log (
 *       productId: product.id,
 *       operationType: RESERVE,
 *       quantityChange: -quantity,
 *       availableStockBefore: product.availableStock + quantity,
 *       availableStockAfter: product.availableStock,
 *       executedAt: now,
 *       requestId: correlationId
 *     )
 * 
 *   COMMIT TRANSACTION
 *   RETURN HTTP 201 CREATED with ReservationResponse
 * 
 * RETRY LOGIC:
 * ============
 * IF OptimisticLockingFailureException occurs:
 *   - Attempt retry (max 3 times)
 *   - Exponential backoff:
 *       - Retry 1: Wait 100ms + random(0-50ms)
 *       - Retry 2: Wait 200ms + random(0-100ms)
 *       - Retry 3: Wait 400ms + random(0-200ms)
 *   - IF all retries exhausted: RETURN HTTP 409 CONCURRENT_MODIFICATION
 * 
 * CONCURRENCY SAFETY:
 * ===================
 * - Pessimistic locking (FOR UPDATE NOWAIT) prevents concurrent modifications
 * - No two transactions can modify same product simultaneously
 * - Optimistic locking detects version conflicts and retries
 * - Stock invariant maintained: totalStock = availableStock + reservedStock
 * - Available stock never goes negative due to validation
 * 
 * ISOLATION LEVEL:
 * ================
 * - READ_COMMITTED: Prevents dirty reads, allows non-repeatable reads
 * - Sufficient for our needs with explicit row-level locking
 * - Better performance than SERIALIZABLE
 * 
 * IDEMPOTENCY:
 * ============
 * - Idempotency key uniquely identifies a reservation attempt
 * - If same request retried with same key: returns existing reservation
 * - Prevents duplicate reservations on network retries or client retry logic
 * - Requires: orderId + idempotencyKey to be unique (database constraint)
 * 
 * REQUIREMENTS:
 * - 2.1: Create reservation with ACTIVE status
 * - 2.2: Return HTTP 409 INSUFFICIENT_STOCK if not enough stock
 * - 2.3: Decrement available stock by reserved quantity
 * - 2.4: Set expiration time to now + TTL_MINUTES
 * - 2.5: Assign unique reservation ID
 * - 2.6: Return reservation ID, creation timestamp, expiration timestamp
 * - 2.7: Link reservation to order ID
 * - 6.1: Acquire exclusive lock on product
 * - 6.2: Re-check available stock before confirming (done after lock)
 * - 6.5: Use database transactions for atomicity
 * 
 * @author Inventory Service Team
 * @version 1.0
 */
@Service
@Transactional(isolation = Isolation.READ_COMMITTED)
@RequiredArgsConstructor
@Slf4j
public class ReservationService {

    private final ProductRepository productRepository;
    private final ReservationRepository reservationRepository;
    private final StockAuditLogRepository stockAuditLogRepository;

    @Value("${inventory.reservation.ttl-minutes:15}")
    private Integer reservationTtlMinutes;

    @Value("${inventory.lock-timeout-seconds:30}")
    private Integer lockTimeoutSeconds;

    @Value("${inventory.max-retries:3}")
    private Integer maxRetries;

    /**
     * Creates a stock reservation for an order using atomic, oversell-safe operations.
     *
     * <p>The reservation is created inside a {@code READ_COMMITTED} transaction that
     * acquires a pessimistic row lock on the product, validates that available stock
     * covers the requested quantity, persists an {@code ACTIVE} reservation with an
     * expiration time, decrements available stock, increments reserved stock, and
     * writes a stock audit-log entry. When an idempotency key is supplied, a prior
     * matching reservation is reused instead of creating a duplicate. On an
     * optimistic locking conflict the operation is retried with exponential backoff
     * up to the configured {@code maxRetries} before failing.
     *
     * @param request the reservation request carrying orderId, productId, quantity,
     *                and an optional idempotencyKey and correlationId
     * @return a {@link ReservationResponse} describing the created (or, on an
     *         idempotent retry, the existing {@code ACTIVE}) reservation, including
     *         the reservation id, timestamps, expiration time, and remaining
     *         available stock
     * @throws LockTimeoutException if the product row lock cannot be acquired
     *         (intended to map to HTTP 503 Service Unavailable)
     * @throws PessimisticLockException if the product row lock cannot be acquired
     *         (intended to map to HTTP 503 Service Unavailable)
     * @throws jakarta.persistence.EntityNotFoundException if the product does not
     *         exist (intended to map to HTTP 404 Not Found)
     * @throws RuntimeException with message {@code "INSUFFICIENT_STOCK"} when the
     *         available stock is less than the requested quantity (intended to map
     *         to HTTP 409 Conflict); with an "already processed" message when an
     *         idempotent retry matches a non-{@code ACTIVE} reservation; or when the
     *         optimistic locking retries are exhausted after {@code maxRetries}
     *         attempts
     */
    public ReservationResponse createReservation(CreateReservationRequest request) {
        String correlationId = request.getCorrelationId() != null ? 
                request.getCorrelationId() : UUID.randomUUID().toString();
        
        log.info("Starting reservation creation: orderId={}, productId={}, quantity={}, correlationId={}",
                request.getOrderId(), request.getProductId(), request.getQuantity(), correlationId);

        return retryWithExponentialBackoff(request, correlationId, 0);
    }

    /**
     * Internal method for reservation creation with retry logic.
     * Retries up to 3 times with exponential backoff on OptimisticLockingFailureException.
     * 
     * @param request CreateReservationRequest
     * @param correlationId correlation ID for tracing
     * @param retryAttempt current retry attempt (0-based)
     * @return ReservationResponse
     */
    private ReservationResponse retryWithExponentialBackoff(
            CreateReservationRequest request,
            String correlationId,
            int retryAttempt) {
        
        try {
            return executeReservationCreation(request, correlationId);
        } catch (JpaOptimisticLockingFailureException e) {
            if (retryAttempt < maxRetries) {
                long backoffMs = calculateExponentialBackoff(retryAttempt);
                log.warn("Optimistic lock conflict, retrying after {}ms (attempt {}/{}): orderId={}, productId={}",
                        backoffMs, retryAttempt + 1, maxRetries, request.getOrderId(), request.getProductId());
                
                try {
                    Thread.sleep(backoffMs);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    log.error("Retry sleep interrupted for orderId={}: {}", request.getOrderId(), ie.getMessage());
                    throw new RuntimeException("Reservation creation interrupted", ie);
                }
                
                return retryWithExponentialBackoff(request, correlationId, retryAttempt + 1);
            } else {
                log.error("Max retries ({}) exhausted for reservation: orderId={}, productId={}, correlationId={}",
                        maxRetries, request.getOrderId(), request.getProductId(), correlationId);
                throw new RuntimeException("Concurrent modification - max retries exhausted", e);
            }
        }
    }

    /**
     * Calculates exponential backoff time in milliseconds.
     * Retry 1: 100ms + random(0-50ms)
     * Retry 2: 200ms + random(0-100ms)
     * Retry 3: 400ms + random(0-200ms)
     * 
     * @param retryAttempt attempt number (0-based)
     * @return milliseconds to wait
     */
    private long calculateExponentialBackoff(int retryAttempt) {
        long baseMs = 100L * (1L << retryAttempt); // 100, 200, 400
        long randomRange = baseMs / 2; // 50, 100, 200
        return baseMs + (long) (Math.random() * randomRange);
    }

    /**
     * Executes the actual reservation creation logic.
     * This is the core algorithm that:
     * 1. Checks idempotency key
     * 2. Acquires pessimistic lock on product
     * 3. Validates stock
     * 4. Creates reservation
     * 5. Updates product
     * 6. Logs audit trail
     * 
     * @param request CreateReservationRequest
     * @param correlationId correlation ID for logging
     * @return ReservationResponse
     * @throws LockTimeoutException if cannot acquire lock
     * @throws jakarta.persistence.EntityNotFoundException if product not found
     * @throws RuntimeException for insufficient stock
     */
    private ReservationResponse executeReservationCreation(
            CreateReservationRequest request,
            String correlationId) {
        
        UUID orderId = request.getOrderId();
        UUID productId = request.getProductId();
        Long quantity = request.getQuantity();
        String idempotencyKey = request.getIdempotencyKey();

        log.debug("STEP 1: Checking for idempotent retry: orderId={}, idempotencyKey={}",
                orderId, idempotencyKey);

        // STEP 1: Check for idempotent retry (duplicate detection)
        if (idempotencyKey != null) {
            Optional<Reservation> existingReservation = 
                    reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId);
            
            if (existingReservation.isPresent()) {
                Reservation reservation = existingReservation.get();
                log.info("Idempotent retry detected: reservationId={}, status={}, orderId={}",
                        reservation.getId(), reservation.getStatus(), orderId);
                
                if (reservation.getStatus() == ReservationStatus.ACTIVE) {
                    // Idempotent success: return existing reservation
                    return buildReservationResponse(reservation, quantity);
                } else {
                    // Reservation already processed/released/expired
                    log.warn("Idempotent retry for already-processed reservation: reservationId={}, status={}, orderId={}",
                            reservation.getId(), reservation.getStatus(), orderId);
                    throw new RuntimeException("Reservation already processed with status: " + reservation.getStatus());
                }
            }
        }

        log.debug("STEP 2: Acquiring pessimistic lock on product: productId={}", productId);

        // STEP 2: Acquire exclusive lock on Product row (FOR UPDATE NOWAIT)
        Product product;
        try {
            product = productRepository.findByIdWithLock(productId)
                    .orElseThrow(() -> new jakarta.persistence.EntityNotFoundException(
                            String.format("Product not found: %s", productId)
                    ));
            log.debug("Pessimistic lock acquired on product: productId={}, availableStock={}",
                    productId, product.getAvailableStock());
        } catch (LockTimeoutException | PessimisticLockException e) {
            log.warn("Lock timeout acquiring product lock: productId={}, correlationId={}, error={}",
                    productId, correlationId, e.getMessage());
            throw e;
        }

        log.debug("STEP 3: Validating available stock: productId={}, availableStock={}, requested={}",
                productId, product.getAvailableStock(), quantity);

        // STEP 3: Validate available stock >= requested quantity
        if (product.getAvailableStock() < quantity) {
            log.warn("Insufficient stock: productId={}, available={}, requested={}, orderId={}",
                    productId, product.getAvailableStock(), quantity, orderId);
            throw new RuntimeException("INSUFFICIENT_STOCK");
        }

        log.debug("STEP 4: Creating reservation record: orderId={}, productId={}, quantity={}",
                orderId, productId, quantity);

        // STEP 4: Create reservation record with ACTIVE status and expiration time
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expirationTime = now.plusMinutes(reservationTtlMinutes);

        Reservation reservation = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(expirationTime)
                .createdAt(now)
                .idempotencyKey(idempotencyKey)
                .build();

        reservation = reservationRepository.save(reservation);
        log.debug("Reservation created: reservationId={}, expirationTime={}", reservation.getId(), expirationTime);

        log.debug("STEP 5: Updating product stock: productId={}, quantity={}", productId, quantity);

        // STEP 5: Update product: decrement availableStock, increment reservedStock
        Long availableStockBefore = product.getAvailableStock();
        product.setAvailableStock(product.getAvailableStock() - quantity);
        product.setReservedStock(product.getReservedStock() + quantity);
        product.setUpdatedAt(now);

        // Version field automatically incremented by @Version annotation
        productRepository.save(product);
        log.debug("Product stock updated: productId={}, availableStock: {} -> {}, reservedStock: {} -> {}",
                productId, availableStockBefore, product.getAvailableStock(),
                availableStockBefore == null ? quantity : product.getReservedStock() - quantity,
                product.getReservedStock());

        log.debug("STEP 6: Logging to stock_audit_log: productId={}, operation=RESERVE, quantity={}",
                productId, quantity);

        // STEP 6: Log to stock_audit_log
        StockAuditLog auditLog = StockAuditLog.builder()
                .product(product)
                .operationType(StockOperationType.RESERVE)
                .quantityChange(-quantity)
                .availableStockBefore(availableStockBefore)
                .availableStockAfter(product.getAvailableStock())
                .executedAt(now)
                .requestId(correlationId)
                .build();

        stockAuditLogRepository.save(auditLog);
        log.debug("Stock audit log entry created: auditLogId={}, productId={}", auditLog.getId(), productId);

        log.info("Reservation successfully created: reservationId={}, orderId={}, productId={}, quantity={}, correlationId={}",
                reservation.getId(), orderId, productId, quantity, correlationId);

        // Build and return response
        return buildReservationResponse(reservation, quantity);
    }

    /**
     * Builds ReservationResponse from Reservation entity.
     * 
     * @param reservation Reservation entity
     * @param quantity reserved quantity
     * @return ReservationResponse DTO
     */
    private ReservationResponse buildReservationResponse(Reservation reservation, Long quantity) {
        return ReservationResponse.builder()
                .reservationId(reservation.getId())
                .orderId(reservation.getOrderId())
                .productId(reservation.getProduct().getId())
                .quantity(quantity)
                .status(reservation.getStatus().name())
                .createdAt(reservation.getCreatedAt())
                .expirationTime(reservation.getExpirationTime())
                .availableStock(reservation.getProduct().getAvailableStock())
                .build();
    }
}
