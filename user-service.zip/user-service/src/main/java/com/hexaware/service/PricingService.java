package com.hexaware.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service for calculating pricing and discounts for orders.
 */
@Service
@Slf4j
public class PricingService {

    private static final int DISCOUNT_QUANTITY_THRESHOLD = 10;
    private static final double DISCOUNT_RATE = 0.10;

    /**
     * Calculate the price after applying a quantity-based discount.
     * A 10% discount is applied when the quantity is greater than 10;
     * otherwise the full price is returned.
     *
     * @param price    the unit or base price before discount
     * @param quantity the quantity being ordered
     * @return the price after any applicable discount
     */
    public double calculateDiscount(double price, int quantity) {
        log.debug("Calculating discount for price: {}, quantity: {}", price, quantity);

        if (quantity > DISCOUNT_QUANTITY_THRESHOLD) {
            double discountedPrice = price * (1 - DISCOUNT_RATE);
            log.debug("Applied {}% discount. Original: {}, Discounted: {}",
                    DISCOUNT_RATE * 100, price, discountedPrice);
            return discountedPrice;
        }

        log.debug("No discount applied for quantity: {}", quantity);
        return price;
    }
}
