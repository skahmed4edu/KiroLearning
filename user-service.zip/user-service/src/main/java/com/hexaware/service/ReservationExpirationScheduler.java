package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationHistory;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationHistoryRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.LockTimeoutException;
import jakarta.persistence.PessimisticLockException;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * Background scheduler that expires {@code ACTIVE} reservations whose TTL has elapsed and
 * restores the held stock back to availability.
 *
 * <p>DESIGN OVERVIEW:
 * <p>This component mirrors the concurrency and auditing patterns of {@link ReservationService}
 * and {@link ReservationReleaseService}: a {@code READ_COMMITTED} transaction per product, a
 * pessimistic row lock on the product, delegation of the stock mutation to
 * {@link Product#releaseStock(Long)}, a reservation state transition via
 * {@link Reservation#expire(LocalDateTime)}, and a full audit trail written to both
 * {@code reservation_history} (one record per reservation) and {@code stock_audit_log}
 * (one EXPIRE record per product carrying the total restored quantity).
 *
 * <p>ALGORITHM ({@link #processExpiredReservations()}):
 * <pre>
 * STEP 1: Query up to {@code batchLimit} ACTIVE reservations with expirationTime &lt;= now().
 *         If none, log and return (no-op).
 * STEP 2: Group the expired reservations by product id (preserving encounter order).
 * STEP 3: For each product, in its own transaction:
 *           a. Acquire a pessimistic write lock on the product.
 *              - On lock-acquisition failure: log a warning, skip the product, continue.
 *           b. For each reservation of that product that is still ACTIVE (idempotence:
 *              already-EXPIRED reservations are skipped and never double-restore stock):
 *                - restore stock via product.releaseStock(quantity)
 *                - transition reservation ACTIVE -&gt; EXPIRED
 *                - write a reservation_history record (ACTIVE -&gt; EXPIRED)
 *           c. Write a single stock_audit_log EXPIRE record for the product with the
 *              total restored quantity (skipped when nothing was restored).
 * STEP 4: Log batch statistics (reservations expired, products affected, duration).
 * </pre>
 *
 * <p>IDEMPOTENCE: A reservation already in {@code EXPIRED} state is skipped, so re-running the
 * job (or racing with a release) never restores stock twice.
 *
 * <p>FAULT ISOLATION: Each product is processed in an independent transaction; a lock timeout
 * (or error) on one product does not prevent the remaining products from being processed.
 *
 * <p>Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.8, 8.1, 8.3
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ReservationExpirationScheduler {

    private final ProductRepository productRepository;
    private final ReservationRepository reservationRepository;
    private final ReservationHistoryRepository reservationHistoryRepository;
    private final StockAuditLogRepository stockAuditLogRepository;

    /**
     * Maximum number of expired reservations processed per scheduler cycle.
     * Default 1000 (INVENTORY_BULK_UPDATE_MAX_SIZE / batch limit).
     */
    @Value("${inventory.expiration.batch-size:1000}")
    private int batchLimit;

    /**
     * Fixed delay between scheduler cycles, in seconds. Mirrors the value used by
     * {@link #scheduledExpirationCheck()} (INVENTORY_EXPIRATION_CHECK_INTERVAL_SECONDS,
     * default 60). Used only to compute the estimated next execution time surfaced by the
     * health indicator; it does not drive the scheduling itself.
     */
    @Value("${inventory.expiration.check-interval-seconds:60}")
    private long checkIntervalSeconds;

    // --- Execution state tracking (observability; consumed by the health indicator) ---

    /** Timestamp at which the most recent cycle completed successfully; {@code null} until the first success. */
    private final AtomicReference<LocalDateTime> lastSuccessfulExecutionTime = new AtomicReference<>();

    /** Timestamp at which the most recent cycle completed, regardless of outcome; {@code null} until the first run. */
    private final AtomicReference<LocalDateTime> lastExecutionTime = new AtomicReference<>();

    /** Count of cycles that completed without throwing. */
    private final AtomicLong successCount = new AtomicLong();

    /** Count of cycles that terminated with an unhandled error. */
    private final AtomicLong errorCount = new AtomicLong();

    /** Reservations expired during the most recent cycle. */
    private final AtomicLong lastBatchExpiredCount = new AtomicLong();

    /** Distinct products affected during the most recent cycle. */
    private final AtomicLong lastBatchProductsAffected = new AtomicLong();

    /** Wall-clock duration of the most recent cycle, in milliseconds. */
    private final AtomicLong lastBatchDurationMs = new AtomicLong();

    /**
     * Scheduled entry point. Runs on a fixed delay configured by
     * {@code INVENTORY_EXPIRATION_CHECK_INTERVAL_SECONDS} (default 60 seconds).
     *
     * <p>Delegates to {@link #processExpiredReservations()} so the processing logic can be
     * exercised directly in unit tests without the scheduling infrastructure.
     */
    @Scheduled(fixedDelayString = "${inventory.expiration.check-interval-seconds:60}000")
    public void scheduledExpirationCheck() {
        processExpiredReservations();
    }

    /**
     * Processes expired reservations: marks them EXPIRED and restores their stock.
     *
     * <p>Each product is handled in its own {@code READ_COMMITTED} transaction so that a
     * failure on one product does not roll back or block the others.
     *
     * @return the number of reservations successfully transitioned to EXPIRED
     */
    public int processExpiredReservations() {
        long startNanos = System.nanoTime();
        LocalDateTime now = LocalDateTime.now();

        int totalExpired = 0;
        int productsAffected = 0;
        try {
            // STEP 1: Query a bounded batch of expired ACTIVE reservations.
            List<Reservation> expired = reservationRepository.findExpiredReservations(now).stream()
                    .limit(batchLimit)
                    .collect(Collectors.toList());

            if (expired.isEmpty()) {
                log.debug("No expired reservations to process");
                recordSuccessfulCycle(0, 0, startNanos);
                return 0;
            }

            // STEP 2: Group by product id, preserving encounter order for deterministic processing.
            Map<UUID, List<Reservation>> groupedByProduct = expired.stream()
                    .collect(Collectors.groupingBy(
                            r -> r.getProduct().getId(),
                            LinkedHashMap::new,
                            Collectors.toList()));

            log.info("Starting expiration cycle: {} reservations across {} products",
                    expired.size(), groupedByProduct.size());

            // STEP 3: Process each product independently.
            for (Map.Entry<UUID, List<Reservation>> entry : groupedByProduct.entrySet()) {
                int expiredForProduct = expireProductReservations(entry.getKey(), entry.getValue());
                if (expiredForProduct > 0) {
                    productsAffected++;
                    totalExpired += expiredForProduct;
                }
            }

            // STEP 4: Record and emit batch statistics.
            recordSuccessfulCycle(totalExpired, productsAffected, startNanos);
            log.info("Completed expiration cycle: expired={}, productsAffected={}, durationMs={}",
                    totalExpired, productsAffected, lastBatchDurationMs.get());

            return totalExpired;
        } catch (RuntimeException e) {
            // A failure of the whole cycle (not an individual product skip) is tracked so the
            // health indicator can surface a degraded success rate.
            recordFailedCycle(startNanos);
            log.error("Expiration cycle failed after expiring {} reservations across {} products",
                    totalExpired, productsAffected, e);
            throw e;
        }
    }

    /**
     * Records a successfully completed cycle: updates last-execution/last-successful-execution
     * timestamps, the success counter, and the most recent batch statistics.
     *
     * @param expiredCount     reservations transitioned to EXPIRED in this cycle
     * @param productsAffected distinct products whose stock was restored in this cycle
     * @param startNanos       {@link System#nanoTime()} captured at the start of the cycle
     */
    private void recordSuccessfulCycle(int expiredCount, int productsAffected, long startNanos) {
        LocalDateTime completedAt = LocalDateTime.now();
        long durationMs = (System.nanoTime() - startNanos) / 1_000_000L;
        lastBatchExpiredCount.set(expiredCount);
        lastBatchProductsAffected.set(productsAffected);
        lastBatchDurationMs.set(durationMs);
        lastExecutionTime.set(completedAt);
        lastSuccessfulExecutionTime.set(completedAt);
        successCount.incrementAndGet();
    }

    /**
     * Records a cycle that terminated with an unhandled error: updates the last-execution
     * timestamp (but not last-successful-execution), the duration, and the error counter.
     *
     * @param startNanos {@link System#nanoTime()} captured at the start of the cycle
     */
    private void recordFailedCycle(long startNanos) {
        lastBatchDurationMs.set((System.nanoTime() - startNanos) / 1_000_000L);
        lastExecutionTime.set(LocalDateTime.now());
        errorCount.incrementAndGet();
    }

    /**
     * Returns an immutable snapshot of the scheduler's current execution state for monitoring.
     *
     * <p>The snapshot includes the last (and last successful) execution times, the estimated
     * next execution time (last run + configured interval), cumulative success/error counts,
     * derived success and error rates, and the statistics of the most recent batch. It is the
     * data source for the Actuator health indicator described in Requirement 8.7.
     *
     * @return a point-in-time {@link SchedulerExecutionStats} snapshot
     */
    public SchedulerExecutionStats getExecutionStats() {
        LocalDateTime lastRun = lastExecutionTime.get();
        LocalDateTime nextRun = lastRun == null ? null : lastRun.plusSeconds(checkIntervalSeconds);
        long successes = successCount.get();
        long errors = errorCount.get();
        return new SchedulerExecutionStats(
                lastSuccessfulExecutionTime.get(),
                lastRun,
                nextRun,
                successes,
                errors,
                lastBatchExpiredCount.get(),
                lastBatchProductsAffected.get(),
                lastBatchDurationMs.get());
    }

    /**
     * Immutable snapshot of the expiration scheduler's execution state.
     *
     * <p>Rates are expressed as fractions in {@code [0.0, 1.0]}. When no cycle has run yet
     * (total == 0), {@code successRate} defaults to {@code 1.0} and {@code errorRate} to
     * {@code 0.0} so a freshly started, not-yet-run scheduler is not reported as failing.
     *
     * @param lastSuccessfulExecutionTime completion time of the last successful cycle, or {@code null}
     * @param lastExecutionTime           completion time of the last cycle (any outcome), or {@code null}
     * @param nextExecutionTime           estimated time of the next cycle, or {@code null} if never run
     * @param successCount                cumulative count of successful cycles
     * @param errorCount                  cumulative count of failed cycles
     * @param lastBatchExpiredCount       reservations expired in the most recent cycle
     * @param lastBatchProductsAffected   distinct products affected in the most recent cycle
     * @param lastBatchDurationMs         duration of the most recent cycle, in milliseconds
     */
    public record SchedulerExecutionStats(
            LocalDateTime lastSuccessfulExecutionTime,
            LocalDateTime lastExecutionTime,
            LocalDateTime nextExecutionTime,
            long successCount,
            long errorCount,
            long lastBatchExpiredCount,
            long lastBatchProductsAffected,
            long lastBatchDurationMs) {

        /** @return total number of cycles executed (successes + errors). */
        public long totalExecutions() {
            return successCount + errorCount;
        }

        /**
         * @return the fraction of cycles that succeeded, in {@code [0.0, 1.0]}; {@code 1.0}
         * when no cycle has run yet.
         */
        public double successRate() {
            long total = totalExecutions();
            return total == 0 ? 1.0 : (double) successCount / total;
        }

        /**
         * @return the fraction of cycles that failed, in {@code [0.0, 1.0]}; {@code 0.0}
         * when no cycle has run yet.
         */
        public double errorRate() {
            long total = totalExecutions();
            return total == 0 ? 0.0 : (double) errorCount / total;
        }

        /** @return {@code true} once at least one cycle has completed successfully. */
        public boolean hasExecuted() {
            return lastExecutionTime != null;
        }
    }

    /**
     * Expires all still-ACTIVE reservations for a single product within its own transaction.
     *
     * <p>Lock-acquisition failures are handled gracefully: the product is skipped (0 returned)
     * and the caller continues with the next product.
     *
     * @param productId    the product whose expired reservations are being processed
     * @param reservations the expired reservations for this product (candidates)
     * @return the number of reservations transitioned to EXPIRED for this product
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRES_NEW)
    public int expireProductReservations(UUID productId, List<Reservation> reservations) {
        // STEP 3a: Acquire a pessimistic write lock on the product.
        Product product;
        try {
            product = productRepository.findByIdWithLock(productId).orElse(null);
        } catch (LockTimeoutException | PessimisticLockException e) {
            log.warn("Could not acquire lock on product {}; skipping, will retry next cycle: {}",
                    productId, e.getMessage());
            return 0;
        }

        if (product == null) {
            log.warn("Product {} not found while expiring reservations; skipping", productId);
            return 0;
        }

        LocalDateTime now = LocalDateTime.now();
        Long availableStockBefore = product.getAvailableStock();
        long totalRestored = 0L;
        int expiredCount = 0;

        // STEP 3b: Expire each still-ACTIVE reservation (idempotence skips already-EXPIRED).
        for (Reservation reservation : reservations) {
            if (reservation.getStatus() != ReservationStatus.ACTIVE) {
                log.debug("Skipping non-ACTIVE reservation {} (status={}) for product {}",
                        reservation.getId(), reservation.getStatus(), productId);
                continue;
            }

            Long quantity = reservation.getQuantity();
            product.releaseStock(quantity);
            reservation.expire(now);
            reservationRepository.save(reservation);

            ReservationHistory history = ReservationHistory.builder()
                    .reservation(reservation)
                    .orderId(reservation.getOrderId())
                    .productId(productId)
                    .quantity(quantity)
                    .oldStatus(ReservationStatus.ACTIVE.name())
                    .newStatus(ReservationStatus.EXPIRED.name())
                    .changedAt(now)
                    .reason("Expired due to TTL elapse")
                    .build();
            reservationHistoryRepository.save(history);

            totalRestored += quantity;
            expiredCount++;
        }

        if (expiredCount == 0) {
            log.debug("No ACTIVE reservations to expire for product {}", productId);
            return 0;
        }

        // Persist the restored stock.
        product.setUpdatedAt(now);
        productRepository.save(product);

        // STEP 3c: Write a single EXPIRE audit-log entry for the product.
        StockAuditLog auditLog = StockAuditLog.builder()
                .product(product)
                .operationType(StockOperationType.EXPIRE)
                .quantityChange(totalRestored)
                .availableStockBefore(availableStockBefore)
                .availableStockAfter(product.getAvailableStock())
                .executedAt(now)
                .requestId("SCHEDULED-EXPIRATION-" + now)
                .build();
        stockAuditLogRepository.save(auditLog);

        log.info("Expired {} reservations for product {}, restored {} units (availableStock: {} -> {})",
                expiredCount, productId, totalRestored, availableStockBefore, product.getAvailableStock());

        return expiredCount;
    }
}
