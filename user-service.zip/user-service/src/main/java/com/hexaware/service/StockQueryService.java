package com.hexaware.service;

import com.hexaware.dto.StockLevelDTO;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Service for querying stock levels and availability information.
 * 
 * This service provides methods to retrieve current stock information for products,
 * calculating available stock as: totalStock - sum(activeReservations).
 * 
 * PERFORMANCE OPTIMIZATIONS:
 * - Response time cache: caches results for 1 second to reduce database load
 * - Batch queries: supports retrieving stock for multiple products efficiently
 * - Response time metrics: tracks P50, P95, P99 percentiles for monitoring
 * 
 * REQUIREMENTS:
 * - Requirement 1.1: Return product ID, total stock, available stock, reserved stock
 * - Requirement 1.3: Calculate available stock as totalStock - sum(activeReservations)
 * - Requirement 1.4: Response time < 100ms for 99th percentile
 * - Requirement 1.5: Support batch queries for multiple products
 * - Requirement 8.5: Track and expose response time metrics (P50, P95, P99)
 */
@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Slf4j
public class StockQueryService {

    private final ProductRepository productRepository;
    private final ReservationRepository reservationRepository;

    /**
     * Internal cache for stock level DTOs with timestamp tracking.
     * Thread-safe: uses ConcurrentHashMap for concurrent access without locks.
     * 
     * Cache key: product UUID
     * Cache value: CachedStockLevel (contains DTO and cached timestamp)
     * 
     * TTL: 1 second - refreshes cache if product.updated_at is older than 1 second
     * This balances between performance and freshness.
     */
    private static class CachedStockLevel {
        final StockLevelDTO dto;
        final Instant cachedAt;

        CachedStockLevel(StockLevelDTO dto, Instant cachedAt) {
            this.dto = dto;
            this.cachedAt = cachedAt;
        }

        /**
         * Checks if cache entry is still valid.
         * Cache is valid if:
         * - Product was updated before cache time (no concurrent modifications)
         * - Cache was created less than 1 second ago
         */
        boolean isValid(LocalDateTime productUpdatedAt, Instant now) {
            return productUpdatedAt.isBefore(java.time.LocalDateTime.ofInstant(this.cachedAt, java.time.ZoneId.systemDefault()))
                    && Instant.now().getEpochSecond() - this.cachedAt.getEpochSecond() < 1;
        }
    }

    private final Map<UUID, CachedStockLevel> stockLevelCache = new ConcurrentHashMap<>();

    /**
     * Response time metrics: tracks operation latencies for monitoring.
     * Stores individual response times for percentile calculation.
     */
    private static class ResponseTimeMetrics {
        private final List<Long> responseTimes = new ArrayList<>();
        private static final int MAX_SAMPLES = 10000;

        synchronized void recordTime(long milliseconds) {
            if (responseTimes.size() < MAX_SAMPLES) {
                responseTimes.add(milliseconds);
            }
        }

        synchronized long getPercentile(double percentile) {
            if (responseTimes.isEmpty()) return 0;
            List<Long> sorted = new ArrayList<>(responseTimes);
            Collections.sort(sorted);
            int index = (int) Math.ceil((percentile / 100) * sorted.size()) - 1;
            return sorted.get(Math.max(0, index));
        }

        synchronized void reset() {
            responseTimes.clear();
        }
    }

    private final ResponseTimeMetrics responseTimeMetrics = new ResponseTimeMetrics();

    /**
     * Retrieves stock level information for a single product.
     * 
     * ALGORITHM:
     * 1. Check cache for valid entry (updated_at within last 1 second)
     * 2. If cache hit: return cached DTO and record response time
     * 3. If cache miss:
     *    a. Load product from database
     *    b. Query active reservations for product
     *    c. Calculate available stock = totalStock - sum(activeReservations)
     *    d. Build and cache DTO
     *    e. Return DTO
     * 
     * PERFORMANCE:
     * - Cache hit latency: < 1ms (in-memory lookup)
     * - Cache miss latency: 5-20ms (database query + calculation)
     * - Response time should be < 100ms for 99th percentile
     * 
     * STOCK INVARIANT:
     * - availableStock = totalStock - sum(activeReservations)
     * - This is validated at the database level and checked in response
     * - If invariant is violated, log error and return partially calculated value
     * 
     * @param productId UUID of the product
     * @return StockLevelDTO with current stock information
     * @throws jakarta.persistence.EntityNotFoundException if product not found (404)
     */
    public StockLevelDTO getStockLevel(UUID productId) {
        long startTime = System.currentTimeMillis();

        try {
            // Step 1: Check cache
            CachedStockLevel cached = stockLevelCache.get(productId);
            if (cached != null) {
                Product product = productRepository.findById(productId).orElse(null);
                if (product != null && cached.isValid(product.getUpdatedAt(), Instant.now())) {
                    log.debug("Cache hit for product {}", productId);
                    return cached.dto;
                }
            }

            // Step 2: Cache miss - load from database
            log.debug("Querying stock level for product {}", productId);
            Product product = productRepository.findById(productId)
                    .orElseThrow(() -> new jakarta.persistence.EntityNotFoundException(
                            String.format("Product not found: %s", productId)
                    ));

            // Step 3: Query active reservations
            List<Reservation> activeReservations = reservationRepository.findActiveReservationsByProductId(productId);

            // Step 4: Calculate available stock
            long totalReserved = activeReservations.stream()
                    .mapToLong(Reservation::getQuantity)
                    .sum();

            long availableStock = product.getTotalStock() - totalReserved;

            // Step 5: Validate invariant
            boolean invariantValid = availableStock >= 0 
                    && product.getTotalStock() > 0
                    && product.getTotalStock().equals(availableStock + product.getReservedStock());

            if (!invariantValid) {
                log.error("Stock invariant violated for product {}: totalStock={}, availableStock={}, reservedStock={}",
                        productId, product.getTotalStock(), availableStock, product.getReservedStock());
            }

            // Step 6: Build DTO
            StockLevelDTO dto = StockLevelDTO.builder()
                    .productId(product.getId())
                    .sku(product.getSku())
                    .name(product.getName())
                    .totalStock(product.getTotalStock())
                    .availableStock(availableStock)
                    .reservedStock(product.getReservedStock())
                    .activeReservations((long) activeReservations.size())
                    .lastUpdatedAt(product.getUpdatedAt())
                    .invariantValid(invariantValid)
                    .build();

            // Step 7: Cache the result
            stockLevelCache.put(productId, new CachedStockLevel(dto, Instant.now()));

            log.debug("Stock level retrieved for product {}: available={}, reserved={}", 
                    productId, availableStock, product.getReservedStock());

            return dto;

        } finally {
            // Record response time for metrics
            long duration = System.currentTimeMillis() - startTime;
            responseTimeMetrics.recordTime(duration);
        }
    }

    /**
     * Retrieves stock level information for multiple products in a single batch query.
     * 
     * ALGORITHM:
     * 1. Split product IDs into: cached (valid) and to-fetch (cache miss or invalid)
     * 2. For cached products: add to results immediately
     * 3. For to-fetch products:
     *    a. Batch query all products from database
     *    b. For each product, query active reservations
     *    c. Calculate available stock for each
     *    d. Cache results
     * 4. Combine results and return in original order (if possible)
     * 
     * PERFORMANCE:
     * - Cache hits: < 1ms per product (in-memory lookup)
     * - Cache misses: N database queries + 1 batch reservation query
     * - Expected latency: 10-50ms for 100 products
     * - Should be < 100ms for 99th percentile
     * 
     * ERROR HANDLING:
     * - If product not found: excluded from results (no exception thrown)
     * - Log warnings for missing products
     * - Continue processing other products on error
     * 
     * @param productIds list of product UUIDs to query
     * @return list of StockLevelDTOs for found products (may be smaller than input if some not found)
     */
    public List<StockLevelDTO> getStockLevels(List<UUID> productIds) {
        long startTime = System.currentTimeMillis();

        try {
            if (productIds == null || productIds.isEmpty()) {
                log.debug("Empty product list provided to getStockLevels");
                return Collections.emptyList();
            }

            log.debug("Querying stock levels for {} products", productIds.size());

            // Step 1: Check cache and identify cache misses
            List<UUID> idsToFetch = new ArrayList<>();
            List<StockLevelDTO> cachedResults = new ArrayList<>();

            for (UUID productId : productIds) {
                CachedStockLevel cached = stockLevelCache.get(productId);
                if (cached != null) {
                    Product product = productRepository.findById(productId).orElse(null);
                    if (product != null && cached.isValid(product.getUpdatedAt(), Instant.now())) {
                        cachedResults.add(cached.dto);
                        continue;
                    }
                }
                idsToFetch.add(productId);
            }

            log.debug("Cache hit for {}/{} products", cachedResults.size(), productIds.size());

            // Step 2: If all cached, return early
            if (idsToFetch.isEmpty()) {
                return cachedResults;
            }

            // Step 3: Batch fetch missing products
            Set<UUID> idSet = new HashSet<>(idsToFetch);
            List<Product> products = productRepository.findByIdSet(idSet);

            if (products.isEmpty()) {
                log.warn("No products found for batch query with {} IDs", idsToFetch.size());
                return cachedResults;
            }

            // Step 4: Query active reservations for all fetched products
            Map<UUID, Long> activeReservationMap = new HashMap<>();
            for (UUID productId : products.stream().map(Product::getId).collect(Collectors.toList())) {
                List<Reservation> activeReservations = reservationRepository.findActiveReservationsByProductId(productId);
                long totalReserved = activeReservations.stream()
                        .mapToLong(Reservation::getQuantity)
                        .sum();
                activeReservationMap.put(productId, totalReserved);
            }

            // Step 5: Build DTOs for fetched products
            List<StockLevelDTO> fetchedResults = products.stream()
                    .map(product -> {
                        long totalReserved = activeReservationMap.getOrDefault(product.getId(), 0L);
                        long availableStock = product.getTotalStock() - totalReserved;

                        boolean invariantValid = availableStock >= 0 
                                && product.getTotalStock() > 0
                                && product.getTotalStock().equals(availableStock + product.getReservedStock());

                        if (!invariantValid) {
                            log.error("Stock invariant violated for product {}: totalStock={}, availableStock={}, reservedStock={}",
                                    product.getId(), product.getTotalStock(), availableStock, product.getReservedStock());
                        }

                        StockLevelDTO dto = StockLevelDTO.builder()
                                .productId(product.getId())
                                .sku(product.getSku())
                                .name(product.getName())
                                .totalStock(product.getTotalStock())
                                .availableStock(availableStock)
                                .reservedStock(product.getReservedStock())
                                .activeReservations((long) reservationRepository.countActiveByProductId(product.getId()))
                                .lastUpdatedAt(product.getUpdatedAt())
                                .invariantValid(invariantValid)
                                .build();

                        // Cache the result
                        stockLevelCache.put(product.getId(), new CachedStockLevel(dto, Instant.now()));

                        return dto;
                    })
                    .collect(Collectors.toList());

            // Step 6: Combine and return results
            List<StockLevelDTO> allResults = new ArrayList<>(cachedResults);
            allResults.addAll(fetchedResults);

            log.debug("Batch stock level query completed: {} results from cache, {} from database",
                    cachedResults.size(), fetchedResults.size());

            return allResults;

        } finally {
            // Record response time for metrics
            long duration = System.currentTimeMillis() - startTime;
            responseTimeMetrics.recordTime(duration);
        }
    }

    /**
     * Gets response time metrics for monitoring.
     * 
     * RETURNS:
     * - P50: 50th percentile (median) response time in milliseconds
     * - P95: 95th percentile response time
     * - P99: 99th percentile response time
     * 
     * These metrics help identify performance bottlenecks and verify SLA compliance:
     * - SLA requirement: 99th percentile < 100ms
     * 
     * @return map with keys "p50", "p95", "p99" and values in milliseconds
     */
    public Map<String, Long> getResponseTimeMetrics() {
        return Map.of(
                "p50", responseTimeMetrics.getPercentile(50),
                "p95", responseTimeMetrics.getPercentile(95),
                "p99", responseTimeMetrics.getPercentile(99)
        );
    }

    /**
     * Clears the response time metrics.
     * Used for testing and manual metric reset.
     */
    public void clearMetrics() {
        responseTimeMetrics.reset();
    }

    /**
     * Clears the stock level cache.
     * Used for testing and manual cache invalidation.
     */
    public void clearCache() {
        stockLevelCache.clear();
    }
}
