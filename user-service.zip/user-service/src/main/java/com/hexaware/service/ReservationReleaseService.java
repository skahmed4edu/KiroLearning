package com.hexaware.service;

import com.hexaware.dto.ReleaseResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationHistoryRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import com.hexaware.entity.ReservationHistory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.LockTimeoutException;
import jakarta.persistence.PessimisticLockException;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Service for releasing stock reservations with idempotent, oversell-safe operations.
 *
 * <p>DESIGN OVERVIEW:
 * <p>This service restores reserved stock back to availability when an order is cancelled
 * or stock is otherwise released. It mirrors the concurrency and auditing patterns of
 * {@link ReservationService}: a {@code READ_COMMITTED} transaction, a pessimistic row lock
 * on the reservation (and its product), delegation of stock mutation to
 * {@link Product#releaseStock(Long)}, a reservation state transition via
 * {@link Reservation#release(LocalDateTime)}, and a full audit trail written to both
 * {@code reservation_history} and {@code stock_audit_log}.
 *
 * <p>IDEMPOTENCY:
 * Releasing a reservation that is already {@code RELEASED} is a success and does NOT restore
 * stock a second time. This lets callers (notably order cancellation) retry safely without
 * double-counting stock.
 *
 * <p>ALGORITHM (releaseReservation):
 * <pre>
 * BEGIN TRANSACTION (READ_COMMITTED)
 *   STEP 1: Look up the reservation by id with a pessimistic write lock.
 *           - not found -> throw EntityNotFoundException (HTTP 404)
 *   STEP 2: If status == RELEASED -> return idempotent success (no stock change).
 *   STEP 3: If status != ACTIVE (EXPIRED / CANCELLED) ->
 *           throw IllegalStateException "RESERVATION_ALREADY_PROCESSED" (HTTP 409).
 *   STEP 4: Acquire a pessimistic write lock on the product.
 *   STEP 5: Restore stock: product.releaseStock(quantity)
 *           (increments availableStock, decrements reservedStock).
 *   STEP 6: Transition reservation ACTIVE -> RELEASED, record releasedAt.
 *   STEP 7: Insert a reservation_history record (ACTIVE -> RELEASED).
 *   STEP 8: Insert a stock_audit_log record (RELEASE, +quantity).
 * COMMIT
 * </pre>
 *
 * <p>CONCURRENCY: Two concurrent releases of the same reservation serialize on the
 * reservation row lock; the first performs the release, the second observes {@code RELEASED}
 * and returns an idempotent success. If a lock cannot be acquired, the underlying
 * {@link LockTimeoutException}/{@link PessimisticLockException} propagates (intended to map
 * to HTTP 503).
 *
 * <p>Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 6.5
 */
@Service
@Transactional(isolation = Isolation.READ_COMMITTED)
@RequiredArgsConstructor
@Slf4j
public class ReservationReleaseService {

    private final ProductRepository productRepository;
    private final ReservationRepository reservationRepository;
    private final ReservationHistoryRepository reservationHistoryRepository;
    private final StockAuditLogRepository stockAuditLogRepository;

    /**
     * Releases a reservation by its identifier, restoring the reserved quantity to the
     * product's available stock.
     *
     * <p>The operation is idempotent: if the reservation is already {@code RELEASED}, this
     * returns a success response flagged {@code idempotent=true} without restoring stock
     * again.
     *
     * @param reservationId  the reservation to release
     * @param idempotencyKey optional idempotency key for request correlation/tracing
     * @return a {@link ReleaseResponse} describing the released reservation and the restored
     *         available stock
     * @throws EntityNotFoundException if no reservation exists with the given id
     *         (intended to map to HTTP 404 Not Found)
     * @throws IllegalStateException if the reservation is in a non-releasable state such as
     *         {@code EXPIRED} or {@code CANCELLED} (intended to map to HTTP 409 Conflict)
     * @throws LockTimeoutException if the reservation or product row lock cannot be acquired
     *         (intended to map to HTTP 503 Service Unavailable)
     * @throws PessimisticLockException if the reservation or product row lock cannot be
     *         acquired (intended to map to HTTP 503 Service Unavailable)
     */
    public ReleaseResponse releaseReservation(UUID reservationId, String idempotencyKey) {
        log.info("Starting reservation release: reservationId={}, idempotencyKey={}",
                reservationId, idempotencyKey);

        Reservation reservation;
        try {
            reservation = reservationRepository.findByIdWithLock(reservationId)
                    .orElseThrow(() -> new EntityNotFoundException(
                            String.format("Reservation not found: %s", reservationId)));
        } catch (LockTimeoutException | PessimisticLockException e) {
            log.warn("Lock timeout acquiring reservation lock: reservationId={}, error={}",
                    reservationId, e.getMessage());
            throw e;
        }

        return releaseLockedReservation(reservation, idempotencyKey);
    }

    /**
     * Releases the single {@code ACTIVE} reservation associated with an order, restoring its
     * reserved quantity to the product's available stock.
     *
     * <p>Idempotency is handled as follows:
     * <ul>
     *   <li>If an {@code ACTIVE} reservation is found for the order, it is released.</li>
     *   <li>If no {@code ACTIVE} reservation is found but a {@code RELEASED} one exists for
     *       the order, an idempotent success is returned (the order was already released).</li>
     *   <li>If neither exists, {@link EntityNotFoundException} is thrown.</li>
     * </ul>
     *
     * @param orderId        the order whose active reservation should be released
     * @param idempotencyKey optional idempotency key for request correlation/tracing
     * @return a {@link ReleaseResponse} describing the released reservation
     * @throws EntityNotFoundException if the order has no active or previously-released
     *         reservation (intended to map to HTTP 404 Not Found)
     * @throws LockTimeoutException if a required row lock cannot be acquired
     *         (intended to map to HTTP 503 Service Unavailable)
     * @throws PessimisticLockException if a required row lock cannot be acquired
     *         (intended to map to HTTP 503 Service Unavailable)
     */
    public ReleaseResponse releaseReservationByOrderId(UUID orderId, String idempotencyKey) {
        log.info("Starting reservation release by order: orderId={}, idempotencyKey={}",
                orderId, idempotencyKey);

        Reservation reservation;
        try {
            reservation = reservationRepository.findByOrderIdWithLock(orderId)
                    .orElse(null);
        } catch (LockTimeoutException | PessimisticLockException e) {
            log.warn("Lock timeout acquiring reservation lock by order: orderId={}, error={}",
                    orderId, e.getMessage());
            throw e;
        }

        if (reservation == null) {
            // No ACTIVE reservation: check for an already-released one to stay idempotent.
            Reservation released = reservationRepository.findReleasedByOrderId(orderId).stream()
                    .findFirst()
                    .orElseThrow(() -> new EntityNotFoundException(
                            String.format("No releasable reservation found for order: %s", orderId)));
            log.info("Idempotent release by order: order already released, orderId={}, reservationId={}",
                    orderId, released.getId());
            return buildResponse(released, true);
        }

        return releaseLockedReservation(reservation, idempotencyKey);
    }

    /**
     * Core release logic operating on a reservation that has already been looked up (and,
     * for the ACTIVE path, locked).
     *
     * @param reservation    the reservation to release
     * @param idempotencyKey optional idempotency key for logging/tracing
     * @return a {@link ReleaseResponse} describing the outcome
     * @throws IllegalStateException if the reservation is in a non-releasable state
     */
    private ReleaseResponse releaseLockedReservation(Reservation reservation, String idempotencyKey) {
        // STEP 2: Idempotent replay — already released, do not restore stock again.
        if (reservation.getStatus() == ReservationStatus.RELEASED) {
            log.info("Idempotent release: reservation already RELEASED, reservationId={}, orderId={}",
                    reservation.getId(), reservation.getOrderId());
            return buildResponse(reservation, true);
        }

        // STEP 3: Non-ACTIVE, non-RELEASED states cannot be released.
        if (reservation.getStatus() != ReservationStatus.ACTIVE) {
            log.warn("Attempt to release non-releasable reservation: reservationId={}, status={}",
                    reservation.getId(), reservation.getStatus());
            throw new IllegalStateException(
                    "RESERVATION_ALREADY_PROCESSED: status=" + reservation.getStatus());
        }

        UUID productId = reservation.getProduct().getId();
        Long quantity = reservation.getQuantity();

        // STEP 4: Acquire a pessimistic write lock on the product row.
        Product product;
        try {
            product = productRepository.findByIdWithLock(productId)
                    .orElseThrow(() -> new EntityNotFoundException(
                            String.format("Product not found: %s", productId)));
        } catch (LockTimeoutException | PessimisticLockException e) {
            log.warn("Lock timeout acquiring product lock during release: productId={}, error={}",
                    productId, e.getMessage());
            throw e;
        }

        // STEP 5: Restore stock (increment available, decrement reserved).
        Long availableStockBefore = product.getAvailableStock();
        product.releaseStock(quantity);
        LocalDateTime now = LocalDateTime.now();
        product.setUpdatedAt(now);
        productRepository.save(product);

        log.debug("Stock restored on release: productId={}, availableStock: {} -> {}",
                productId, availableStockBefore, product.getAvailableStock());

        // STEP 6: Transition reservation ACTIVE -> RELEASED.
        reservation.release(now);
        reservationRepository.save(reservation);

        // STEP 7: Write reservation_history record (ACTIVE -> RELEASED).
        ReservationHistory history = ReservationHistory.builder()
                .reservation(reservation)
                .orderId(reservation.getOrderId())
                .productId(productId)
                .quantity(quantity)
                .oldStatus(ReservationStatus.ACTIVE.name())
                .newStatus(ReservationStatus.RELEASED.name())
                .changedAt(now)
                .reason("Released due to order cancellation")
                .build();
        reservationHistoryRepository.save(history);

        // STEP 8: Write stock_audit_log record (RELEASE, +quantity).
        StockAuditLog auditLog = StockAuditLog.builder()
                .product(product)
                .operationType(StockOperationType.RELEASE)
                .quantityChange(quantity)
                .availableStockBefore(availableStockBefore)
                .availableStockAfter(product.getAvailableStock())
                .executedAt(now)
                .requestId(idempotencyKey)
                .build();
        stockAuditLogRepository.save(auditLog);

        log.info("Reservation successfully released: reservationId={}, orderId={}, productId={}, quantity={}",
                reservation.getId(), reservation.getOrderId(), productId, quantity);

        return buildResponse(reservation, false);
    }

    /**
     * Builds a {@link ReleaseResponse} from a reservation.
     *
     * @param reservation the released (or already-released) reservation
     * @param idempotent  whether this response represents an idempotent replay
     * @return the response DTO
     */
    private ReleaseResponse buildResponse(Reservation reservation, boolean idempotent) {
        return ReleaseResponse.builder()
                .reservationId(reservation.getId())
                .orderId(reservation.getOrderId())
                .productId(reservation.getProduct().getId())
                .quantity(reservation.getQuantity())
                .status(reservation.getStatus().name())
                .releasedAt(reservation.getReleasedAt())
                .availableStock(reservation.getProduct().getAvailableStock())
                .idempotent(idempotent)
                .build();
    }
}
