package com.hexaware.service;

import com.hexaware.dto.OrderResponse;
import com.hexaware.dto.PlaceOrderRequest;
import com.hexaware.entity.Order;
import com.hexaware.entity.User;
import com.hexaware.repository.OrderRepository;
import com.hexaware.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * Service for managing orders
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;

    /**
     * Place a new order for a user
     * 
     * @param request the order placement request
     * @return the created order response
     * @throws IllegalArgumentException if user not found or order number already exists
     */
    @Transactional
    public OrderResponse placeOrder(PlaceOrderRequest request) {
        log.info("Placing new order for user: {}, orderNumber: {}", request.getUserId(), request.getOrderNumber());

        // Validate user exists
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> {
                    log.warn("Order placement failed: User not found with id: {}", request.getUserId());
                    return new IllegalArgumentException("User not found with id: " + request.getUserId());
                });

        // Check if order number already exists
        if (orderRepository.existsByOrderNumber(request.getOrderNumber())) {
            log.warn("Order placement failed: Order number already exists: {}", request.getOrderNumber());
            throw new IllegalArgumentException("Order number already exists: " + request.getOrderNumber());
        }

        // Create new order entity
        Order order = Order.builder()
                .orderNumber(request.getOrderNumber())
                .user(user)
                .totalAmount(request.getTotalAmount())
                .paymentMethod(request.getPaymentMethod())
                .shippingAddress(request.getShippingAddress())
                .description(request.getDescription())
                .status(Order.OrderStatus.PENDING)
                .paymentStatus(Order.PaymentStatus.UNPAID)
                .build();

        // Save order to database
        Order savedOrder = orderRepository.save(order);
        log.info("Order placed successfully with id: {}, orderNumber: {}", savedOrder.getId(), savedOrder.getOrderNumber());

        // Return order response
        return mapOrderToResponse(savedOrder);
    }

    /**
     * Retrieve an order by its ID
     * 
     * @param orderId the order ID
     * @return the order response
     * @throws IllegalArgumentException if order not found
     */
    @Transactional(readOnly = true)
    public OrderResponse getOrderById(UUID orderId) {
        log.info("Retrieving order with id: {}", orderId);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> {
                    log.warn("Order retrieval failed: Order not found with id: {}", orderId);
                    return new IllegalArgumentException("Order not found with id: " + orderId);
                });

        log.info("Order retrieved successfully: orderId: {}, orderNumber: {}", order.getId(), order.getOrderNumber());
        return mapOrderToResponse(order);
    }

    /**
     * Retrieve an order by its order number
     * 
     * @param orderNumber the order number
     * @return the order response
     * @throws IllegalArgumentException if order not found
     */
    @Transactional(readOnly = true)
    public OrderResponse getOrderByOrderNumber(String orderNumber) {
        log.info("Retrieving order with orderNumber: {}", orderNumber);

        Order order = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> {
                    log.warn("Order retrieval failed: Order not found with orderNumber: {}", orderNumber);
                    return new IllegalArgumentException("Order not found with orderNumber: " + orderNumber);
                });

        log.info("Order retrieved successfully: orderId: {}, orderNumber: {}", order.getId(), order.getOrderNumber());
        return mapOrderToResponse(order);
    }

    /**
     * Retrieve the description for an order by its ID
     * 
     * @param order the order ID
     * @return the order description
     * @throws IllegalArgumentException if order not found
     */
    @Transactional(readOnly = true)
    public String getDescription(UUID orderId) {
        log.info("Retrieving description for order with id: {}", orderId);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> {
                    log.warn("Description retrieval failed: Order not found with id: {}", orderId);
                    return new IllegalArgumentException("Order not found with id: " + orderId);
                });

        log.info("Description retrieved successfully for orderId: {}", orderId);
        return order.getDescription();
    }

    /**
     * Delete an order by its ID
     * 
     * @param orderId the order ID
     * @throws IllegalArgumentException if order not found
     */
    @Transactional
    public void deleteOrderById(UUID orderId) {
        log.info("Deleting order with id: {}", orderId);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> {
                    log.warn("Order deletion failed: Order not found with id: {}", orderId);
                    return new IllegalArgumentException("Order not found with id: " + orderId);
                });

        orderRepository.delete(order);
        log.info("Order deleted successfully: orderId: {}", orderId);
    }

    /**
     * Map Order entity to OrderResponse DTO
     * 
     * @param order the order entity
     * @return the order response DTO
     */
    private OrderResponse mapOrderToResponse(Order order) {
        return OrderResponse.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .userId(order.getUser().getId())
                .totalAmount(order.getTotalAmount())
                .status(order.getStatus().toString())
                .paymentMethod(order.getPaymentMethod())
                .paymentStatus(order.getPaymentStatus().toString())
                .shippingAddress(order.getShippingAddress())
                .description(order.getDescription())
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .paidAt(order.getPaidAt())
                .build();
    }
}
