package com.hexaware.exception;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Standardized error payload for inventory / stock-reservation operations.
 *
 * <p>This is the body returned by {@link GlobalExceptionHandler} for the inventory
 * exception family. It is deliberately separate from the user-registration
 * {@link ErrorResponse} so that existing handlers remain untouched while
 * inventory errors can carry the richer, design-mandated shape:
 *
 * <pre>
 * {
 *   "error": "LOCK_TIMEOUT",
 *   "message": "Could not acquire lock on product; please retry",
 *   "details": { "productId": "..." },
 *   "timestamp": "2024-01-15T10:30:00",
 *   "requestId": "req-12345",
 *   "httpStatus": 503,
 *   "retryAfter": 100
 * }
 * </pre>
 *
 * <p>The {@code retryAfter} field (milliseconds) is populated <strong>only</strong>
 * for retryable errors (e.g. {@code LOCK_TIMEOUT} → HTTP 503). Non-retryable errors
 * leave it {@code null}, and {@link JsonInclude.Include#NON_NULL} omits it from the
 * serialized response.
 *
 * <p>Requirements: 2.2, 3.5, 3.6, 3.7, 5.2, 5.3, 5.7, 6.7
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InventoryErrorResponse {

    /** Machine-readable error code, e.g. {@code INSUFFICIENT_STOCK}. Never null. */
    private String error;

    /** Human-readable description of what went wrong. Never null. */
    private String message;

    /** Optional contextual key/value details (product id, quantities, failures). */
    private Map<String, Object> details;

    /** Server timestamp when the error was produced. */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime timestamp;

    /** Correlation / request id for tracing against server logs, when available. */
    private String requestId;

    /** The HTTP status associated with this error. */
    private int httpStatus;

    /**
     * Retry hint in milliseconds. Present only for retryable errors (HTTP 503
     * {@code LOCK_TIMEOUT}); {@code null} for non-retryable errors.
     */
    private Long retryAfter;
}
