package com.hexaware.exception;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * Handle validation errors (400 Bad Request)
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(MethodArgumentNotValidException ex) {
        log.warn("Validation error: {}", ex.getMessage());

        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            fieldErrors.put(fieldName, errorMessage);
        });

        ErrorResponse errorResponse = ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.BAD_REQUEST.value())
                .message("Validation failed")
                .errors(fieldErrors)
                .build();

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    /**
     * Handle constraint violation exceptions (400 Bad Request)
     * 
     * This handler catches ConstraintViolationException which is thrown by
     * JSR-303 validation when using custom validators (e.g., @ValidProductExists,
     * @BulkUpdateMaxSize, @ValidProductQuantity).
     * 
     * The exception includes a set of ConstraintViolation objects, each containing:
     * - propertyPath: field name that failed validation
     * - message: validation error message
     * - invalidValue: the value that failed validation
     * 
     * Response Structure:
     * {
     *   "status": 400,
     *   "message": "Validation failed",
     *   "errors": {
     *     "productId": "Product with ID ... does not exist",
     *     "quantity": "Product quantity must be positive (greater than 0)",
     *     "updates": "Bulk update list exceeds maximum size of 1000 items"
     *   },
     *   "timestamp": "2024-01-15T10:30:00"
     * }
     * 
     * Requirements: 5.2, 5.3, 5.6
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException ex) {
        log.warn("Constraint violation: {}", ex.getMessage());

        // Extract validation errors into a map: field -> message
        Map<String, String> fieldErrors = new HashMap<>();
        Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
        
        violations.forEach(violation -> {
            // Get the property path (field name)
            String propertyPath = violation.getPropertyPath().toString();
            // Get the violation message
            String message = violation.getMessage();
            // Get the invalid value for additional context if needed
            Object invalidValue = violation.getInvalidValue();
            
            // Store in map: field -> message
            fieldErrors.put(propertyPath, message);
            
            // Log the violation with context
            log.debug("Constraint violation on field '{}': {} (value: {})", 
                    propertyPath, message, invalidValue);
        });

        ErrorResponse errorResponse = ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.BAD_REQUEST.value())
                .message("Validation failed")
                .errors(fieldErrors)
                .build();

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    /**
     * Handle email already exists exception (409 Conflict)
     */
    @ExceptionHandler(EmailAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleEmailAlreadyExistsException(EmailAlreadyExistsException ex) {
        log.warn("Email already exists: {}", ex.getMessage());

        ErrorResponse errorResponse = ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.CONFLICT.value())
                .message(ex.getMessage())
                .build();

        return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);
    }

    // ---------------------------------------------------------------------
    // Inventory / stock-reservation exception handlers (task 16)
    //
    // These produce the standardized InventoryErrorResponse body (error code,
    // message, details, timestamp, requestId, httpStatus). Retryable errors
    // (LOCK_TIMEOUT -> 503) carry a retryAfter hint; non-retryable errors omit it.
    // ---------------------------------------------------------------------

    /**
     * Handle insufficient-stock conflicts (409 Conflict). Non-retryable at the
     * HTTP layer, so no retry hint is included. The available and requested
     * quantities are surfaced in {@code details} to aid client-side adjustment.
     *
     * @param ex the thrown {@link InsufficientStockException}
     * @return a 409 response carrying an {@link InventoryErrorResponse}
     */
    @ExceptionHandler(InsufficientStockException.class)
    public ResponseEntity<InventoryErrorResponse> handleInsufficientStockException(InsufficientStockException ex) {
        log.warn("Insufficient stock: productId={}, available={}, requested={}",
                ex.getProductId(), ex.getAvailableStock(), ex.getRequestedQuantity());

        Map<String, Object> details = new LinkedHashMap<>();
        details.put("productId", ex.getProductId());
        details.put("availableStock", ex.getAvailableStock());
        details.put("requestedQuantity", ex.getRequestedQuantity());

        return buildInventoryError("INSUFFICIENT_STOCK", ex.getMessage(),
                HttpStatus.CONFLICT, details, null);
    }

    /**
     * Handle reservation-not-found errors (404 Not Found). Non-retryable; no
     * retry hint is included.
     *
     * @param ex the thrown {@link ReservationNotFoundException}
     * @return a 404 response carrying an {@link InventoryErrorResponse}
     */
    @ExceptionHandler(ReservationNotFoundException.class)
    public ResponseEntity<InventoryErrorResponse> handleReservationNotFoundException(ReservationNotFoundException ex) {
        log.warn("Reservation not found: {}", ex.getMessage());

        return buildInventoryError("RESERVATION_NOT_FOUND", ex.getMessage(),
                HttpStatus.NOT_FOUND, null, null);
    }

    /**
     * Handle release attempts against a non-ACTIVE reservation (409 Conflict).
     * Non-retryable; no retry hint is included.
     *
     * @param ex the thrown {@link ReservationAlreadyReleasedException}
     * @return a 409 response carrying an {@link InventoryErrorResponse}
     */
    @ExceptionHandler(ReservationAlreadyReleasedException.class)
    public ResponseEntity<InventoryErrorResponse> handleReservationAlreadyReleasedException(
            ReservationAlreadyReleasedException ex) {
        log.warn("Reservation already processed: {}", ex.getMessage());

        return buildInventoryError("RESERVATION_ALREADY_RELEASED", ex.getMessage(),
                HttpStatus.CONFLICT, null, null);
    }

    /**
     * Handle lock-acquisition timeouts (503 Service Unavailable). This is the
     * only <strong>retryable</strong> inventory error: the response includes a
     * {@code retryAfter} hint (milliseconds) so clients can back off and retry.
     *
     * @param ex the thrown {@link LockTimeoutException}
     * @return a 503 response carrying an {@link InventoryErrorResponse} with a retry hint
     */
    @ExceptionHandler(LockTimeoutException.class)
    public ResponseEntity<InventoryErrorResponse> handleLockTimeoutException(LockTimeoutException ex) {
        log.warn("Lock timeout, advising retry after {}ms: {}", ex.getRetryAfterMs(), ex.getMessage());

        return buildInventoryError("LOCK_TIMEOUT", ex.getMessage(),
                HttpStatus.SERVICE_UNAVAILABLE, null, ex.getRetryAfterMs());
    }

    /**
     * Handle bulk-update validation failures (400 Bad Request). Non-retryable;
     * any per-item failures are surfaced in {@code details.failures}.
     *
     * @param ex the thrown {@link InvalidBulkUpdateException}
     * @return a 400 response carrying an {@link InventoryErrorResponse}
     */
    @ExceptionHandler(InvalidBulkUpdateException.class)
    public ResponseEntity<InventoryErrorResponse> handleInvalidBulkUpdateException(InvalidBulkUpdateException ex) {
        log.warn("Invalid bulk update: {}", ex.getMessage());

        Map<String, Object> details = null;
        if (!ex.getFailures().isEmpty()) {
            details = new LinkedHashMap<>();
            details.put("failures", ex.getFailures());
        }

        return buildInventoryError("INVALID_BULK_UPDATE", ex.getMessage(),
                HttpStatus.BAD_REQUEST, details, null);
    }

    /**
     * Handle stock updates that would drop total stock below reserved stock
     * (409 Conflict). Non-retryable; conflicting values are surfaced in
     * {@code details}.
     *
     * @param ex the thrown {@link InvalidStockAfterReservationsException}
     * @return a 409 response carrying an {@link InventoryErrorResponse}
     */
    @ExceptionHandler(InvalidStockAfterReservationsException.class)
    public ResponseEntity<InventoryErrorResponse> handleInvalidStockAfterReservationsException(
            InvalidStockAfterReservationsException ex) {
        log.warn("Invalid stock after reservations: productId={}, newTotalStock={}, reservedStock={}",
                ex.getProductId(), ex.getNewTotalStock(), ex.getReservedStock());

        Map<String, Object> details = new LinkedHashMap<>();
        details.put("productId", ex.getProductId());
        details.put("newTotalStock", ex.getNewTotalStock());
        details.put("reservedStock", ex.getReservedStock());

        return buildInventoryError("INVALID_STOCK_AFTER_RESERVATIONS", ex.getMessage(),
                HttpStatus.CONFLICT, details, null);
    }

    /**
     * Builds a standardized inventory error response.
     *
     * @param errorCode   machine-readable error code
     * @param message     human-readable message
     * @param status      HTTP status to return
     * @param details     optional contextual details (may be {@code null})
     * @param retryAfterMs retry hint in milliseconds for retryable errors, or
     *                     {@code null} for non-retryable errors (omitted from the body)
     * @return a {@link ResponseEntity} wrapping the populated {@link InventoryErrorResponse}
     */
    private ResponseEntity<InventoryErrorResponse> buildInventoryError(
            String errorCode,
            String message,
            HttpStatus status,
            Map<String, Object> details,
            Long retryAfterMs) {

        InventoryErrorResponse body = InventoryErrorResponse.builder()
                .error(errorCode)
                .message(message)
                .details(details)
                .timestamp(LocalDateTime.now())
                .requestId(MDC.get("requestId"))
                .httpStatus(status.value())
                .retryAfter(retryAfterMs)
                .build();

        return ResponseEntity.status(status).body(body);
    }

    /**
     * Handle generic exceptions (500 Internal Server Error)
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {
        log.error("Unexpected error occurred", ex);

        ErrorResponse errorResponse = ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .message("An unexpected error occurred")
                .build();

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }
}
