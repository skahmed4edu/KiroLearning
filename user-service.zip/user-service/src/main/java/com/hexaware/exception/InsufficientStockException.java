package com.hexaware.exception;

import java.util.UUID;

/**
 * Thrown when a reservation cannot be created because the product's available
 * stock is less than the requested quantity.
 *
 * <p>Maps to HTTP 409 Conflict. This is a business-rule conflict, not a client
 * input error. The response carries the available stock and requested quantity
 * so callers can adjust and retry.
 *
 * <p>Requirements: 2.2
 */
public class InsufficientStockException extends RuntimeException {

    private final UUID productId;
    private final Long availableStock;
    private final Long requestedQuantity;

    public InsufficientStockException(UUID productId, Long availableStock, Long requestedQuantity) {
        super(String.format(
                "Insufficient stock for product %s: requested %d, only %d available",
                productId, requestedQuantity, availableStock));
        this.productId = productId;
        this.availableStock = availableStock;
        this.requestedQuantity = requestedQuantity;
    }

    public UUID getProductId() {
        return productId;
    }

    public Long getAvailableStock() {
        return availableStock;
    }

    public Long getRequestedQuantity() {
        return requestedQuantity;
    }
}
