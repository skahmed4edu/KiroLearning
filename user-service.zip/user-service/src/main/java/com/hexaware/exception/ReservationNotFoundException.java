package com.hexaware.exception;

/**
 * Thrown when a reservation lookup by reservation ID or order ID finds no
 * matching record.
 *
 * <p>Maps to HTTP 404 Not Found. This is a non-retryable error.
 *
 * <p>Requirements: 3.5
 */
public class ReservationNotFoundException extends RuntimeException {

    public ReservationNotFoundException(String message) {
        super(message);
    }

    public ReservationNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
