package com.hexaware.exception;

/**
 * Thrown when a release is attempted against a reservation that is no longer in
 * the {@code ACTIVE} state (already RELEASED, EXPIRED, or CANCELLED).
 *
 * <p>Maps to HTTP 409 Conflict. This is a non-retryable error. Note that a
 * strictly idempotent re-release of an already-RELEASED reservation is treated
 * as success by the service layer; this exception represents the conflicting
 * state-transition case that must surface a 409.
 *
 * <p>Requirements: 3.6, 3.7
 */
public class ReservationAlreadyReleasedException extends RuntimeException {

    public ReservationAlreadyReleasedException(String message) {
        super(message);
    }

    public ReservationAlreadyReleasedException(String message, Throwable cause) {
        super(message, cause);
    }
}
