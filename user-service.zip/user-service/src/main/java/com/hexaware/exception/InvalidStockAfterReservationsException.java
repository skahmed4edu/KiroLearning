package com.hexaware.exception;

import java.util.UUID;

/**
 * Thrown when a stock update would leave a product's new total stock below the
 * quantity already committed to active reservations, which would violate the
 * stock invariant ({@code availableStock >= 0}).
 *
 * <p>Maps to HTTP 409 Conflict. This is a non-retryable error.
 *
 * <p>Requirements: 5.7
 */
public class InvalidStockAfterReservationsException extends RuntimeException {

    private final UUID productId;
    private final Long newTotalStock;
    private final Long reservedStock;

    public InvalidStockAfterReservationsException(UUID productId, Long newTotalStock, Long reservedStock) {
        super(String.format(
                "New total stock %d for product %s is below reserved stock %d",
                newTotalStock, productId, reservedStock));
        this.productId = productId;
        this.newTotalStock = newTotalStock;
        this.reservedStock = reservedStock;
    }

    public UUID getProductId() {
        return productId;
    }

    public Long getNewTotalStock() {
        return newTotalStock;
    }

    public Long getReservedStock() {
        return reservedStock;
    }
}
