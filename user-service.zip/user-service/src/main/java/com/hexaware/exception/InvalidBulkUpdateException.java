package com.hexaware.exception;

import java.util.Collections;
import java.util.List;

/**
 * Thrown when a bulk stock update fails validation (for example, an invalid
 * product ID, a negative quantity, or a batch that exceeds the configured
 * maximum size). Bulk updates are all-or-nothing, so this error means no
 * product was modified.
 *
 * <p>Maps to HTTP 400 Bad Request. This is a non-retryable error.
 *
 * <p>Requirements: 5.2, 5.3
 */
public class InvalidBulkUpdateException extends RuntimeException {

    private final List<String> failures;

    public InvalidBulkUpdateException(String message) {
        this(message, Collections.emptyList());
    }

    public InvalidBulkUpdateException(String message, List<String> failures) {
        super(message);
        this.failures = failures == null ? Collections.emptyList() : List.copyOf(failures);
    }

    /**
     * @return per-item failure descriptions explaining why the batch was rejected
     */
    public List<String> getFailures() {
        return failures;
    }
}
