package com.hexaware.exception;

/**
 * Thrown when a database row lock could not be acquired within the configured
 * timeout (for example, {@code SELECT ... FOR UPDATE NOWAIT} failing under
 * concurrent contention).
 *
 * <p>Maps to HTTP 503 Service Unavailable. This is a <strong>retryable</strong>
 * error: the response includes a retry hint ({@code retryAfter}, in
 * milliseconds) so clients can back off and try again.
 *
 * <p>Not to be confused with {@link jakarta.persistence.LockTimeoutException},
 * which is the JPA-level cause this exception typically wraps.
 *
 * <p>Requirements: 6.7
 */
public class LockTimeoutException extends RuntimeException {

    /** Default retry hint in milliseconds when none is supplied. */
    public static final long DEFAULT_RETRY_AFTER_MS = 100L;

    private final long retryAfterMs;

    public LockTimeoutException(String message) {
        this(message, DEFAULT_RETRY_AFTER_MS, null);
    }

    public LockTimeoutException(String message, long retryAfterMs) {
        this(message, retryAfterMs, null);
    }

    public LockTimeoutException(String message, Throwable cause) {
        this(message, DEFAULT_RETRY_AFTER_MS, cause);
    }

    public LockTimeoutException(String message, long retryAfterMs, Throwable cause) {
        super(message, cause);
        this.retryAfterMs = retryAfterMs;
    }

    /**
     * @return suggested delay in milliseconds before the client retries the request
     */
    public long getRetryAfterMs() {
        return retryAfterMs;
    }
}
