package com.hexaware.entity;

/**
 * Enum representing the different types of stock operations that are logged in the audit trail.
 * 
 * Each operation type indicates what kind of stock change occurred and can be used to:
 * 1. Categorize stock changes for analytics
 * 2. Filter audit logs by operation type
 * 3. Implement operation-specific reconciliation logic
 * 4. Generate operation-specific reports
 * 
 * Database Storage:
 * - Stored as VARCHAR in stock_audit_log.operation_type column
 * - Values: RESERVE, RELEASE, EXPIRE, BULK_UPDATE
 * - Cannot be null (enforced by @NotNull annotation)
 */
public enum StockOperationType {

    /**
     * RESERVE operation: Stock is reserved for an order.
     * 
     * Occurs when:
     * - ReservationService.createReservation() successfully reserves stock
     * 
     * Impact on Available Stock:
     * - quantity_change: negative (stock is held and removed from available pool)
     * - availableStock decreases
     * - reservedStock increases
     * 
     * Example:
     * - Available stock before: 100 units
     * - Reserve quantity: 10 units
     * - Available stock after: 90 units
     * - quantity_change: -10
     */
    RESERVE,

    /**
     * RELEASE operation: Stock is released back from a reservation.
     * 
     * Occurs when:
     * - ReservationReleaseService.releaseReservation() explicitly releases a reservation
     * - This typically happens when an order is cancelled
     * 
     * Impact on Available Stock:
     * - quantity_change: positive (stock is restored to available pool)
     * - availableStock increases
     * - reservedStock decreases
     * 
     * Example:
     * - Available stock before: 90 units
     * - Release quantity: 10 units (from a cancelled order)
     * - Available stock after: 100 units
     * - quantity_change: +10
     */
    RELEASE,

    /**
     * EXPIRE operation: Stock is released due to reservation expiration.
     * 
     * Occurs when:
     * - ReservationExpirationScheduler.processExpiredReservations() marks a reservation as EXPIRED
     * - Automatically triggered by the scheduled background job
     * - Happens when reservation TTL elapses without explicit release
     * 
     * Impact on Available Stock:
     * - quantity_change: positive (stock is restored to available pool)
     * - availableStock increases
     * - reservedStock decreases
     * 
     * Note: EXPIRE has the same financial impact as RELEASE but different business meaning.
     * - RELEASE: intentional action by user (order cancelled)
     * - EXPIRE: automatic action by system (time limit reached)
     * 
     * Example:
     * - Available stock before: 90 units
     * - Expire quantity: 10 units (from expired reservation)
     * - Available stock after: 100 units
     * - quantity_change: +10
     */
    EXPIRE,

    /**
     * BULK_UPDATE operation: Total stock is adjusted via bulk update operation.
     * 
     * Occurs when:
     * - StockUpdateService.bulkUpdateStock() adjusts product stock during restocking
     * - Handles inventory receipts and stock corrections
     * - Supports setting new total stock quantities
     * 
     * Impact on Available Stock:
     * - quantity_change: can be positive or negative
     * - If total stock increases and no reservations change: availableStock increases
     * - If total stock decreases and no reservations change: availableStock decreases
     * - Recalculated as: newAvailable = newTotal - activeReservations
     * 
     * Example 1 (Restock):
     * - Total stock before: 50, Reserved: 20, Available: 30
     * - Bulk update new total: 100
     * - Total stock after: 100, Reserved: 20, Available: 80
     * - quantity_change: +50
     * 
     * Example 2 (Stock correction):
     * - Total stock before: 100, Reserved: 30, Available: 70
     * - Bulk update new total: 80 (error correction)
     * - Total stock after: 80, Reserved: 30, Available: 50
     * - quantity_change: -20
     * 
     * Validation:
     * - New total stock must be >= active reservations
     * - Cannot create overselling by bulk updating down
     */
    BULK_UPDATE
}
