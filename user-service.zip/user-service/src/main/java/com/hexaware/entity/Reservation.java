package com.hexaware.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Reservation entity representing a temporary hold on product stock.
 * 
 * A reservation links an Order to a Product and holds stock for a configured TTL.
 * Reservations prevent overselling by ensuring stock quantities cannot be allocated
 * to multiple orders simultaneously.
 * 
 * Key Responsibilities:
 * 1. Track reservation status lifecycle (ACTIVE → RELEASED or EXPIRED)
 * 2. Enforce idempotency via idempotency_key for deduplication
 * 3. Support both manual release and automatic expiration
 * 4. Maintain audit trail via timestamps (created_at, released_at, expired_at)
 * 5. Link orders to products with quantity tracking
 * 
 * Concurrency Model:
 * - Uses pessimistic locking (SELECT ... FOR UPDATE) during creation/release
 * - Row-level locks acquired in consistent order to prevent deadlocks
 * - Database constraints ensure no orphaned or invalid states
 * 
 * Indexes (for query performance):
 * - idx_reservation_order_id: for quick order lookup
 * - idx_reservation_product_id: for product-based queries
 * - idx_reservation_status: for filtering by state
 * - idx_reservation_expiration_time: for finding expired reservations
 * - idx_reservation_created_at: for time-range queries
 * - idx_reservation_idempotency_key: for deduplication on retry
 * 
 * Requirements: 2.5, 2.6, 2.7, 3.2, 3.3
 */
@Entity
@Table(
    name = "reservations",
    indexes = {
        @Index(name = "idx_reservation_order_id", columnList = "order_id"),
        @Index(name = "idx_reservation_product_id", columnList = "product_id"),
        @Index(name = "idx_reservation_status", columnList = "status"),
        @Index(name = "idx_reservation_expiration_time", columnList = "expiration_time"),
        @Index(name = "idx_reservation_created_at", columnList = "created_at"),
        @Index(name = "idx_reservation_idempotency_key", columnList = "idempotency_key")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reservation {

    /**
     * Unique reservation identifier (UUID, primary key).
     * Generated server-side using PostgreSQL's gen_random_uuid().
     * Used for API references and audit trails.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "UUID")
    private UUID id;

    /**
     * Order identifier linking this reservation to an order.
     * Immutable: set at creation and never updated.
     * This is a foreign key reference to the Order Service (orders table).
     * Used to look up reservations by order ID during cancellation.
     * 
     * Note: This is NOT a database FK to order table in Order Service DB.
     * It's a soft reference (orderId value) for cross-service communication.
     */
    @NotNull(message = "Order ID cannot be null")
    @Column(name = "order_id", nullable = false, updatable = false)
    private UUID orderId;

    /**
     * Product being reserved via ManyToOne relationship.
     * Lazy loading: Product data loaded only when accessed.
     * This prevents N+1 queries when loading multiple reservations.
     * 
     * Database FK: REFERENCES products(id) ON DELETE RESTRICT
     * - RESTRICT prevents deletion of product if active reservations exist
     * - Ensures data consistency: cannot delete product with outstanding reservations
     * 
     * Immutable at the application level: never reassigned after creation.
     * Marked as updatable=false to prevent accidental modifications.
     */
    @NotNull(message = "Product cannot be null")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false, updatable = false)
    private Product product;

    /**
     * Quantity of product reserved (in units).
     * Immutable: set at creation and never updated.
     * Must be positive (enforced by @Positive annotation).
     * 
     * This quantity is:
     * 1. Decremented from product.availableStock on creation
     * 2. Incremented to product.availableStock on release/expiration
     * 3. Used to validate stock levels before reservation creation
     */
    @Positive(message = "Quantity must be positive")
    @Column(name = "quantity", nullable = false, updatable = false)
    private Long quantity;

    /**
     * Current status of the reservation.
     * Uses @Enumerated(EnumType.STRING) to store as VARCHAR in database.
     * 
     * Valid Values: ACTIVE, RELEASED, EXPIRED, CANCELLED
     * 
     * State Machine:
     * - ACTIVE: Initial state, stock is reserved
     * - ACTIVE → RELEASED: Explicit release (order cancelled)
     * - ACTIVE → EXPIRED: Automatic expiration (TTL elapses)
     * - Transitions to RELEASED/EXPIRED are terminal
     * 
     * Updated via:
     * - release(LocalDateTime) → RELEASED
     * - expire(LocalDateTime) → EXPIRED
     */
    @NotNull(message = "Status cannot be null")
    @Column(name = "status", nullable = false, length = 20)
    @Enumerated(EnumType.STRING)
    private ReservationStatus status;

    /**
     * Timestamp when this reservation expires if not released.
     * Immutable: set at creation as now + TTL.
     * Computed by service layer: expirationTime = createdAt + RESERVATION_TTL_MINUTES
     * 
     * Used by:
     * 1. Expiration job: query WHERE expirationTime <= NOW()
     * 2. API responses: returned to client for tracking
     * 3. Validation logic: to determine if reservation is already expired
     * 
     * Index: idx_reservation_expiration_time for efficient expiration queries.
     */
    @NotNull(message = "Expiration time cannot be null")
    @Column(name = "expiration_time", nullable = false, updatable = false)
    private LocalDateTime expirationTime;

    /**
     * Timestamp when reservation was created.
     * Set automatically via @PrePersist lifecycle hook.
     * Immutable: updatable = false prevents modification.
     * 
     * Used for:
     * 1. Audit trails and history tracking
     * 2. Analytics (e.g., "reservations created today")
     * 3. Calculating TTL: expirationTime - createdAt should equal configured TTL
     * 4. Database queries: time-range searches for reservation analysis
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Timestamp when reservation was released (transitioned to RELEASED status).
     * Null while reservation is ACTIVE or EXPIRED.
     * Set via release(LocalDateTime) method.
     * 
     * Used for:
     * 1. Audit trail: when was the stock restored?
     * 2. SLA tracking: how long was stock held?
     * 3. Analytics: reservation processing time
     */
    @Column(name = "released_at")
    private LocalDateTime releasedAt;

    /**
     * Timestamp when reservation expired (transitioned to EXPIRED status).
     * Null while reservation is ACTIVE or RELEASED.
     * Set via expire(LocalDateTime) method by expiration job.
     * 
     * Used for:
     * 1. Audit trail: when did TTL elapse?
     * 2. Analytics: tracking expiration frequency
     * 3. Debugging: understanding reservation lifecycle
     */
    @Column(name = "expired_at")
    private LocalDateTime expiredAt;

    /**
     * Idempotency key for deduplication on retry.
     * Optional: null if client doesn't provide idempotency key.
     * 
     * Used for:
     * 1. Idempotent reservation creation: retry with same key returns same result
     * 2. Preventing duplicate reservations from network retries
     * 3. Client tracking: linking retries to original request
     * 
     * Index: idx_reservation_idempotency_key for quick deduplication lookup.
     * Scope: Unique per (idempotency_key, order_id) pair to allow multiple orders.
     * 
     * TTL: Idempotency keys retained for INVENTORY_IDEMPOTENCY_KEY_RETENTION_DAYS (default 1 day).
     */
    @Column(name = "idempotency_key", length = 100)
    private String idempotencyKey;

    /**
     * JPA lifecycle hook: automatically set timestamps on persist.
     */
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    /**
     * Gets human-readable status label.
     * Delegates to enum method for localization support.
     * 
     * @return display label for current status
     */
    public String getStatusLabel() {
        return this.status != null ? this.status.getLabel() : "Unknown";
    }

    /**
     * Checks if reservation has expired based on current time.
     * Returns true if current time is at or past expiration time.
     * 
     * Algorithm:
     * IF status is not ACTIVE: return false (already expired or released)
     * ELSE: return expirationTime <= now
     * 
     * Precondition: expirationTime must be set
     * 
     * @param now the current time for expiration check
     * @return true if reservation has expired
     */
    public boolean isExpired(LocalDateTime now) {
        if (this.status != ReservationStatus.ACTIVE) {
            return false;
        }
        return this.expirationTime.isBefore(now) || this.expirationTime.isEqual(now);
    }

    /**
     * Checks if reservation can be released.
     * Release is allowed only for ACTIVE or already-RELEASED reservations.
     * RELEASED is allowed for idempotent semantics (idempotent retry returns success).
     * EXPIRED and CANCELLED reservations cannot be released.
     * 
     * @return true if release is allowed
     */
    public boolean canBeReleased() {
        return this.status != null && this.status.canBeReleased();
    }

    /**
     * Checks if reservation can transition to EXPIRED.
     * Only ACTIVE reservations can expire.
     * 
     * @return true if expiration is allowed
     */
    public boolean canBeExpired() {
        return this.status != null && this.status.canExpire();
    }

    /**
     * Transitions reservation from ACTIVE to RELEASED.
     * Updates status and records release timestamp.
     * 
     * Precondition: status == ACTIVE (checked by caller)
     * Postcondition: status == RELEASED, releasedAt set
     * 
     * Note: This method does NOT update the Product entity.
     * Stock restoration is handled by ReservationService.
     * 
     * @param releasedTime the timestamp when release occurred
     * @throws IllegalStateException if reservation is not ACTIVE
     */
    public void release(LocalDateTime releasedTime) {
        if (this.status != ReservationStatus.ACTIVE) {
            throw new IllegalStateException(
                String.format(
                    "Cannot release reservation %s; status is %s (not ACTIVE)",
                    this.id, this.status
                )
            );
        }
        this.status = ReservationStatus.RELEASED;
        this.releasedAt = releasedTime;
    }

    /**
     * Transitions reservation from ACTIVE to EXPIRED.
     * Updates status and records expiration timestamp.
     * 
     * Precondition: status == ACTIVE (checked by caller)
     * Postcondition: status == EXPIRED, expiredAt set
     * 
     * Note: This method does NOT update the Product entity.
     * Stock restoration is handled by ReservationExpirationScheduler.
     * 
     * @param expiredTime the timestamp when expiration occurred
     * @throws IllegalStateException if reservation is not ACTIVE
     */
    public void expire(LocalDateTime expiredTime) {
        if (this.status != ReservationStatus.ACTIVE) {
            throw new IllegalStateException(
                String.format(
                    "Cannot expire reservation %s; status is %s (not ACTIVE)",
                    this.id, this.status
                )
            );
        }
        this.status = ReservationStatus.EXPIRED;
        this.expiredAt = expiredTime;
    }

    /**
     * Validates that the reservation is in a valid state.
     * Performs sanity checks for consistency.
     * 
     * Checks:
     * 1. Status must not be null
     * 2. Quantity must be positive
     * 3. Order ID must not be null
     * 4. Product must not be null
     * 5. Created timestamp must be set
     * 6. Expiration time must be set
     * 7. Expiration time must be >= creation time
     * 8. Released/Expired timestamps must be consistent with status
     * 
     * @throws IllegalStateException if any validation fails
     */
    public void validate() {
        if (this.status == null) {
            throw new IllegalStateException(
                String.format("Reservation %s has null status", this.id)
            );
        }

        if (this.quantity == null || this.quantity <= 0) {
            throw new IllegalStateException(
                String.format("Reservation %s has invalid quantity: %s", this.id, this.quantity)
            );
        }

        if (this.orderId == null) {
            throw new IllegalStateException(
                String.format("Reservation %s has null order ID", this.id)
            );
        }

        if (this.product == null) {
            throw new IllegalStateException(
                String.format("Reservation %s has null product", this.id)
            );
        }

        if (this.createdAt == null) {
            throw new IllegalStateException(
                String.format("Reservation %s has null created_at", this.id)
            );
        }

        if (this.expirationTime == null) {
            throw new IllegalStateException(
                String.format("Reservation %s has null expiration_time", this.id)
            );
        }

        if (this.expirationTime.isBefore(this.createdAt)) {
            throw new IllegalStateException(
                String.format(
                    "Reservation %s has expiration_time (%s) before created_at (%s)",
                    this.id, this.expirationTime, this.createdAt
                )
            );
        }

        if (this.status == ReservationStatus.RELEASED && this.releasedAt == null) {
            throw new IllegalStateException(
                String.format("Reservation %s is RELEASED but released_at is null", this.id)
            );
        }

        if (this.status == ReservationStatus.EXPIRED && this.expiredAt == null) {
            throw new IllegalStateException(
                String.format("Reservation %s is EXPIRED but expired_at is null", this.id)
            );
        }

        if (this.status == ReservationStatus.ACTIVE && this.releasedAt != null) {
            throw new IllegalStateException(
                String.format("Reservation %s is ACTIVE but has released_at set", this.id)
            );
        }

        if (this.status == ReservationStatus.ACTIVE && this.expiredAt != null) {
            throw new IllegalStateException(
                String.format("Reservation %s is ACTIVE but has expired_at set", this.id)
            );
        }
    }
}
