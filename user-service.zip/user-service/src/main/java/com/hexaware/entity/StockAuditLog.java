package com.hexaware.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * StockAuditLog entity for tracking all stock operations.
 * 
 * This entity maintains a complete audit trail of every stock modification:
 * - Reservations (RESERVE operation)
 * - Releases (RELEASE operation)
 * - Expirations (EXPIRE operation)
 * - Bulk updates (BULK_UPDATE operation)
 * 
 * Each log entry captures before/after stock levels, enabling:
 * 1. Stock reconciliation: detect discrepancies by replaying all operations
 * 2. Compliance auditing: prove every stock change was authorized and logged
 * 3. Debugging: trace root cause of stock inconsistencies
 * 4. Analytics: understand stock level trends and patterns
 * 5. Forensics: answer "who changed what and when?"
 * 
 * Audit Trail Entry Points:
 * - ReservationService.createReservation() → logs RESERVE operation
 * - ReservationReleaseService.releaseReservation() → logs RELEASE operation
 * - ReservationExpirationScheduler.processExpiredReservations() → logs EXPIRE operation
 * - StockUpdateService.bulkUpdateStock() → logs BULK_UPDATE operation
 * 
 * Operation Types:
 * - RESERVE: Quantity reserved for an order (available stock decreased)
 * - RELEASE: Quantity released from an order (available stock increased)
 * - EXPIRE: Quantity expired from a reservation (available stock increased)
 * - BULK_UPDATE: Total stock adjusted (available stock recalculated)
 * 
 * Indexes (for efficient queries):
 * - idx_stock_audit_log_product_id: for querying operation history for a product
 * - idx_stock_audit_log_executed_at: for time-range queries on operations
 * 
 * Immutability:
 * - All fields are immutable (updatable = false)
 * - Once created, audit log entries cannot be modified or deleted
 * - This ensures audit trail integrity and non-repudiation
 * 
 * Cascade Behavior:
 * - ON DELETE CASCADE: if product is deleted, its audit logs are also deleted
 * - This ensures clean data cleanup without orphaned audit records
 * - Note: In practice, products are rarely deleted; cascading is for data consistency
 * 
 * Requirements: 8.1, 8.3 (Audit logging for stock operations)
 */
@Entity
@Table(
    name = "stock_audit_log",
    indexes = {
        @Index(name = "idx_stock_audit_log_product_id", columnList = "product_id"),
        @Index(name = "idx_stock_audit_log_executed_at", columnList = "executed_at")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StockAuditLog {

    /**
     * Unique audit log record identifier (UUID, primary key).
     * Generated server-side using PostgreSQL's gen_random_uuid().
     * Used to uniquely identify each audit log entry across the system.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "UUID")
    private UUID id;

    /**
     * Product being operated on via ManyToOne relationship.
     * Cascade delete: if product is deleted, its audit logs are also deleted.
     * Lazy loading: audit logs loaded only when explicitly queried.
     * 
     * Database FK: REFERENCES products(id) ON DELETE CASCADE
     * - CASCADE ensures orphaned audit logs are cleaned up when products are deleted
     * - This is a safety measure; in practice products are rarely deleted
     * 
     * Immutable: updatable = false prevents accidental reassignment.
     */
    @NotNull(message = "Product cannot be null")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false, updatable = false, foreignKey = @ForeignKey(name = "fk_stock_audit_log_product"))
    private Product product;

    /**
     * Type of stock operation being logged.
     * Uses @Enumerated(EnumType.STRING) to store as VARCHAR in database.
     * 
     * Valid Operation Types:
     * - RESERVE: Stock reserved for an order (quantity_change < 0)
     * - RELEASE: Stock released back to available (quantity_change > 0)
     * - EXPIRE: Stock released due to reservation expiration (quantity_change > 0)
     * - BULK_UPDATE: Total stock adjusted via bulk update (quantity_change can be +/-)
     * 
     * Used for:
     * 1. Filtering: "show me all RESERVE operations for this product"
     * 2. Analytics: "what percentage of reservations expire vs release?"
     * 3. Reconciliation: "verify all BULK_UPDATE operations were authorized"
     * 4. Root cause analysis: "trace the sequence of operations"
     * 
     * Immutable: set once at log creation.
     */
    @NotNull(message = "Operation type cannot be null")
    @Column(name = "operation_type", nullable = false, length = 20, updatable = false)
    @Enumerated(EnumType.STRING)
    private StockOperationType operationType;

    /**
     * Change in available stock as a result of this operation.
     * Can be positive (stock released) or negative (stock reserved).
     * 
     * Examples:
     * - RESERVE with quantity 10: quantity_change = -10
     * - RELEASE with quantity 10: quantity_change = +10
     * - EXPIRE with quantity 5: quantity_change = +5
     * - BULK_UPDATE from 100 to 120 units: quantity_change = +20 (if no reservations change)
     * 
     * Used for:
     * 1. Reconciliation: sum of all quantity_changes should match (current_available - initial_available)
     * 2. Analytics: "how much stock has been reserved today?"
     * 3. Debugging: identify which operations caused stock discrepancies
     * 
     * Immutable: set once at log creation.
     * Cannot be null (can be 0, but must be set).
     */
    @NotNull(message = "Quantity change cannot be null")
    @Column(name = "quantity_change", nullable = false, updatable = false)
    private Long quantityChange;

    /**
     * Available stock snapshot BEFORE this operation.
     * Captures the state before modification.
     * 
     * Used for:
     * 1. Reconciliation: verify quantity_change calculation
     * 2. Debugging: understand stock state evolution
     * 3. Analytics: track available stock trend
     * 4. Root cause analysis: identify when stock fell below threshold
     * 
     * Immutable: set once at log creation.
     * Must be >= 0 per business rules.
     */
    @NotNull(message = "Available stock before cannot be null")
    @Column(name = "available_stock_before", nullable = false, updatable = false)
    private Long availableStockBefore;

    /**
     * Available stock snapshot AFTER this operation.
     * Captures the state after modification.
     * 
     * Invariant: availableStockAfter = availableStockBefore + quantityChange
     * 
     * Used for:
     * 1. Verification: cross-check with before + change
     * 2. Debugging: confirm operation had intended effect
     * 3. Analytics: track current available stock
     * 4. Historical queries: "what was available stock at this exact moment?"
     * 
     * Immutable: set once at log creation.
     * Must be >= 0 per business rules.
     */
    @NotNull(message = "Available stock after cannot be null")
    @Column(name = "available_stock_after", nullable = false, updatable = false)
    private Long availableStockAfter;

    /**
     * Exact timestamp when this operation was executed.
     * Immutable: set once at log creation.
     * Precision: millisecond level (Java LocalDateTime).
     * 
     * Used for:
     * 1. Chronological ordering: recreate exact sequence of operations
     * 2. Time-range queries: "what changed between 9 AM and 5 PM?"
     * 3. Performance analysis: identify when highest activity occurred
     * 4. Compliance: prove audit log entries are in correct order
     * 5. Debugging: correlate with application logs by timestamp
     * 
     * Index: idx_stock_audit_log_executed_at for efficient time-based queries.
     */
    @NotNull(message = "Executed at timestamp cannot be null")
    @Column(name = "executed_at", nullable = false, updatable = false)
    private LocalDateTime executedAt;

    /**
     * Request identifier for tracing operations back to originating request.
     * Optional: null for operations that don't have a request context (e.g., scheduled expiration).
     * 
     * Used for:
     * 1. Correlation: link audit log to application logs using X-Request-ID header
     * 2. Tracing: trace full request journey across microservices
     * 3. Debugging: answer "which API call caused this stock change?"
     * 4. User support: identify the exact order that triggered a stock operation
     * 5. Compliance: prove operation was requested by authorized user
     * 
     * Typical values:
     * - UUID (X-Request-ID from API request)
     * - "SCHEDULED-EXPIRATION-<timestamp>" (for expiration job)
     * - "BULK-UPDATE-<batch-id>" (for bulk operations)
     * 
     * Maximum length 100 to accommodate various ID formats.
     * Immutable: set once at log creation.
     */
    @Column(name = "request_id", length = 100, updatable = false)
    private String requestId;

    /**
     * JPA lifecycle hook: automatically set audit timestamp on persist.
     * If executedAt is not set, default to now().
     */
    @PrePersist
    protected void onCreate() {
        if (this.executedAt == null) {
            this.executedAt = LocalDateTime.now();
        }
    }

    /**
     * Validates the audit log record for consistency.
     * Performs sanity checks to ensure data integrity.
     * 
     * Checks:
     * 1. ID must be set (should be auto-generated)
     * 2. Product must not be null
     * 3. Operation type must not be null
     * 4. Quantity change must not be null
     * 5. Available stock before must not be null and >= 0
     * 6. Available stock after must not be null and >= 0
     * 7. Executed at timestamp must be set
     * 8. Invariant: availableStockAfter = availableStockBefore + quantityChange
     * 
     * @throws IllegalStateException if any validation fails
     */
    public void validate() {
        if (this.id == null) {
            throw new IllegalStateException("Audit log record ID is null");
        }

        if (this.product == null) {
            throw new IllegalStateException("Audit log record has null product");
        }

        if (this.operationType == null) {
            throw new IllegalStateException("Audit log record has null operation_type");
        }

        if (this.quantityChange == null) {
            throw new IllegalStateException("Audit log record has null quantity_change");
        }

        if (this.availableStockBefore == null || this.availableStockBefore < 0) {
            throw new IllegalStateException(
                String.format(
                    "Audit log record has invalid available_stock_before: %s",
                    this.availableStockBefore
                )
            );
        }

        if (this.availableStockAfter == null || this.availableStockAfter < 0) {
            throw new IllegalStateException(
                String.format(
                    "Audit log record has invalid available_stock_after: %s",
                    this.availableStockAfter
                )
            );
        }

        if (this.executedAt == null) {
            throw new IllegalStateException("Audit log record has null executed_at");
        }

        // Verify invariant: after = before + change
        long expectedAfter = this.availableStockBefore + this.quantityChange;
        if (!this.availableStockAfter.equals(expectedAfter)) {
            throw new IllegalStateException(
                String.format(
                    "Audit log invariant violated: availableStockAfter (%d) != availableStockBefore (%d) + quantityChange (%d) [expected %d]",
                    this.availableStockAfter, this.availableStockBefore, this.quantityChange, expectedAfter
                )
            );
        }
    }
}
