package com.hexaware.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Product entity representing inventory items with stock tracking.
 * 
 * Implements stock invariant: totalStock = availableStock + reservedStock
 * Uses optimistic locking with @Version annotation for concurrent updates.
 * Supports pessimistic locking via custom repository queries (SELECT ... FOR UPDATE NOWAIT).
 * 
 * Stock Invariant Constraints (enforced at both database and application level):
 * - total_stock > 0: Product must always have positive total stock
 * - available_stock >= 0: Available stock cannot be negative
 * - reserved_stock >= 0: Reserved stock cannot be negative
 * - total_stock = available_stock + reserved_stock: Stock conservation invariant
 */
@Entity
@Table(
    name = "products",
    indexes = {
        @Index(name = "idx_product_sku", columnList = "sku", unique = true),
        @Index(name = "idx_product_updated_at", columnList = "updated_at")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product {

    /**
     * Unique product identifier (UUID, primary key).
     * Generated server-side using PostgreSQL's gen_random_uuid().
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "UUID")
    private UUID id;

    /**
     * Stock Keeping Unit - unique product code for external systems.
     * Used for product lookup by external services.
     */
    @Column(name = "sku", nullable = false, unique = true, length = 100)
    private String sku;

    /**
     * Human-readable product name.
     */
    @Column(name = "name", nullable = false, length = 255)
    private String name;

    /**
     * Free-text remark / notes about the product.
     * Mandatory (NOT NULL) at the database level; defaults to an empty string
     * for rows that existed before this column was introduced (see migration
     * V4__Add_remark_to_products.sql).
     */
    @Column(name = "remark", nullable = false, length = 500)
    private String remark;

    /**
     * Total stock quantity = availableStock + reservedStock.
     * Always > 0 per database constraint.
     * Represents the physical inventory count.
     */
    @Column(name = "total_stock", nullable = false)
    @Positive(message = "Total stock must be positive")
    private Long totalStock;

    /**
     * Stock quantity reserved by active orders.
     * Incremented when reservations are created.
     * Decremented when reservations are released or expire.
     * Always >= 0 per database constraint.
     */
    @Column(name = "reserved_stock", nullable = false)
    private Long reservedStock;

    /**
     * Stock quantity available for new orders.
     * Calculated as: availableStock = totalStock - reservedStock
     * Always >= 0 per database constraint.
     * Decremented when reservations are created.
     * Incremented when reservations are released or expire.
     */
    @Column(name = "available_stock", nullable = false)
    private Long availableStock;

    /**
     * Version field for optimistic locking.
     * Incremented on every update.
     * If two transactions attempt concurrent updates, the second will fail with OptimisticLockingFailureException.
     * This prevents lost updates in high-concurrency scenarios.
     * 
     * Separate from lock_version field:
     * - version: Used for optimistic locking (JPA @Version)
     * - lock_version: Used for pessimistic locking (database SELECT ... FOR UPDATE)
     */
    @Version
    @Column(name = "lock_version")
    private Long lockVersion;

    /**
     * Timestamp when product was last updated (stock modified, etc).
     * Updated automatically via @PreUpdate lifecycle hook.
     * Used for performance optimization and change tracking.
     */
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    /**
     * Timestamp when product was created.
     * Set once at creation, never updated.
     * Marked as immutable (updatable = false) in database.
     * Set automatically via @PrePersist lifecycle hook.
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * JPA lifecycle hook: automatically set timestamps on persist.
     */
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * JPA lifecycle hook: automatically update modification timestamp.
     */
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Validates the stock invariant: totalStock = availableStock + reservedStock.
     * 
     * This validation is performed:
     * 1. At the database level via CHECK constraint
     * 2. At the application level via this method (defensive programming)
     * 
     * Should be called after any stock modification to ensure consistency.
     * 
     * @throws IllegalStateException if invariant is violated
     */
    public void validateStockInvariant() {
        long calculatedTotal = this.availableStock + this.reservedStock;
        if (!this.totalStock.equals(calculatedTotal)) {
            throw new IllegalStateException(
                String.format(
                    "Stock invariant violated for product %s: totalStock (%d) != availableStock (%d) + reservedStock (%d)",
                    this.id, this.totalStock, this.availableStock, this.reservedStock
                )
            );
        }

        if (this.availableStock < 0) {
            throw new IllegalStateException(
                String.format("Available stock cannot be negative for product %s: %d", this.id, this.availableStock)
            );
        }

        if (this.reservedStock < 0) {
            throw new IllegalStateException(
                String.format("Reserved stock cannot be negative for product %s: %d", this.id, this.reservedStock)
            );
        }

        if (this.totalStock <= 0) {
            throw new IllegalStateException(
                String.format("Total stock must be positive for product %s: %d", this.id, this.totalStock)
            );
        }
    }

    /**
     * Reserves stock for a new order.
     * Decrements availableStock and increments reservedStock atomically.
     * 
     * Precondition: quantity <= availableStock (checked by caller/service layer)
     * Postcondition: stock invariant maintained
     * 
     * @param quantity number of units to reserve
     * @throws IllegalArgumentException if quantity is invalid
     * @throws IllegalStateException if stock invariant would be violated
     */
    public void reserveStock(Long quantity) {
        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("Reservation quantity must be positive: " + quantity);
        }

        if (quantity > this.availableStock) {
            throw new IllegalStateException(
                String.format(
                    "Cannot reserve %d units; only %d available for product %s",
                    quantity, this.availableStock, this.id
                )
            );
        }

        this.availableStock -= quantity;
        this.reservedStock += quantity;

        // Validate invariant after modification
        this.validateStockInvariant();
    }

    /**
     * Releases reserved stock (e.g., when order is cancelled or reservation expires).
     * Increments availableStock and decrements reservedStock atomically.
     * 
     * Precondition: quantity <= reservedStock (checked by caller/service layer)
     * Postcondition: stock invariant maintained
     * 
     * @param quantity number of units to release
     * @throws IllegalArgumentException if quantity is invalid
     * @throws IllegalStateException if stock invariant would be violated
     */
    public void releaseStock(Long quantity) {
        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("Release quantity must be positive: " + quantity);
        }

        if (quantity > this.reservedStock) {
            throw new IllegalStateException(
                String.format(
                    "Cannot release %d units; only %d reserved for product %s",
                    quantity, this.reservedStock, this.id
                )
            );
        }

        this.availableStock += quantity;
        this.reservedStock -= quantity;

        // Validate invariant after modification
        this.validateStockInvariant();
    }

    /**
     * Updates the total stock quantity.
     * Recalculates availableStock to maintain invariant.
     * 
     * Used for bulk stock updates (restocking operations).
     * Ensures invariant: availableStock_new = newTotalStock - reservedStock
     * 
     * Precondition: newTotalStock > 0 and newTotalStock >= reservedStock
     * Postcondition: stock invariant maintained
     * 
     * @param newTotalStock the new total stock quantity
     * @throws IllegalArgumentException if quantity is invalid
     * @throws IllegalStateException if stock invariant would be violated
     */
    public void updateTotalStock(Long newTotalStock) {
        if (newTotalStock == null || newTotalStock <= 0) {
            throw new IllegalArgumentException("Total stock must be positive: " + newTotalStock);
        }

        if (newTotalStock < this.reservedStock) {
            throw new IllegalStateException(
                String.format(
                    "Cannot set total stock to %d; %d units already reserved for product %s",
                    newTotalStock, this.reservedStock, this.id
                )
            );
        }

        this.totalStock = newTotalStock;
        this.availableStock = newTotalStock - this.reservedStock;

        // Validate invariant after modification
        this.validateStockInvariant();
    }
}
