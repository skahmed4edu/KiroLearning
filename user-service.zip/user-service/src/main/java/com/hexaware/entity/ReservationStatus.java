package com.hexaware.entity;

/**
 * Enum representing the lifecycle states of a reservation.
 * 
 * State Transitions:
 * - ACTIVE: Initial state, stock is reserved
 * - ACTIVE → RELEASED: When order is cancelled or stock is released manually
 * - ACTIVE → EXPIRED: When TTL elapses (automatic via background job)
 * - ACTIVE → CANCELLED: Reserved for future use (not currently used)
 * - RELEASED: Terminal state, reservation was successfully released
 * - EXPIRED: Terminal state, reservation expired without being released
 * - CANCELLED: Terminal state, reservation was cancelled
 * 
 * Idempotency Note:
 * - Releasing a RELEASED reservation is idempotent (returns success)
 * - Releasing EXPIRED or CANCELLED reservations returns error
 * - This allows safe retry logic for order cancellations
 */
public enum ReservationStatus {
    /**
     * Reservation is active and stock is reserved.
     * This is the initial state of every reservation.
     * Can transition to RELEASED or EXPIRED.
     */
    ACTIVE("Active"),

    /**
     * Reservation was released, stock was restored.
     * This is a terminal state reached via explicit release.
     * No further transitions possible.
     */
    RELEASED("Released"),

    /**
     * Reservation expired due to TTL.
     * This is a terminal state reached automatically by expiration job.
     * Stock was automatically restored upon expiration.
     * No further transitions possible.
     */
    EXPIRED("Expired"),

    /**
     * Reservation was cancelled.
     * This is a terminal state reserved for future use.
     * Currently not used in the implementation.
     * No further transitions possible.
     */
    CANCELLED("Cancelled");

    private final String label;

    ReservationStatus(String label) {
        this.label = label;
    }

    /**
     * Gets human-readable label for this status.
     * 
     * @return display label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Checks if this status represents a terminal state.
     * Terminal states cannot transition further.
     * 
     * @return true if status is terminal (RELEASED, EXPIRED, CANCELLED)
     */
    public boolean isTerminal() {
        return this == RELEASED || this == EXPIRED || this == CANCELLED;
    }

    /**
     * Checks if this status allows release.
     * Only ACTIVE reservations can be released.
     * RELEASED status is idempotent (already released).
     * 
     * @return true if can be released
     */
    public boolean canBeReleased() {
        return this == ACTIVE || this == RELEASED;
    }

    /**
     * Checks if this status allows expiration.
     * Only ACTIVE reservations can expire.
     * 
     * @return true if can expire
     */
    public boolean canExpire() {
        return this == ACTIVE;
    }
}
