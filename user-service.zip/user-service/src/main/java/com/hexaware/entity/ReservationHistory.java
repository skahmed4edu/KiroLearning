package com.hexaware.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * ReservationHistory entity for tracking all status transitions of reservations.
 * 
 * This entity maintains a complete audit trail of every status change in a reservation's lifecycle.
 * Each record captures the before and after state, enabling full historical analysis and compliance auditing.
 * 
 * Key Responsibilities:
 * 1. Record every reservation status transition (ACTIVE → RELEASED, ACTIVE → EXPIRED, etc.)
 * 2. Capture the changed_at timestamp for each transition
 * 3. Store the reason for transition (user action, automatic expiration, etc.)
 * 4. Enable audit compliance by providing immutable change history
 * 5. Support historical analysis (average reservation lifetime, expiration rates, etc.)
 * 
 * Audit Trail Entry Points:
 * - ReservationService.createReservation() → logs ACTIVE creation
 * - ReservationReleaseService.releaseReservation() → logs ACTIVE → RELEASED transition
 * - ReservationExpirationScheduler.processExpiredReservations() → logs ACTIVE → EXPIRED transition
 * 
 * Indexes (for efficient queries):
 * - idx_reservation_history_reservation_id: for querying history of specific reservation
 * - idx_reservation_history_changed_at: for time-range queries on changes
 * 
 * Immutability:
 * - All fields are immutable (updatable = false)
 * - Once created, history records cannot be modified
 * - This ensures audit trail integrity
 * 
 * Cascade Behavior:
 * - ON DELETE CASCADE: if reservation is deleted, its history is also deleted
 * - This ensures clean data cleanup without orphaned history records
 * 
 * Requirements: 8.1, 8.3 (Audit logging for stock operations)
 */
@Entity
@Table(
    name = "reservation_history",
    indexes = {
        @Index(name = "idx_reservation_history_reservation_id", columnList = "reservation_id"),
        @Index(name = "idx_reservation_history_changed_at", columnList = "changed_at")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReservationHistory {

    /**
     * Unique history record identifier (UUID, primary key).
     * Generated server-side using PostgreSQL's gen_random_uuid().
     * Used to identify specific history records in queries or exports.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "UUID")
    private UUID id;

    /**
     * Reservation being tracked via ManyToOne relationship.
     * Cascade delete: if reservation is deleted, this history record is also deleted.
     * Lazy loading: history records loaded only when explicitly queried.
     * 
     * Database FK: REFERENCES reservations(id) ON DELETE CASCADE
     * - CASCADE ensures orphaned history records are cleaned up
     * - No RESTRICT: we want to allow deletion of old reservations and their history
     * 
     * Immutable: updatable = false prevents accidental reassignment.
     */
    @NotNull(message = "Reservation cannot be null")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "reservation_id", nullable = false, updatable = false, foreignKey = @ForeignKey(name = "fk_reservation_history_reservation"))
    private Reservation reservation;

    /**
     * Order identifier from the reservation (denormalized for easy analysis without fetching Reservation).
     * Immutable: set once at creation.
     * This avoids the need to join to Reservation entity just to get the order ID.
     * 
     * Used for:
     * 1. Quick lookup: find all history for an order across multiple reservations
     * 2. Analytics: analyze order processing patterns
     * 3. Customer support: retrieve full order history without joins
     */
    @NotNull(message = "Order ID cannot be null")
    @Column(name = "order_id", nullable = false, updatable = false, columnDefinition = "UUID")
    private UUID orderId;

    /**
     * Product identifier from the reservation (denormalized for easy analysis).
     * Immutable: set once at creation.
     * Avoids the need to join to Reservation → Product entities.
     * 
     * Used for:
     * 1. Product-level analytics: how many times did this product hit zero stock?
     * 2. Inventory reports: track all reservations for a product over time
     * 3. Dashboard queries: quick visibility into product-specific reservation patterns
     */
    @NotNull(message = "Product ID cannot be null")
    @Column(name = "product_id", nullable = false, updatable = false, columnDefinition = "UUID")
    private UUID productId;

    /**
     * Quantity that was reserved (denormalized from Reservation for historical accuracy).
     * Immutable: set once at creation.
     * Important for historical accuracy: the actual quantity at the time of transition.
     * 
     * Useful for:
     * 1. Audit verification: confirm that stock was properly adjusted
     * 2. Historical analysis: what were typical order sizes?
     * 3. Stock reconciliation: verify total quantity changes match reservation quantities
     */
    @Positive(message = "Quantity must be positive")
    @Column(name = "quantity", nullable = false, updatable = false)
    private Long quantity;

    /**
     * Status before the transition (e.g., ACTIVE).
     * Immutable: recorded at transition time.
     * Stored as VARCHAR to preserve exact status value at that moment.
     * 
     * Example transitions:
     * - null → ACTIVE (creation record may have null oldStatus)
     * - ACTIVE → RELEASED (manual release)
     * - ACTIVE → EXPIRED (automatic expiration)
     * - ACTIVE → CANCELLED (order cancellation)
     * 
     * Maximum length 20 to match ReservationStatus enum values.
     */
    @Column(name = "old_status", length = 20, updatable = false)
    private String oldStatus;

    /**
     * Status after the transition (e.g., RELEASED).
     * Immutable: recorded at transition time.
     * Stored as VARCHAR.
     * 
     * Together with oldStatus, describes the exact state change that occurred.
     */
    @NotNull(message = "New status cannot be null")
    @Column(name = "new_status", nullable = false, length = 20, updatable = false)
    private String newStatus;

    /**
     * Exact timestamp when this status transition occurred.
     * Immutable: set once at creation.
     * Used for:
     * 1. Chronological ordering of history records
     * 2. Time-range queries: "what changed between midnight and noon?"
     * 3. SLA analysis: how long was stock held?
     * 4. Performance analysis: when did expirations spike?
     * 
     * Index: idx_reservation_history_changed_at for efficient time-based queries.
     */
    @NotNull(message = "Changed at timestamp cannot be null")
    @Column(name = "changed_at", nullable = false, updatable = false)
    private LocalDateTime changedAt;

    /**
     * Reason for the status transition.
     * Immutable: set once at creation.
     * Examples:
     * - "Created for order placement" (initial creation)
     * - "Released due to order cancellation" (manual release)
     * - "Expired due to TTL elapse" (automatic expiration)
     * - "Cancelled due to refund" (order cancellation)
     * - "System release during bulk stock update" (edge case)
     * 
     * Used for:
     * 1. Audit compliance: explain every change
     * 2. Debugging: understand why a state transition occurred
     * 3. Analytics: categorize transitions by reason (release vs expiration)
     * 4. Customer service: explain to users what happened to their order
     * 
     * Nullable: legacy records may not have a reason recorded.
     * Maximum length 255 to allow detailed explanations.
     */
    @Column(name = "reason", length = 255, updatable = false)
    private String reason;

    /**
     * JPA lifecycle hook: automatically set audit timestamp on persist.
     * If changedAt is not set, default to now().
     */
    @PrePersist
    protected void onCreate() {
        if (this.changedAt == null) {
            this.changedAt = LocalDateTime.now();
        }
    }

    /**
     * Validates the history record for consistency.
     * Performs sanity checks to ensure data integrity.
     * 
     * Checks:
     * 1. ID must be set (should be auto-generated)
     * 2. Reservation must not be null
     * 3. Order ID must not be null
     * 4. Product ID must not be null
     * 5. Quantity must be positive
     * 6. New status must not be null
     * 7. Changed at timestamp must be set
     * 8. oldStatus and newStatus must be different (except for creation)
     * 
     * @throws IllegalStateException if any validation fails
     */
    public void validate() {
        if (this.id == null) {
            throw new IllegalStateException("History record ID is null");
        }

        if (this.reservation == null) {
            throw new IllegalStateException("History record has null reservation");
        }

        if (this.orderId == null) {
            throw new IllegalStateException("History record has null order ID");
        }

        if (this.productId == null) {
            throw new IllegalStateException("History record has null product ID");
        }

        if (this.quantity == null || this.quantity <= 0) {
            throw new IllegalStateException(
                String.format("History record has invalid quantity: %s", this.quantity)
            );
        }

        if (this.newStatus == null || this.newStatus.isEmpty()) {
            throw new IllegalStateException("History record has null or empty new_status");
        }

        if (this.changedAt == null) {
            throw new IllegalStateException("History record has null changed_at");
        }

        // If both oldStatus and newStatus are set, they should be different
        if (this.oldStatus != null && this.oldStatus.equals(this.newStatus)) {
            throw new IllegalStateException(
                String.format(
                    "History record for reservation %s has identical oldStatus and newStatus: %s",
                    this.reservation.getId(), this.oldStatus
                )
            );
        }
    }
}
