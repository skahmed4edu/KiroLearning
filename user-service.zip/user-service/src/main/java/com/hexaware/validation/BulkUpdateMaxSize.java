package com.hexaware.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

/**
 * Custom JSR-303 validator annotation for bulk update batch size validation.
 * 
 * Validates that a List<BulkStockUpdateEntry> contains at most the specified
 * maximum number of items. This prevents batch operations from exceeding
 * system capacity limits.
 * 
 * Usage:
 * @BulkUpdateMaxSize(max = 1000)
 * private List<BulkStockUpdateEntry> updates;
 * 
 * Default maximum is 1000 products per bulk update request (configurable).
 * 
 * Behavior:
 * - If list is null: validation passes (handled by @NotNull separately)
 * - If list is empty: validation passes (handled by @NotEmpty separately)
 * - If list.size() <= max: validation passes
 * - If list.size() > max: validation fails with configured message
 * 
 * Requirements: 5.2, 5.6
 */
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = BulkUpdateMaxSizeValidator.class)
@Documented
public @interface BulkUpdateMaxSize {
    
    /**
     * Maximum allowed size of the list.
     * 
     * Default: 1000 (can be overridden per usage)
     */
    int max() default 1000;
    
    /**
     * Error message to display when validation fails.
     * 
     * Default message includes the max size limit.
     * Can be overridden in annotation usage.
     */
    String message() default "Bulk update list exceeds maximum size of {max} items";
    
    /**
     * JSR-303 validation groups.
     */
    Class<?>[] groups() default {};
    
    /**
     * JSR-303 payload for clients to assign custom payload objects.
     */
    Class<? extends Payload>[] payload() default {};
}
