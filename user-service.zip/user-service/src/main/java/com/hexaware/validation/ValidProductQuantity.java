package com.hexaware.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

/**
 * Custom JSR-303 validator annotation for product quantity validation.
 * 
 * Validates that a quantity value is positive (> 0).
 * This is applied to all quantity fields in reservation and bulk update operations
 * to ensure invalid quantities (zero, negative) are rejected at the validation layer.
 * 
 * Usage:
 * @ValidProductQuantity
 * private Long quantity;
 * 
 * Behavior:
 * - If value is null: validation passes (handled by @NotNull separately)
 * - If value > 0: validation passes
 * - If value <= 0: validation fails with error message
 * 
 * Note:
 * This is very similar to standard @Positive annotation from jakarta.validation.
 * We provide a custom annotation for consistency with other custom validators
 * and for potential future extensions (e.g., maximum quantity limits).
 * 
 * Constraints:
 * - Minimum: 1 unit
 * - Maximum: Long.MAX_VALUE (very large numbers, constrained by total stock)
 * 
 * Requirements: 5.3, 5.6
 */
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidProductQuantityValidator.class)
@Documented
public @interface ValidProductQuantity {
    
    /**
     * Error message to display when validation fails.
     * 
     * Default message explains that quantity must be positive.
     * Can be overridden in annotation usage.
     */
    String message() default "Product quantity must be positive (greater than 0)";
    
    /**
     * JSR-303 validation groups.
     */
    Class<?>[] groups() default {};
    
    /**
     * JSR-303 payload for clients to assign custom payload objects.
     */
    Class<? extends Payload>[] payload() default {};
}
