package com.hexaware.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Validator implementation for @ValidProductQuantity annotation.
 * 
 * This validator checks that a quantity value is positive (> 0).
 * It's used to validate quantity fields in reservation and bulk update operations.
 * 
 * Logic:
 * 1. If value is null: pass validation (let @NotNull handle it)
 * 2. If value > 0: pass validation
 * 3. If value <= 0: fail validation with message
 * 
 * Supported Types:
 * - Long (primary use case)
 * - Other Number types can also be validated
 * 
 * Performance:
 * - O(1) comparison operation
 * - No database queries or external dependencies
 * - Suitable for all validation scenarios
 * 
 * Requirements: 5.3, 5.6
 */
public class ValidProductQuantityValidator implements ConstraintValidator<ValidProductQuantity, Number> {
    
    /**
     * Initialize the validator.
     * No special initialization needed for this validator.
     * 
     * @param annotation The @ValidProductQuantity annotation instance
     */
    @Override
    public void initialize(ValidProductQuantity annotation) {
        // No initialization needed
    }
    
    /**
     * Validate that the quantity is positive.
     * 
     * @param value The quantity value to validate (may be null)
     * @param context Validation context for adding constraint violations
     * @return true if value is null or value > 0, false if value <= 0
     */
    @Override
    public boolean isValid(Number value, ConstraintValidatorContext context) {
        // Pass validation if value is null (let @NotNull handle it)
        if (value == null) {
            return true;
        }
        
        // Check if value is positive (> 0)
        return value.longValue() > 0;
    }
}
