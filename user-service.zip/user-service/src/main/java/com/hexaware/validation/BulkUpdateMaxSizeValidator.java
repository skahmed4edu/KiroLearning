package com.hexaware.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.List;

/**
 * Validator implementation for @BulkUpdateMaxSize annotation.
 * 
 * This validator checks that a List contains at most the specified maximum
 * number of items. It's used to enforce batch size limits on bulk update operations.
 * 
 * Logic:
 * 1. If list is null: pass validation (other annotations handle null checks)
 * 2. If list.size() <= max: pass validation
 * 3. If list.size() > max: fail validation with message
 * 
 * Performance:
 * - O(1) for null lists
 * - O(1) for size check (list.size() is O(1) for ArrayList)
 * - Minimal overhead suitable for request validation
 * 
 * Requirements: 5.2, 5.6
 */
public class BulkUpdateMaxSizeValidator implements ConstraintValidator<BulkUpdateMaxSize, List<?>> {
    
    private int max;
    
    /**
     * Initialize the validator with the constraint annotation.
     * Extract the max parameter value from the annotation.
     * 
     * Called once per constraint instance during initialization.
     * 
     * @param annotation The @BulkUpdateMaxSize annotation instance
     */
    @Override
    public void initialize(BulkUpdateMaxSize annotation) {
        this.max = annotation.max();
    }
    
    /**
     * Validate that the list size does not exceed the maximum.
     * 
     * @param value The list to validate (may be null)
     * @param context Validation context for adding constraint violations
     * @return true if valid (size <= max), false otherwise
     */
    @Override
    public boolean isValid(List<?> value, ConstraintValidatorContext context) {
        // Pass validation if list is null (let @NotNull handle it)
        if (value == null) {
            return true;
        }
        
        // Check if list size exceeds maximum
        return value.size() <= max;
    }
}
