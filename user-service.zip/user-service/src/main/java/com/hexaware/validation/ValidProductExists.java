package com.hexaware.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

/**
 * Custom JSR-303 validator annotation for product existence validation.
 * 
 * Validates that a Product ID (UUID) exists in the database.
 * This prevents reservation requests and other operations from targeting
 * non-existent products.
 * 
 * Usage:
 * @ValidProductExists
 * private UUID productId;
 * 
 * Behavior:
 * - If value is null: validation passes (handled by @NotNull separately)
 * - If product exists in database: validation passes
 * - If product does not exist: validation fails with error message
 * 
 * Database Interaction:
 * The validator is Spring-aware and can inject repositories to check
 * the database. It queries the ProductRepository to verify existence.
 * 
 * Performance:
 * - Single database query per validation
 * - Uses indexed lookups on product ID (UUID primary key)
 * - Typically < 5ms per validation on reasonably indexed database
 * 
 * Requirements: 5.2, 5.3, 5.6
 */
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidProductExistsValidator.class)
@Documented
public @interface ValidProductExists {
    
    /**
     * Error message to display when product does not exist.
     * 
     * Default message includes the product ID that was not found.
     * Can be overridden in annotation usage.
     */
    String message() default "Product with ID {value} does not exist";
    
    /**
     * JSR-303 validation groups.
     */
    Class<?>[] groups() default {};
    
    /**
     * JSR-303 payload for clients to assign custom payload objects.
     */
    Class<? extends Payload>[] payload() default {};
}
