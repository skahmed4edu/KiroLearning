package com.hexaware.validation;

import com.hexaware.repository.ProductRepository;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Validator implementation for @ValidProductExists annotation.
 * 
 * This validator checks that a product ID (UUID) exists in the database
 * by querying the ProductRepository. Used to validate product references
 * in reservation and bulk update requests.
 * 
 * Logic:
 * 1. If value is null: pass validation (other annotations handle null checks)
 * 2. Query database to check if product exists with given ID
 * 3. If product found: pass validation
 * 4. If product not found: fail validation with message
 * 
 * Spring Integration:
 * - Annotated with @Component to enable Spring-aware constraint validation
 * - Injects ProductRepository via @Autowired
 * - Works with JSR-303 validation framework
 * 
 * Performance Considerations:
 * - Single database query per validation
 * - Uses indexed lookup on product ID (primary key)
 * - Typical latency: 1-5ms on local database
 * - For bulk operations, consider validating at service layer instead
 *   to batch multiple existence checks into a single query
 * 
 * Requirements: 5.2, 5.3, 5.6
 */
@Component
public class ValidProductExistsValidator implements ConstraintValidator<ValidProductExists, UUID> {
    
    @Autowired
    private ProductRepository productRepository;
    
    /**
     * Initialize the validator.
     * No special initialization needed for this validator.
     * 
     * @param annotation The @ValidProductExists annotation instance
     */
    @Override
    public void initialize(ValidProductExists annotation) {
        // No initialization needed
    }
    
    /**
     * Validate that the product ID exists in the database.
     * 
     * @param value The product ID (UUID) to validate (may be null)
     * @param context Validation context for adding constraint violations
     * @return true if product exists or value is null, false if product not found
     */
    @Override
    public boolean isValid(UUID value, ConstraintValidatorContext context) {
        // Pass validation if value is null (let @NotNull handle it)
        if (value == null) {
            return true;
        }
        
        // Query database to check if product exists
        return productRepository.existsById(value);
    }
}
