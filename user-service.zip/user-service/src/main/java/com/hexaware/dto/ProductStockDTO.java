package com.hexaware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Data Transfer Object for product stock information.
 * 
 * Used internally for stock level calculations and API responses.
 * Contains all stock-related fields and metadata.
 * 
 * This DTO is immutable (via Lombok @Data and builder pattern)
 * to ensure thread-safety across multiple concurrent requests.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductStockDTO {

    /**
     * Unique product identifier (UUID).
     */
    private UUID productId;

    /**
     * Stock Keeping Unit - unique product code.
     */
    private String sku;

    /**
     * Human-readable product name.
     */
    private String name;

    /**
     * Total stock quantity = availableStock + reservedStock.
     * Represents the complete physical inventory for this product.
     */
    private Long totalStock;

    /**
     * Stock quantity available for new orders.
     * Calculated as: availableStock = totalStock - reservedStock
     * 
     * This is the quantity that can be immediately reserved by new orders.
     */
    private Long availableStock;

    /**
     * Stock quantity reserved by active orders.
     * Sum of all quantities from ACTIVE reservations.
     * 
     * When a reservation is released or expires, this count decreases
     * and availableStock increases correspondingly.
     */
    private Long reservedStock;

    /**
     * Number of active reservations for this product.
     * 
     * Useful for operational monitoring:
     * - High reservation count may indicate popular product
     * - Can help identify products with many pending orders
     * - Used in stock velocity calculations
     */
    private Long activeReservationCount;

    /**
     * Timestamp when this stock information was last updated.
     * 
     * Used to determine if the stock level is fresh or stale.
     * If current time - lastUpdatedAt > threshold, consider updating stock level.
     */
    private LocalDateTime lastUpdatedAt;

    /**
     * Timestamp when product was created.
     * 
     * Read-only field for informational purposes.
     */
    private LocalDateTime createdAt;
}
