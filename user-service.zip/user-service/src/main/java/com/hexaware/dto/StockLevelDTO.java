package com.hexaware.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Data Transfer Object for API responses containing stock level information.
 * 
 * This DTO is optimized for REST API responses:
 * - Minimal fields to reduce response payload size
 * - Clean JSON serialization via JsonProperty annotations
 * - Suitable for both single product and batch queries
 * 
 * Used in endpoints:
 * - GET /api/v1/inventory/products/{productId}/stock
 * - POST /api/v1/inventory/products/stock/batch
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StockLevelDTO {

    /**
     * Unique product identifier (UUID).
     */
    @JsonProperty("productId")
    private UUID productId;

    /**
     * Stock Keeping Unit - unique product code.
     * Used for external system lookup and merchant communication.
     */
    @JsonProperty("sku")
    private String sku;

    /**
     * Human-readable product name.
     */
    @JsonProperty("name")
    private String name;

    /**
     * Total stock quantity = availableStock + reservedStock.
     * 
     * Represents the complete physical inventory currently tracked.
     * Includes both available and reserved units.
     */
    @JsonProperty("totalStock")
    private Long totalStock;

    /**
     * Stock quantity available for new orders.
     * 
     * Calculated as: availableStock = totalStock - sum(activeReservations)
     * 
     * This is the critical field for order fulfillment:
     * - If availableStock >= requestedQuantity, order can be fulfilled
     * - Otherwise, return HTTP 409 INSUFFICIENT_STOCK
     * 
     * In API response:
     * - Used by Order Service to determine if reservation is possible
     * - Included in error responses for retry logic
     * - Cached by clients for performance optimization
     */
    @JsonProperty("availableStock")
    private Long availableStock;

    /**
     * Stock quantity reserved by active orders.
     * 
     * Sum of all quantities from ACTIVE reservations.
     * Decreases when reservations are released or expire.
     * 
     * In API response:
     * - Provides transparency to operators about pending orders
     * - Helps with inventory planning (how much is "locked")
     * - Used in operational dashboards
     */
    @JsonProperty("reservedStock")
    private Long reservedStock;

    /**
     * Number of active reservations for this product.
     * 
     * Useful for operational visibility:
     * - Shows how many orders are waiting for this product
     * - High count may indicate popular/high-demand product
     * - Can help with demand forecasting
     * 
     * Derived from COUNT(*) WHERE product_id = ? AND status = 'ACTIVE'
     */
    @JsonProperty("activeReservations")
    private Long activeReservations;

    /**
     * Timestamp when this stock information was last updated at the database level.
     * 
     * Used by clients to determine freshness of cached data:
     * - If current_time - lastUpdatedAt < cache_ttl, use cached value
     * - Otherwise, re-query for latest stock level
     * 
     * In API response:
     * - Allows clients to implement intelligent caching
     * - Provides transparency about data freshness
     */
    @JsonProperty("lastUpdatedAt")
    private LocalDateTime lastUpdatedAt;

    /**
     * Invariant check result (for operational debugging).
     * 
     * Should always be true: totalStock = availableStock + reservedStock
     * 
     * Included in response for diagnostic purposes:
     * - If false, indicates data corruption or bug
     * - Helps with troubleshooting production issues
     * - Optional field (not always included)
     */
    @JsonProperty("invariantValid")
    private Boolean invariantValid;
}
