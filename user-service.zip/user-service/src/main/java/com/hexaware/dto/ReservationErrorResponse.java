package com.hexaware.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTO for error responses from inventory operations.
 * 
 * This DTO represents error conditions that can occur during:
 * 1. Reservation creation (POST /api/v1/inventory/reservations)
 * 2. Reservation release (DELETE /api/v1/inventory/reservations/{id})
 * 3. Bulk stock updates (POST /api/v1/inventory/bulk-update)
 * 4. Stock queries (GET /api/v1/inventory/products/{id}/stock)
 * 
 * Error Codes:
 * - INSUFFICIENT_STOCK: Cannot reserve; not enough available stock
 *   HTTP 409 Conflict
 *   Includes: availableStock (for retry logic)
 * 
 * - RESERVATION_NOT_FOUND: No reservation found with given ID
 *   HTTP 404 Not Found
 *   Includes: only basic error info
 * 
 * - RESERVATION_ALREADY_PROCESSED: Reservation already released/expired
 *   HTTP 409 Conflict
 *   Includes: current status
 * 
 * - LOCK_TIMEOUT: Could not acquire database lock (concurrent conflict)
 *   HTTP 503 Service Unavailable
 *   Includes: retryAfter (milliseconds to wait before retry)
 *   Client should implement exponential backoff retry
 * 
 * - INVALID_BULK_UPDATE: Bulk update validation failed
 *   HTTP 400 Bad Request
 *   Includes: failures array with per-product error details
 * 
 * - INVALID_STOCK_AFTER_RESERVATIONS: New stock < reserved stock
 *   HTTP 409 Conflict
 *   Includes: failures with specific product conflicts
 * 
 * - PRODUCT_NOT_FOUND: Product doesn't exist in inventory
 *   HTTP 404 Not Found
 *   Includes: only basic error info
 * 
 * Response Structure:
 * {
 *   "error": "INSUFFICIENT_STOCK",
 *   "message": "Cannot reserve 50 units; only 25 available",
 *   "availableStock": 25,
 *   "requestId": "req-12345",
 *   "timestamp": "2024-01-15T10:30:00"
 * }
 * 
 * Requirements: 2.2, 3.5, 5.2, 5.3, 7.5, 7.8
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReservationErrorResponse {

    /**
     * Error code identifying the type of error.
     * 
     * Machine-readable code that clients can use to implement error handling logic.
     * Examples: "INSUFFICIENT_STOCK", "RESERVATION_NOT_FOUND", "LOCK_TIMEOUT"
     * 
     * Validation: Never null
     * Example: "INSUFFICIENT_STOCK"
     */
    @JsonProperty("error")
    private String errorCode;

    /**
     * Human-readable error message explaining what went wrong.
     * 
     * Provides details about the error for logging and user communication.
     * Should be descriptive enough for debugging but safe for frontend display.
     * 
     * Examples:
     * - "Cannot reserve 50 units; only 25 available"
     * - "Reservation already released at 2024-01-15T10:35:00"
     * - "Could not acquire database lock; please retry"
     * - "Product with ID 6ba7b810-9dad-11d1-80b4-00c04fd430c8 not found"
     * 
     * Validation: Never null
     */
    @JsonProperty("message")
    private String message;

    /**
     * Available stock for the product (only for INSUFFICIENT_STOCK errors).
     * 
     * When reservation fails due to insufficient stock, this field contains
     * the actual available stock at the time of the failure.
     * 
     * Clients use this for:
     * 1. User feedback: "Only 25 units available, you requested 50"
     * 2. Retry logic: "Try reserving 25 units instead"
     * 3. Analytics: track stock contention
     * 
     * Null for all other error types (populated only when errorCode = INSUFFICIENT_STOCK).
     * 
     * Validation: Long >= 0, but may be 0 if stock completely exhausted
     * Example: 25
     */
    @JsonProperty("availableStock")
    private Long availableStock;

    /**
     * Unique request identifier for tracing and support.
     * 
     * This ID is generated server-side and correlates the error response
     * with server logs for debugging.
     * 
     * Clients should:
     * 1. Extract this ID from the response
     * 2. Include it in support tickets: "Got error, request ID: req-12345"
     * 3. Send it in retry requests (Idempotency-Key header)
     * 
     * Format: Typically "req-" + timestamp + random suffix
     * Example: "req-12345-abc"
     * 
     * Validation: Never null
     */
    @JsonProperty("requestId")
    private String requestId;

    /**
     * Server timestamp when the error occurred.
     * 
     * Used for:
     * 1. Audit trail: correlating client and server timestamps
     * 2. Analytics: when did the error happen?
     * 3. Client retry logic: has enough time passed to retry?
     * 
     * Formatted as ISO 8601 string (e.g., "2024-01-15T10:30:00")
     * 
     * Validation: Never null
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonProperty("timestamp")
    private LocalDateTime timestamp;

    /**
     * Suggested delay in milliseconds before retrying (only for retryable errors).
     * 
     * For specific error codes, this field suggests how long the client should
     * wait before attempting the same request again.
     * 
     * Included for error codes:
     * - LOCK_TIMEOUT: 100-500ms (concurrent conflict, wait and retry)
     * - INSUFFICIENT_STOCK: Not included (wait for operator restock, not client retry)
     * 
     * Clients should:
     * 1. Check if this field is present
     * 2. Wait the specified milliseconds
     * 3. Add randomized jitter (±25%) to prevent thundering herd
     * 4. Implement exponential backoff: multiply by 1.5 on each retry (max 3 retries)
     * 
     * Example retry flow:
     * - First retry: wait retryAfter (e.g., 100ms) + random
     * - Second retry: wait retryAfter * 1.5 + random
     * - Third retry: wait retryAfter * 2.25 + random
     * - If still failing: give up
     * 
     * Format: Long (milliseconds)
     * Example: 100 (wait 100 milliseconds before retry)
     * 
     * Validation: Long > 0, typically 50-5000ms
     */
    @JsonProperty("retryAfter")
    private Long retryAfter;

    /**
     * Current total stock for the product (context information).
     * 
     * Included in some error responses for context:
     * Example: INSUFFICIENT_STOCK error includes totalStock so client knows pool size
     * 
     * Null for most error types.
     * 
     * Format: Long >= 0
     */
    @JsonProperty("totalStock")
    private Long totalStock;

    /**
     * Requested quantity that triggered the error.
     * 
     * Included in INSUFFICIENT_STOCK errors so client knows what was requested
     * vs. what was available.
     * 
     * Example: Client requested 50, only 25 available
     * requestedQuantity = 50, availableStock = 25
     * 
     * Null for other error types.
     * 
     * Format: Long > 0
     */
    @JsonProperty("requestedQuantity")
    private Long requestedQuantity;
}
