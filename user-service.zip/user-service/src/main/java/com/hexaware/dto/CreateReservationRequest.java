package com.hexaware.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hexaware.validation.ValidProductExists;
import com.hexaware.validation.ValidProductQuantity;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * DTO for creating a stock reservation via POST /api/v1/inventory/reservations
 * 
 * This DTO carries the request payload when clients want to reserve stock for an order.
 * The Inventory Management Service receives this request and creates a reservation
 * record if validation passes (sufficient stock available).
 * 
 * Validation Rules:
 * - orderId: mandatory, must be a valid UUID of the order being placed
 * - productId: mandatory, must be a valid UUID of the product to reserve
 * - quantity: mandatory, must be positive (> 0) and <= available stock
 * - idempotencyKey: optional, used for deduplication of retried requests
 * 
 * Idempotency Support:
 * When a client provides idempotencyKey (UUID), the service will:
 * 1. Check if a reservation with this key+orderId already exists
 * 2. If it exists and is ACTIVE, return the same reservation (no duplicate)
 * 3. If it doesn't exist, create a new reservation and store the key
 * This allows safe retry logic: client can safely retry without creating duplicates.
 * 
 * Example:
 * {
 *   "orderId": "550e8400-e29b-41d4-a716-446655440000",
 *   "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
 *   "quantity": 5,
 *   "idempotencyKey": "f47ac10b-58cc-4372-a567-0e02b2c3d479"
 * }
 * 
 * Requirements: 2.1, 2.5, 2.6, 7.5, 7.8
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateReservationRequest {

    /**
     * Order identifier that this reservation is for.
     * 
     * This UUID links the reservation to the order placed by the client.
     * Used to track which order a reservation belongs to and for release operations.
     * 
     * Validation: Must not be null
     * Example: "550e8400-e29b-41d4-a716-446655440000"
     */
    @NotNull(message = "Order ID is required")
    @JsonProperty("orderId")
    private UUID orderId;

    /**
     * Product identifier to reserve stock for.
     * 
     * This UUID identifies which product's stock should be reserved.
     * The Inventory Management Service will validate this product exists
     * and has sufficient available stock.
     * 
     * Validation: Must not be null
     * Example: "6ba7b810-9dad-11d1-80b4-00c04fd430c8"
     */
    @NotNull(message = "Product ID is required")
    @ValidProductExists(message = "Product does not exist")
    @JsonProperty("productId")
    private UUID productId;

    /**
     * Quantity of product to reserve (in units).
     * 
     * The number of units to hold in reservation.
     * Must be positive and cannot exceed available stock.
     * 
     * Validation: Must be positive (> 0)
     * Example: 5 (reserve 5 units)
     */
    @NotNull(message = "Quantity is required")
    @Positive(message = "Quantity must be positive")
    @ValidProductQuantity(message = "Quantity must be positive")
    @JsonProperty("quantity")
    private Long quantity;

    /**
     * Optional idempotency key for request deduplication.
     * 
     * When provided, the service uses this key to detect and deduplicate retried requests.
     * 
     * Usage Pattern:
     * 1. Client generates a UUID: idempotencyKey = UUID.randomUUID().toString()
     * 2. Client sends first request with idempotencyKey
     * 3. If network timeout or 5xx error, client retries with SAME idempotencyKey
     * 4. Service detects key already processed, returns same result without duplicate
     * 
     * Benefits:
     * - Prevents accidental double-reservations due to network retries
     * - Supports at-least-once delivery semantics safely
     * - Allows client retry logic without careful coordination
     * 
     * Format: String (typically UUID string: 36 characters with hyphens, or 32 without)
     * Example: "f47ac10b-58cc-4372-a567-0e02b2c3d479"
     * 
     * Note: Optional field. If not provided, service doesn't deduplicate,
     * and duplicate requests could create duplicate reservations.
     * 
     * Validation: None (any value accepted, but should be valid UUID format)
     */
    @JsonProperty("idempotencyKey")
    private String idempotencyKey;

    /**
     * Optional correlation ID for distributed tracing and logging.
     * 
     * When provided, this ID is used to correlate all log entries and metrics
     * across the distributed system for this request.
     * 
     * Usage: 
     * - Clients can provide this (or server generates one)
     * - Used in: logs, metrics, audit trail, error responses
     * - Helps debug end-to-end request flow across services
     * 
     * Format: String (typically UUID or other unique ID)
     * Example: "trace-550e8400-e29b-41d4-a716-446655440000"
     * 
     * Note: Optional. Server generates one if not provided.
     * Validation: None
     */
    @JsonProperty("correlationId")
    private String correlationId;
}
