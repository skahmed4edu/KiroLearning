package com.hexaware.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * DTO for reservation response in API replies.
 * 
 * This DTO is used to return reservation details to clients:
 * 1. After successful reservation creation (POST /reservations)
 * 2. After reservation release (DELETE /reservations/{id})
 * 3. In stock level responses (inventory details)
 * 
 * Fields are selected to provide clients with:
 * - Reservation tracking: id, orderId, productId
 * - Status information: status, statusLabel
 * - Timing details: createdAt, expirationTime, releasedAt, expiredAt
 * - Stock information: quantity, availableStock (context for decision-making)
 * 
 * JsonInclude(NON_NULL) ensures null fields are omitted from JSON response,
 * reducing payload size (e.g., releasedAt only included if reservation released).
 * 
 * Requirements: 2.1, 2.5, 2.7, 3.1
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReservationResponse {

    /**
     * Unique reservation identifier.
     * Returned immediately on creation for client tracking.
     * Used in subsequent API calls to reference this reservation.
     */
    private UUID reservationId;

    /**
     * Order identifier this reservation is linked to.
     * Helps client correlate reservation with original order request.
     */
    private UUID orderId;

    /**
     * Product identifier being reserved.
     * Confirms which product was reserved.
     */
    private UUID productId;

    /**
     * Product SKU for external system reference.
     * Useful for debugging and cross-system tracing.
     */
    private String productSku;

    /**
     * Quantity of product reserved (in units).
     * Confirms how much stock was held for this order.
     */
    private Long quantity;

    /**
     * Current reservation status (enum name).
     * Values: ACTIVE, RELEASED, EXPIRED, CANCELLED
     * 
     * Used by client for state tracking:
     * - ACTIVE: stock is currently reserved
     * - RELEASED: stock was released, available for others
     * - EXPIRED: stock was released due to TTL
     */
    private String status;

    /**
     * Human-readable status label for display.
     * Example: "Active", "Released", "Expired", "Cancelled"
     * 
     * Useful for user-facing dashboards and reports.
     */
    private String statusLabel;

    /**
     * Timestamp when reservation was created.
     * Shows when stock hold was initiated.
     * Formatted as ISO 8601 datetime string.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;

    /**
     * Timestamp when reservation will automatically expire if not released.
     * Critical for client understanding of reservation lifetime.
     * Example use: client UI shows countdown timer.
     * 
     * Calculated as: createdAt + RESERVATION_TTL_MINUTES
     * Formatted as ISO 8601 datetime string.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime expirationTime;

    /**
     * Timestamp when reservation was released (manual cancellation).
     * Null while reservation is ACTIVE or EXPIRED.
     * Set when status transitions to RELEASED.
     * 
     * Used for audit trail and analytics.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime releasedAt;

    /**
     * Timestamp when reservation expired (TTL elapsed).
     * Null while reservation is ACTIVE or RELEASED.
     * Set when status transitions to EXPIRED.
     * 
     * Used for audit trail and analytics.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime expiredAt;

    /**
     * Current available stock for the reserved product.
     * Included for context: how much stock is available for other orders?
     * Updated as of response generation time.
     * 
     * Note: This may change rapidly in high-concurrency scenarios.
     * Only guaranteed accurate at response generation time.
     */
    private Long availableStock;

    /**
     * Total stock (reserved + available) for the product.
     * Included for context: what's the total inventory?
     */
    private Long totalStock;
}
