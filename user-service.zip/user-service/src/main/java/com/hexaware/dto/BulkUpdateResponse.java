package com.hexaware.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * DTO for bulk stock update responses from POST /api/v1/inventory/bulk-update
 * 
 * This DTO represents the result of a bulk stock update operation.
 * It includes:
 * 1. Overall status: SUCCESS or FAILURE
 * 2. List of updated products (on success)
 * 3. List of failures with details (on failure or partial success)
 * 4. Timestamp of operation
 * 5. Request ID for tracing
 * 
 * Response Semantics:
 * - SUCCESS: All updates were applied successfully
 * - FAILURE: One or more updates failed; no changes applied (all-or-nothing)
 * 
 * Success Response Example:
 * {
 *   "status": "SUCCESS",
 *   "updatedProducts": [
 *     {
 *       "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
 *       "sku": "PROD-001",
 *       "previousTotalStock": 100,
 *       "newTotalStock": 150,
 *       "availableStock": 95,
 *       "reservedStock": 55
 *     },
 *     {
 *       "productId": "7ba7b811-9dad-11d1-80b4-00c04fd430c9",
 *       "sku": "PROD-002",
 *       "previousTotalStock": 200,
 *       "newTotalStock": 250,
 *       "availableStock": 170,
 *       "reservedStock": 80
 *     }
 *   ],
 *   "timestamp": "2024-01-15T10:40:00",
 *   "requestId": "bulk-req-789"
 * }
 * 
 * Failure Response Example:
 * {
 *   "status": "FAILURE",
 *   "failures": [
 *     {
 *       "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
 *       "reason": "New total stock (50) < reserved stock (55)",
 *       "failureType": "INVALID_STOCK_AFTER_RESERVATIONS",
 *       "currentTotalStock": 100,
 *       "proposedTotalStock": 50,
 *       "reservedStock": 55
 *     }
 *   ],
 *   "timestamp": "2024-01-15T10:40:00",
 *   "requestId": "bulk-req-789"
 * }
 * 
 * Requirements: 5.1, 5.4, 5.5, 5.8, 7.5, 7.8
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BulkUpdateResponse {

    /**
     * Overall status of the bulk update operation.
     * 
     * Values:
     * - "SUCCESS": All products updated successfully
     * - "FAILURE": One or more updates failed; no changes applied
     * 
     * When status = SUCCESS:
     * - updatedProducts: contains all updated products
     * - failures: will be null/empty (omitted from JSON)
     * - All changes are persisted
     * 
     * When status = FAILURE:
     * - updatedProducts: will be null/empty (omitted from JSON)
     * - failures: contains details of failed updates
     * - No changes are persisted (all-or-nothing semantics)
     * 
     * Validation: Always present, never null
     * Example: "SUCCESS" or "FAILURE"
     */
    @JsonProperty("status")
    private String status;

    /**
     * List of successfully updated products (present only when status = SUCCESS).
     * 
     * Each entry shows the updated product with before/after stock levels.
     * 
     * Includes:
     * - Product identification: productId, sku
     * - Stock levels: previousTotalStock, newTotalStock, availableStock, reservedStock
     * - Helps client verify the update and update their local cache
     * 
     * Format: List of BulkUpdateResultEntry
     * 
     * Included Only When:
     * - status = "SUCCESS" (always populated)
     * - null/omitted when status = "FAILURE"
     * 
     * Example: [
     *   {
     *     "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
     *     "sku": "PROD-001",
     *     "previousTotalStock": 100,
     *     "newTotalStock": 150,
     *     "availableStock": 95,
     *     "reservedStock": 55
     *   }
     * ]
     */
    @JsonProperty("updatedProducts")
    private List<BulkUpdateResultEntry> updatedProducts;

    /**
     * List of failed updates (present only when status = FAILURE).
     * 
     * Each entry shows which product failed and why.
     * 
     * Includes:
     * - Product identification: productId
     * - Error details: reason, failureType
     * - Context: currentTotalStock, proposedTotalStock, reservedStock
     * - Helps client understand what went wrong and how to correct it
     * 
     * Format: List of BulkUpdateFailure
     * 
     * Included Only When:
     * - status = "FAILURE" (always populated when any update fails)
     * - null/omitted when status = "SUCCESS"
     * 
     * Example: [
     *   {
     *     "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
     *     "reason": "New total stock (50) < reserved stock (55)",
     *     "failureType": "INVALID_STOCK_AFTER_RESERVATIONS",
     *     "currentTotalStock": 100,
     *     "proposedTotalStock": 50,
     *     "reservedStock": 55
     *   }
     * ]
     */
    @JsonProperty("failures")
    private List<BulkUpdateFailure> failures;

    /**
     * Server timestamp when the bulk update was processed.
     * 
     * Used for:
     * 1. Audit trail: when did this update happen?
     * 2. Synchronization: ensuring client/server clock sync
     * 3. Analytics: tracking update frequency and timing
     * 
     * Formatted as ISO 8601 string (e.g., "2024-01-15T10:40:00")
     * 
     * Validation: Never null
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonProperty("timestamp")
    private LocalDateTime timestamp;

    /**
     * Unique request identifier for tracing and support.
     * 
     * Correlates this response with server logs for debugging.
     * Include in support tickets when reporting issues.
     * 
     * Format: String (typically "bulk-req-" + timestamp + suffix)
     * Example: "bulk-req-789"
     * 
     * Validation: Never null
     */
    @JsonProperty("requestId")
    private String requestId;

    /**
     * Nested DTO representing a successfully updated product in bulk update.
     * 
     * Shows the product that was updated and its new stock levels.
     * Clients can use this to verify the update and sync local cache.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkUpdateResultEntry {

        /**
         * Product identifier that was updated.
         * 
         * Example: "6ba7b810-9dad-11d1-80b4-00c04fd430c8"
         */
        @JsonProperty("productId")
        private UUID productId;

        /**
         * Product SKU for external system reference.
         * 
         * Useful for debugging and cross-system tracing.
         * Example: "PROD-001"
         */
        @JsonProperty("sku")
        private String sku;

        /**
         * Total stock before the update.
         * 
         * Helps client see what changed.
         * Example: 100 (was 100 units)
         */
        @JsonProperty("previousTotalStock")
        private Long previousTotalStock;

        /**
         * Total stock after the update.
         * 
         * The new value that was set.
         * Example: 150 (now 150 units)
         */
        @JsonProperty("newTotalStock")
        private Long newTotalStock;

        /**
         * Available stock after the update.
         * 
         * Calculated as: newTotalStock - reservedStock
         * Shows how much stock is actually available for new reservations.
         * 
         * Example: 95 (150 total - 55 reserved = 95 available)
         */
        @JsonProperty("availableStock")
        private Long availableStock;

        /**
         * Reserved stock (unchanged by this update).
         * 
         * Shows active reservations on this product.
         * Example: 55 (55 units are reserved by active orders)
         */
        @JsonProperty("reservedStock")
        private Long reservedStock;
    }

    /**
     * Nested DTO representing a failed product update in bulk operation.
     * 
     * Shows which product failed to update and why.
     * When any product fails, the entire bulk update fails and no changes apply.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkUpdateFailure {

        /**
         * Product identifier that failed to update.
         * 
         * Example: "6ba7b810-9dad-11d1-80b4-00c04fd430c8"
         */
        @JsonProperty("productId")
        private UUID productId;

        /**
         * Human-readable reason why the update failed.
         * 
         * Examples:
         * - "Negative stock quantity: -10"
         * - "New total stock (50) < reserved stock (55)"
         * - "Product does not exist"
         * - "Invalid product ID format"
         * 
         * Used for client error messages and debugging.
         */
        @JsonProperty("reason")
        private String reason;

        /**
         * Machine-readable failure type for error handling.
         * 
         * Values:
         * - INVALID_QUANTITY: Negative or zero stock quantity
         * - PRODUCT_NOT_FOUND: Product doesn't exist
         * - INVALID_STOCK_AFTER_RESERVATIONS: New stock < reserved stock
         * - INVALID_PRODUCT_ID: Malformed product ID
         * - CONCURRENT_MODIFICATION: Version conflict
         * 
         * Used for implementing error handling logic.
         */
        @JsonProperty("failureType")
        private String failureType;

        /**
         * Current total stock for context.
         * 
         * What the total stock was before the attempted update.
         * Helps understand the difference.
         * 
         * Null if product doesn't exist.
         * Example: 100 (was 100 units)
         */
        @JsonProperty("currentTotalStock")
        private Long currentTotalStock;

        /**
         * Proposed total stock for context.
         * 
         * What the client tried to set it to.
         * Helps understand the rejected change.
         * 
         * Example: 50 (client tried to set to 50)
         */
        @JsonProperty("proposedTotalStock")
        private Long proposedTotalStock;

        /**
         * Current reserved stock for context.
         * 
         * When failure is INVALID_STOCK_AFTER_RESERVATIONS,
         * shows how much stock is currently reserved.
         * 
         * Example: 55 (55 units are reserved, can't go below this)
         */
        @JsonProperty("reservedStock")
        private Long reservedStock;
    }
}
