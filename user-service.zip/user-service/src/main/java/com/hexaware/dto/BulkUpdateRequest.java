package com.hexaware.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hexaware.validation.BulkUpdateMaxSize;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for bulk stock update requests via POST /api/v1/inventory/bulk-update
 * 
 * This DTO carries a batch of stock update operations for multiple products.
 * The Inventory Management Service processes all updates atomically:
 * - If all updates are valid and succeed: apply all changes
 * - If any update fails validation: reject entire batch (all-or-nothing semantics)
 * 
 * Batch Size Limits:
 * - Minimum: 1 update (reject empty lists)
 * - Maximum: 1000 updates per request (prevent huge batches)
 * 
 * Use Cases:
 * 1. Inventory restock: operator adds 500 units to Product A, 1000 to Product B
 * 2. Inventory correction: data correction after physical inventory count
 * 3. Product promotion: increasing stock levels for featured products
 * 4. Bulk adjustment: applying a stock correction across multiple products
 * 
 * Transaction Semantics:
 * This operation uses database transactions to ensure atomicity:
 * 1. All-or-nothing: Either all updates succeed or none are applied
 * 2. Consistent: All products are locked in consistent order (prevent deadlocks)
 * 3. Isolated: No other operations can see partial updates
 * 4. Durable: Once success response returned, all changes are persisted
 * 
 * Validation Rules:
 * - updates: List must not be empty (@NotEmpty)
 * - updates: List size must be <= 1000 (@Size(max=1000))
 * - updates[*]: Each entry must be valid (see BulkStockUpdateEntry)
 * 
 * Example Request:
 * {
 *   "updates": [
 *     {
 *       "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
 *       "newTotalStock": 150,
 *       "reason": "Restock from warehouse shipment S-2024-001"
 *     },
 *     {
 *       "productId": "7ba7b811-9dad-11d1-80b4-00c04fd430c9",
 *       "newTotalStock": 250,
 *       "reason": "Restock from warehouse shipment S-2024-001"
 *     }
 *   ]
 * }
 * 
 * Error Responses:
 * 
 * 400 Bad Request - Validation failed:
 * {
 *   "error": "INVALID_BULK_UPDATE",
 *   "message": "Updates list must not be empty",
 *   "timestamp": "2024-01-15T10:40:00"
 * }
 * 
 * 400 Bad Request - Size exceeded:
 * {
 *   "error": "INVALID_BULK_UPDATE",
 *   "message": "Updates list size (1001) exceeds maximum (1000)",
 *   "timestamp": "2024-01-15T10:40:00"
 * }
 * 
 * 400 Bad Request - Invalid entry:
 * {
 *   "error": "INVALID_BULK_UPDATE",
 *   "message": "Bulk update validation failed",
 *   "failures": [
 *     {
 *       "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
 *       "reason": "Negative stock quantity: -10",
 *       "failureType": "INVALID_QUANTITY"
 *     }
 *   ],
 *   "timestamp": "2024-01-15T10:40:00"
 * }
 * 
 * 409 Conflict - Stock below reservations:
 * {
 *   "error": "INVALID_STOCK_AFTER_RESERVATIONS",
 *   "message": "New stock quantity is less than reserved quantity",
 *   "failures": [
 *     {
 *       "productId": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
 *       "reason": "New total stock (50) < reserved stock (55)",
 *       "currentTotalStock": 100,
 *       "proposedTotalStock": 50,
 *       "reservedStock": 55
 *     }
 *   ],
 *   "timestamp": "2024-01-15T10:40:00"
 * }
 * 
 * Requirements: 5.1, 5.2, 5.3, 5.6, 7.5, 7.8
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BulkUpdateRequest {

    /**
     * List of stock update entries for individual products.
     * 
     * Each entry specifies a product to update and its new total stock level.
     * 
     * Validation Rules:
     * - @NotEmpty: List must contain at least 1 update
     * - @Size(max=1000): List must not exceed 1000 updates
     * - @Valid: Each entry must pass its own validation rules
     * 
     * Ordering:
     * Order of entries doesn't matter (internally sorted by product ID for locking)
     * 
     * Format: List of BulkStockUpdateEntry objects
     * Example: [
     *   {"productId": "...", "newTotalStock": 150, "reason": "..."},
     *   {"productId": "...", "newTotalStock": 250, "reason": "..."}
     * ]
     * 
     * Constraints:
     * - Minimum size: 1
     * - Maximum size: 1000
     * - Each entry must be valid per BulkStockUpdateEntry validation rules
     */
    @NotEmpty(message = "Updates list must not be empty")
    @BulkUpdateMaxSize(max = 1000)
    @Valid
    @JsonProperty("updates")
    private List<BulkStockUpdateEntry> updates;

    /**
     * Nested DTO representing a single product's stock update.
     * 
     * This class is nested inside BulkUpdateRequest to keep related
     * concepts together and indicate that entries are only valid within
     * a bulk update context.
     * 
     * Each entry specifies:
     * - Which product to update (productId)
     * - What the new total stock should be (newTotalStock)
     * - Why the update is happening (reason - audit trail)
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BulkStockUpdateEntry {

        /**
         * Product identifier to update stock for.
         * 
         * This UUID identifies which product's total stock should be updated.
         * Must reference an existing product in the inventory system.
         * 
         * Validation:
         * - Must not be null
         * - Product must exist (checked during processing)
         * 
         * Example: "6ba7b810-9dad-11d1-80b4-00c04fd430c8"
         */
        @jakarta.validation.constraints.NotNull(message = "Product ID is required")
        @JsonProperty("productId")
        private java.util.UUID productId;

        /**
         * New total stock quantity for this product (in units).
         * 
         * The new totalStock value for this product after the update.
         * This replaces the current totalStock completely.
         * 
         * Important Invariants:
         * 1. Must be positive (> 0): Can't have zero or negative total stock
         * 2. Must be >= reserved stock: Can't make total less than currently reserved
         *    Example: If 55 units are reserved, newTotalStock must be >= 55
         * 3. Available stock is automatically calculated as:
         *    availableStock = newTotalStock - reservedStock
         * 
         * Validation:
         * - Must not be null
         * - Must be positive (> 0)
         * - Must be >= current reserved stock (checked during processing)
         * 
         * Format: Long (integer number of units)
         * Example: 150 (set total stock to 150 units)
         */
        @jakarta.validation.constraints.NotNull(message = "New total stock is required")
        @jakarta.validation.constraints.Positive(message = "New total stock must be positive")
        @JsonProperty("newTotalStock")
        private Long newTotalStock;

        /**
         * Reason for this stock update (audit trail).
         * 
         * Recorded in stock_audit_log for tracking and compliance.
         * Helps operations team understand why stock changed.
         * 
         * Examples:
         * - "Restock from warehouse shipment S-2024-001"
         * - "Inventory correction after physical count"
         * - "Damage adjustment from RMA-2024-123"
         * - "Transfer from warehouse A to warehouse B"
         * - "Promotional stock allocation"
         * 
         * Validation:
         * - Must not be null or blank
         * - Should be descriptive (max 255 characters)
         * - Used in logs and audit trail
         * 
         * Format: String (text description)
         * Example: "Restock from warehouse shipment S-2024-001"
         */
        @jakarta.validation.constraints.NotBlank(message = "Reason is required")
        @jakarta.validation.constraints.Size(
            max = 255,
            message = "Reason must not exceed 255 characters"
        )
        @JsonProperty("reason")
        private String reason;
    }
}
