package com.hexaware.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * DTO for reservation release responses.
 *
 * <p>Returned to clients after a reservation is released, either:
 * <ol>
 *   <li>In response to an explicit release (DELETE /api/v1/inventory/reservations/{id}),</li>
 *   <li>In response to a release-by-order (DELETE /api/v1/inventory/reservations/by-order/{orderId}),</li>
 *   <li>As an idempotent success when the reservation was already RELEASED.</li>
 * </ol>
 *
 * <p>The {@code idempotent} flag lets the client distinguish a fresh release (stock was
 * just restored) from an idempotent replay (stock was restored by an earlier call), while
 * both represent a successful outcome.
 *
 * <p>{@link JsonInclude.Include#NON_NULL} omits null fields from the serialized JSON,
 * keeping the payload compact.
 *
 * <p>Requirements: 3.1, 3.3, 3.4, 3.7
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReleaseResponse {

    /**
     * Identifier of the reservation that was released.
     */
    private UUID reservationId;

    /**
     * Order identifier the released reservation was linked to.
     */
    private UUID orderId;

    /**
     * Product identifier whose stock was restored by the release.
     */
    private UUID productId;

    /**
     * Quantity that was released back to available stock.
     */
    private Long quantity;

    /**
     * Reservation status after the release (always {@code RELEASED} on success).
     */
    private String status;

    /**
     * Timestamp when the reservation was released.
     * Formatted as ISO 8601 datetime string.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime releasedAt;

    /**
     * Available stock for the product after the release.
     */
    private Long availableStock;

    /**
     * Whether this response represents an idempotent replay of a prior release.
     *
     * <p>{@code false}: this call performed the release and restored stock.
     * {@code true}: the reservation was already RELEASED; stock was restored earlier and
     * is not restored again.
     */
    private boolean idempotent;
}
