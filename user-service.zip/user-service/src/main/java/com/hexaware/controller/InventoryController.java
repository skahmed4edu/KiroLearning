package com.hexaware.controller;

import com.hexaware.dto.BulkUpdateRequest;
import com.hexaware.dto.BulkUpdateResponse;
import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReleaseResponse;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.dto.StockLevelDTO;
import com.hexaware.service.ReservationReleaseService;
import com.hexaware.service.ReservationService;
import com.hexaware.service.StockQueryService;
import com.hexaware.service.StockUpdateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.UUID;

/**
 * REST Controller for inventory stock-reservation operations.
 *
 * <p>This controller is a thin HTTP adapter over the inventory service layer. It
 * performs no business logic: it extracts request-correlation metadata, delegates
 * to the appropriate service ({@link ReservationService},
 * {@link ReservationReleaseService}, {@link StockQueryService},
 * {@link StockUpdateService}) and shapes the HTTP response (status code and, for
 * creation, a {@code Location} header).
 *
 * <p>Base path follows the API design standard: versioned, plural, kebab-case
 * resource names under {@code /api/v1/inventory}.
 *
 * <p><strong>Idempotency &amp; correlation.</strong> POST/DELETE operations accept an
 * optional {@code Idempotency-Key} header so safe retries do not duplicate work,
 * and an optional {@code X-Request-ID} header for distributed tracing. The request
 * id is placed on the SLF4J {@link MDC} for the duration of the request so that log
 * lines and {@link com.hexaware.exception.GlobalExceptionHandler} error payloads can
 * echo the same correlation id.
 *
 * <p><strong>Error mapping.</strong> Business failures surface as inventory
 * exceptions ({@code InsufficientStockException} -&gt; 409,
 * {@code LockTimeoutException} -&gt; 503 with retry hint,
 * {@code ReservationNotFoundException} -&gt; 404, etc.) and are mapped to HTTP
 * statuses centrally by the GlobalExceptionHandler; the controller does not catch
 * them.
 *
 * <p>Requirements: 2.1, 3.1, 1.1, 1.5, 5.1, 7.5, 7.6, 7.7
 */
@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Inventory", description = "Stock reservation, release, stock-level query and bulk stock-update operations")
public class InventoryController {

    private static final String IDEMPOTENCY_KEY_HEADER = "Idempotency-Key";
    private static final String REQUEST_ID_HEADER = "X-Request-ID";
    private static final String REQUEST_ID_MDC_KEY = "requestId";

    private final ReservationService reservationService;
    private final ReservationReleaseService reservationReleaseService;
    private final StockQueryService stockQueryService;
    private final StockUpdateService stockUpdateService;

    /**
     * Create a stock reservation for an order.
     *
     * <p>Returns 201 Created with a {@code Location} header pointing at the created
     * reservation and the reservation details in the body. If an
     * {@code Idempotency-Key} header is supplied and the request body does not
     * already carry one, the header value is applied so a repeated request returns
     * the existing reservation instead of creating a duplicate.
     *
     * @param request        the reservation request (orderId, productId, quantity)
     * @param idempotencyKey optional Idempotency-Key header for safe retries
     * @param requestId      optional X-Request-ID correlation id
     * @return 201 Created with the created reservation and a Location header
     */
    @Operation(summary = "Create a stock reservation",
            description = "Reserves stock for an order, preventing overselling. Supports idempotent retries via the Idempotency-Key header.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Reservation created",
                    content = @Content(schema = @Schema(implementation = ReservationResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid request body"),
            @ApiResponse(responseCode = "404", description = "Product not found"),
            @ApiResponse(responseCode = "409", description = "Insufficient stock"),
            @ApiResponse(responseCode = "503", description = "Could not acquire lock, retry later")
    })
    @PostMapping("/reservations")
    public ResponseEntity<ReservationResponse> createReservation(
            @Valid @RequestBody CreateReservationRequest request,
            @Parameter(description = "Optional Idempotency-Key for safe retries; a repeated key returns the existing reservation instead of creating a duplicate")
            @RequestHeader(value = IDEMPOTENCY_KEY_HEADER, required = false) String idempotencyKey,
            @Parameter(description = "Optional X-Request-ID correlation id used for distributed tracing")
            @RequestHeader(value = REQUEST_ID_HEADER, required = false) String requestId) {

        setCorrelationId(requestId);
        try {
            log.info("Received reservation request: orderId={}, productId={}",
                    request.getOrderId(), request.getProductId());

            if (idempotencyKey != null && request.getIdempotencyKey() == null) {
                request.setIdempotencyKey(idempotencyKey);
            }
            if (requestId != null && request.getCorrelationId() == null) {
                request.setCorrelationId(requestId);
            }

            ReservationResponse response = reservationService.createReservation(request);

            URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                    .path("/{reservationId}")
                    .buildAndExpand(response.getReservationId())
                    .toUri();

            return ResponseEntity.created(location).body(response);
        } finally {
            clearCorrelationId();
        }
    }

    /**
     * Release a reservation by its identifier, restoring the reserved stock.
     *
     * <p>Idempotent: releasing an already-released reservation returns 200 OK with
     * {@code idempotent=true} and does not restore stock a second time.
     *
     * @param reservationId  the reservation to release
     * @param idempotencyKey optional Idempotency-Key header for request correlation
     * @param requestId      optional X-Request-ID correlation id
     * @return 200 OK with the release outcome
     */
    @Operation(summary = "Release a reservation",
            description = "Releases a reservation and restores its reserved stock. Idempotent: releasing an already-released reservation succeeds without restoring stock again.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Reservation released",
                    content = @Content(schema = @Schema(implementation = ReleaseResponse.class))),
            @ApiResponse(responseCode = "404", description = "Reservation not found"),
            @ApiResponse(responseCode = "409", description = "Reservation in a non-releasable state"),
            @ApiResponse(responseCode = "503", description = "Could not acquire lock, retry later")
    })
    @DeleteMapping("/reservations/{reservationId}")
    public ResponseEntity<ReleaseResponse> releaseReservation(
            @Parameter(description = "Identifier of the reservation to release")
            @PathVariable UUID reservationId,
            @Parameter(description = "Optional Idempotency-Key for safe retries")
            @RequestHeader(value = IDEMPOTENCY_KEY_HEADER, required = false) String idempotencyKey,
            @Parameter(description = "Optional X-Request-ID correlation id used for distributed tracing")
            @RequestHeader(value = REQUEST_ID_HEADER, required = false) String requestId) {

        setCorrelationId(requestId);
        try {
            log.info("Received release request: reservationId={}", reservationId);
            ReleaseResponse response = reservationReleaseService.releaseReservation(reservationId, idempotencyKey);
            return ResponseEntity.ok(response);
        } finally {
            clearCorrelationId();
        }
    }

    /**
     * Release the active reservation associated with an order.
     *
     * <p>Idempotent: if the order's reservation was already released, returns 200 OK
     * with {@code idempotent=true}.
     *
     * @param orderId        the order whose reservation should be released
     * @param idempotencyKey optional Idempotency-Key header for request correlation
     * @param requestId      optional X-Request-ID correlation id
     * @return 200 OK with the release outcome
     */
    @Operation(summary = "Release a reservation by order id",
            description = "Finds and releases the active reservation linked to the given order, restoring its reserved stock. Idempotent on an already-released order.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Reservation released",
                    content = @Content(schema = @Schema(implementation = ReleaseResponse.class))),
            @ApiResponse(responseCode = "404", description = "No releasable reservation found for the order"),
            @ApiResponse(responseCode = "503", description = "Could not acquire lock, retry later")
    })
    @DeleteMapping("/reservations/by-order/{orderId}")
    public ResponseEntity<ReleaseResponse> releaseReservationByOrder(
            @Parameter(description = "Identifier of the order whose reservation should be released")
            @PathVariable UUID orderId,
            @Parameter(description = "Optional Idempotency-Key for safe retries")
            @RequestHeader(value = IDEMPOTENCY_KEY_HEADER, required = false) String idempotencyKey,
            @Parameter(description = "Optional X-Request-ID correlation id used for distributed tracing")
            @RequestHeader(value = REQUEST_ID_HEADER, required = false) String requestId) {

        setCorrelationId(requestId);
        try {
            log.info("Received release-by-order request: orderId={}", orderId);
            ReleaseResponse response = reservationReleaseService.releaseReservationByOrderId(orderId, idempotencyKey);
            return ResponseEntity.ok(response);
        } finally {
            clearCorrelationId();
        }
    }

    /**
     * Get the current stock level for a single product.
     *
     * @param productId the product to query
     * @param requestId optional X-Request-ID correlation id
     * @return 200 OK with the product's stock level
     */
    @Operation(summary = "Get stock level for a product",
            description = "Returns the current total, available and reserved stock for a product.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Stock level returned",
                    content = @Content(schema = @Schema(implementation = StockLevelDTO.class))),
            @ApiResponse(responseCode = "404", description = "Product not found")
    })
    @GetMapping("/products/{productId}/stock")
    public ResponseEntity<StockLevelDTO> getStockLevel(
            @Parameter(description = "Identifier of the product to query")
            @PathVariable UUID productId,
            @Parameter(description = "Optional X-Request-ID correlation id used for distributed tracing")
            @RequestHeader(value = REQUEST_ID_HEADER, required = false) String requestId) {

        setCorrelationId(requestId);
        try {
            log.debug("Received stock-level request: productId={}", productId);
            StockLevelDTO response = stockQueryService.getStockLevel(productId);
            return ResponseEntity.ok(response);
        } finally {
            clearCorrelationId();
        }
    }

    /**
     * Get stock levels for a batch of products in a single call.
     *
     * @param productIds the products to query
     * @param requestId  optional X-Request-ID correlation id
     * @return 200 OK with the stock levels for the found products
     */
    @Operation(summary = "Batch stock-level query",
            description = "Returns stock levels for multiple products in one request.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Stock levels returned")
    })
    @PostMapping("/products/stock/batch")
    public ResponseEntity<List<StockLevelDTO>> getStockLevels(
            @RequestBody List<UUID> productIds,
            @Parameter(description = "Optional X-Request-ID correlation id used for distributed tracing")
            @RequestHeader(value = REQUEST_ID_HEADER, required = false) String requestId) {

        setCorrelationId(requestId);
        try {
            log.debug("Received batch stock-level request: productCount={}",
                    productIds == null ? 0 : productIds.size());
            List<StockLevelDTO> response = stockQueryService.getStockLevels(productIds);
            return ResponseEntity.ok(response);
        } finally {
            clearCorrelationId();
        }
    }

    /**
     * Apply a bulk stock update with all-or-nothing semantics.
     *
     * @param request        the batch of per-product stock updates
     * @param idempotencyKey optional Idempotency-Key header for safe retries
     * @param requestId      optional X-Request-ID correlation id
     * @return 200 OK with the per-product update results
     */
    @Operation(summary = "Bulk stock update",
            description = "Atomically updates the total stock of multiple products. Either all updates succeed or none are applied.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Bulk update applied",
                    content = @Content(schema = @Schema(implementation = BulkUpdateResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid bulk update request"),
            @ApiResponse(responseCode = "409", description = "A requested stock level is below reserved stock"),
            @ApiResponse(responseCode = "503", description = "Could not acquire lock, retry later")
    })
    @PostMapping("/bulk-update")
    public ResponseEntity<BulkUpdateResponse> bulkUpdateStock(
            @Valid @RequestBody BulkUpdateRequest request,
            @Parameter(description = "Optional Idempotency-Key for safe retries")
            @RequestHeader(value = IDEMPOTENCY_KEY_HEADER, required = false) String idempotencyKey,
            @Parameter(description = "Optional X-Request-ID correlation id used for distributed tracing")
            @RequestHeader(value = REQUEST_ID_HEADER, required = false) String requestId) {

        setCorrelationId(requestId);
        try {
            log.info("Received bulk-update request: batchSize={}",
                    request.getUpdates() == null ? 0 : request.getUpdates().size());
            BulkUpdateResponse response = stockUpdateService.bulkUpdateStock(request);
            return ResponseEntity.ok(response);
        } finally {
            clearCorrelationId();
        }
    }

    /**
     * Places the supplied correlation id on the SLF4J MDC so downstream logs and
     * error payloads can echo it. No-op when the header is absent.
     *
     * @param requestId the X-Request-ID header value, or {@code null}
     */
    private void setCorrelationId(String requestId) {
        if (requestId != null && !requestId.isBlank()) {
            MDC.put(REQUEST_ID_MDC_KEY, requestId);
        }
    }

    /**
     * Removes the correlation id from the MDC at the end of the request.
     */
    private void clearCorrelationId() {
        MDC.remove(REQUEST_ID_MDC_KEY);
    }
}
