package com.hexaware.controller;

import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.service.ReservationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

/**
 * REST Controller for stock reservations.
 *
 * <p>Exposes the synchronous reservation API consumed by the Order Service to
 * reserve stock when an order is placed (Requirement 7.1, 7.5). This controller
 * is a thin HTTP adapter: it performs no business logic and delegates all stock
 * and concurrency handling to {@link ReservationService}.
 *
 * <p>Base path follows the API design standard: versioned, plural, kebab-case
 * resource name (`/api/v1/stock-reservations`).
 *
 * <p>Error-to-status mapping (INSUFFICIENT_STOCK -> 409, LOCK_TIMEOUT -> 503,
 * product not found -> 404) is handled centrally by the GlobalExceptionHandler.
 */
@RestController
@RequestMapping("/api/v1/stock-reservations")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Stock Reservations", description = "Atomic, oversell-safe stock reservation operations consumed by the Order Service")
public class ReservationController {

    private static final String IDEMPOTENCY_KEY_HEADER = "Idempotency-Key";
    private static final String REQUEST_ID_HEADER = "X-Request-ID";

    private final ReservationService reservationService;

    /**
     * Create a new stock reservation for an order.
     *
     * <p>On success returns 201 Created with a Location header pointing at the
     * created reservation and the reservation details in the body (Requirement
     * 2.1, 2.6, 2.7).
     *
     * <p>Idempotency: clients may supply an {@code Idempotency-Key} header so that
     * safe retries do not create duplicate reservations. If the header is present
     * and the request body does not already carry an idempotency key, the header
     * value is applied to the request. A correlation id may be supplied via the
     * {@code X-Request-ID} header for distributed tracing.
     *
     * @param request       the reservation request (orderId, productId, quantity, optional idempotencyKey)
     * @param idempotencyKey optional Idempotency-Key header for safe retries
     * @param requestId      optional X-Request-ID header for request tracing
     * @return 201 Created with the created reservation and a Location header
     */
    @Operation(summary = "Create a stock reservation", description = "Reserves stock for an order, preventing overselling. Supports idempotent retries via the Idempotency-Key header.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Reservation created", content = @Content(schema = @Schema(implementation = ReservationResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid request body"),
            @ApiResponse(responseCode = "404", description = "Product not found"),
            @ApiResponse(responseCode = "409", description = "Insufficient stock or reservation already processed"),
            @ApiResponse(responseCode = "503", description = "Could not acquire lock, retry later")
    })
    @PostMapping
    public ResponseEntity<ReservationResponse> createReservation(
            @Valid @RequestBody CreateReservationRequest request,
            @Parameter(description = "Optional Idempotency-Key for safe retries; a repeated key returns the existing reservation instead of creating a duplicate")
            @RequestHeader(value = IDEMPOTENCY_KEY_HEADER, required = false) String idempotencyKey,
            @Parameter(description = "Optional X-Request-ID correlation id used for distributed tracing")
            @RequestHeader(value = REQUEST_ID_HEADER, required = false) String requestId) {

        log.info("Received reservation request: orderId={}, productId={}",
                request.getOrderId(), request.getProductId());

        if (idempotencyKey != null && request.getIdempotencyKey() == null) {
            request.setIdempotencyKey(idempotencyKey);
        }
        if (requestId != null && request.getCorrelationId() == null) {
            request.setCorrelationId(requestId);
        }

        ReservationResponse response = reservationService.createReservation(request);

        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{reservationId}")
                .buildAndExpand(response.getReservationId())
                .toUri();

        return ResponseEntity.created(location).body(response);
    }

    /**
     * Simple health/test endpoint that returns a plain-text greeting.
     *
     * <p>Intended for smoke-testing that the controller is wired up and reachable;
     * it performs no business logic and touches no reservation state.
     *
     * @return 200 OK with the body {@code "Hello World"}
     */
    @Operation(summary = "Test greeting", description = "Returns a plain-text 'Hello World' greeting for smoke-testing connectivity.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Greeting returned")
    })
    @GetMapping("/hello")
    public ResponseEntity<String> hello() {
        log.debug("Hello endpoint invoked");
        return ResponseEntity.ok("Hello World");
    }
}
