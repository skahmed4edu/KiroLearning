package com.hexaware.controller;

import com.hexaware.dto.OrderResponse;
import com.hexaware.dto.PlaceOrderRequest;
import com.hexaware.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

/**
 * REST Controller for order management
 */
@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Orders", description = "Order management operations")
public class OrderController {

    private final OrderService orderService;

    /**
     * Create a new order
     * 
     * @param request the order placement request
     * @return 201 Created with the created order details
     */
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@Valid @RequestBody PlaceOrderRequest request) {
        log.info("Received request to create order for user: {}", request.getUserId());
        OrderResponse response = orderService.placeOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Retrieve an order by its ID
     * 
     * @param id the order ID
     * @return 200 OK with the order details
     */
    @GetMapping("/{id}")
    public ResponseEntity<OrderResponse> getOrderById(@PathVariable UUID id) {
        log.info("Received request to retrieve order with id: {}", id);
        OrderResponse response = orderService.getOrderById(id);
        return ResponseEntity.ok(response);
    }

    /**
     * Retrieve an order by its order number
     * 
     * @param orderNumber the order number
     * @return 200 OK with the order details
     */
    @GetMapping("/number/{orderNumber}")
    public ResponseEntity<OrderResponse> getOrderByOrderNumber(@PathVariable String orderNumber) {
        log.info("Received request to retrieve order with orderNumber: {}", orderNumber);
        OrderResponse response = orderService.getOrderByOrderNumber(orderNumber);
        return ResponseEntity.ok(response);
    }

    /**
     * Retrieve the description for an order by its ID
     * 
     * @param id the order ID
     * @return 200 OK with the order description
     */
    @Operation(summary = "Get an order's description", description = "Returns the description text for the order with the given ID.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Description retrieved", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "404", description = "Order not found")
    })
    @GetMapping("/{id}/description")
    public ResponseEntity<String> getOrderDescription(@PathVariable UUID id) {
        log.info("Received request to retrieve description for order with id: {}", id);
        String description = orderService.getDescription(id);
        return ResponseEntity.ok(description);
    }

    /**
     * Delete an order by its ID
     * 
     * @param id the order ID
     * @return 204 No Content
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable UUID id) {
        log.info("Received request to delete order with id: {}", id);
        orderService.deleteOrderById(id);
        return ResponseEntity.noContent().build();
    }
}
