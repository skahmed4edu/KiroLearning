package com.hexaware.repository;

import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Repository for StockAuditLog entities.
 * 
 * Provides database access methods for stock operation audit trail queries.
 * Uses Spring Data JPA for automatic CRUD operation generation.
 * 
 * Supported Operations:
 * 1. Query audit logs by product ID
 * 2. Query audit logs by operation type
 * 3. Time-range based queries for operation tracking
 * 4. Cross-cutting queries for reconciliation
 * 
 * Use Cases:
 * - Stock reconciliation: replay all operations to verify final state
 * - Compliance auditing: prove every stock change was logged
 * - Debugging: trace root cause of stock inconsistencies
 * - Analytics: understand stock operation patterns and trends
 * - Forensics: answer "who changed what and when?"
 * 
 * Requirements: 8.1, 8.3 (Audit logging for stock operations)
 */
@Repository
public interface StockAuditLogRepository extends JpaRepository<StockAuditLog, UUID> {

    /**
     * Find all audit log records for a specific product.
     * Returns logs in chronological order (oldest first).
     * Includes all operation types (RESERVE, RELEASE, EXPIRE, BULK_UPDATE).
     * 
     * Use Case:
     * - Complete operation history for a product
     * - Stock reconciliation: replay all operations to verify current stock
     * - Analytics: analyze stock operation patterns
     * 
     * @param productId the product ID to query
     * @return list of audit logs in chronological order, empty if none found
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.product.id = :productId
        ORDER BY a.executedAt ASC
    """)
    List<StockAuditLog> findByProductId(@Param("productId") UUID productId);

    /**
     * Find all audit log records of a specific operation type.
     * Returns logs in chronological order (oldest first).
     * 
     * Use Case:
     * - Analytics: "how many RESERVE operations occurred today?"
     * - Monitoring: "what percentage of operations are EXPIRE vs RELEASE?"
     * - Debugging: trace all operations of a specific type
     * 
     * @param operationType the operation type to filter by (RESERVE, RELEASE, EXPIRE, BULK_UPDATE)
     * @return list of matching audit logs, empty if none found
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.operationType = :operationType
        ORDER BY a.executedAt ASC
    """)
    List<StockAuditLog> findByOperationType(@Param("operationType") StockOperationType operationType);

    /**
     * Find audit log records for a specific product and operation type.
     * Returns logs in chronological order (oldest first).
     * 
     * Use Case:
     * - Product-specific analytics: "how many times did this product get reserved?"
     * - Compliance: "trace all BULK_UPDATE operations for this product"
     * - Debugging: identify specific operation patterns
     * 
     * @param productId the product ID to filter by
     * @param operationType the operation type to filter by
     * @return list of matching audit logs, empty if none found
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.product.id = :productId AND a.operationType = :operationType
        ORDER BY a.executedAt ASC
    """)
    List<StockAuditLog> findByProductIdAndOperationType(
        @Param("productId") UUID productId,
        @Param("operationType") StockOperationType operationType
    );

    /**
     * Find audit log records within a specific time range.
     * Returns logs in chronological order (oldest first).
     * 
     * Use Case:
     * - Time-based auditing: "what stock changes occurred today?"
     * - Incident analysis: "trace all operations from 2 PM to 3 PM"
     * - Compliance: "all changes this month for regulatory review"
     * 
     * @param startTime the earliest execution timestamp to include (inclusive)
     * @param endTime the latest execution timestamp to include (inclusive)
     * @return list of audit logs in the time range, empty if none found
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.executedAt >= :startTime AND a.executedAt <= :endTime
        ORDER BY a.executedAt ASC
    """)
    List<StockAuditLog> findByTimeRange(
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Find audit log records for a specific product within a time range.
     * Returns logs in chronological order (oldest first).
     * 
     * Use Case:
     * - Product-level time-based queries: "what changed for this product today?"
     * - Root cause analysis: identify when stock fell below threshold
     * - Analytics: track stock level trends
     * 
     * @param productId the product ID to filter by
     * @param startTime the earliest execution timestamp (inclusive)
     * @param endTime the latest execution timestamp (inclusive)
     * @return list of matching audit logs
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.product.id = :productId
        AND a.executedAt >= :startTime
        AND a.executedAt <= :endTime
        ORDER BY a.executedAt ASC
    """)
    List<StockAuditLog> findByProductIdAndTimeRange(
        @Param("productId") UUID productId,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Find audit log records for a specific product, operation type, and time range.
     * Returns logs in chronological order (oldest first).
     * Most specific query for detailed analysis.
     * 
     * Use Case:
     * - Detailed analytics: "how many RESERVE operations for product X today?"
     * - Compliance: "all BULK_UPDATE operations for this product this month"
     * - Debugging: trace specific operation type during time window
     * 
     * @param productId the product ID to filter by
     * @param operationType the operation type to filter by
     * @param startTime the earliest execution timestamp (inclusive)
     * @param endTime the latest execution timestamp (inclusive)
     * @return list of matching audit logs
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.product.id = :productId
        AND a.operationType = :operationType
        AND a.executedAt >= :startTime
        AND a.executedAt <= :endTime
        ORDER BY a.executedAt ASC
    """)
    List<StockAuditLog> findByProductIdAndOperationTypeAndTimeRange(
        @Param("productId") UUID productId,
        @Param("operationType") StockOperationType operationType,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Find audit log records by request ID.
     * Returns logs in chronological order (oldest first).
     * Used to trace all stock operations triggered by a specific request.
     * 
     * Use Case:
     * - Correlation: link audit log entries to specific API requests
     * - Debugging: trace all operations triggered by one order
     * - Tracing: connect audit logs to application logs using request ID
     * 
     * Note: requestId can be null for operations without request context (e.g., scheduled expiration).
     * This query only returns logs with non-null requestId matching the parameter.
     * 
     * @param requestId the request identifier to filter by (typically X-Request-ID)
     * @return list of matching audit logs, empty if none found
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.requestId = :requestId
        ORDER BY a.executedAt ASC
    """)
    List<StockAuditLog> findByRequestId(@Param("requestId") String requestId);

    /**
     * Count audit log records by operation type within a time range.
     * Useful for monitoring and analytics.
     * 
     * Use Case:
     * - Dashboard: "how many RESERVE operations in the last hour?"
     * - Monitoring: detect unusual operation frequency
     * - Analytics: track operation distribution patterns
     * 
     * @param operationType the operation type to filter by
     * @param startTime the earliest execution timestamp (inclusive)
     * @param endTime the latest execution timestamp (inclusive)
     * @return count of matching records
     */
    @Query("""
        SELECT COUNT(a) FROM StockAuditLog a
        WHERE a.operationType = :operationType
        AND a.executedAt >= :startTime
        AND a.executedAt <= :endTime
    """)
    long countByOperationTypeInTimeRange(
        @Param("operationType") StockOperationType operationType,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Count audit log records by product and operation type within a time range.
     * Useful for product-level analytics and monitoring.
     * 
     * Use Case:
     * - Product dashboard: "how many EXPIRE operations for this product today?"
     * - Stock reconciliation: verify operation counts
     * 
     * @param productId the product ID to filter by
     * @param operationType the operation type to filter by
     * @param startTime the earliest execution timestamp (inclusive)
     * @param endTime the latest execution timestamp (inclusive)
     * @return count of matching records
     */
    @Query("""
        SELECT COUNT(a) FROM StockAuditLog a
        WHERE a.product.id = :productId
        AND a.operationType = :operationType
        AND a.executedAt >= :startTime
        AND a.executedAt <= :endTime
    """)
    long countByProductIdAndOperationTypeInTimeRange(
        @Param("productId") UUID productId,
        @Param("operationType") StockOperationType operationType,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Find the latest audit log record for a specific product.
     * Returns the most recent operation.
     * 
     * Use Case:
     * - Quick check: what was the last operation on this product?
     * - Current state: verify the last known stock levels
     * - Debugging: identify the most recent modification
     * 
     * @param productId the product ID to query
     * @return the most recent audit log, or null if no logs exist
     */
    @Query("""
        SELECT a FROM StockAuditLog a
        WHERE a.product.id = :productId
        ORDER BY a.executedAt DESC
        LIMIT 1
    """)
    StockAuditLog findMostRecentByProductId(@Param("productId") UUID productId);

    /**
     * Count total operations for a product.
     * Useful for analytics and monitoring.
     * 
     * @param productId the product ID to query
     * @return total count of operations for the product
     */
    @Query("""
        SELECT COUNT(a) FROM StockAuditLog a
        WHERE a.product.id = :productId
    """)
    long countByProductId(@Param("productId") UUID productId);

    /**
     * Count total operations by type.
     * Useful for system-wide analytics.
     * 
     * @param operationType the operation type to count
     * @return total count of operations of that type
     */
    @Query("""
        SELECT COUNT(a) FROM StockAuditLog a
        WHERE a.operationType = :operationType
    """)
    long countByOperationType(@Param("operationType") StockOperationType operationType);
}
