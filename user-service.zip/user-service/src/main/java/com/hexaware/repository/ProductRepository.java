package com.hexaware.repository;

import com.hexaware.entity.Product;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Repository for Product entity with support for both optimistic and pessimistic locking.
 * 
 * PESSIMISTIC LOCKING STRATEGIES:
 * 1. findByIdWithLock() - PESSIMISTIC_WRITE (SELECT ... FOR UPDATE NOWAIT)
 *    Throws LockAcquisitionFailedException if product is already locked by another transaction.
 *    Use this for reservation creation to prevent concurrent overselling.
 * 
 * 2. findByIdWithLockSkipLocked() - PESSIMISTIC_READ (SELECT ... FOR UPDATE SKIP LOCKED)
 *    Skips locked rows and returns other available products.
 *    Useful for alternative product selection when primary product is locked.
 * 
 * OPTIMISTIC LOCKING (via @Version annotation on Product.lockVersion):
 * Standard JPA queries use optimistic locking.
 * If concurrent updates occur, the second update fails with OptimisticLockingFailureException.
 * 
 * DATABASE CONSTRAINTS:
 * The products table has the following constraints:
 * - CHECK (total_stock > 0)
 * - CHECK (available_stock >= 0)
 * - CHECK (reserved_stock >= 0)
 * - CHECK (total_stock = available_stock + reserved_stock)
 * 
 * These constraints are enforced at the database level and should never be violated
 * if application code properly validates before updates.
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, java.util.UUID> {

    /**
     * Finds a product by ID with pessimistic write lock (SELECT ... FOR UPDATE NOWAIT).
     * 
     * BEHAVIOR:
     * - Acquires an exclusive lock on the product row
     * - If another transaction already holds the lock, throws LockAcquisitionFailedException immediately
     * - Does NOT wait for lock to be released (NOWAIT semantics)
     * 
     * USE CASE:
     * Critical for reservation creation to prevent race conditions and overselling.
     * When creating a reservation, we must:
     * 1. Lock the product row
     * 2. Check if available_stock >= quantity
     * 3. Update available_stock and reserved_stock atomically
     * If another transaction is already doing this, we fail immediately and client retries.
     * 
     * EXCEPTION HANDLING:
     * If lock cannot be acquired:
     * - Throws LockAcquisitionFailedException (not caught by default exception handler)
     * - Service layer converts this to HTTP 503 LOCK_TIMEOUT
     * - Client retries with exponential backoff
     * 
     * @param id product UUID
     * @return Optional containing the locked product, or empty if not found
     * @throws LockAcquisitionFailedException if lock cannot be acquired immediately
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM Product p WHERE p.id = :id")
    Optional<Product> findByIdWithLock(@Param("id") java.util.UUID id);

    /**
     * Finds a product by ID with pessimistic read lock and SKIP LOCKED clause.
     * 
     * BEHAVIOR:
     * - Attempts to acquire a lock on the product row
     * - If another transaction already holds the lock, silently skips this row
     * - May return empty if product doesn't exist or is locked by another transaction
     * 
     * USE CASE:
     * When you want to process products in batch but skip those currently locked by other transactions.
     * Example: Bulk stock update where you process available products and skip those with ongoing operations.
     * 
     * DATABASE SUPPORT:
     * This query uses "SKIP LOCKED" clause which is supported by:
     * - PostgreSQL 9.5+
     * - Oracle 12c+
     * - MySQL 8.0.1+
     * 
     * Note: Spring Data JPA's PESSIMISTIC_READ does not automatically add SKIP LOCKED.
     * For full "SKIP LOCKED" support, use the native SQL variant or custom implementation.
     * 
     * @param id product UUID
     * @return Optional containing the locked product, or empty if locked or not found
     */
    @Lock(LockModeType.PESSIMISTIC_READ)
    @Query("SELECT p FROM Product p WHERE p.id = :id")
    Optional<Product> findByIdWithLockSkipLocked(@Param("id") java.util.UUID id);

    /**
     * Finds a product by its SKU (Stock Keeping Unit).
     * 
     * SKU is a unique product code used for external system lookup.
     * This is a standard JPA query without locking.
     * 
     * USE CASE:
     * - Product lookup by external identifier
     * - Migration scripts or bulk operations
     * - API endpoint to get product by SKU
     * 
     * PERFORMANCE:
     * - Uses database index: idx_product_sku
     * - Expected latency: < 5ms for typical dataset
     * 
     * @param sku product SKU (unique identifier)
     * @return Optional containing the product, or empty if not found
     */
    Optional<Product> findBySku(String sku);

    /**
     * Finds all products matching a set of product IDs.
     * 
     * USE CASE:
     * - Batch stock level queries
     * - Bulk update operations
     * - Multi-product reservation requests
     * 
     * PERFORMANCE:
     * - Uses IN clause optimized by database
     * - Expected latency: < 50ms for 100 products
     * 
     * NOTE:
     * For large sets (> 1000 products), consider pagination to avoid database performance issues.
     * 
     * @param ids set of product UUIDs to find
     * @return list of matching products (may be empty if none found)
     */
    @Query("SELECT p FROM Product p WHERE p.id IN :ids")
    List<Product> findByIdSet(@Param("ids") Set<java.util.UUID> ids);

    /**
     * Finds multiple products by IDs with pessimistic write lock.
     * 
     * USE CASE:
     * Bulk operations that need to lock multiple products.
     * Critical for deadlock prevention: locks must be acquired in consistent order.
     * 
     * DEADLOCK PREVENTION:
     * The results are ordered by product ID (ascending) to ensure consistent lock ordering
     * across concurrent transactions. This prevents circular wait conditions.
     * 
     * Algorithm:
     * - Transaction A: locks products [P1, P2, P3] in order
     * - Transaction B: locks products [P1, P2, P3] in order (same order)
     * - Result: No circular wait, no deadlock
     * 
     * @param ids set of product UUIDs to lock
     * @return list of locked products ordered by ID (or empty if none found)
     * @throws LockAcquisitionFailedException if any product cannot be locked immediately
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM Product p WHERE p.id IN :ids ORDER BY p.id ASC")
    List<Product> findByIdSetWithLock(@Param("ids") Set<java.util.UUID> ids);
}
