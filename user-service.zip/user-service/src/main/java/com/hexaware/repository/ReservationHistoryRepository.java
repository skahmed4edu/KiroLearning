package com.hexaware.repository;

import com.hexaware.entity.ReservationHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Repository for ReservationHistory entities.
 * 
 * Provides database access methods for audit trail queries.
 * Uses Spring Data JPA for automatic CRUD operation generation.
 * 
 * Supported Operations:
 * 1. Query history by reservation ID
 * 2. Query history by order ID
 * 3. Query history by product ID
 * 4. Time-range based queries for change tracking
 * 
 * Requirements: 8.1, 8.3 (Audit logging and retrieval)
 */
@Repository
public interface ReservationHistoryRepository extends JpaRepository<ReservationHistory, UUID> {

    /**
     * Find all history records for a specific reservation.
     * Returns history in chronological order (oldest first).
     * 
     * Use Case:
     * - Audit trail for a specific reservation
     * - Replay all state transitions for a reservation
     * - Answer: "What happened to this reservation?"
     * 
     * @param reservationId the reservation ID to query
     * @return list of history records in chronological order, empty if none found
     */
    @Query("""
        SELECT h FROM ReservationHistory h
        WHERE h.reservation.id = :reservationId
        ORDER BY h.changedAt ASC
    """)
    List<ReservationHistory> findByReservationId(@Param("reservationId") UUID reservationId);

    /**
     * Find all history records for a specific order.
     * Returns history in chronological order (oldest first).
     * Can span multiple reservations if an order was retried or had multiple reservations.
     * 
     * Use Case:
     * - Complete order history including all state changes
     * - Customer support: show what happened with their order
     * - Analytics: analyze order processing patterns
     * 
     * @param orderId the order ID to query
     * @return list of history records for the order, empty if none found
     */
    @Query("""
        SELECT h FROM ReservationHistory h
        WHERE h.orderId = :orderId
        ORDER BY h.changedAt ASC
    """)
    List<ReservationHistory> findByOrderId(@Param("orderId") UUID orderId);

    /**
     * Find all history records for a specific product.
     * Returns history in chronological order (oldest first).
     * Shows all reservation state changes affecting that product.
     * 
     * Use Case:
     * - Product-level audit trail
     * - Analyze reservation patterns for a product
     * - Stock reconciliation: verify all state changes for a product
     * 
     * @param productId the product ID to query
     * @return list of history records for the product, empty if none found
     */
    @Query("""
        SELECT h FROM ReservationHistory h
        WHERE h.productId = :productId
        ORDER BY h.changedAt ASC
    """)
    List<ReservationHistory> findByProductId(@Param("productId") UUID productId);

    /**
     * Find history records within a specific time range.
     * Returns results in chronological order (oldest first).
     * 
     * Use Case:
     * - Time-based auditing: "what changed today?"
     * - Root cause analysis: "trace events from 2 PM to 3 PM"
     * - Compliance queries: "all changes this month"
     * 
     * @param startTime the earliest timestamp to include (inclusive)
     * @param endTime the latest timestamp to include (inclusive)
     * @return list of history records in the time range, empty if none found
     */
    @Query("""
        SELECT h FROM ReservationHistory h
        WHERE h.changedAt >= :startTime AND h.changedAt <= :endTime
        ORDER BY h.changedAt ASC
    """)
    List<ReservationHistory> findByTimeRange(
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Find history records for a reservation created within a specific time range.
     * Returns results in chronological order (oldest first).
     * 
     * Use Case:
     * - Recent activity queries
     * - Analytics: "how many reservations transitioned in the last hour?"
     * - Performance monitoring: track state change frequency
     * 
     * @param startTime the earliest change timestamp to include (inclusive)
     * @param endTime the latest change timestamp to include (inclusive)
     * @param productId optional product filter
     * @return list of matching history records
     */
    @Query("""
        SELECT h FROM ReservationHistory h
        WHERE h.productId = :productId
        AND h.changedAt >= :startTime
        AND h.changedAt <= :endTime
        ORDER BY h.changedAt ASC
    """)
    List<ReservationHistory> findByProductIdAndTimeRange(
        @Param("productId") UUID productId,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Count history records by new status within a time range.
     * Useful for analytics and monitoring.
     * 
     * Use Case:
     * - Dashboard: "how many reservations expired in the last hour?"
     * - Analytics: "what percentage of reservations get released?"
     * - Monitoring: detect unusual patterns
     * 
     * @param newStatus the status to filter by (e.g., "RELEASED", "EXPIRED")
     * @param startTime the earliest change timestamp (inclusive)
     * @param endTime the latest change timestamp (inclusive)
     * @return count of matching records
     */
    @Query("""
        SELECT COUNT(h) FROM ReservationHistory h
        WHERE h.newStatus = :newStatus
        AND h.changedAt >= :startTime
        AND h.changedAt <= :endTime
    """)
    long countByNewStatusInTimeRange(
        @Param("newStatus") String newStatus,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Count history records by new status and product within a time range.
     * Useful for product-level analytics.
     * 
     * Use Case:
     * - Product dashboard: "how many reservations expired for this product?"
     * - Stock reconciliation: identify problematic products
     * 
     * @param productId the product ID to filter by
     * @param newStatus the status to filter by
     * @param startTime the earliest change timestamp (inclusive)
     * @param endTime the latest change timestamp (inclusive)
     * @return count of matching records
     */
    @Query("""
        SELECT COUNT(h) FROM ReservationHistory h
        WHERE h.productId = :productId
        AND h.newStatus = :newStatus
        AND h.changedAt >= :startTime
        AND h.changedAt <= :endTime
    """)
    long countByProductIdAndNewStatusInTimeRange(
        @Param("productId") UUID productId,
        @Param("newStatus") String newStatus,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );
}
