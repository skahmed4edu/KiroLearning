package com.hexaware.repository;

import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository for Reservation entity with status-aware queries and pessimistic locking support.
 * 
 * This repository provides all necessary query patterns for:
 * 1. Finding reservations by order ID (for release operations)
 * 2. Finding expired reservations (for background expiration job)
 * 3. Calculating active reservations by product (for stock level calculations)
 * 4. Supporting idempotent reservation creation via idempotency key lookup
 * 5. Pessimistic locking queries (SELECT ... FOR UPDATE NOWAIT) for concurrency safety
 * 
 * LOCKING STRATEGY:
 * - Uses PESSIMISTIC_WRITE lock (SELECT ... FOR UPDATE NOWAIT) for critical operations
 * - Prevents race conditions during reservation creation/release
 * - Throws LockAcquisitionFailedException if lock cannot be acquired immediately
 * - Service layer converts exceptions to HTTP 503 LOCK_TIMEOUT for client retry
 * 
 * CONCURRENCY MODEL:
 * - Each query method is designed to be called within a database transaction
 * - Lock scope: duration of the transaction (from lock acquisition to commit/rollback)
 * - Lock mode: exclusive (PESSIMISTIC_WRITE) or shared (PESSIMISTIC_READ)
 * 
 * REQUIREMENTS: 2.5, 3.1, 4.1, 4.6
 */
@Repository
public interface ReservationRepository extends JpaRepository<Reservation, UUID> {

    /**
     * Finds a reservation by ID with pessimistic write lock.
     * 
     * BEHAVIOR:
     * - Acquires an exclusive lock on the reservation row via SELECT ... FOR UPDATE NOWAIT
     * - If another transaction already holds the lock, throws LockAcquisitionFailedException immediately
     * - Does NOT wait for lock to be released (NOWAIT semantics)
     * 
     * USE CASE:
     * Critical for reservation release operations to prevent concurrent modifications.
     * When releasing a reservation, we must:
     * 1. Lock the reservation row
     * 2. Check that status is ACTIVE (or already RELEASED for idempotency)
     * 3. Update status and record release timestamp
     * 4. Lock product row and restore stock
     * 
     * EXCEPTION HANDLING:
     * If lock cannot be acquired:
     * - Throws LockAcquisitionFailedException
     * - Service layer converts to HTTP 503 LOCK_TIMEOUT
     * - Client retries with exponential backoff
     * 
     * Requirements: 3.1, 6.1
     * 
     * @param id reservation UUID
     * @return Optional containing the locked reservation, or empty if not found
     * @throws jakarta.persistence.LockTimeoutException if lock cannot be acquired immediately
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT r FROM Reservation r WHERE r.id = :id")
    Optional<Reservation> findByIdWithLock(@Param("id") UUID id);

    /**
     * Finds all reservations for a specific order ID.
     * 
     * BEHAVIOR:
     * - Returns all reservations linked to the given order ID
     * - Typically returns 0-1 reservation per order in most use cases
     * - May return multiple reservations if an order reserves multiple products
     * - Results are NOT locked; suitable for read-only operations
     * 
     * USE CASE:
     * Primary use: Order cancellation - look up reservation by order ID to release stock.
     * Secondary use: Order status queries - check if order has active reservations.
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_order_id
     * - Expected latency: < 5ms
     * - Results returned in arbitrary order (not sorted)
     * 
     * Requirements: 3.1
     * 
     * @param orderId UUID of the order
     * @return list of reservations for the order (may be empty if none found)
     */
    @Query("SELECT r FROM Reservation r WHERE r.orderId = :orderId")
    List<Reservation> findByOrderId(@Param("orderId") UUID orderId);

    /**
     * Finds the first active reservation for an order ID with pessimistic write lock.
     * 
     * BEHAVIOR:
     * - Searches for ACTIVE reservations associated with the given order ID
     * - Acquires an exclusive lock on the reservation row via SELECT ... FOR UPDATE NOWAIT
     * - Returns the first (typically only) active reservation
     * - Returns empty if no active reservation exists
     * 
     * USE CASE:
     * Order release/cancellation: atomically find and lock the active reservation
     * for preventing concurrent modifications during release processing.
     * This combines the lookup and locking in a single query for better performance.
     * 
     * ALGORITHM IN SERVICE:
     * try {
     *   activeReservation = findByOrderIdWithLock(orderId)
     *   if (activeReservation.isEmpty()) return error "RESERVATION_NOT_FOUND"
     *   if (activeReservation.getStatus() != ACTIVE) return error "INVALID_STATE"
     *   // proceed to update stock and release reservation
     * } catch (LockTimeoutException) {
     *   return error LOCK_TIMEOUT (HTTP 503)
     * }
     * 
     * EXCEPTION HANDLING:
     * If lock cannot be acquired:
     * - Throws LockAcquisitionFailedException
     * - Service layer converts to HTTP 503 LOCK_TIMEOUT
     * 
     * Requirements: 3.1, 6.6
     * 
     * @param orderId UUID of the order
     * @return Optional containing the locked active reservation, or empty if not found
     * @throws jakarta.persistence.LockTimeoutException if lock cannot be acquired immediately
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT r FROM Reservation r WHERE r.orderId = :orderId AND r.status = 'ACTIVE'")
    Optional<Reservation> findByOrderIdWithLock(@Param("orderId") UUID orderId);

    /**
     * Finds all ACTIVE reservations that have expired based on current time.
     * 
     * BEHAVIOR:
     * - Returns ACTIVE reservations where expirationTime <= current time
     * - Excludes RELEASED, EXPIRED, or CANCELLED reservations
     * - Results are ordered by expiration time (oldest first)
     * - Results are NOT locked; suitable for batch processing with per-row locking
     * 
     * USE CASE:
     * Background job: Reservation expiration scheduler runs every minute.
     * Queries for expired active reservations and processes them in batch.
     * 
     * ALGORITHM IN SERVICE:
     * expiredReservations = findExpiredReservations(now)
     * for each reservation in expiredReservations:
     *   try {
     *     productLocked = lockProduct(reservation.productId)
     *     reservation.expire(now)
     *     product.availableStock += reservation.quantity
     *     product.reservedStock -= reservation.quantity
     *     save(reservation)
     *     save(product)
     *   } catch (LockTimeoutException) {
     *     // Skip and retry on next run, or retry with exponential backoff
     *     log.warn("Failed to expire reservation; will retry: " + reservation.id)
     *   }
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_expiration_time, idx_reservation_status
     * - Expected latency: < 20ms for typical dataset
     * - Row count: typically 0-100 expired reservations per minute in normal load
     * 
     * Requirements: 4.1, 4.6
     * 
     * @param now current timestamp for expiration comparison
     * @return list of expired ACTIVE reservations ordered by expiration time (or empty if none)
     */
    @Query("""
        SELECT r FROM Reservation r 
        WHERE r.status = 'ACTIVE' 
        AND r.expirationTime <= :now 
        ORDER BY r.expirationTime ASC
        """)
    List<Reservation> findExpiredReservations(@Param("now") LocalDateTime now);

    /**
     * Finds all ACTIVE reservations for a specific product.
     * 
     * BEHAVIOR:
     * - Returns ACTIVE reservations where product ID matches
     * - Excludes RELEASED, EXPIRED, or CANCELLED reservations
     * - Does NOT include expired reservations (checked by caller)
     * - Results are NOT locked; suitable for aggregation queries
     * 
     * USE CASE:
     * Calculating available stock for a product:
     * availableStock = totalStock - SUM(active reservations for product)
     * 
     * This query is used to:
     * 1. Stock level response: calculate current available stock
     * 2. Validation: check if sufficient stock before reservation
     * 3. Health checks: verify stock invariant
     * 
     * ALGORITHM IN SERVICE:
     * activeReservations = findActiveReservationsByProductId(productId)
     * totalReservedQuantity = SUM(activeReservations.quantity)
     * availableStock = product.totalStock - totalReservedQuantity
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_product_id, idx_reservation_status
     * - Expected latency: < 10ms for typical dataset
     * - Row count: typically 5-50 active reservations per product in normal load
     * 
     * IMPORTANT:
     * - Caller is responsible for filtering out expired reservations separately
     * - This query only returns ACTIVE status; expired reservations are excluded
     * - This is efficient because expiration job runs frequently (every 60 seconds)
     * - Therefore, expired reservations should be rare in normal operation
     * 
     * Requirements: 2.5, 4.1
     * 
     * @param productId UUID of the product
     * @return list of active reservations for the product (may be empty)
     */
    @Query("SELECT r FROM Reservation r WHERE r.product.id = :productId AND r.status = 'ACTIVE'")
    List<Reservation> findActiveReservationsByProductId(@Param("productId") UUID productId);

    /**
     * Finds a reservation by idempotency key and order ID.
     * 
     * BEHAVIOR:
     * - Looks up reservation using combination of idempotency_key and order_id
     * - Returns empty if no reservation matches both criteria
     * - Suitable for deduplication on retry
     * - Does NOT lock the result; suitable for read-only checks
     * 
     * USE CASE:
     * Idempotent reservation creation:
     * 1. Client sends: POST /reservations with Idempotency-Key header
     * 2. Server queries: findByIdempotencyKeyAndOrderId(key, orderId)
     * 3. If found: return existing reservation (idempotent)
     * 4. If not found: create new reservation
     * 
     * IDEMPOTENCY SCOPE:
     * - Unique by (idempotency_key, order_id) pair
     * - Allows same idempotency key for different orders
     * - Protects against duplicate reservations from network retries
     * 
     * ALGORITHM IN SERVICE (CREATE RESERVATION):
     * existingReservation = findByIdempotencyKeyAndOrderId(key, orderId)
     * if (existingReservation.isPresent()) {
     *   if (existingReservation.getStatus() == ACTIVE) {
     *     return success with existing reservation
     *   } else if (existingReservation.getStatus() == RELEASED) {
     *     return error RESERVATION_ALREADY_RELEASED
     *   } else {
     *     return error RESERVATION_INVALID_STATE
     *   }
     * }
     * // Not found, proceed to create new reservation
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_idempotency_key
     * - Expected latency: < 5ms
     * 
     * Requirements: 2.5, 4.6
     * 
     * @param idempotencyKey the idempotency key (unique request identifier)
     * @param orderId the order UUID
     * @return Optional containing the reservation if found, or empty
     */
    @Query("""
        SELECT r FROM Reservation r 
        WHERE r.idempotencyKey = :idempotencyKey 
        AND r.orderId = :orderId
        """)
    Optional<Reservation> findByIdempotencyKeyAndOrderId(
        @Param("idempotencyKey") String idempotencyKey,
        @Param("orderId") UUID orderId
    );

    /**
     * Finds all ACTIVE reservations across all products, ordered by expiration time.
     * 
     * BEHAVIOR:
     * - Returns all ACTIVE reservations
     * - Excludes RELEASED, EXPIRED, or CANCELLED reservations
     * - Ordered by expiration time (oldest first) for processing
     * - Suitable for batch processing with pagination
     * 
     * USE CASE:
     * Health checks or monitoring: query total active reservations.
     * Batch expiration processing: get next batch of expiring reservations.
     * Analytics: count active reservations across all products.
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_status, idx_reservation_expiration_time
     * - Expected latency: < 50ms depending on reservation count
     * 
     * @return list of all active reservations ordered by expiration time
     */
    @Query("""
        SELECT r FROM Reservation r 
        WHERE r.status = 'ACTIVE' 
        ORDER BY r.expirationTime ASC
        """)
    List<Reservation> findAllActiveReservations();

    /**
     * Counts total number of reservations for a specific product and status.
     * 
     * BEHAVIOR:
     * - Counts reservations matching product ID and status
     * - Suitable for metrics and monitoring
     * - Fast aggregation query
     * 
     * USE CASE:
     * Metrics collection: count active/expired/released reservations per product.
     * Health checks: verify reservation counts are reasonable.
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_product_id, idx_reservation_status
     * - Expected latency: < 5ms
     * 
     * @param productId UUID of the product
     * @param status the reservation status to count
     * @return count of reservations matching criteria
     */
    @Query("""
        SELECT COUNT(r) FROM Reservation r 
        WHERE r.product.id = :productId 
        AND r.status = :status
        """)
    long countByProductIdAndStatus(
        @Param("productId") UUID productId,
        @Param("status") ReservationStatus status
    );

    /**
     * Finds reservations created within a specific time range.
     * 
     * BEHAVIOR:
     * - Returns reservations where createdAt is between startTime and endTime (inclusive)
     * - Includes all statuses (ACTIVE, RELEASED, EXPIRED, CANCELLED)
     * - Ordered by creation time (oldest first)
     * 
     * USE CASE:
     * Analytics: query reservations created today/this week.
     * Audit: find reservations created around a specific time.
     * Performance analysis: measure reservation processing time.
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_created_at
     * - Expected latency: < 50ms depending on time range and result count
     * 
     * @param startTime start of time range (inclusive)
     * @param endTime end of time range (inclusive)
     * @return list of reservations created in the range (ordered by creation time)
     */
    @Query("""
        SELECT r FROM Reservation r 
        WHERE r.createdAt >= :startTime 
        AND r.createdAt <= :endTime 
        ORDER BY r.createdAt ASC
        """)
    List<Reservation> findByCreatedAtBetween(
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );

    /**
     * Finds all RELEASED reservations for a specific order ID.
     * 
     * BEHAVIOR:
     * - Returns RELEASED reservations for the order
     * - Typically returns 0-1 reservation per order
     * - Useful for auditing order cancellations
     * 
     * USE CASE:
     * Audit trail: verify which reservations were released for an order.
     * Order status: check if reservation was released and when.
     * 
     * @param orderId UUID of the order
     * @return list of released reservations for the order
     */
    @Query("""
        SELECT r FROM Reservation r 
        WHERE r.orderId = :orderId 
        AND r.status = 'RELEASED'
        """)
    List<Reservation> findReleasedByOrderId(@Param("orderId") UUID orderId);

    /**
     * Counts total active reservations for a specific product.
     * 
     * BEHAVIOR:
     * - Counts only ACTIVE reservations (excludes RELEASED, EXPIRED, CANCELLED)
     * - Used for calculating reserved stock quantity
     * 
     * USE CASE:
     * Stock calculation: determine total reserved quantity for a product.
     * Metrics: track active reservation count per product.
     * 
     * PERFORMANCE:
     * - Uses index: idx_reservation_product_id, idx_reservation_status
     * - Expected latency: < 5ms
     * 
     * @param productId UUID of the product
     * @return count of active reservations for the product
     */
    @Query("""
        SELECT COUNT(r) FROM Reservation r 
        WHERE r.product.id = :productId 
        AND r.status = 'ACTIVE'
        """)
    long countActiveByProductId(@Param("productId") UUID productId);

    /**
     * Sums the total quantity reserved for a specific product.
     * 
     * BEHAVIOR:
     * - Sums quantity of all ACTIVE reservations for the product
     * - Returns 0 if no active reservations
     * - Used for verifying stock invariant
     * 
     * USE CASE:
     * Stock validation: verify that sum of active reservations equals product.reservedStock.
     * Health checks: ensure stock invariant is maintained.
     * 
     * @param productId UUID of the product
     * @return sum of active reservation quantities, or 0 if none
     */
    @Query("""
        SELECT COALESCE(SUM(r.quantity), 0) FROM Reservation r 
        WHERE r.product.id = :productId 
        AND r.status = 'ACTIVE'
        """)
    long sumActiveQuantityByProductId(@Param("productId") UUID productId);
}
