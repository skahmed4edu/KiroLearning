package com.hexaware.repository;

import com.hexaware.entity.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository for Order entity
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, UUID> {

    /**
     * Find an order by order number
     * 
     * @param orderNumber the order number to search for
     * @return Optional containing the order if found
     */
    Optional<Order> findByOrderNumber(String orderNumber);

    /**
     * Check if an order with the given order number already exists
     * 
     * @param orderNumber the order number to check
     * @return true if order number exists, false otherwise
     */
    boolean existsByOrderNumber(String orderNumber);

    /**
     * Find all orders for a specific user with pagination
     * 
     * @param userId the user ID
     * @param pageable pagination information
     * @return Page of orders for the user
     */
    Page<Order> findByUserId(UUID userId, Pageable pageable);

    /**
     * Find all orders with a specific status with pagination
     * 
     * @param status the order status
     * @param pageable pagination information
     * @return Page of orders with the given status
     */
    Page<Order> findByStatus(Order.OrderStatus status, Pageable pageable);

    /**
     * Find all orders with a specific payment status with pagination
     * 
     * @param paymentStatus the payment status
     * @param pageable pagination information
     * @return Page of orders with the given payment status
     */
    Page<Order> findByPaymentStatus(Order.PaymentStatus paymentStatus, Pageable pageable);

    /**
     * Find all orders for a user with a specific status
     * 
     * @param userId the user ID
     * @param status the order status
     * @return List of orders matching both criteria
     */
    @Query("SELECT o FROM Order o WHERE o.user.id = :userId AND o.status = :status")
    List<Order> findByUserIdAndStatus(@Param("userId") UUID userId, @Param("status") Order.OrderStatus status);

    /**
     * Find all orders for a user with a specific payment status
     * 
     * @param userId the user ID
     * @param paymentStatus the payment status
     * @return List of orders matching both criteria
     */
    @Query("SELECT o FROM Order o WHERE o.user.id = :userId AND o.paymentStatus = :paymentStatus")
    List<Order> findByUserIdAndPaymentStatus(@Param("userId") UUID userId, @Param("paymentStatus") Order.PaymentStatus paymentStatus);

    /**
     * Count orders for a user
     * 
     * @param userId the user ID
     * @return count of orders for the user
     */
    long countByUserId(UUID userId);

    /**
     * Count unpaid orders for a user
     * 
     * @param userId the user ID
     * @return count of unpaid orders for the user
     */
    @Query("SELECT COUNT(o) FROM Order o WHERE o.user.id = :userId AND o.paymentStatus IN (com.hexaware.entity.Order$PaymentStatus.UNPAID, com.hexaware.entity.Order$PaymentStatus.PENDING)")
    long countUnpaidOrdersByUserId(@Param("userId") UUID userId);
}
