package com.hexaware.util;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Utility class for preventing deadlocks in concurrent bulk stock updates.
 * 
 * DEADLOCK PREVENTION STRATEGY:
 * =============================
 * Deadlocks occur when multiple transactions try to acquire locks on the same resources
 * in different orders. This creates a circular wait condition:
 * 
 * Example of DEADLOCK (without lock ordering):
 * ┌─────────────────────────────────────────┐
 * │ Thread A (Transaction 1)                │
 * │ Step 1: Lock Product P2                 │
 * │ Step 2: Wait for lock on Product P1     │ ◄── Blocked by Thread B
 * │         (held by Thread B)              │
 * └─────────────────────────────────────────┘
 *         △                                 
 *         │ Circular Wait!                  
 *         ▼                                 
 * ┌─────────────────────────────────────────┐
 * │ Thread B (Transaction 2)                │
 * │ Step 1: Lock Product P1                 │
 * │ Step 2: Wait for lock on Product P2     │ ◄── Blocked by Thread A
 * │         (held by Thread A)              │
 * └─────────────────────────────────────────┘
 * 
 * RESULT: DEADLOCK - both transactions are blocked indefinitely
 * 
 * HOW THIS UTILITY PREVENTS DEADLOCKS:
 * ====================================
 * By ensuring consistent lock ordering across all transactions:
 * 
 * Example with CONSISTENT ORDERING (using this utility):
 * ┌─────────────────────────────────────────┐
 * │ Thread A (Transaction 1)                │
 * │ Step 1: Lock Product P1 (sorted order)  │
 * │ Step 2: Lock Product P2 (sorted order)  │ ◄── No wait, ordered access
 * │ Step 3: Commit                          │
 * └─────────────────────────────────────────┘
 * 
 * ┌─────────────────────────────────────────┐
 * │ Thread B (Transaction 2)                │
 * │ Step 1: Lock Product P1 (sorted order)  │ ◄── Must wait for Thread A
 * │ Step 2: Lock Product P2 (sorted order)  │
 * │ Step 3: Commit                          │
 * └─────────────────────────────────────────┘
 * 
 * RESULT: NO DEADLOCK - Thread B simply waits for Thread A to finish
 * 
 * KEY PRINCIPLE:
 * ==============
 * If all transactions lock resources in the same order (ascending by ID),
 * circular wait conditions become impossible, and deadlocks cannot occur.
 * 
 * PERFORMANCE IMPLICATIONS:
 * ========================
 * - Positive: Prevents deadlocks entirely, eliminating retry-and-backoff overhead
 * - Positive: Ensures predictable performance (no sudden retries)
 * - Negative: Introduces a sorting overhead O(n log n) for each bulk operation
 * - Negative: Serializes bulk updates (one thread waits for another)
 * - Net result: Small sorting cost is outweighed by elimination of deadlock retries
 * 
 * USAGE:
 * ======
 * List<UUID> sortedIds = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);
 * // Now lock products in this order to prevent deadlocks
 * for (UUID id : sortedIds) {
 *     Product p = repository.findByIdWithLock(id);
 *     // Process product
 * }
 * 
 * @author Inventory Management Service
 * @version 1.0
 */
public class DeadlockPreventionUtil {

    private DeadlockPreventionUtil() {
        // Utility class, no instantiation
    }

    /**
     * Sorts product IDs in ascending order for consistent lock acquisition.
     * 
     * This method enforces consistent lock ordering across all concurrent transactions.
     * By ensuring all transactions lock products in the same order (ascending by ID),
     * we eliminate the possibility of circular wait conditions and prevent deadlocks.
     * 
     * ALGORITHM:
     * 1. Convert input collection to list (if not already)
     * 2. Sort list by product ID in ascending order (natural UUID ordering)
     * 3. Return sorted list
     * 
     * TIME COMPLEXITY: O(n log n) where n is the number of product IDs
     * SPACE COMPLEXITY: O(n) for the output list
     * 
     * USE CASE:
     * - Bulk stock updates: ensure all products locked in same order
     * - Concurrent reservation operations on multiple products
     * - Any multi-row lock acquisition scenario
     * 
     * EXAMPLE:
     * Input: [UUID3, UUID1, UUID2]
     * Output: [UUID1, UUID2, UUID3]  (ascending order)
     * 
     * Thread A: locks [UUID1, UUID2, UUID3] in this order
     * Thread B: locks [UUID1, UUID2, UUID3] in this order
     * Result: No deadlock (consistent order)
     * 
     * @param productIds collection of product UUIDs to sort (can be any Collection type)
     * @return immutable list of product IDs sorted in ascending order
     * @throws NullPointerException if productIds is null
     * @throws NullPointerException if any product ID in the collection is null
     */
    public static List<UUID> sortProductsByIdForLocking(Collection<UUID> productIds) {
        if (productIds == null) {
            throw new NullPointerException("productIds cannot be null");
        }

        return productIds.stream()
                .sorted()
                .collect(Collectors.toUnmodifiableList());
    }

    /**
     * Validates that a list of product IDs is sorted in ascending order.
     * 
     * USAGE:
     * Internal utility for assertions and testing. Verifies that the output
     * from sortProductsByIdForLocking() is correctly ordered.
     * 
     * @param sortedIds list of product IDs to validate
     * @return true if list is sorted in ascending order, false otherwise
     */
    public static boolean isSortedAscending(List<UUID> sortedIds) {
        if (sortedIds == null || sortedIds.isEmpty()) {
            return true;
        }

        for (int i = 0; i < sortedIds.size() - 1; i++) {
            if (sortedIds.get(i).compareTo(sortedIds.get(i + 1)) > 0) {
                return false;
            }
        }

        return true;
    }
}
