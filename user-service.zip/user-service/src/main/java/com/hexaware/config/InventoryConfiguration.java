package com.hexaware.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.*;

/**
 * Configuration properties for the Inventory Management Service.
 * 
 * Loads all inventory-related configuration from environment variables
 * and application.properties with the prefix "inventory".
 * 
 * Configuration Hierarchy (in order of precedence):
 * 1. Environment variables (e.g., INVENTORY_LOCK_TIMEOUT_SECONDS)
 * 2. System properties (e.g., -Dinventory.lock.timeout-seconds=30)
 * 3. application.properties file
 * 4. Default values specified in this class
 * 
 * Validation:
 * - All configuration values are validated at startup
 * - Invalid ranges cause application startup failure
 * - Specific range constraints are enforced via @Min/@Max annotations
 * 
 * REQUIREMENTS:
 * - Requirements: 4.4, 4.5, 4.7 (Configuration Management)
 * - INVENTORY_LOCK_TIMEOUT_SECONDS: Requirement 6.8 (Deadlock Prevention)
 * 
 * @author Inventory Management Service
 * @version 1.0
 */
@Component
@ConfigurationProperties(prefix = "inventory")
@Validated
@Data
public class InventoryConfiguration {

    /**
     * INVENTORY_RESERVATION_TTL_MINUTES
     * 
     * Time-To-Live (TTL) for reservations in minutes.
     * When a reservation is created, it automatically expires after this period.
     * 
     * Default: 15 minutes
     * Valid range: 1-1440 (1 minute to 24 hours)
     * 
     * Example: If TTL = 15 minutes, a reservation created at 10:00 AM
     *          will automatically expire at 10:15 AM if not released before then.
     */
    @NotNull(message = "Reservation TTL must not be null")
    @Min(value = 1, message = "Reservation TTL must be at least 1 minute")
    @Max(value = 1440, message = "Reservation TTL must not exceed 1440 minutes (24 hours)")
    private Integer reservationTtlMinutes = 15;

    /**
     * INVENTORY_EXPIRATION_CHECK_INTERVAL_SECONDS
     * 
     * How often the background expiration job checks for expired reservations.
     * 
     * Default: 60 seconds
     * Valid range: 10-300 (10 seconds to 5 minutes)
     * 
     * Example: If check interval = 60 seconds, the expiration job runs every 60 seconds
     *          to find and process expired reservations.
     * 
     * Trade-off:
     * - Lower value: Faster expiration of reservations (more responsive)
     * - Higher value: Lower database load (more efficient)
     */
    @NotNull(message = "Expiration check interval must not be null")
    @Min(value = 10, message = "Expiration check interval must be at least 10 seconds")
    @Max(value = 300, message = "Expiration check interval must not exceed 300 seconds")
    private Integer expirationCheckIntervalSeconds = 60;

    /**
     * INVENTORY_BULK_UPDATE_MAX_SIZE
     * 
     * Maximum number of products that can be updated in a single bulk operation.
     * 
     * Default: 1000 products
     * Valid range: 1-10000
     * 
     * This limit prevents:
     * - Excessively large database transactions
     * - Long lock acquisition times (higher deadlock risk)
     * - Memory exhaustion on large updates
     */
    @NotNull(message = "Bulk update max size must not be null")
    @Min(value = 1, message = "Bulk update max size must be at least 1")
    @Max(value = 10000, message = "Bulk update max size must not exceed 10000")
    private Integer bulkUpdateMaxSize = 1000;

    /**
     * INVENTORY_LOCK_TIMEOUT_SECONDS
     * 
     * Database lock timeout for concurrent operations (pessimistic locking).
     * 
     * Default: 30 seconds
     * Valid range: 5-300 (5 seconds to 5 minutes)
     * 
     * When a transaction attempts to acquire a pessimistic lock on a product row:
     * - If the lock is acquired within this timeout, the operation proceeds normally
     * - If the lock cannot be acquired after this timeout, the transaction fails
     * - The client receives HTTP 503 Service Unavailable with retry hint
     * - Client implements exponential backoff retry logic
     * 
     * DEADLOCK PREVENTION (Requirement 6.8):
     * - This timeout prevents indefinite blocking of transactions
     * - Forced failure allows other clients to proceed
     * - Enables clients to implement retry logic
     * - In combination with consistent lock ordering, prevents deadlock scenarios
     * 
     * Performance Impact:
     * - Too low (5 seconds): Clients fail frequently, high retry rate
     * - Too high (5 minutes): Slow failure detection, client stalls
     * - Optimal (30 seconds): Balances responsiveness with throughput
     */
    @NotNull(message = "Lock timeout must not be null")
    @Min(value = 5, message = "Lock timeout must be at least 5 seconds")
    @Max(value = 300, message = "Lock timeout must not exceed 300 seconds")
    private Integer lockTimeoutSeconds = 30;

    /**
     * INVENTORY_MAX_RESERVATIONS_PER_SECOND
     * 
     * Maximum concurrent reservations per second for rate limiting.
     * 
     * Default: 10000 reservations/second
     * Valid range: 100-100000
     * 
     * This configuration can be used to:
     * - Prevent database resource exhaustion
     * - Ensure fair distribution of database connections
     * - Handle traffic spikes gracefully
     */
    @NotNull(message = "Max reservations per second must not be null")
    @Min(value = 100, message = "Max reservations per second must be at least 100")
    @Max(value = 100000, message = "Max reservations per second must not exceed 100000")
    private Integer maxReservationsPerSecond = 10000;

    /**
     * INVENTORY_IDEMPOTENCY_KEY_RETENTION_DAYS
     * 
     * How long idempotency keys are retained for deduplication.
     * 
     * Default: 1 day
     * Valid range: 1-30
     * 
     * Idempotency keys enable:
     * - Safe request retries (no duplicate reservations)
     * - Resilient client implementations
     * - Automatic deduplication of duplicate requests
     * 
     * Storage:
     * - Keys older than retention period can be purged to save storage
     * - Each key can be indexed for fast lookup
     */
    @NotNull(message = "Idempotency key retention days must not be null")
    @Min(value = 1, message = "Idempotency key retention must be at least 1 day")
    @Max(value = 30, message = "Idempotency key retention must not exceed 30 days")
    private Integer idempotencyKeyRetentionDays = 1;

    /**
     * INVENTORY_DB_CONNECTION_POOL_SIZE
     * 
     * Number of database connections in the connection pool for inventory operations.
     * 
     * Default: 20 connections
     * Valid range: 10-100
     * 
     * Connection Pool Sizing:
     * - Too low: Connection starvation, requests queued waiting for connections
     * - Too high: Resource wastage, unnecessary database overhead
     * - Optimal: Number of concurrent operations expected
     */
    @NotNull(message = "Database connection pool size must not be null")
    @Min(value = 10, message = "Database connection pool size must be at least 10")
    @Max(value = 100, message = "Database connection pool size must not exceed 100")
    private Integer databaseConnectionPoolSize = 20;

    /**
     * Inner class for nested configuration properties (database section).
     * Allows hierarchical property binding: inventory.database.lock-timeout-seconds
     */
    @Data
    public static class Database {
        /**
         * Alternative configuration path for lock timeout (same as inventory.lock.timeout-seconds).
         * Supports hierarchical configuration like inventory.database.lock-timeout-seconds.
         */
        private Integer lockTimeoutSeconds = 30;

        /**
         * Connection pool size for database operations.
         */
        private Integer connectionPoolSize = 20;
    }

    /**
     * Inner class for nested configuration properties (reservation section).
     * Allows hierarchical property binding: inventory.reservation.ttl-minutes
     */
    @Data
    public static class Reservation {
        /**
         * Reservation TTL in minutes.
         */
        private Integer ttlMinutes = 15;
    }

    /**
     * Inner class for nested configuration properties (expiration section).
     * Allows hierarchical property binding: inventory.expiration.check-interval-seconds
     */
    @Data
    public static class Expiration {
        /**
         * Check interval in seconds.
         */
        private Integer checkIntervalSeconds = 60;
    }

    /**
     * Inner class for nested configuration properties (bulk-update section).
     * Allows hierarchical property binding: inventory.bulk-update.max-size
     */
    @Data
    public static class BulkUpdate {
        /**
         * Maximum size for bulk update operations.
         */
        private Integer maxSize = 1000;
    }

    /**
     * Inner class for nested configuration properties (lock section).
     * Allows hierarchical property binding: inventory.lock.timeout-seconds
     */
    @Data
    public static class Lock {
        /**
         * Lock timeout in seconds.
         */
        private Integer timeoutSeconds = 30;
    }

    /**
     * Get lock timeout in milliseconds (for Hibernate JPA compatibility).
     * 
     * Hibernate expects lock timeout in milliseconds.
     * Configuration is stored in seconds for readability.
     * 
     * @return lock timeout in milliseconds
     */
    public long getLockTimeoutMillis() {
        return (long) lockTimeoutSeconds * 1000;
    }

    /**
     * Validate configuration on bean initialization.
     * Automatically called by Spring after properties are set.
     * 
     * Additional validation logic can be added here beyond @Min/@Max constraints.
     */
    @Override
    public String toString() {
        return "InventoryConfiguration{" +
                "reservationTtlMinutes=" + reservationTtlMinutes +
                ", expirationCheckIntervalSeconds=" + expirationCheckIntervalSeconds +
                ", bulkUpdateMaxSize=" + bulkUpdateMaxSize +
                ", lockTimeoutSeconds=" + lockTimeoutSeconds +
                ", maxReservationsPerSecond=" + maxReservationsPerSecond +
                ", idempotencyKeyRetentionDays=" + idempotencyKeyRetentionDays +
                ", databaseConnectionPoolSize=" + databaseConnectionPoolSize +
                '}';
    }
}
