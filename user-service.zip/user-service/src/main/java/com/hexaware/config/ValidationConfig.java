package com.hexaware.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;

import jakarta.validation.Validator;

/**
 * Configuration class for enabling JSR-303 Bean Validation in the application.
 * 
 * This configuration enables:
 * 1. Bean validation for request/response DTOs
 * 2. Method-level validation for service layer methods
 * 3. Custom validators (validators in com.hexaware.validation package)
 * 
 * Functionality:
 * - LocalValidatorFactoryBean: Primary bean validation factory that discovers
 *   and registers all custom validators
 * - MethodValidationPostProcessor: Enables @Validated on classes for method
 *   parameter and return value validation
 * 
 * Custom Validators Registered:
 * - @BulkUpdateMaxSize: Validates list batch sizes
 * - @ValidProductExists: Validates product ID existence in database
 * - @ValidProductQuantity: Validates quantity is positive
 * 
 * Requirements: 5.2, 5.3, 5.6
 */
@Configuration
public class ValidationConfig {
    
    /**
     * Create the LocalValidatorFactoryBean for JSR-303 validation.
     * 
     * This bean is responsible for:
     * - Discovering and registering custom constraint validators
     * - Creating Validator instances for programmatic validation
     * - Integration with Spring's validation framework
     * 
     * The bean is automatically used by Spring to validate:
     * - Request DTOs annotated with @Valid
     * - Path variables and request parameters
     * - Method parameters in @Validated classes
     * 
     * @return LocalValidatorFactoryBean configured for validation
     */
    @Bean
    public LocalValidatorFactoryBean validator() {
        return new LocalValidatorFactoryBean();
    }
    
    /**
     * Create MethodValidationPostProcessor for method-level validation.
     * 
     * This post-processor enables method parameter and return value validation
     * on classes annotated with @Validated.
     * 
     * Usage:
     * @Service
     * @Validated
     * public class MyService {
     *     public void method(@Valid CreateReservationRequest request) {
     *         // request is validated before method execution
     *     }
     * }
     * 
     * Benefits:
     * - Service layer methods can be validated automatically
     * - Reduces boilerplate validation code
     * - Provides consistent validation across layers
     * 
     * @return MethodValidationPostProcessor for enabling method validation
     */
    @Bean
    public MethodValidationPostProcessor methodValidationPostProcessor() {
        MethodValidationPostProcessor processor = new MethodValidationPostProcessor();
        processor.setValidator(validator());
        return processor;
    }
}
