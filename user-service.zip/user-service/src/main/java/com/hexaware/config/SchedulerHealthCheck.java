package com.hexaware.config;

import com.hexaware.service.ReservationExpirationScheduler;
import com.hexaware.service.ReservationExpirationScheduler.SchedulerExecutionStats;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.boot.health.contributor.Status;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 * Spring Boot Actuator health indicator for the reservation-expiration background job
 * ({@link ReservationExpirationScheduler}).
 *
 * <p>Satisfies Requirement 8.7 by reporting the status of reservation expiration processing
 * through the standard Actuator health infrastructure. Because the bean is named
 * {@code reservationExpiration}, Actuator contributes its result under the
 * {@code reservationExpiration} key of {@code GET /actuator/health}, matching the shape in
 * the design document:
 *
 * <pre>
 * "reservationExpiration": {
 *   "status": "UP",
 *   "lastExecutionTime": "2024-01-15T10:30:00Z",
 *   "nextExecutionTime": "2024-01-15T10:31:00Z",
 *   "successRate": "99.9%"
 * }
 * </pre>
 *
 * <p>STATUS RULES:
 * <ul>
 *   <li>{@code UP} — the scheduler has not run yet (freshly started) or its most recent
 *       cycles are succeeding at or above {@link #MINIMUM_HEALTHY_SUCCESS_RATE}, and the last
 *       run is not older than {@link #STALE_EXECUTION_MULTIPLIER} intervals.</li>
 *   <li>{@code DOWN} — the success rate has dropped below the healthy threshold, or the job
 *       appears stalled (no successful run within the expected window).</li>
 * </ul>
 *
 * <p>The indicator derives all data from a {@link SchedulerExecutionStats} snapshot and holds
 * no mutable state of its own, so it is safe to query concurrently with scheduler cycles.
 *
 * <p>Requirements: 8.7
 */
@Component("reservationExpiration")
@RequiredArgsConstructor
@Slf4j
public class SchedulerHealthCheck implements HealthIndicator {

    /**
     * Minimum fraction of successful cycles for the scheduler to be reported {@code UP}.
     * Below this (e.g. repeated unhandled failures) the component is {@code DOWN}.
     */
    static final double MINIMUM_HEALTHY_SUCCESS_RATE = 0.90;

    /**
     * Multiplier applied to the configured check interval to decide whether the last
     * successful run is "stale". If the scheduler last succeeded more than
     * {@code intervalSeconds * STALE_EXECUTION_MULTIPLIER} ago, it is treated as stalled.
     */
    static final long STALE_EXECUTION_MULTIPLIER = 5L;

    private final ReservationExpirationScheduler scheduler;

    /**
     * Builds the health report for the reservation-expiration scheduler from its latest
     * execution-state snapshot, and logs the outcome at debug level.
     *
     * @return a {@link Health} with status plus {@code lastExecutionTime},
     * {@code nextExecutionTime}, {@code successRate}, {@code errorRate} and batch statistics
     */
    @Override
    public Health health() {
        SchedulerExecutionStats stats = scheduler.getExecutionStats();

        Health.Builder builder = isHealthy(stats) ? Health.up() : Health.down();

        builder.withDetail("lastExecutionTime", nullSafe(stats.lastExecutionTime()))
                .withDetail("lastSuccessfulExecutionTime", nullSafe(stats.lastSuccessfulExecutionTime()))
                .withDetail("nextExecutionTime", nullSafe(stats.nextExecutionTime()))
                .withDetail("successRate", formatPercentage(stats.successRate()))
                .withDetail("errorRate", formatPercentage(stats.errorRate()))
                .withDetail("totalExecutions", stats.totalExecutions())
                .withDetail("successCount", stats.successCount())
                .withDetail("errorCount", stats.errorCount())
                .withDetail("lastBatchExpiredCount", stats.lastBatchExpiredCount())
                .withDetail("lastBatchProductsAffected", stats.lastBatchProductsAffected())
                .withDetail("lastBatchDurationMs", stats.lastBatchDurationMs());

        Health health = builder.build();
        log.debug("Reservation expiration scheduler health: status={}, successRate={}, lastExecutionTime={}",
                health.getStatus(), formatPercentage(stats.successRate()), nullSafe(stats.lastExecutionTime()));
        return health;
    }

    /**
     * Determines whether the scheduler is healthy.
     *
     * <p>A scheduler that has never run is considered healthy (it has only just started).
     * Once it has run, it must both maintain the minimum success rate and have produced a
     * recent successful execution.
     *
     * @param stats the current execution snapshot
     * @return {@code true} if the component should report {@link Status#UP}
     */
    private boolean isHealthy(SchedulerExecutionStats stats) {
        if (!stats.hasExecuted()) {
            return true;
        }
        if (stats.successRate() < MINIMUM_HEALTHY_SUCCESS_RATE) {
            return false;
        }
        return !isStale(stats);
    }

    /**
     * Returns whether the last successful execution is older than the allowed staleness
     * window ({@link #STALE_EXECUTION_MULTIPLIER} intervals). A scheduler that has run but
     * never succeeded is treated as stale.
     *
     * @param stats the current execution snapshot
     * @return {@code true} if the scheduler appears stalled
     */
    private boolean isStale(SchedulerExecutionStats stats) {
        LocalDateTime nextExecutionTime = stats.nextExecutionTime();
        LocalDateTime lastSuccess = stats.lastSuccessfulExecutionTime();
        if (lastSuccess == null || stats.lastExecutionTime() == null || nextExecutionTime == null) {
            return true;
        }
        // nextExecutionTime == lastExecutionTime + interval, so the interval is recoverable.
        long intervalSeconds = Duration.between(stats.lastExecutionTime(), nextExecutionTime).getSeconds();
        long staleAfterSeconds = Math.max(intervalSeconds, 1L) * STALE_EXECUTION_MULTIPLIER;
        return Duration.between(lastSuccess, LocalDateTime.now()).getSeconds() > staleAfterSeconds;
    }

    /**
     * Formats a rate fraction in {@code [0.0, 1.0]} as a one-decimal percentage string, e.g.
     * {@code 0.999 -> "99.9%"}.
     *
     * @param rate the fraction to format
     * @return the formatted percentage
     */
    private String formatPercentage(double rate) {
        return String.format("%.1f%%", rate * 100);
    }

    /**
     * Renders a possibly-null detail value, using {@code "N/A"} when absent so the health
     * payload never contains null detail values.
     *
     * @param value the value to render
     * @return the value, or {@code "N/A"} when {@code null}
     */
    private Object nullSafe(Object value) {
        return value == null ? "N/A" : value;
    }
}
