package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

/**
 * Property-Based Test for idempotent reservation release.
 *
 * <p><b>Property 9 — Idempotence (Validates: Requirements 3.7).</b> Releasing the same
 * reservation multiple times produces the same final state as releasing it exactly once:
 * the reserved quantity is restored to available stock <em>once</em>, the reservation ends
 * in {@code RELEASED}, and no double-restore ever occurs.
 *
 * <p>Task 12 ({@code ReservationReleaseService}) is not yet implemented, so this property is
 * exercised at the point where the behaviour actually lives: the stock mutation
 * {@link Product#releaseStock(Long)} plus the state transition
 * {@link Reservation#release(LocalDateTime)}. Idempotence is enforced the same way the
 * release service specifies it (design step 3): before restoring stock, the service checks
 * whether the reservation is already {@code RELEASED} and, if so, skips the stock mutation
 * and returns success. This test models that guard directly in {@link #releaseOnce} so that
 * repeated releases do not double-restore.
 *
 * <p>Properties verified for releasing an active reservation of quantity {@code q} a total of
 * {@code n >= 1} times:
 * <ul>
 *   <li><b>Property 9 — Idempotence:</b> the final product state after {@code n} releases is
 *       identical to the state after exactly one release — in particular
 *       {@code availableStock_final = availableStock_before + q} regardless of {@code n}
 *       (<b>Validates: Requirements 3.7</b>)</li>
 *   <li><b>No double-restore:</b> {@code q} is added to available stock exactly once, never
 *       {@code n * q}</li>
 *   <li><b>Terminal status:</b> the reservation ends {@code RELEASED} with a single stable
 *       {@code releasedAt} timestamp that does not change on subsequent releases</li>
 *   <li><b>Conservation:</b> {@code available + reserved} equals {@code totalStock} throughout</li>
 * </ul>
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath, dependencies are governed by architecture steering), this is a JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} test driven by hand-picked edge-case
 * scenarios and a fixed-seed randomized generator. A fixed seed keeps runs deterministic and
 * any counterexample reproducible.
 */
@Slf4j
class ReservationReleaseIdempotencePropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if a property ever fails. */
    private static final long SEED = 20240115L;

    /**
     * PROPERTY 9: Idempotence
     *
     * <p><b>Validates: Requirements 3.7</b>
     *
     * <p>Releasing the same reservation {@code n >= 1} times leaves the product in the same
     * state as releasing it once: available stock grows by exactly the reserved quantity, the
     * reserved pool shrinks by exactly that quantity, and the reservation is {@code RELEASED}.
     * Only the first release mutates stock; every later release is a no-op.
     *
     * @param scenario a product/reservation pair plus a release-attempt count {@code >= 1}
     */
    @ParameterizedTest(name = "Idempotent release: {0}")
    @MethodSource({"idempotenceScenarios", "randomizedIdempotenceScenarios"})
    void releaseReservation_whenReleasedRepeatedly_matchesSingleReleaseAndRestoresStockOnce(
            IdempotenceScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.releaseQuantity);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();

        // Act
        releaseOnce(reservation, product);
        LocalDateTime releasedAtAfterFirst = reservation.getReleasedAt();
        long availableAfterFirst = product.getAvailableStock();
        long reservedAfterFirst = product.getReservedStock();

        for (int attempt = 2; attempt <= scenario.releaseAttempts; attempt++) {
            releaseOnce(reservation, product);
        }

        // Assert
        assertThat(product.getAvailableStock())
                .as("available stock after %d releases must equal the single-release result "
                        + "(restored exactly once)", scenario.releaseAttempts)
                .isEqualTo(availableAfterFirst)
                .isEqualTo(availableBefore + scenario.releaseQuantity);

        assertThat(product.getReservedStock())
                .as("reserved stock after %d releases must equal the single-release result "
                        + "(decremented exactly once)", scenario.releaseAttempts)
                .isEqualTo(reservedAfterFirst)
                .isEqualTo(reservedBefore - scenario.releaseQuantity);

        assertThat(reservation.getStatus())
                .as("reservation must remain RELEASED after any number of releases")
                .isEqualTo(ReservationStatus.RELEASED);

        assertThat(reservation.getReleasedAt())
                .as("releasedAt must be set once and never change on repeated releases")
                .isEqualTo(releasedAtAfterFirst)
                .isNotNull();

        log.info("✓ Idempotence verified over {} releases: available {} -> {} (restored {} once), "
                        + "reserved {} -> {}", scenario.releaseAttempts, availableBefore,
                product.getAvailableStock(), scenario.releaseQuantity, reservedBefore,
                product.getReservedStock());
    }

    /**
     * CONSERVATION UNDER REPEATED RELEASE
     *
     * <p>No matter how many times a reservation is released, stock is only ever moved between
     * the reserved and available buckets — never created or destroyed. So
     * {@code available + reserved} must stay equal to {@code totalStock} and the full stock
     * invariant must hold after every release attempt.
     *
     * @param scenario a product/reservation pair plus a release-attempt count {@code >= 1}
     */
    @ParameterizedTest(name = "Conservation under repeat: {0}")
    @MethodSource({"idempotenceScenarios", "randomizedIdempotenceScenarios"})
    void releaseReservation_whenReleasedRepeatedly_conservesTotalStock(IdempotenceScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.releaseQuantity);

        long totalBefore = product.getTotalStock();

        // Act
        for (int attempt = 1; attempt <= scenario.releaseAttempts; attempt++) {
            releaseOnce(reservation, product);

            // Assert (holds after every single attempt)
            assertThat(product.getAvailableStock() + product.getReservedStock())
                    .as("available + reserved must equal total stock after release attempt %d", attempt)
                    .isEqualTo(totalBefore);
            assertThatCode(product::validateStockInvariant)
                    .as("full stock invariant must hold after release attempt %d", attempt)
                    .doesNotThrowAnyException();
        }

        // Assert
        assertThat(product.getTotalStock())
                .as("total stock itself must be unchanged by any number of releases")
                .isEqualTo(totalBefore);

        log.info("✓ Conservation verified across {} releases: total={} preserved",
                scenario.releaseAttempts, totalBefore);
    }

    // ========== Idempotent Release Model ==========

    /**
     * Models a single release attempt exactly as {@code ReservationReleaseService} specifies
     * its idempotency guard (design step 3): if the reservation is already {@code RELEASED},
     * the release is a successful no-op and stock is <b>not</b> mutated again. Only an
     * {@code ACTIVE} reservation transitions and restores stock.
     *
     * @param reservation the reservation being released
     * @param product     the owning product whose stock is restored on the first release
     */
    private static void releaseOnce(Reservation reservation, Product product) {
        if (reservation.getStatus() == ReservationStatus.RELEASED) {
            // Idempotent: already released, skip the stock restore and succeed.
            return;
        }
        reservation.release(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());
    }

    // ========== Scenario Generators ==========

    /**
     * Hand-picked edge-case scenarios covering the single-release boundary ({@code n == 1}),
     * typical retry counts, and large repeat counts — across small, mixed, and large stock
     * splits.
     *
     * @return stream of idempotence scenarios
     */
    static Stream<IdempotenceScenario> idempotenceScenarios() {
        return Stream.of(
                // n == 1: the baseline single release
                new IdempotenceScenario(0, 1, 1, 1),
                // release the single reserved unit twice
                new IdempotenceScenario(99, 1, 1, 2),
                // partial release, repeated three times
                new IdempotenceScenario(50, 50, 25, 3),
                // release the entire reserved pool, repeated
                new IdempotenceScenario(50, 50, 50, 5),
                // fully reserved product, release all, many retries
                new IdempotenceScenario(0, 100, 100, 10),
                // fully reserved product, release one, repeated
                new IdempotenceScenario(0, 100, 1, 4),
                // large stock, small release, repeated
                new IdempotenceScenario(95_000, 5_000, 1, 7),
                // large release, repeated
                new IdempotenceScenario(1, 999, 999, 3),
                // mid-range partial release, high retry count
                new IdempotenceScenario(700, 300, 150, 20),
                // large product, full reserved release, repeated
                new IdempotenceScenario(50_000, 50_000, 50_000, 6)
        );
    }

    /**
     * Fixed-seed randomized generator covering the valid release input space broadly, each
     * paired with a repeat count in {@code [1, 10]}. For each scenario it samples a total
     * stock, splits it into a valid available/reserved pair, and picks a release quantity in
     * {@code [1, reserved]} so the release always targets stock that is actually held — the
     * same precondition the release service enforces.
     *
     * @return stream of 100 randomized idempotence scenarios
     */
    static Stream<IdempotenceScenario> randomizedIdempotenceScenarios() {
        Random random = new Random(SEED);
        int numberOfScenarios = 100;

        List<IdempotenceScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Total in [1, 100_000].
            long total = 1 + (long) (random.nextDouble() * 100_000);
            // Reserved must be at least 1 so there is something to release; up to total.
            long reserved = 1 + (long) (random.nextDouble() * total);
            if (reserved > total) {
                reserved = total;
            }
            long available = total - reserved;
            // Release somewhere in [1, reserved].
            long release = 1 + (long) (random.nextDouble() * reserved);
            if (release > reserved) {
                release = reserved;
            }
            // Repeat the release between 1 and 10 times.
            int attempts = 1 + random.nextInt(10);

            scenarios.add(new IdempotenceScenario(available, reserved, release, attempts));
        }

        return scenarios.stream();
    }

    // ========== Test Data Class ==========

    /**
     * One idempotence case: the product's available/reserved split before release, the
     * quantity to release ({@code releaseQuantity} is always in {@code [1, reservedBefore]}),
     * and how many times the release is attempted ({@code releaseAttempts >= 1}).
     */
    static class IdempotenceScenario {
        final long availableBefore;
        final long reservedBefore;
        final long releaseQuantity;
        final int releaseAttempts;

        IdempotenceScenario(long availableBefore, long reservedBefore, long releaseQuantity,
                            int releaseAttempts) {
            this.availableBefore = availableBefore;
            this.reservedBefore = reservedBefore;
            this.releaseQuantity = releaseQuantity;
            this.releaseAttempts = releaseAttempts;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, release=%d, attempts=%d",
                    availableBefore, reservedBefore, releaseQuantity, releaseAttempts);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    static Reservation createActiveReservation(Product product, long quantity) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();
    }
}
