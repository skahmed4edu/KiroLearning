package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

/**
 * Property-Based Tests for reservation expiration stock-restoration invariants.
 *
 * <p>Task 13 ({@code ReservationExpirationScheduler}) processes {@code ACTIVE} reservations
 * whose TTL has elapsed: each expired reservation transitions to {@code EXPIRED} and its
 * reserved quantity is returned to the owning product's available stock. The stock mutation
 * is performed by {@link Product#releaseStock(Long)} and the state transition by
 * {@link Reservation#expire(LocalDateTime)} — exactly the two operations the scheduler
 * composes per expired reservation. These properties therefore exercise the expiration flow
 * at the entity level where the stock invariants actually live, mirroring the sibling
 * release property tests and staying independent of the (separately authored) scheduler
 * wiring.
 *
 * <p>Properties verified for expiring an active reservation of quantity {@code q}:
 * <ul>
 *   <li><b>Property 11 — Expiration stock restoration invariant:</b>
 *       {@code availableStock_after = availableStock_before + q}
 *       (<b>Validates: Requirements 4.2</b>)</li>
 *   <li><b>Symmetric reserved decrease:</b> {@code reservedStock_after = reservedStock_before - q}</li>
 *   <li><b>Conservation:</b> {@code available + reserved} stays equal to {@code totalStock}
 *       before and after expiration</li>
 *   <li><b>Bounds:</b> available stock never exceeds total stock and reserved stock never
 *       goes negative after expiration</li>
 * </ul>
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath, dependencies are governed by architecture steering), these are JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} tests driven by a mix of hand-picked
 * edge-case scenarios and a fixed-seed randomized generator. A fixed seed keeps runs
 * deterministic and any counterexample reproducible.
 */
@Slf4j
class ReservationExpirationProcessingPropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if a property ever fails. */
    private static final long SEED = 20240115L;

    /**
     * PROPERTY 11: Expiration Stock Restoration Invariant
     *
     * <p><b>Validates: Requirements 4.2</b>
     *
     * <p>Expiring an {@code ACTIVE} reservation of quantity {@code q} returns exactly
     * {@code q} units to available stock:
     *
     * <pre>availableStock_after = availableStock_before + q</pre>
     *
     * <p>and symmetrically removes {@code q} from reserved stock. This is the core guarantee
     * that stock held by a reservation whose TTL has elapsed becomes available again for new
     * reservations.
     *
     * @param scenario a product/reservation pair with an expirable quantity
     */
    @ParameterizedTest(name = "Expiration restore: {0}")
    @MethodSource({"expirationScenarios", "randomizedExpirationScenarios"})
    void expireReservation_whenActive_restoresReservedQuantityToAvailable(ExpirationScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.expireQuantity);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();

        // Act
        reservation.expire(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        // Assert
        assertThat(product.getAvailableStock())
                .as("available stock must increase by exactly the expired quantity")
                .isEqualTo(availableBefore + scenario.expireQuantity);

        assertThat(product.getReservedStock())
                .as("reserved stock must decrease by exactly the expired quantity")
                .isEqualTo(reservedBefore - scenario.expireQuantity);

        assertThat(reservation.getStatus())
                .as("reservation must transition ACTIVE -> EXPIRED")
                .isEqualTo(ReservationStatus.EXPIRED);
        assertThat(reservation.getExpiredAt())
                .as("expired reservation must record its expiration timestamp")
                .isNotNull();

        log.info("✓ Expiration restore verified: available {} -> {}, reserved {} -> {}",
                availableBefore, product.getAvailableStock(),
                reservedBefore, product.getReservedStock());
    }

    /**
     * CONSERVATION PROPERTY
     *
     * <p>Expiring a reservation only moves units between the reserved and available buckets —
     * it never creates or destroys stock. Therefore {@code available + reserved} must equal
     * {@code totalStock} both before and after the expiration.
     *
     * @param scenario a product/reservation pair with an expirable quantity
     */
    @ParameterizedTest(name = "Conservation: {0}")
    @MethodSource({"expirationScenarios", "randomizedExpirationScenarios"})
    void expireReservation_whenActive_conservesTotalStock(ExpirationScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.expireQuantity);

        long totalBefore = product.getTotalStock();
        long sumBefore = product.getAvailableStock() + product.getReservedStock();

        // Act
        reservation.expire(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        // Assert
        long sumAfter = product.getAvailableStock() + product.getReservedStock();

        assertThat(sumBefore)
                .as("available + reserved must equal total stock before expiration")
                .isEqualTo(totalBefore);
        assertThat(sumAfter)
                .as("available + reserved must equal total stock after expiration")
                .isEqualTo(totalBefore);
        assertThat(product.getTotalStock())
                .as("total stock itself must be unchanged by an expiration")
                .isEqualTo(totalBefore);

        log.info("✓ Conservation verified: total={} stays equal to available+reserved={}",
                totalBefore, sumAfter);
    }

    /**
     * BOUNDS PROPERTY
     *
     * <p>After expiring an {@code ACTIVE} reservation the product must stay within valid
     * stock bounds:
     * <ul>
     *   <li>available stock never exceeds total stock</li>
     *   <li>reserved stock never goes negative</li>
     * </ul>
     *
     * <p>The product's own {@link Product#validateStockInvariant()} is also asserted to not
     * throw, confirming the full stock invariant holds after expiration.
     *
     * @param scenario a product/reservation pair with an expirable quantity
     */
    @ParameterizedTest(name = "Bounds: {0}")
    @MethodSource({"expirationScenarios", "randomizedExpirationScenarios"})
    void expireReservation_whenActive_keepsStockWithinValidBounds(ExpirationScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.expireQuantity);

        // Act
        reservation.expire(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        // Assert
        assertThat(product.getAvailableStock())
                .as("available stock must never exceed total stock after expiration")
                .isLessThanOrEqualTo(product.getTotalStock());

        assertThat(product.getReservedStock())
                .as("reserved stock must never go negative after expiration")
                .isGreaterThanOrEqualTo(0L);

        assertThat(product.getAvailableStock())
                .as("available stock must never go negative after expiration")
                .isGreaterThanOrEqualTo(0L);

        assertThatCode(product::validateStockInvariant)
                .as("full stock invariant must hold after expiration")
                .doesNotThrowAnyException();

        log.info("✓ Bounds verified: available={} <= total={}, reserved={} >= 0",
                product.getAvailableStock(), product.getTotalStock(), product.getReservedStock());
    }

    // ========== Scenario Generators ==========

    /**
     * Hand-picked edge-case scenarios: expiring the only reserved unit, expiring the entire
     * reserved pool, expiring from a fully reserved product, and large-stock cases.
     *
     * @return stream of expiration scenarios
     */
    static Stream<ExpirationScenario> expirationScenarios() {
        return Stream.of(
                // available=0, reserved=1, expire 1 -> everything becomes available
                new ExpirationScenario(0, 1, 1),
                // expire the single reserved unit from a mixed product
                new ExpirationScenario(99, 1, 1),
                // expire part of the reserved pool
                new ExpirationScenario(50, 50, 25),
                // expire the entire reserved pool
                new ExpirationScenario(50, 50, 50),
                // fully reserved product, expire all
                new ExpirationScenario(0, 100, 100),
                // fully reserved product, expire one
                new ExpirationScenario(0, 100, 1),
                // large stock, small expiration
                new ExpirationScenario(95_000, 5_000, 1),
                // large stock, large expiration
                new ExpirationScenario(1, 999, 999),
                // mid-range partial expiration
                new ExpirationScenario(700, 300, 150),
                // expire equal to the full reserved amount on a large product
                new ExpirationScenario(50_000, 50_000, 50_000)
        );
    }

    /**
     * Fixed-seed randomized generator covering the valid expiration input space broadly.
     *
     * <p>For each scenario it samples a total stock, splits it into a valid
     * available/reserved pair, and picks an expiration quantity in {@code [1, reserved]} so
     * the expiration always targets stock that is actually held. This mirrors the
     * precondition the scheduler relies on (a reservation can only expire the quantity it
     * holds) while probing many combinations of magnitudes and ratios.
     *
     * @return stream of 100 randomized expiration scenarios
     */
    static Stream<ExpirationScenario> randomizedExpirationScenarios() {
        Random random = new Random(SEED);
        int numberOfScenarios = 100;

        List<ExpirationScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Total in [1, 100_000].
            long total = 1 + (long) (random.nextDouble() * 100_000);
            // Reserved must be at least 1 so there is something to expire; up to total.
            long reserved = 1 + (long) (random.nextDouble() * total);
            if (reserved > total) {
                reserved = total;
            }
            long available = total - reserved;
            // Expire somewhere in [1, reserved].
            long expire = 1 + (long) (random.nextDouble() * reserved);
            if (expire > reserved) {
                expire = reserved;
            }

            scenarios.add(new ExpirationScenario(available, reserved, expire));
        }

        return scenarios.stream();
    }

    // ========== Test Data Class ==========

    /**
     * One expiration case: the product's available/reserved split before expiration and the
     * quantity to expire. {@code expireQuantity} is always in {@code [1, reservedBefore]}.
     */
    static class ExpirationScenario {
        final long availableBefore;
        final long reservedBefore;
        final long expireQuantity;

        ExpirationScenario(long availableBefore, long reservedBefore, long expireQuantity) {
            this.availableBefore = availableBefore;
            this.reservedBefore = reservedBefore;
            this.expireQuantity = expireQuantity;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, expire=%d",
                    availableBefore, reservedBefore, expireQuantity);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    static Reservation createActiveReservation(Product product, long quantity) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().minusMinutes(1))
                .createdAt(LocalDateTime.now().minusMinutes(16))
                .build();
    }
}
