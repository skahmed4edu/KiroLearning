package com.hexaware.service;

import com.hexaware.dto.StockLevelDTO;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Property-based tests for stock level calculation in {@link StockQueryService}.
 *
 * <p><b>Property-based testing approach</b>: the project does not depend on a dedicated
 * property-based testing library (no jqwik / QuickTheories on the classpath, and the
 * design document's references to "fast-check" / "Hypothesis" are not Java libraries).
 * To avoid introducing an unapproved dependency, these property tests follow the standard
 * PBT pattern using a seeded generator: many randomized-but-constrained inputs are
 * generated, the property is asserted to hold for every one of them, and the fixed seed
 * makes any failure deterministically reproducible. The failing input is reported so the
 * minimal counterexample can be inspected.</p>
 *
 * <p><b>Property 1: Available stock invariant</b> (Validates: Requirements 1.3)<br>
 * {@code availableStock = totalStock - sum(activeReservations)} must hold for the value
 * returned by {@link StockQueryService#getStockLevel(UUID)}, across arbitrary total-stock
 * values and arbitrary sets of active reservations.</p>
 */
@ExtendWith(MockitoExtension.class)
class StockQueryServicePropertyTest {

    /** Fixed seed so any failing case is deterministically reproducible. */
    private static final long SEED = 20240115L;

    /** Number of randomized cases generated per property. */
    private static final int CASES = 500;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @InjectMocks
    private StockQueryService stockQueryService;

    @Test
    @DisplayName("getStockLevel_withArbitraryActiveReservations_availableStockEqualsTotalMinusReservedSum")
    void getStockLevel_withArbitraryActiveReservations_availableStockEqualsTotalMinusReservedSum() {
        // Arrange
        Random random = new Random(SEED);

        for (int i = 0; i < CASES; i++) {
            // Generate a reserved sum first, then a total stock >= reserved sum so the
            // product's own invariant (totalStock = availableStock + reservedStock) is
            // respected and availableStock stays non-negative.
            List<Long> quantities = randomReservationQuantities(random);
            long reservedSum = quantities.stream().mapToLong(Long::longValue).sum();
            long totalStock = reservedSum + nextNonNegative(random, 10_000);
            if (totalStock == 0) {
                totalStock = 1; // Product requires totalStock > 0
            }

            UUID productId = UUID.randomUUID();
            Product product = buildProduct(productId, totalStock, reservedSum);
            List<Reservation> activeReservations = buildActiveReservations(product, quantities);

            stockQueryService.clearCache();
            when(productRepository.findById(productId)).thenReturn(java.util.Optional.of(product));
            when(reservationRepository.findActiveReservationsByProductId(productId))
                    .thenReturn(activeReservations);

            // Act
            StockLevelDTO result = stockQueryService.getStockLevel(productId);

            // Assert
            long expectedAvailable = totalStock - reservedSum;
            assertThat(result.getAvailableStock())
                    .as("case #%d: availableStock must equal totalStock(%d) - sum(activeReservations)(%d)",
                            i, totalStock, reservedSum)
                    .isEqualTo(expectedAvailable);
            assertThat(result.getTotalStock())
                    .as("case #%d: totalStock must be reported unchanged", i)
                    .isEqualTo(totalStock);
            assertThat(result.getAvailableStock())
                    .as("case #%d: availableStock must never be negative", i)
                    .isGreaterThanOrEqualTo(0L);
        }
    }

    @Test
    @DisplayName("getStockLevel_withNoActiveReservations_availableStockEqualsTotalStock")
    void getStockLevel_withNoActiveReservations_availableStockEqualsTotalStock() {
        // Arrange
        Random random = new Random(SEED + 1);

        for (int i = 0; i < CASES; i++) {
            long totalStock = nextNonNegative(random, 1_000_000) + 1; // totalStock > 0

            UUID productId = UUID.randomUUID();
            Product product = buildProduct(productId, totalStock, 0L);

            stockQueryService.clearCache();
            when(productRepository.findById(productId)).thenReturn(java.util.Optional.of(product));
            when(reservationRepository.findActiveReservationsByProductId(productId))
                    .thenReturn(List.of());

            // Act
            StockLevelDTO result = stockQueryService.getStockLevel(productId);

            // Assert
            assertThat(result.getAvailableStock())
                    .as("case #%d: with no active reservations availableStock must equal totalStock", i)
                    .isEqualTo(totalStock);
        }
    }

    // ---------------------------------------------------------------------
    // Generators
    // ---------------------------------------------------------------------

    /**
     * Generates a list of 0..20 positive reservation quantities. Each quantity is in the
     * range 1..500, keeping the aggregate within a realistic inventory range.
     */
    private List<Long> randomReservationQuantities(Random random) {
        int count = random.nextInt(21); // 0..20 reservations
        List<Long> quantities = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            quantities.add((long) (random.nextInt(500) + 1)); // 1..500
        }
        return quantities;
    }

    private long nextNonNegative(Random random, int bound) {
        return random.nextInt(bound);
    }

    // ---------------------------------------------------------------------
    // Builders
    // ---------------------------------------------------------------------

    private Product buildProduct(UUID productId, long totalStock, long reservedStock) {
        return Product.builder()
                .id(productId)
                .sku("SKU-" + productId)
                .name("Test Product")
                .remark("")
                .totalStock(totalStock)
                .reservedStock(reservedStock)
                .availableStock(totalStock - reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now().minusDays(1))
                .updatedAt(LocalDateTime.now().minusDays(1))
                .build();
    }

    private List<Reservation> buildActiveReservations(Product product, List<Long> quantities) {
        List<Reservation> reservations = new ArrayList<>(quantities.size());
        LocalDateTime now = LocalDateTime.now();
        for (Long quantity : quantities) {
            reservations.add(Reservation.builder()
                    .id(UUID.randomUUID())
                    .orderId(UUID.randomUUID())
                    .product(product)
                    .quantity(quantity)
                    .status(ReservationStatus.ACTIVE)
                    .expirationTime(now.plusMinutes(15))
                    .createdAt(now)
                    .build());
        }
        return reservations;
    }
}
