package com.hexaware.service;

import com.hexaware.dto.BulkUpdateRequest;
import com.hexaware.dto.BulkUpdateResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.repository.ProductRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Property-Based Tests for StockUpdateService
 * 
 * These tests verify critical invariants and metamorphic properties of the bulk
 * stock update system. They test that the system behaves correctly across a wide
 * range of scenarios using property-based testing techniques.
 * 
 * PROPERTIES TESTED:
 * 
 * **Property 2: Invariant After Bulk Update**
 * **Validates: Requirements 5.1, 5.8**
 * After a bulk stock update:
 * - For each product: totalStock_new > 0
 * - For each product: availableStock_new >= 0
 * - For each product: availableStock_new = totalStock_new - sum(activeReservations)
 * 
 * **Property 3: Metamorphic Property - Bulk Update Idempotence**
 * **Validates: Requirement 5.1**
 * Bulk updating N products sequentially (N separate updates) should produce identical
 * results to bulk updating all N products in one operation.
 * Example:
 *   Sequential: updateProduct(P1, 100) then updateProduct(P2, 200)
 *   Batch: updateProducts([P1->100, P2->200])
 *   Result: Final state should be identical
 * 
 * This tests that the batch operation semantics are correct.
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class StockUpdateServicePropertyTest {

    @Mock
    private ProductRepository productRepository;

    private StockUpdateService stockUpdateService;

    @BeforeEach
    void setUp() {
        stockUpdateService = new StockUpdateService(productRepository);
        // Set default batch size to 1000 for testing
        ReflectionTestUtils.setField(stockUpdateService, "maxBatchSize", 1000);
        ReflectionTestUtils.setField(stockUpdateService, "maxRetries", 3);
    }

    /**
     * PROPERTY 2: Invariant After Bulk Update
     * 
     * **Validates: Requirements 5.1, 5.8**
     * 
     * For each product in the bulk update:
     * 1. totalStock_new > 0 (total stock must always be positive)
     * 2. availableStock_new >= 0 (available stock can't be negative)
     * 3. availableStock_new = totalStock_new - sum(activeReservations)
     * 
     * This invariant must hold after any successful bulk update.
     * Property-based testing verifies it holds across all scenarios.
     * 
     * @param scenario The test scenario containing products and updates
     */
    @ParameterizedTest(name = "Invariant: scenario={0}")
    @MethodSource({"bulkUpdateInvariantScenarios", "randomizedBulkUpdateInvariantScenarios"})
    void property_invariantAfterBulkUpdate_holds(BulkUpdateScenario scenario) {
        // Arrange
        BulkUpdateRequest request = scenario.createRequest();
        
        // Mock repository calls
        List<Product> productsForValidation = scenario.getProductsForValidation();
        List<Product> productsForUpdate = scenario.getProductsForUpdate();
        
        when(productRepository.findByIdSet(anySet()))
                .thenReturn(productsForValidation);
        
        when(productRepository.findByIdSetWithLock(anySet()))
                .thenReturn(productsForUpdate);

        // Mock save to return updated products
        when(productRepository.save(any(Product.class)))
                .thenAnswer(invocation -> {
                    Product saved = (Product) invocation.getArgument(0);
                    // Simulate database version increment
                    saved.setLockVersion((saved.getLockVersion() != null ? saved.getLockVersion() : 0) + 1);
                    return saved;
                });

        // Act
        BulkUpdateResponse response = stockUpdateService.bulkUpdateStock(request);

        // Assert - Verify invariants hold after update
        assertThat(response.getStatus()).isEqualTo("SUCCESS");
        assertThat(response.getUpdatedProducts()).hasSize(scenario.getProductsForUpdate().size());

        // Check each updated product maintains invariant
        for (BulkUpdateResponse.BulkUpdateResultEntry result : response.getUpdatedProducts()) {
            // Invariant 1: totalStock > 0
            assertThat(result.getNewTotalStock())
                    .as("Total stock must be positive for product %s", result.getProductId())
                    .isGreaterThan(0);

            // Invariant 2: availableStock >= 0
            assertThat(result.getAvailableStock())
                    .as("Available stock must be non-negative for product %s", result.getProductId())
                    .isGreaterThanOrEqualTo(0);

            // Invariant 3: availableStock = totalStock - reservedStock
            long calculatedAvailable = result.getNewTotalStock() - result.getReservedStock();
            assertThat(result.getAvailableStock())
                    .as("Available stock must equal total - reserved for product %s", result.getProductId())
                    .isEqualTo(calculatedAvailable);

            log.info("✓ Invariant verified for {}: total={}, available={}, reserved={}",
                    result.getProductId(), result.getNewTotalStock(), 
                    result.getAvailableStock(), result.getReservedStock());
        }
    }

    /**
     * PROPERTY 3: Metamorphic Property - Bulk Update Idempotence
     *
     * **Validates: Requirements 5.1**
     *
     * For any set of N products with distinct target stock levels:
     * - Path A (batch): a single {@code bulkUpdateStock} call carrying all N entries.
     * - Path B (sequential): N separate {@code bulkUpdateStock} calls, one entry each.
     *
     * The persisted final state of every product (totalStock, availableStock,
     * reservedStock) must be identical regardless of which path is taken. This is a
     * metamorphic relation: the follow-up input (same updates, different batching) is
     * derived from the source input, and the two outputs must agree.
     *
     * Each path runs against its own in-memory product store seeded from the same
     * initial snapshot, so the comparison reflects only the batching strategy and not
     * shared mutable state. The store is wired through {@link ProductRepository} mocks
     * so the real {@link StockUpdateService} validation, lock-ordering, and apply logic
     * is exercised end to end (only the database boundary is faked).
     *
     * @param scenario randomized set of products and their new total stock targets
     */
    @ParameterizedTest(name = "Idempotence[{index}]: {0}")
    @MethodSource("bulkUpdateIdempotenceScenarios")
    void bulkUpdateStock_appliedAsSingleBatchVersusSequentially_producesIdenticalState(
            BulkUpdateIdempotenceScenario scenario) {
        // Arrange
        Map<UUID, Long> targets = scenario.targetStockByProduct();

        InMemoryProductStore batchStore = InMemoryProductStore.seededFrom(scenario.initialProducts());
        InMemoryProductStore sequentialStore = InMemoryProductStore.seededFrom(scenario.initialProducts());

        // Act - Path A: a single batch update carrying all N entries.
        BulkUpdateResponse batchResponse =
                runBulkUpdate(batchStore, bulkRequest(targets));

        // Act - Path B: N sequential single-entry updates applied one after another.
        for (Map.Entry<UUID, Long> target : targets.entrySet()) {
            runBulkUpdate(sequentialStore,
                    bulkRequest(Map.of(target.getKey(), target.getValue())));
        }

        // Assert - both paths report success for every product.
        assertThat(batchResponse.getStatus()).isEqualTo("SUCCESS");
        assertThat(batchResponse.getUpdatedProducts()).hasSize(targets.size());

        // Assert - the persisted final state is identical product-for-product.
        Map<UUID, Product> batchFinal = batchStore.snapshot();
        Map<UUID, Product> sequentialFinal = sequentialStore.snapshot();

        assertThat(batchFinal.keySet())
                .as("both paths persist the same set of products")
                .isEqualTo(sequentialFinal.keySet());

        for (UUID productId : targets.keySet()) {
            Product fromBatch = batchFinal.get(productId);
            Product fromSequential = sequentialFinal.get(productId);

            assertThat(fromBatch.getTotalStock())
                    .as("totalStock identical for product %s", productId)
                    .isEqualTo(fromSequential.getTotalStock())
                    .isEqualTo(targets.get(productId));

            assertThat(fromBatch.getAvailableStock())
                    .as("availableStock identical for product %s", productId)
                    .isEqualTo(fromSequential.getAvailableStock());

            assertThat(fromBatch.getReservedStock())
                    .as("reservedStock identical for product %s", productId)
                    .isEqualTo(fromSequential.getReservedStock());

            // The core invariant must also survive either batching strategy.
            assertThat(fromBatch.getAvailableStock())
                    .as("invariant available = total - reserved for product %s", productId)
                    .isEqualTo(fromBatch.getTotalStock() - fromBatch.getReservedStock());

            log.info("✓ Metamorphic equivalence for {}: batch(total={}, avail={}) == sequential(total={}, avail={})",
                    productId, fromBatch.getTotalStock(), fromBatch.getAvailableStock(),
                    fromSequential.getTotalStock(), fromSequential.getAvailableStock());
        }
    }

    /**
     * Runs a single {@code bulkUpdateStock} call against a fresh service instance whose
     * {@link ProductRepository} is backed by the supplied in-memory store.
     *
     * <p>A fresh service/mock per call keeps Mockito stubbing simple and avoids leaking
     * state between the batch and sequential paths; the shared state lives entirely in
     * the {@link InMemoryProductStore}.
     */
    private BulkUpdateResponse runBulkUpdate(InMemoryProductStore store, BulkUpdateRequest request) {
        ProductRepository repository = mock(ProductRepository.class);
        store.wireInto(repository);

        StockUpdateService service = new StockUpdateService(repository);
        ReflectionTestUtils.setField(service, "maxBatchSize", 1000);
        ReflectionTestUtils.setField(service, "maxRetries", 3);

        return service.bulkUpdateStock(request);
    }

    /** Builds a bulk update request from a productId -> newTotalStock map. */
    private static BulkUpdateRequest bulkRequest(Map<UUID, Long> targets) {
        List<BulkUpdateRequest.BulkStockUpdateEntry> entries = targets.entrySet().stream()
                .map(e -> BulkUpdateRequest.BulkStockUpdateEntry.builder()
                        .productId(e.getKey())
                        .newTotalStock(e.getValue())
                        .reason("Metamorphic idempotence test")
                        .build())
                .collect(Collectors.toList());
        return BulkUpdateRequest.builder().updates(entries).build();
    }

    /**
     * Generates test scenarios for bulk update invariant testing.
     * 
     * Scenarios cover:
     * - Single product update
     * - Multiple products with no reservations
     * - Multiple products with varying reservation levels
     * - Edge cases: minimum updates, maximum stock updates
     * 
     * @return stream of bulk update scenarios
     */
    static Stream<BulkUpdateScenario> bulkUpdateInvariantScenarios() {
        List<BulkUpdateScenario> scenarios = new ArrayList<>();
        
        // Scenario 1: Single product, no reservations
        UUID p1 = UUID.randomUUID();
        scenarios.add(BulkUpdateScenario.builder()
                .description("Single product, no reservations")
                .updates(Map.of(p1, 150L))
                .products(Map.of(p1, createTestProduct(p1, "PROD-001", 100, 0, 100)))
                .build());

        // Scenario 2: Single product with partial reservation
        UUID p2 = UUID.randomUUID();
        scenarios.add(BulkUpdateScenario.builder()
                .description("Single product with 50 units reserved")
                .updates(Map.of(p2, 200L))
                .products(Map.of(p2, createTestProduct(p2, "PROD-002", 100, 50, 50)))
                .build());

        // Scenario 3: Multiple products without reservations
        UUID p3a = UUID.randomUUID();
        UUID p3b = UUID.randomUUID();
        UUID p3c = UUID.randomUUID();
        scenarios.add(BulkUpdateScenario.builder()
                .description("Multiple products without reservations")
                .updates(Map.of(p3a, 150L, p3b, 250L, p3c, 300L))
                .products(Map.of(
                        p3a, createTestProduct(p3a, "PROD-003", 100, 0, 100),
                        p3b, createTestProduct(p3b, "PROD-004", 200, 0, 200),
                        p3c, createTestProduct(p3c, "PROD-005", 300, 0, 300)
                ))
                .build());

        // Scenario 4: Multiple products with mixed reservations
        UUID p4a = UUID.randomUUID();
        UUID p4b = UUID.randomUUID();
        scenarios.add(BulkUpdateScenario.builder()
                .description("Multiple products with mixed reservation levels")
                .updates(Map.of(p4a, 200L, p4b, 300L))
                .products(Map.of(
                        p4a, createTestProduct(p4a, "PROD-006", 100, 30, 70),
                        p4b, createTestProduct(p4b, "PROD-007", 200, 80, 120)
                ))
                .build());

        // Scenario 5: Increase stock from near-full reservation
        UUID p5 = UUID.randomUUID();
        scenarios.add(BulkUpdateScenario.builder()
                .description("Increase stock when nearly fully reserved")
                .updates(Map.of(p5, 150L))
                .products(Map.of(p5, createTestProduct(p5, "PROD-008", 100, 99, 1)))
                .build());

        // Scenario 6: Large stock levels
        UUID p6a = UUID.randomUUID();
        UUID p6b = UUID.randomUUID();
        scenarios.add(BulkUpdateScenario.builder()
                .description("Large stock quantities")
                .updates(Map.of(p6a, 1_000_000L, p6b, 500_000L))
                .products(Map.of(
                        p6a, createTestProduct(p6a, "PROD-009", 100_000, 50_000, 50_000),
                        p6b, createTestProduct(p6b, "PROD-010", 200_000, 100_000, 100_000)
                ))
                .build());

        return scenarios.stream();
    }

    /**
     * Generates a large set of randomized-but-valid bulk update scenarios.
     *
     * This is the property-based core of the test: rather than a handful of
     * hand-picked examples, it samples the input space broadly so the invariant
     * (Property 2) is exercised against many combinations of:
     * - batch sizes (1..20 products per bulk update)
     * - current total/reserved/available stock levels
     * - new total stock values that are always valid (newTotalStock >= reservedStock
     *   and newTotalStock > 0), since the service only applies updates that pass
     *   validation and the invariant is asserted on the resulting state.
     *
     * A fixed seed keeps the run deterministic and reproducible while still
     * covering a wide range of inputs.
     *
     * @return stream of randomized bulk update scenarios
     */
    static Stream<BulkUpdateScenario> randomizedBulkUpdateInvariantScenarios() {
        // Fixed seed → deterministic, reproducible counterexamples if one ever fails.
        Random random = new Random(20240115L);
        int numberOfScenarios = 100;

        List<BulkUpdateScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int s = 0; s < numberOfScenarios; s++) {
            int batchSize = 1 + random.nextInt(20); // 1..20 products

            Map<UUID, Long> updates = new LinkedHashMap<>();
            Map<UUID, Product> products = new LinkedHashMap<>();

            for (int i = 0; i < batchSize; i++) {
                UUID productId = UUID.randomUUID();

                // Current total stock in [1, 100_000].
                long currentTotal = 1 + (long) (random.nextDouble() * 100_000);
                // Reserved somewhere in [0, currentTotal].
                long reserved = (long) (random.nextDouble() * (currentTotal + 1));
                if (reserved > currentTotal) {
                    reserved = currentTotal;
                }
                long available = currentTotal - reserved;

                // New total must be > 0 and >= reserved for the update to be valid.
                // Pick within [max(1, reserved), max(1, reserved) + 100_000].
                long floor = Math.max(1L, reserved);
                long newTotal = floor + (long) (random.nextDouble() * 100_000);

                products.put(productId,
                        createTestProduct(productId, "PROD-RND-" + s + "-" + i,
                                currentTotal, reserved, available));
                updates.put(productId, newTotal);
            }

            scenarios.add(BulkUpdateScenario.builder()
                    .description("Randomized scenario #" + s + " (" + batchSize + " products)")
                    .updates(updates)
                    .products(products)
                    .build());
        }

        return scenarios.stream();
    }

    /**
     * Generates randomized scenarios for the bulk-update idempotence property.
     *
     * <p>Rather than a handful of fixed examples, this draws many randomized cases from
     * the valid input space so the metamorphic relation is exercised broadly. Each case
     * varies: the number of products (1..12), each product's reserved stock, and each
     * product's new total stock target. Generation respects the service's preconditions
     * so every case is expected to succeed:
     * <ul>
     *   <li>newTotalStock &gt; 0</li>
     *   <li>newTotalStock &gt;= reservedStock (otherwise the invariant check rejects it)</li>
     * </ul>
     *
     * <p>A fixed seed keeps failures reproducible; the counterexample is still printed via
     * the scenario's {@code toString()} in the parameterized test name.
     *
     * @return stream of randomized idempotence scenarios
     */
    static Stream<BulkUpdateIdempotenceScenario> bulkUpdateIdempotenceScenarios() {
        Random random = new Random(20240115L);
        int caseCount = 60;

        return Stream.generate(() -> randomScenario(random))
                .limit(caseCount);
    }

    /** Draws a single randomized scenario of 1..12 products with valid stock targets. */
    private static BulkUpdateIdempotenceScenario randomScenario(Random random) {
        int productCount = 1 + random.nextInt(12);

        List<Product> initial = new ArrayList<>(productCount);
        Map<UUID, Long> targets = new LinkedHashMap<>(productCount);

        for (int i = 0; i < productCount; i++) {
            UUID id = UUID.randomUUID();

            // Original totals span small to large to probe boundary and bulk magnitudes.
            long originalTotal = 1 + random.nextInt(100_000);
            // Reserved stock is a valid fraction of the original total (0 .. total).
            long reserved = (long) (random.nextDouble() * originalTotal);
            long available = originalTotal - reserved;

            // New total must stay positive and >= reserved so the update is accepted.
            long newTotal = reserved + random.nextInt(50_000);
            if (newTotal <= 0) {
                newTotal = Math.max(1, reserved);
            }

            initial.add(createTestProduct(id, "PROD-" + i, originalTotal, reserved, available));
            targets.put(id, newTotal);
        }

        return new BulkUpdateIdempotenceScenario(productCount, initial, targets);
    }

    /**
     * Test data class for bulk update invariant scenarios.
     */
    static class BulkUpdateScenario {
        private String description;
        private Map<UUID, Long> updates;
        private Map<UUID, Product> productMap;

        private BulkUpdateScenario(String description, Map<UUID, Long> updates,
                                  Map<UUID, Product> productMap) {
            this.description = description;
            this.updates = updates;
            this.productMap = productMap;
        }

        BulkUpdateRequest createRequest() {
            List<BulkUpdateRequest.BulkStockUpdateEntry> entries = updates.entrySet().stream()
                    .map(e -> BulkUpdateRequest.BulkStockUpdateEntry.builder()
                            .productId(e.getKey())
                            .newTotalStock(e.getValue())
                            .reason("Test update")
                            .build())
                    .toList();
            return BulkUpdateRequest.builder().updates(entries).build();
        }

        List<Product> getProductsForValidation() {
            return new ArrayList<>(productMap.values());
        }

        List<Product> getProductsForUpdate() {
            // Return products in the order they'll be locked (sorted by ID)
            return productMap.values().stream()
                    .sorted(Comparator.comparing(Product::getId))
                    .collect(Collectors.toList());
        }

        @Override
        public String toString() {
            return description;
        }

        static Builder builder() {
            return new Builder();
        }

        static class Builder {
            private String description;
            private Map<UUID, Long> updates = new HashMap<>();
            private Map<UUID, Product> productMap = new LinkedHashMap<>();

            Builder description(String description) {
                this.description = description;
                return this;
            }

            Builder updates(Map<UUID, Long> updates) {
                this.updates = updates;
                return this;
            }

            Builder products(Map<UUID, Product> products) {
                this.productMap = products;
                return this;
            }

            BulkUpdateScenario build() {
                return new BulkUpdateScenario(description, updates, productMap);
            }
        }
    }

    /**
     * Immutable description of one idempotence case: the initial product snapshot and
     * the target total-stock value for each product. Both the batch and the sequential
     * path are seeded from {@link #initialProducts()} so they start identical.
     */
    static class BulkUpdateIdempotenceScenario {
        private final int productCount;
        private final List<Product> initialProducts;
        private final Map<UUID, Long> targetStockByProduct;

        BulkUpdateIdempotenceScenario(int productCount,
                                      List<Product> initialProducts,
                                      Map<UUID, Long> targetStockByProduct) {
            this.productCount = productCount;
            this.initialProducts = initialProducts;
            this.targetStockByProduct = targetStockByProduct;
        }

        /** Fresh copies of the seed products (never shared between paths). */
        List<Product> initialProducts() {
            return initialProducts;
        }

        Map<UUID, Long> targetStockByProduct() {
            return targetStockByProduct;
        }

        @Override
        public String toString() {
            return String.format("%d product(s), targets=%s", productCount, targetStockByProduct.values());
        }
    }

    /**
     * Minimal in-memory stand-in for the products table, used to make the mocked
     * {@link ProductRepository} behave like a real store across multiple service calls.
     *
     * <p>It supports exactly the three repository methods {@link StockUpdateService}
     * relies on: {@code findByIdSet}, {@code findByIdSetWithLock} (sorted by id to mirror
     * the real deadlock-avoidance ordering), and {@code save}. Products are deep-copied on
     * seed and on read so the service mutates detached copies and only {@code save}
     * commits changes back, matching JPA semantics closely enough for this property.
     */
    static class InMemoryProductStore {
        private final Map<UUID, Product> rows = new LinkedHashMap<>();

        static InMemoryProductStore seededFrom(List<Product> products) {
            InMemoryProductStore store = new InMemoryProductStore();
            for (Product p : products) {
                store.rows.put(p.getId(), copy(p));
            }
            return store;
        }

        void wireInto(ProductRepository repository) {
            when(repository.findByIdSet(anySet())).thenAnswer(invocation -> {
                Set<UUID> ids = invocation.getArgument(0);
                return ids.stream()
                        .filter(rows::containsKey)
                        .map(id -> copy(rows.get(id)))
                        .collect(Collectors.toList());
            });

            when(repository.findByIdSetWithLock(anySet())).thenAnswer(invocation -> {
                Set<UUID> ids = invocation.getArgument(0);
                return ids.stream()
                        .filter(rows::containsKey)
                        .sorted()
                        .map(id -> copy(rows.get(id)))
                        .collect(Collectors.toList());
            });

            when(repository.save(any(Product.class))).thenAnswer(invocation -> {
                Product toSave = invocation.getArgument(0);
                Product persisted = copy(toSave);
                persisted.setLockVersion(
                        (persisted.getLockVersion() != null ? persisted.getLockVersion() : 0L) + 1L);
                rows.put(persisted.getId(), persisted);
                return copy(persisted);
            });
        }

        Map<UUID, Product> snapshot() {
            Map<UUID, Product> copy = new LinkedHashMap<>();
            rows.forEach((id, product) -> copy.put(id, copy(product)));
            return copy;
        }

        private static Product copy(Product source) {
            return Product.builder()
                    .id(source.getId())
                    .sku(source.getSku())
                    .name(source.getName())
                    .remark(source.getRemark())
                    .totalStock(source.getTotalStock())
                    .reservedStock(source.getReservedStock())
                    .availableStock(source.getAvailableStock())
                    .lockVersion(source.getLockVersion())
                    .createdAt(source.getCreatedAt())
                    .updatedAt(source.getUpdatedAt())
                    .build();
        }
    }

    /**
     * Factory method to create test Product instances.
     */
    private static Product createTestProduct(UUID id, String sku, long totalStock, 
                                            long reservedStock, long availableStock) {
        return Product.builder()
                .id(id)
                .sku(sku)
                .name("Test Product " + sku)
                .totalStock(totalStock)
                .reservedStock(reservedStock)
                .availableStock(availableStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }
}
