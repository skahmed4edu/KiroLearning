package com.hexaware.service;

import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.LockTimeoutException;
import jakarta.persistence.OptimisticLockException;
import jakarta.persistence.PessimisticLockException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.jpa.JpaOptimisticLockingFailureException;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link ReservationService#createReservation} (task 10.4).
 *
 * <p>These tests exercise the create-reservation path in isolation using Mockito
 * mocks for the three collaborators ({@link ProductRepository},
 * {@link ReservationRepository}, {@link StockAuditLogRepository}). No Spring
 * context or database is started, so the pessimistic-locking and transactional
 * behaviour is simulated through mock return values and thrown exceptions.
 *
 * <p>Coverage mirrors the acceptance criteria in task 10.4:
 * <ul>
 *   <li>successful creation with sufficient stock (response correctness + stock decrement)</li>
 *   <li>insufficient stock -&gt; INSUFFICIENT_STOCK (HTTP 409 semantics)</li>
 *   <li>product not found -&gt; EntityNotFoundException (HTTP 404 semantics)</li>
 *   <li>invalid / zero quantity -&gt; treated as insufficient stock</li>
 *   <li>idempotent retry returns existing reservation without duplicate creation</li>
 *   <li>idempotent retry on a non-ACTIVE reservation -&gt; already-processed error</li>
 *   <li>lock timeout -&gt; LockTimeoutException / PessimisticLockException (HTTP 503 semantics)</li>
 *   <li>version conflict retried with exponential backoff, then exhausted</li>
 *   <li>expiration time computed as now + TTL, order linkage, audit-log entry</li>
 * </ul>
 */
@ExtendWith(MockitoExtension.class)
class ReservationServiceTest {

    private static final int TTL_MINUTES = 15;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private StockAuditLogRepository stockAuditLogRepository;

    @InjectMocks
    private ReservationService reservationService;

    private UUID orderId;
    private UUID productId;
    private Product product;

    @BeforeEach
    void setUp() {
        // @Value fields are not populated without a Spring context, so inject them directly.
        ReflectionTestUtils.setField(reservationService, "reservationTtlMinutes", TTL_MINUTES);
        ReflectionTestUtils.setField(reservationService, "lockTimeoutSeconds", 30);
        ReflectionTestUtils.setField(reservationService, "maxRetries", 3);

        orderId = UUID.fromString("550e8400-e29b-41d4-a716-446655440000");
        productId = UUID.fromString("6ba7b810-9dad-11d1-80b4-00c04fd430c8");

        product = Product.builder()
                .id(productId)
                .sku("WIDGET-BLUE-001")
                .name("Blue Widget")
                .remark("Standard catalogue item")
                .totalStock(100L)
                .availableStock(100L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now().minusDays(1))
                .updatedAt(LocalDateTime.now().minusDays(1))
                .build();
    }

    private CreateReservationRequest requestFor(long quantity) {
        return CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(quantity)
                .correlationId("trace-abc-123")
                .build();
    }

    @Test
    @DisplayName("create with valid request and sufficient stock returns ACTIVE reservation")
    void createReservation_withSufficientStock_returnsActiveReservation() {
        // Arrange
        CreateReservationRequest request = requestFor(5L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getReservationId()).isNotNull();
        assertThat(response.getOrderId()).isEqualTo(orderId);
        assertThat(response.getProductId()).isEqualTo(productId);
        assertThat(response.getQuantity()).isEqualTo(5L);
        assertThat(response.getStatus()).isEqualTo(ReservationStatus.ACTIVE.name());
        assertThat(response.getCreatedAt()).isNotNull();
        assertThat(response.getExpirationTime()).isNotNull();
    }

    @Test
    @DisplayName("create with sufficient stock decrements available and increments reserved stock")
    void createReservation_withSufficientStock_decrementsAvailableStock() {
        // Arrange
        CreateReservationRequest request = requestFor(30L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert
        assertThat(product.getAvailableStock()).isEqualTo(70L);
        assertThat(product.getReservedStock()).isEqualTo(30L);
        assertThat(product.getTotalStock()).isEqualTo(100L);
        assertThat(response.getAvailableStock()).isEqualTo(70L);
        verify(productRepository).save(product);
    }

    @Test
    @DisplayName("create persists reservation linked to the order id")
    void createReservation_withValidRequest_linksReservationToOrderId() {
        // Arrange
        CreateReservationRequest request = requestFor(2L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        reservationService.createReservation(request);

        // Assert
        ArgumentCaptor<Reservation> captor = ArgumentCaptor.forClass(Reservation.class);
        verify(reservationRepository).save(captor.capture());
        Reservation saved = captor.getValue();
        assertThat(saved.getOrderId()).isEqualTo(orderId);
        assertThat(saved.getProduct()).isEqualTo(product);
        assertThat(saved.getQuantity()).isEqualTo(2L);
        assertThat(saved.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
    }

    @Test
    @DisplayName("create sets expiration time to now + TTL minutes")
    void createReservation_withValidRequest_setsExpirationToNowPlusTtl() {
        // Arrange
        CreateReservationRequest request = requestFor(1L);
        LocalDateTime before = LocalDateTime.now();

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert
        LocalDateTime after = LocalDateTime.now();
        assertThat(response.getExpirationTime())
                .isAfterOrEqualTo(before.plusMinutes(TTL_MINUTES).minusSeconds(2))
                .isBeforeOrEqualTo(after.plusMinutes(TTL_MINUTES).plusSeconds(2));
    }

    @Test
    @DisplayName("create writes a RESERVE stock audit log entry with before/after snapshots")
    void createReservation_withValidRequest_writesStockAuditLog() {
        // Arrange
        CreateReservationRequest request = requestFor(10L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        reservationService.createReservation(request);

        // Assert
        ArgumentCaptor<StockAuditLog> captor = ArgumentCaptor.forClass(StockAuditLog.class);
        verify(stockAuditLogRepository).save(captor.capture());
        StockAuditLog auditLog = captor.getValue();
        assertThat(auditLog.getOperationType()).isEqualTo(StockOperationType.RESERVE);
        assertThat(auditLog.getQuantityChange()).isEqualTo(-10L);
        assertThat(auditLog.getAvailableStockBefore()).isEqualTo(100L);
        assertThat(auditLog.getAvailableStockAfter()).isEqualTo(90L);
        assertThat(auditLog.getRequestId()).isEqualTo("trace-abc-123");
        assertThat(auditLog.getProduct()).isEqualTo(product);
    }

    @Test
    @DisplayName("create with insufficient stock throws INSUFFICIENT_STOCK and leaves stock unchanged")
    void createReservation_withInsufficientStock_throwsInsufficientStock() {
        // Arrange
        product.setAvailableStock(3L);
        product.setReservedStock(97L);
        CreateReservationRequest request = requestFor(5L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act / Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("INSUFFICIENT_STOCK");

        assertThat(product.getAvailableStock()).isEqualTo(3L);
        assertThat(product.getReservedStock()).isEqualTo(97L);
        verify(reservationRepository, never()).save(any(Reservation.class));
        verify(productRepository, never()).save(any(Product.class));
        verifyNoInteractions(stockAuditLogRepository);
    }

    @Test
    @DisplayName("create for a missing product throws EntityNotFoundException")
    void createReservation_whenProductNotFound_throwsEntityNotFoundException() {
        // Arrange
        CreateReservationRequest request = requestFor(5L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.empty());

        // Act / Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(EntityNotFoundException.class)
                .hasMessageContaining(productId.toString());

        verify(reservationRepository, never()).save(any(Reservation.class));
        verifyNoInteractions(stockAuditLogRepository);
    }

    @Test
    @DisplayName("create with quantity larger than any stock throws INSUFFICIENT_STOCK")
    void createReservation_withQuantityExceedingTotal_throwsInsufficientStock() {
        // Arrange
        CreateReservationRequest request = requestFor(101L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act / Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("INSUFFICIENT_STOCK");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    @DisplayName("idempotent retry with an ACTIVE reservation returns it without creating a duplicate")
    void createReservation_withIdempotentActiveRetry_returnsExistingWithoutDuplicate() {
        // Arrange
        String idempotencyKey = "f47ac10b-58cc-4372-a567-0e02b2c3d479";
        CreateReservationRequest request = CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(5L)
                .idempotencyKey(idempotencyKey)
                .build();

        Reservation existing = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(product)
                .quantity(5L)
                .status(ReservationStatus.ACTIVE)
                .createdAt(LocalDateTime.now().minusMinutes(1))
                .expirationTime(LocalDateTime.now().plusMinutes(14))
                .idempotencyKey(idempotencyKey)
                .build();

        when(reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId))
                .thenReturn(Optional.of(existing));

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert
        assertThat(response.getReservationId()).isEqualTo(existing.getId());
        assertThat(response.getStatus()).isEqualTo(ReservationStatus.ACTIVE.name());
        verify(reservationRepository, never()).save(any(Reservation.class));
        verify(productRepository, never()).findByIdWithLock(any());
        verifyNoInteractions(stockAuditLogRepository);
    }

    @Test
    @DisplayName("idempotent retry matching a non-ACTIVE reservation throws already-processed error")
    void createReservation_withIdempotentReleasedRetry_throwsAlreadyProcessed() {
        // Arrange
        String idempotencyKey = "f47ac10b-58cc-4372-a567-0e02b2c3d479";
        CreateReservationRequest request = CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(5L)
                .idempotencyKey(idempotencyKey)
                .build();

        Reservation released = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(product)
                .quantity(5L)
                .status(ReservationStatus.RELEASED)
                .createdAt(LocalDateTime.now().minusMinutes(30))
                .expirationTime(LocalDateTime.now().minusMinutes(15))
                .releasedAt(LocalDateTime.now().minusMinutes(10))
                .idempotencyKey(idempotencyKey)
                .build();

        when(reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId))
                .thenReturn(Optional.of(released));

        // Act / Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("already processed");

        verify(reservationRepository, never()).save(any(Reservation.class));
        verify(productRepository, never()).findByIdWithLock(any());
    }

    @Test
    @DisplayName("create proceeds normally when idempotency key has no prior reservation")
    void createReservation_withUnseenIdempotencyKey_createsNewReservation() {
        // Arrange
        String idempotencyKey = "f47ac10b-58cc-4372-a567-0e02b2c3d479";
        CreateReservationRequest request = CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(5L)
                .idempotencyKey(idempotencyKey)
                .build();

        when(reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId))
                .thenReturn(Optional.empty());
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert
        assertThat(response.getStatus()).isEqualTo(ReservationStatus.ACTIVE.name());
        ArgumentCaptor<Reservation> captor = ArgumentCaptor.forClass(Reservation.class);
        verify(reservationRepository).save(captor.capture());
        assertThat(captor.getValue().getIdempotencyKey()).isEqualTo(idempotencyKey);
    }

    @Test
    @DisplayName("create rethrows LockTimeoutException when the product row lock cannot be acquired")
    void createReservation_whenLockTimeout_throwsLockTimeoutException() {
        // Arrange
        CreateReservationRequest request = requestFor(5L);

        when(productRepository.findByIdWithLock(productId))
                .thenThrow(new LockTimeoutException());

        // Act / Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(LockTimeoutException.class);

        verify(reservationRepository, never()).save(any(Reservation.class));
        verifyNoInteractions(stockAuditLogRepository);
    }

    @Test
    @DisplayName("create rethrows PessimisticLockException when the product row lock cannot be acquired")
    void createReservation_whenPessimisticLock_throwsPessimisticLockException() {
        // Arrange
        CreateReservationRequest request = requestFor(5L);

        when(productRepository.findByIdWithLock(productId))
                .thenThrow(new PessimisticLockException());

        // Act / Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(PessimisticLockException.class);

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    @DisplayName("create retries on optimistic lock conflict and succeeds on a later attempt")
    void createReservation_withTransientVersionConflict_retriesAndSucceeds() {
        // Arrange
        CreateReservationRequest request = requestFor(5L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenThrow(new JpaOptimisticLockingFailureException(new OptimisticLockException("version conflict")))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert
        assertThat(response.getStatus()).isEqualTo(ReservationStatus.ACTIVE.name());
        verify(reservationRepository, times(2)).save(any(Reservation.class));
    }

    @Test
    @DisplayName("create exhausts retries on persistent version conflict and throws")
    void createReservation_withPersistentVersionConflict_throwsAfterRetriesExhausted() {
        // Arrange
        CreateReservationRequest request = requestFor(5L);

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class)))
                .thenThrow(new JpaOptimisticLockingFailureException(new OptimisticLockException("version conflict")));

        // Act / Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("max retries exhausted");

        // Initial attempt + 3 retries = 4 save attempts.
        verify(reservationRepository, times(4)).save(any(Reservation.class));
    }
}
