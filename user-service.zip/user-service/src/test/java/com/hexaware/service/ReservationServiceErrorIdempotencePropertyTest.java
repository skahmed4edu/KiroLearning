package com.hexaware.service;

import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Property-Based Tests for {@link ReservationService} error and idempotency behaviour.
 *
 * <p><b>Property 6: Error condition idempotence</b> &mdash;
 * <b>Validates: Requirements 2.2</b>
 *
 * <p>This test covers the two complementary guarantees that make reservation creation
 * safe to call under failure and retry:
 *
 * <ol>
 *   <li><b>Rejected reservations leave stock untouched.</b> When a create is rejected
 *       (insufficient stock), the product's available and reserved stock remain exactly
 *       as they were &mdash; there is no partial mutation, no reservation row, and no
 *       audit-log entry.</li>
 *   <li><b>Retrying with the same idempotency key does not double-reserve.</b> When a
 *       create is retried with an idempotency key that already maps to an {@code ACTIVE}
 *       reservation, the existing reservation is returned and no second reservation is
 *       created and no stock is mutated a second time.</li>
 * </ol>
 *
 * <p>The project has no property-based testing library on the classpath, so these tests
 * follow the established project convention: JUnit 5 {@code @ParameterizedTest} +
 * {@code @MethodSource} fed by a seeded randomized generator (fixed seed for
 * deterministic, reproducible counterexamples), with Mockito for collaborators and
 * AssertJ for assertions. Each case is driven across a wide slice of the input space
 * rather than a handful of hand-picked examples.
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class ReservationServiceErrorIdempotencePropertyTest {

    /** Fixed seed keeps the randomized runs deterministic and counterexamples reproducible. */
    private static final long SEED = 20240115L;

    /** Number of randomized cases generated per property. */
    private static final int CASES = 100;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private StockAuditLogRepository stockAuditLogRepository;

    private ReservationService reservationService;

    @BeforeEach
    void setUp() {
        reservationService =
                new ReservationService(productRepository, reservationRepository, stockAuditLogRepository);
        ReflectionTestUtils.setField(reservationService, "reservationTtlMinutes", 15);
        ReflectionTestUtils.setField(reservationService, "lockTimeoutSeconds", 30);
        ReflectionTestUtils.setField(reservationService, "maxRetries", 3);
    }

    // =========================================================================
    // Property 6a: a rejected reservation leaves product stock unchanged
    // =========================================================================

    /**
     * PROPERTY 6a: Rejected reservation leaves stock unchanged (no partial mutation).
     *
     * <p><b>Validates: Requirements 2.2</b>
     *
     * <p>For any request whose quantity exceeds the available stock, creation must throw
     * {@code INSUFFICIENT_STOCK} and leave the product exactly as it was: no stock
     * mutation, no reservation persisted, and no audit-log entry written.
     *
     * @param scenario a randomized over-reservation scenario
     */
    @ParameterizedTest(name = "[{index}] insufficient stock leaves stock unchanged: {0}")
    @MethodSource("insufficientStockScenarios")
    void createReservation_whenRequestedExceedsAvailable_throwsAndLeavesStockUnchanged(
            InsufficientStockScenario scenario) {

        // Arrange
        UUID productId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();

        Product product = createProduct(productId, scenario.availableStock, scenario.reservedStock);
        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();
        long totalBefore = product.getTotalStock();

        when(reservationRepository.findByIdempotencyKeyAndOrderId(any(), any()))
                .thenReturn(Optional.empty());
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        CreateReservationRequest request = CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(scenario.requestedQuantity)
                .idempotencyKey(UUID.randomUUID().toString())
                .build();

        // Act
        Throwable thrown = org.assertj.core.api.Assertions.catchThrowable(
                () -> reservationService.createReservation(request));

        // Assert
        assertThat(thrown)
                .as("Over-reservation must be rejected")
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("INSUFFICIENT_STOCK");

        verify(productRepository, never()).save(any(Product.class));
        verify(reservationRepository, never()).save(any(Reservation.class));
        verify(stockAuditLogRepository, never()).save(any(StockAuditLog.class));

        assertThat(product.getAvailableStock())
                .as("Available stock must be unchanged after a rejected reservation")
                .isEqualTo(availableBefore);
        assertThat(product.getReservedStock())
                .as("Reserved stock must be unchanged after a rejected reservation")
                .isEqualTo(reservedBefore);
        assertThat(product.getAvailableStock() + product.getReservedStock())
                .as("Total stock (available + reserved) must be unchanged")
                .isEqualTo(totalBefore);
    }

    /**
     * Generates randomized scenarios where the requested quantity always exceeds the
     * available stock, so every case is expected to be rejected.
     *
     * <p>Each case varies available stock, reserved stock, and the amount of overshoot
     * (1..5000 beyond what is available), including the boundary case of zero available
     * stock.
     *
     * @return stream of over-reservation scenarios
     */
    static Stream<InsufficientStockScenario> insufficientStockScenarios() {
        Random random = new Random(SEED);
        return Stream.generate(() -> {
            // Available in [0, 100_000]; reserved in [0, 100_000].
            long available = (long) (random.nextDouble() * 100_000);
            long reserved = (long) (random.nextDouble() * 100_000);
            // Request strictly more than available: available + overshoot, overshoot in [1, 5000].
            long overshoot = 1 + random.nextInt(5_000);
            long requested = available + overshoot;
            return new InsufficientStockScenario(available, reserved, requested);
        }).limit(CASES);
    }

    // =========================================================================
    // Property 6b: retrying with the same idempotency key does not double-reserve
    // =========================================================================

    /**
     * PROPERTY 6b: Idempotent retry returns the existing reservation without double-reserving.
     *
     * <p><b>Validates: Requirements 2.2</b>
     *
     * <p>When a create is retried with an idempotency key that already maps to an
     * {@code ACTIVE} reservation, the service must return that existing reservation and
     * must not create a second one, must not lock or mutate the product, and must not
     * write an audit-log entry. This holds regardless of the stock levels on the product.
     *
     * @param scenario a randomized idempotent-retry scenario
     */
    @ParameterizedTest(name = "[{index}] duplicate idempotency key returns existing reservation: {0}")
    @MethodSource("idempotentRetryScenarios")
    void createReservation_withExistingIdempotencyKey_returnsExistingWithoutDoubleReserving(
            IdempotentRetryScenario scenario) {

        // Arrange
        UUID productId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();
        String idempotencyKey = UUID.randomUUID().toString();

        Product product = createProduct(productId, scenario.availableStock, scenario.reservedStock);
        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();

        Reservation existing = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(product)
                .quantity(scenario.reservedQuantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .idempotencyKey(idempotencyKey)
                .build();

        when(reservationRepository.findByIdempotencyKeyAndOrderId(eq(idempotencyKey), eq(orderId)))
                .thenReturn(Optional.of(existing));

        CreateReservationRequest request = CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(scenario.reservedQuantity)
                .idempotencyKey(idempotencyKey)
                .build();

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert
        assertThat(response.getReservationId())
                .as("Retry must return the already-existing reservation id")
                .isEqualTo(existing.getId());
        assertThat(response.getOrderId()).isEqualTo(orderId);
        assertThat(response.getStatus()).isEqualTo(ReservationStatus.ACTIVE.name());

        // No second reservation, no product lock/mutation, no audit entry on retry.
        verify(reservationRepository, never()).save(any(Reservation.class));
        verify(productRepository, never()).findByIdWithLock(any());
        verify(productRepository, never()).save(any(Product.class));
        verify(stockAuditLogRepository, never()).save(any(StockAuditLog.class));

        assertThat(product.getAvailableStock())
                .as("Available stock must be unchanged on an idempotent retry")
                .isEqualTo(availableBefore);
        assertThat(product.getReservedStock())
                .as("Reserved stock must be unchanged on an idempotent retry")
                .isEqualTo(reservedBefore);
    }

    /**
     * Generates randomized scenarios for the idempotent-retry property. Each case varies
     * the product's available and reserved stock plus the quantity recorded on the
     * pre-existing reservation.
     *
     * @return stream of idempotent-retry scenarios
     */
    static Stream<IdempotentRetryScenario> idempotentRetryScenarios() {
        Random random = new Random(SEED + 1);
        return Stream.generate(() -> {
            long available = (long) (random.nextDouble() * 100_000);
            long reserved = (long) (random.nextDouble() * 100_000);
            long reservedQuantity = 1 + random.nextInt(10_000);
            return new IdempotentRetryScenario(available, reserved, reservedQuantity);
        }).limit(CASES);
    }

    // =========================================================================
    // Test data classes
    // =========================================================================

    /** A case where {@code requestedQuantity} always exceeds {@code availableStock}. */
    static final class InsufficientStockScenario {
        final long availableStock;
        final long reservedStock;
        final long requestedQuantity;

        InsufficientStockScenario(long availableStock, long reservedStock, long requestedQuantity) {
            this.availableStock = availableStock;
            this.reservedStock = reservedStock;
            this.requestedQuantity = requestedQuantity;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, requested=%d",
                    availableStock, reservedStock, requestedQuantity);
        }
    }

    /** A case describing a product plus a pre-existing ACTIVE reservation to be re-returned. */
    static final class IdempotentRetryScenario {
        final long availableStock;
        final long reservedStock;
        final long reservedQuantity;

        IdempotentRetryScenario(long availableStock, long reservedStock, long reservedQuantity) {
            this.availableStock = availableStock;
            this.reservedStock = reservedStock;
            this.reservedQuantity = reservedQuantity;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, existingQty=%d",
                    availableStock, reservedStock, reservedQuantity);
        }
    }

    // =========================================================================
    // Test utilities
    // =========================================================================

    private static Product createProduct(UUID id, long availableStock, long reservedStock) {
        return Product.builder()
                .id(id)
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }
}
