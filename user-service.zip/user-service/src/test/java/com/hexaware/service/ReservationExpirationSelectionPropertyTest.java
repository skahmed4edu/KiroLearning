package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Property-Based Test for the reservation-expiration <em>selection</em> step.
 *
 * <p><b>Property 12 — Metamorphic (Validates: Requirements 4.1).</b> When the expiration
 * job scans a population of reservations at a fixed {@code currentTime}, the number of
 * reservations it selects to transition to {@code EXPIRED} must equal the number of
 * reservations that are both {@code ACTIVE} and whose {@code expirationTime <= currentTime}.
 *
 * <p>This test deliberately models the <b>selection predicate directly</b> over a generated
 * list of reservations rather than depending on the scheduler component (task 13.5 may create
 * those files concurrently). The authoritative selection rule under test is the entity's own
 * {@link Reservation#isExpired(LocalDateTime)} — the exact predicate the scheduler is specified
 * to use (query {@code ACTIVE} reservations where {@code expiration_time <= now}). We assert
 * that {@code isExpired(now)} agrees, reservation-for-reservation and in aggregate count, with
 * the independent filtering predicate {@code status == ACTIVE AND expirationTime <= now}.
 *
 * <p>Because {@link Reservation#isExpired(LocalDateTime)} returns {@code false} for any
 * non-{@code ACTIVE} reservation, {@code RELEASED}, {@code EXPIRED}, and {@code CANCELLED}
 * reservations are never selected regardless of their expiration times — so a reservation whose
 * TTL has long passed but which was already released/expired is correctly excluded from the
 * count.
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath — dependencies are governed by the architecture steering), these are JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} tests driven by hand-picked edge-case
 * populations plus a fixed-seed randomized generator (~100 populations). The fixed seed keeps
 * runs deterministic and any counterexample reproducible.
 */
@Slf4j
class ReservationExpirationSelectionPropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if a property ever fails. */
    private static final long SEED = 20240115L;

    /** Reference "now" used across the whole suite so cases line up against the same instant. */
    private static final LocalDateTime NOW = LocalDateTime.of(2024, 1, 15, 9, 45, 0);

    /**
     * PROPERTY 12: Metamorphic — expiration selection count.
     *
     * <p><b>Validates: Requirements 4.1</b>
     *
     * <p>The count of reservations the expiration job would select (those for which
     * {@link Reservation#isExpired(LocalDateTime) isExpired(now)} is {@code true}) equals the
     * count produced by the independent predicate {@code status == ACTIVE AND expirationTime <= now}.
     *
     * @param population a mixed population of reservations with varied statuses/expiration times
     */
    @ParameterizedTest(name = "Selection count: {0}")
    @MethodSource({"handPickedPopulations", "randomizedPopulations"})
    void selectExpired_overMixedPopulation_countMatchesActiveAndPastExpirationPredicate(
            ReservationPopulation population) {
        // Arrange
        List<Reservation> reservations = population.reservations;

        long expectedExpiredCount = reservations.stream()
                .filter(r -> r.getStatus() == ReservationStatus.ACTIVE)
                .filter(r -> !r.getExpirationTime().isAfter(NOW)) // expirationTime <= now
                .count();

        // Act
        long selectedForExpirationCount = reservations.stream()
                .filter(r -> r.isExpired(NOW))
                .count();

        // Assert
        assertThat(selectedForExpirationCount)
                .as("count selected by isExpired(now) must equal count of ACTIVE reservations "
                        + "with expirationTime <= now")
                .isEqualTo(expectedExpiredCount);

        log.info("✓ Selection count verified: {} reservations, {} selected for expiration",
                reservations.size(), selectedForExpirationCount);
    }

    /**
     * CONSISTENCY PROPERTY: per-reservation agreement.
     *
     * <p>Beyond the aggregate count, {@link Reservation#isExpired(LocalDateTime)} must agree with
     * the filtering predicate for <em>each individual</em> reservation. This pins down <em>which</em>
     * reservations are selected, not just how many — guarding against a count that happens to match
     * while selecting the wrong members.
     *
     * @param population a mixed population of reservations with varied statuses/expiration times
     */
    @ParameterizedTest(name = "Per-item agreement: {0}")
    @MethodSource({"handPickedPopulations", "randomizedPopulations"})
    void selectExpired_overMixedPopulation_agreesWithPredicatePerReservation(
            ReservationPopulation population) {
        // Arrange
        List<Reservation> reservations = population.reservations;

        // Act / Assert
        for (Reservation r : reservations) {
            boolean predicate =
                    r.getStatus() == ReservationStatus.ACTIVE
                            && !r.getExpirationTime().isAfter(NOW); // expirationTime <= now

            assertThat(r.isExpired(NOW))
                    .as("isExpired(now) must agree with (ACTIVE AND expirationTime <= now) "
                            + "for reservation status=%s expiration=%s",
                            r.getStatus(), r.getExpirationTime())
                    .isEqualTo(predicate);
        }

        log.info("✓ Per-reservation agreement verified across {} reservations",
                reservations.size());
    }

    /**
     * NON-ACTIVE EXCLUSION PROPERTY.
     *
     * <p>No reservation whose status is not {@code ACTIVE} may ever be selected for expiration,
     * even when its {@code expirationTime} is in the past. This is the guarantee behind the
     * scheduler's idempotence: an already {@code EXPIRED} (or {@code RELEASED}/{@code CANCELLED})
     * reservation is never re-processed.
     *
     * @param population a mixed population of reservations with varied statuses/expiration times
     */
    @ParameterizedTest(name = "Non-active exclusion: {0}")
    @MethodSource({"handPickedPopulations", "randomizedPopulations"})
    void selectExpired_overMixedPopulation_neverSelectsNonActiveReservations(
            ReservationPopulation population) {
        // Arrange
        List<Reservation> nonActive = population.reservations.stream()
                .filter(r -> r.getStatus() != ReservationStatus.ACTIVE)
                .toList();

        // Act / Assert
        for (Reservation r : nonActive) {
            assertThat(r.isExpired(NOW))
                    .as("non-ACTIVE reservation (status=%s, expiration=%s) must never be selected "
                            + "for expiration", r.getStatus(), r.getExpirationTime())
                    .isFalse();
        }

        log.info("✓ Non-active exclusion verified: {} non-active reservations, none selected",
                nonActive.size());
    }

    // ========== Population Generators ==========

    /**
     * Hand-picked edge-case populations that exercise the selection boundaries precisely:
     * empty population, the exact {@code expirationTime == now} boundary, one-second either side
     * of the boundary, non-ACTIVE reservations with past expirations (must be excluded), and a
     * fully mixed population covering all four statuses.
     *
     * @return stream of hand-picked populations
     */
    static Stream<ReservationPopulation> handPickedPopulations() {
        Product product = createProduct();

        return Stream.of(
                // Empty population → zero selected.
                new ReservationPopulation("empty", List.of()),

                // Single ACTIVE reservation exactly at the boundary (expirationTime == now) → selected.
                new ReservationPopulation("active-at-boundary", List.of(
                        reservation(product, ReservationStatus.ACTIVE, NOW)
                )),

                // Single ACTIVE reservation one second past expiry → selected.
                new ReservationPopulation("active-one-second-past", List.of(
                        reservation(product, ReservationStatus.ACTIVE, NOW.minusSeconds(1))
                )),

                // Single ACTIVE reservation one second before expiry → not selected.
                new ReservationPopulation("active-one-second-future", List.of(
                        reservation(product, ReservationStatus.ACTIVE, NOW.plusSeconds(1))
                )),

                // Non-ACTIVE reservations with long-past expirations → never selected.
                new ReservationPopulation("non-active-past-expiry", List.of(
                        reservation(product, ReservationStatus.RELEASED, NOW.minusDays(1)),
                        reservation(product, ReservationStatus.EXPIRED, NOW.minusDays(1)),
                        reservation(product, ReservationStatus.CANCELLED, NOW.minusDays(1))
                )),

                // Fully mixed population: 2 of these are ACTIVE and expired → expect exactly 2.
                new ReservationPopulation("mixed-all-statuses", List.of(
                        reservation(product, ReservationStatus.ACTIVE, NOW.minusMinutes(5)),   // selected
                        reservation(product, ReservationStatus.ACTIVE, NOW),                   // selected (boundary)
                        reservation(product, ReservationStatus.ACTIVE, NOW.plusMinutes(5)),    // not: future
                        reservation(product, ReservationStatus.RELEASED, NOW.minusMinutes(5)), // not: released
                        reservation(product, ReservationStatus.EXPIRED, NOW.minusMinutes(5)),  // not: expired
                        reservation(product, ReservationStatus.CANCELLED, NOW.minusMinutes(5)) // not: cancelled
                ))
        );
    }

    /**
     * Fixed-seed randomized generator producing ~100 mixed populations. Each population has a
     * random size and each reservation gets a random status (uniform over the four values) and a
     * random {@code expirationTime} spread around {@code NOW} (from several hours before to several
     * hours after, including exact-boundary hits), so the selection predicate is probed across many
     * status/time combinations.
     *
     * @return stream of 100 randomized populations
     */
    static Stream<ReservationPopulation> randomizedPopulations() {
        Random random = new Random(SEED);
        Product product = createProduct();
        ReservationStatus[] statuses = ReservationStatus.values();
        int numberOfPopulations = 100;

        List<ReservationPopulation> populations = new ArrayList<>(numberOfPopulations);
        for (int i = 0; i < numberOfPopulations; i++) {
            int size = random.nextInt(21); // [0, 20] reservations per population
            List<Reservation> reservations = new ArrayList<>(size);

            for (int j = 0; j < size; j++) {
                ReservationStatus status = statuses[random.nextInt(statuses.length)];

                // Offset in seconds within +/- 4 hours; occasionally land exactly on the boundary.
                LocalDateTime expiration;
                int roll = random.nextInt(10);
                if (roll == 0) {
                    expiration = NOW; // exact boundary
                } else {
                    int offsetSeconds = random.nextInt(2 * 4 * 3600 + 1) - (4 * 3600);
                    expiration = NOW.plusSeconds(offsetSeconds);
                }

                reservations.add(reservation(product, status, expiration));
            }

            populations.add(new ReservationPopulation("random-" + i, reservations));
        }

        return populations.stream();
    }

    // ========== Test Data Class ==========

    /**
     * A generated population of reservations plus a short label for readable test names.
     */
    static class ReservationPopulation {
        final String label;
        final List<Reservation> reservations;

        ReservationPopulation(String label, List<Reservation> reservations) {
            this.label = label;
            this.reservations = reservations;
        }

        @Override
        public String toString() {
            return String.format("%s (n=%d)", label, reservations.size());
        }
    }

    // ========== Test Utilities ==========

    /**
     * A single shared product is sufficient: these properties concern reservation selection, not
     * stock mutation, so the product's stock figures are immaterial here.
     */
    static Product createProduct() {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(1_000L)
                .availableStock(1_000L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(NOW.minusDays(1))
                .updatedAt(NOW.minusDays(1))
                .build();
    }

    /**
     * Builds a reservation with the given status and expiration time. The {@code createdAt} is kept
     * at or before {@code expirationTime} so the entity's own invariants stay satisfiable, and the
     * released/expired timestamps are set consistently for terminal statuses.
     */
    static Reservation reservation(Product product, ReservationStatus status, LocalDateTime expirationTime) {
        LocalDateTime createdAt = expirationTime.minusMinutes(15);

        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(1L)
                .status(status)
                .expirationTime(expirationTime)
                .createdAt(createdAt)
                .releasedAt(status == ReservationStatus.RELEASED ? expirationTime : null)
                .expiredAt(status == ReservationStatus.EXPIRED ? expirationTime : null)
                .build();
    }
}
