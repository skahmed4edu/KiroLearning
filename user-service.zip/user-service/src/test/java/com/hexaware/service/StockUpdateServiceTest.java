package com.hexaware.service;

import com.hexaware.dto.BulkUpdateRequest;
import com.hexaware.dto.BulkUpdateResponse;
import com.hexaware.entity.Product;
import com.hexaware.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.jpa.JpaOptimisticLockingFailureException;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link StockUpdateService}.
 *
 * Covers bulk stock update behaviour in isolation using Mockito mocks for the
 * {@link ProductRepository}. Validates all-or-nothing semantics: successful
 * batches, and failure paths (invalid product ID, non-positive quantity, batch
 * size limits, stock-below-reservations invariant, and optimistic lock conflict).
 *
 * The {@code maxBatchSize} and {@code maxRetries} fields are normally injected via
 * {@code @Value}; here they are set with {@link ReflectionTestUtils} to mirror the
 * configured defaults (1000 and 3).
 */
@ExtendWith(MockitoExtension.class)
class StockUpdateServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private StockUpdateService stockUpdateService;

    private UUID productIdA;
    private UUID productIdB;

    @BeforeEach
    void setUp() {
        // Use fixed, ordered UUIDs so lock-ordering assertions are deterministic.
        productIdA = UUID.fromString("11111111-1111-1111-1111-111111111111");
        productIdB = UUID.fromString("22222222-2222-2222-2222-222222222222");

        ReflectionTestUtils.setField(stockUpdateService, "maxBatchSize", 1000);
        ReflectionTestUtils.setField(stockUpdateService, "maxRetries", 3);
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private Product product(UUID id, String sku, long total, long reserved) {
        return Product.builder()
                .id(id)
                .sku(sku)
                .name("Product " + sku)
                .remark("Test fixture")
                .totalStock(total)
                .reservedStock(reserved)
                .availableStock(total - reserved)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    private BulkUpdateRequest.BulkStockUpdateEntry entry(UUID productId, Long newTotalStock) {
        return BulkUpdateRequest.BulkStockUpdateEntry.builder()
                .productId(productId)
                .newTotalStock(newTotalStock)
                .reason("Restock from warehouse shipment S-2024-001")
                .build();
    }

    private BulkUpdateRequest request(BulkUpdateRequest.BulkStockUpdateEntry... entries) {
        return BulkUpdateRequest.builder()
                .updates(new ArrayList<>(List.of(entries)))
                .build();
    }

    // ---------------------------------------------------------------------
    // Success paths
    // ---------------------------------------------------------------------

    @Test
    void bulkUpdateStock_withValidSingleProduct_returnsSuccessWithUpdatedLevels() {
        // Arrange
        Product existing = product(productIdA, "PROD-001", 100L, 55L);
        BulkUpdateRequest request = request(entry(productIdA, 150L));

        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(existing));
        when(productRepository.findByIdSetWithLock(anySet())).thenReturn(List.of(existing));
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

        // Act
        BulkUpdateResponse response = stockUpdateService.bulkUpdateStock(request);

        // Assert
        assertThat(response.getStatus()).isEqualTo("SUCCESS");
        assertThat(response.getRequestId()).startsWith("bulk-req-");
        assertThat(response.getTimestamp()).isNotNull();
        assertThat(response.getUpdatedProducts()).hasSize(1);

        BulkUpdateResponse.BulkUpdateResultEntry result = response.getUpdatedProducts().get(0);
        assertThat(result.getProductId()).isEqualTo(productIdA);
        assertThat(result.getSku()).isEqualTo("PROD-001");
        assertThat(result.getPreviousTotalStock()).isEqualTo(100L);
        assertThat(result.getNewTotalStock()).isEqualTo(150L);
        assertThat(result.getReservedStock()).isEqualTo(55L);
        assertThat(result.getAvailableStock()).isEqualTo(95L);

        verify(productRepository).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withMultipleProducts_updatesAllProducts() {
        // Arrange
        Product productA = product(productIdA, "PROD-001", 100L, 10L);
        Product productB = product(productIdB, "PROD-002", 200L, 80L);
        BulkUpdateRequest request = request(entry(productIdA, 120L), entry(productIdB, 250L));

        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(productA, productB));
        when(productRepository.findByIdSetWithLock(anySet())).thenReturn(List.of(productA, productB));
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

        // Act
        BulkUpdateResponse response = stockUpdateService.bulkUpdateStock(request);

        // Assert
        assertThat(response.getStatus()).isEqualTo("SUCCESS");
        assertThat(response.getUpdatedProducts()).hasSize(2);
        assertThat(response.getUpdatedProducts())
                .extracting(BulkUpdateResponse.BulkUpdateResultEntry::getNewTotalStock)
                .containsExactlyInAnyOrder(120L, 250L);

        verify(productRepository, org.mockito.Mockito.times(2)).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withNewStockEqualToReserved_setsAvailableStockToZero() {
        // Arrange
        Product existing = product(productIdA, "PROD-001", 100L, 40L);
        BulkUpdateRequest request = request(entry(productIdA, 40L));

        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(existing));
        when(productRepository.findByIdSetWithLock(anySet())).thenReturn(List.of(existing));
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

        // Act
        BulkUpdateResponse response = stockUpdateService.bulkUpdateStock(request);

        // Assert
        assertThat(response.getStatus()).isEqualTo("SUCCESS");
        BulkUpdateResponse.BulkUpdateResultEntry result = response.getUpdatedProducts().get(0);
        assertThat(result.getNewTotalStock()).isEqualTo(40L);
        assertThat(result.getReservedStock()).isEqualTo(40L);
        assertThat(result.getAvailableStock()).isEqualTo(0L);
    }

    @Test
    void bulkUpdateStock_withValidRequest_locksProductsByIdSet() {
        // Arrange
        Product existing = product(productIdA, "PROD-001", 100L, 55L);
        BulkUpdateRequest request = request(entry(productIdA, 150L));

        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(existing));
        when(productRepository.findByIdSetWithLock(anySet())).thenReturn(List.of(existing));
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

        // Act
        stockUpdateService.bulkUpdateStock(request);

        // Assert
        @SuppressWarnings("unchecked")
        ArgumentCaptor<Set<UUID>> captor = ArgumentCaptor.forClass(Set.class);
        verify(productRepository).findByIdSetWithLock(captor.capture());
        assertThat(captor.getValue()).containsExactly(productIdA);
    }

    // ---------------------------------------------------------------------
    // Validation / error paths
    // ---------------------------------------------------------------------

    @Test
    void bulkUpdateStock_withEmptyUpdates_throwsIllegalArgumentExceptionAndAppliesNoChanges() {
        // Arrange
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(new ArrayList<>())
                .build();

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("must not be empty");

        verify(productRepository, never()).save(any(Product.class));
        verify(productRepository, never()).findByIdSetWithLock(anySet());
    }

    @Test
    void bulkUpdateStock_withBatchExceedingMaxSize_throwsIllegalArgumentException() {
        // Arrange
        ReflectionTestUtils.setField(stockUpdateService, "maxBatchSize", 2);
        BulkUpdateRequest request = request(
                entry(productIdA, 100L),
                entry(productIdB, 100L),
                entry(UUID.fromString("33333333-3333-3333-3333-333333333333"), 100L));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("exceeds maximum");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withNullProductId_throwsIllegalArgumentExceptionAndAppliesNoChanges() {
        // Arrange
        BulkUpdateRequest request = request(entry(null, 150L));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Product ID is required");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withNullNewTotalStock_throwsIllegalArgumentException() {
        // Arrange
        BulkUpdateRequest request = request(entry(productIdA, null));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("New total stock is required");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withNegativeQuantity_throwsIllegalArgumentExceptionAndAppliesNoChanges() {
        // Arrange
        BulkUpdateRequest request = request(entry(productIdA, -10L));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("must be positive");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withZeroQuantity_throwsIllegalArgumentException() {
        // Arrange
        BulkUpdateRequest request = request(entry(productIdA, 0L));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("must be positive");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withUnknownProductId_throwsIllegalArgumentExceptionAndAppliesNoChanges() {
        // Arrange
        BulkUpdateRequest request = request(entry(productIdA, 150L));
        when(productRepository.findByIdSet(anySet())).thenReturn(List.of());

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Product not found");

        verify(productRepository, never()).save(any(Product.class));
        verify(productRepository, never()).findByIdSetWithLock(anySet());
    }

    @Test
    void bulkUpdateStock_whenOneProductInBatchMissing_failsEntireBatchWithNoUpdates() {
        // Arrange
        Product productA = product(productIdA, "PROD-001", 100L, 10L);
        BulkUpdateRequest request = request(entry(productIdA, 120L), entry(productIdB, 250L));

        // Only productA exists; productB is missing.
        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(productA));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Product not found");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_withNewStockBelowReserved_throwsIllegalStateExceptionAndAppliesNoChanges() {
        // Arrange
        Product existing = product(productIdA, "PROD-001", 100L, 55L);
        BulkUpdateRequest request = request(entry(productIdA, 50L));

        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(existing));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("already reserved");

        verify(productRepository, never()).save(any(Product.class));
        verify(productRepository, never()).findByIdSetWithLock(anySet());
    }

    @Test
    void bulkUpdateStock_whenLockLoadReturnsFewerProducts_throwsIllegalArgumentException() {
        // Arrange
        Product productA = product(productIdA, "PROD-001", 100L, 10L);
        Product productB = product(productIdB, "PROD-002", 200L, 80L);
        BulkUpdateRequest request = request(entry(productIdA, 120L), entry(productIdB, 250L));

        // Validation passes (both found), but lock acquisition returns only one.
        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(productA, productB));
        when(productRepository.findByIdSetWithLock(anySet())).thenReturn(List.of(productA));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("not found during lock acquisition");

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void bulkUpdateStock_whenOptimisticLockConflict_propagatesException() {
        // Arrange
        Product existing = product(productIdA, "PROD-001", 100L, 55L);
        BulkUpdateRequest request = request(entry(productIdA, 150L));

        when(productRepository.findByIdSet(anySet())).thenReturn(List.of(existing));
        when(productRepository.findByIdSetWithLock(anySet())).thenReturn(List.of(existing));
        when(productRepository.save(any(Product.class)))
                .thenThrow(new JpaOptimisticLockingFailureException(
                        new jakarta.persistence.OptimisticLockException("version conflict")));

        // Act / Assert
        assertThatThrownBy(() -> stockUpdateService.bulkUpdateStock(request))
                .isInstanceOf(JpaOptimisticLockingFailureException.class);
    }
}
