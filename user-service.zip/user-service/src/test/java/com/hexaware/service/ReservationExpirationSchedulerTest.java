package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationHistory;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationHistoryRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import jakarta.persistence.LockTimeoutException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link ReservationExpirationScheduler}.
 *
 * <p>These tests isolate the scheduler from the persistence layer using Mockito-mocked
 * repositories, verifying the expiration algorithm's behaviour: ACTIVE reservations are
 * transitioned to EXPIRED and their stock restored, already-EXPIRED reservations are
 * skipped idempotently (no double-restore), a lock-acquisition failure on one product does
 * not block the others, an audit trail is written (one EXPIRE {@code stock_audit_log} per
 * product plus a {@code reservation_history} record per reservation), and an empty batch is
 * a no-op.
 *
 * <p>Follows the project's testing standards: AAA structure with section comments,
 * {@code methodName_stateUnderTest_expectedBehaviour} naming, AssertJ assertions,
 * {@code @BeforeEach} fixture reset, {@code @InjectMocks} wiring, and
 * {@link ReflectionTestUtils} to inject the {@code @Value} batch-size field.
 *
 * <p>Validates: Requirements 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.8
 */
@ExtendWith(MockitoExtension.class)
class ReservationExpirationSchedulerTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private ReservationHistoryRepository reservationHistoryRepository;

    @Mock
    private StockAuditLogRepository stockAuditLogRepository;

    @InjectMocks
    private ReservationExpirationScheduler scheduler;

    private UUID productId;
    private UUID orderId;

    @BeforeEach
    void setUp() {
        productId = UUID.randomUUID();
        orderId = UUID.randomUUID();
        ReflectionTestUtils.setField(scheduler, "batchLimit", 1000);
    }

    @Test
    void processExpiredReservations_whenActiveReservationExpired_marksExpiredAndRestoresStock() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.ACTIVE);

        when(reservationRepository.findExpiredReservations(any(LocalDateTime.class)))
                .thenReturn(List.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert
        assertThat(expiredCount).isEqualTo(1);
        assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.EXPIRED);
        assertThat(reservation.getExpiredAt()).isNotNull();
        assertThat(product.getAvailableStock()).isEqualTo(100L);
        assertThat(product.getReservedStock()).isEqualTo(0L);

        verify(reservationRepository).save(reservation);
        verify(productRepository).save(product);
    }

    @Test
    void processExpiredReservations_whenReservationAlreadyExpired_skipsWithoutRestoringStock() {
        // Arrange
        Product product = buildProduct(100L, 0L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.EXPIRED);
        reservation.setExpiredAt(LocalDateTime.now().minusMinutes(1));

        when(reservationRepository.findExpiredReservations(any(LocalDateTime.class)))
                .thenReturn(List.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert
        assertThat(expiredCount).isZero();
        assertThat(product.getAvailableStock()).isEqualTo(100L);
        assertThat(product.getReservedStock()).isEqualTo(0L);

        verify(reservationRepository, never()).save(any());
        verify(productRepository, never()).save(any());
        verify(stockAuditLogRepository, never()).save(any());
        verify(reservationHistoryRepository, never()).save(any());
    }

    @Test
    void processExpiredReservations_whenMultipleReservationsForProduct_restoresTotalQuantity() {
        // Arrange
        Product product = buildProduct(70L, 30L);
        Reservation first = buildReservation(product, 10L, ReservationStatus.ACTIVE);
        Reservation second = buildReservation(product, 20L, ReservationStatus.ACTIVE);

        when(reservationRepository.findExpiredReservations(any(LocalDateTime.class)))
                .thenReturn(List.of(first, second));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert
        assertThat(expiredCount).isEqualTo(2);
        assertThat(product.getAvailableStock()).isEqualTo(100L);
        assertThat(product.getReservedStock()).isEqualTo(0L);
        assertThat(first.getStatus()).isEqualTo(ReservationStatus.EXPIRED);
        assertThat(second.getStatus()).isEqualTo(ReservationStatus.EXPIRED);
    }

    @Test
    void processExpiredReservations_whenLockFailsOnOneProduct_stillProcessesOtherProducts() {
        // Arrange
        UUID lockedProductId = UUID.randomUUID();
        Product lockedProduct = buildProduct(lockedProductId, 90L, 10L);
        Product freeProduct = buildProduct(80L, 20L);

        Reservation lockedReservation = buildReservation(lockedProduct, 10L, ReservationStatus.ACTIVE);
        Reservation freeReservation = buildReservation(freeProduct, 20L, ReservationStatus.ACTIVE);

        when(reservationRepository.findExpiredReservations(any(LocalDateTime.class)))
                .thenReturn(List.of(lockedReservation, freeReservation));
        when(productRepository.findByIdWithLock(lockedProductId))
                .thenThrow(new LockTimeoutException("row is locked"));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(freeProduct));

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert
        assertThat(expiredCount).isEqualTo(1);
        assertThat(lockedReservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
        assertThat(lockedProduct.getAvailableStock()).isEqualTo(90L);
        assertThat(freeReservation.getStatus()).isEqualTo(ReservationStatus.EXPIRED);
        assertThat(freeProduct.getAvailableStock()).isEqualTo(100L);

        verify(productRepository).save(freeProduct);
        verify(productRepository, never()).save(lockedProduct);
    }

    @Test
    void processExpiredReservations_whenActiveReservationExpired_writesStockAuditLog() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.ACTIVE);

        when(reservationRepository.findExpiredReservations(any(LocalDateTime.class)))
                .thenReturn(List.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        scheduler.processExpiredReservations();

        // Assert
        ArgumentCaptor<StockAuditLog> auditCaptor = ArgumentCaptor.forClass(StockAuditLog.class);
        verify(stockAuditLogRepository).save(auditCaptor.capture());

        StockAuditLog audit = auditCaptor.getValue();
        assertThat(audit.getOperationType()).isEqualTo(StockOperationType.EXPIRE);
        assertThat(audit.getQuantityChange()).isEqualTo(10L);
        assertThat(audit.getAvailableStockBefore()).isEqualTo(90L);
        assertThat(audit.getAvailableStockAfter()).isEqualTo(100L);
        assertThat(audit.getProduct()).isSameAs(product);
    }

    @Test
    void processExpiredReservations_whenActiveReservationExpired_writesReservationHistory() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.ACTIVE);

        when(reservationRepository.findExpiredReservations(any(LocalDateTime.class)))
                .thenReturn(List.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        scheduler.processExpiredReservations();

        // Assert
        ArgumentCaptor<ReservationHistory> historyCaptor = ArgumentCaptor.forClass(ReservationHistory.class);
        verify(reservationHistoryRepository).save(historyCaptor.capture());

        ReservationHistory history = historyCaptor.getValue();
        assertThat(history.getOldStatus()).isEqualTo("ACTIVE");
        assertThat(history.getNewStatus()).isEqualTo("EXPIRED");
        assertThat(history.getOrderId()).isEqualTo(orderId);
        assertThat(history.getProductId()).isEqualTo(productId);
        assertThat(history.getQuantity()).isEqualTo(10L);
    }

    @Test
    void processExpiredReservations_whenNoExpiredReservations_isNoOp() {
        // Arrange
        when(reservationRepository.findExpiredReservations(any(LocalDateTime.class)))
                .thenReturn(List.of());

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert
        assertThat(expiredCount).isZero();
        verify(productRepository, never()).findByIdWithLock(any());
        verify(productRepository, never()).save(any());
        verify(reservationRepository, never()).save(any());
        verify(stockAuditLogRepository, never()).save(any());
        verify(reservationHistoryRepository, never()).save(any());
    }

    // ========== Test Data Builders ==========

    private Product buildProduct(long availableStock, long reservedStock) {
        return buildProduct(productId, availableStock, reservedStock);
    }

    private Product buildProduct(UUID id, long availableStock, long reservedStock) {
        return Product.builder()
                .id(id)
                .sku("SKU-" + id)
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    private Reservation buildReservation(Product product, long quantity, ReservationStatus status) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(product)
                .quantity(quantity)
                .status(status)
                .expirationTime(LocalDateTime.now().minusMinutes(1))
                .createdAt(LocalDateTime.now().minusMinutes(16))
                .build();
    }
}
