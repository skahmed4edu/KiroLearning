package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

/**
 * Property-Based Test for reservation create → release round-trip consistency.
 *
 * <p>Task 12 ({@code ReservationReleaseService}) delegates stock mutation to the
 * {@link Product} entity: a reservation creation decrements available stock via
 * {@link Product#reserveStock(Long)}, and a release restores it via
 * {@link Product#releaseStock(Long)} together with the reservation state transition
 * {@link Reservation#release(LocalDateTime)}. This property therefore exercises the full
 * round trip at the point where the stock invariants actually live — the product's
 * stock-mutation logic plus the reservation lifecycle — since the release service itself
 * is not yet implemented (parent task 12).
 *
 * <p><b>Property 8 — Round-trip property</b> (<b>Validates: Requirements 3.4</b>):
 * creating a reservation for quantity {@code q} and then releasing it returns the product
 * to its pre-reservation state. Concretely, for any valid starting stock split:
 * <pre>
 *   snapshot          := (available, reserved, total)
 *   reserveStock(q)   -> available-q, reserved+q
 *   release()+releaseStock(q) -> available,   reserved
 *   assert state == snapshot
 * </pre>
 * Available stock returns to its original value, reserved stock returns to its original
 * value, and total stock is conserved throughout the whole round trip.
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath; dependencies are governed by architecture steering), this is a JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} test driven by a mix of hand-picked
 * edge-case scenarios and a fixed-seed randomized generator. A fixed seed keeps runs
 * deterministic and any counterexample reproducible.
 */
@Slf4j
class ReservationReleaseRoundTripPropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if the property ever fails. */
    private static final long SEED = 20240115L;

    /**
     * PROPERTY 8: Round-trip Consistency
     *
     * <p><b>Validates: Requirements 3.4</b>
     *
     * <p>Reserving {@code q} units and then releasing that same reservation is a no-op on
     * the product's stock: available and reserved stock each return to exactly the value
     * they held before the reservation was created.
     *
     * @param scenario a starting stock split with a reserve/release quantity in
     *                 {@code [1, availableBefore]}
     */
    @ParameterizedTest(name = "Round-trip: {0}")
    @MethodSource({"roundTripScenarios", "randomizedRoundTripScenarios"})
    void reserveThenRelease_forSameQuantity_restoresOriginalStock(RoundTripScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);

        long availableSnapshot = product.getAvailableStock();
        long reservedSnapshot = product.getReservedStock();
        long totalSnapshot = product.getTotalStock();

        // Act - create a reservation (reserve stock), then release it (restore stock).
        Reservation reservation = createActiveReservation(product, scenario.quantity);
        product.reserveStock(reservation.getQuantity());

        reservation.release(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        // Assert - the product is back to its pre-reservation state.
        assertThat(product.getAvailableStock())
                .as("available stock must return to its original value after reserve+release")
                .isEqualTo(availableSnapshot);

        assertThat(product.getReservedStock())
                .as("reserved stock must return to its original value after reserve+release")
                .isEqualTo(reservedSnapshot);

        assertThat(product.getTotalStock())
                .as("total stock must be conserved across the whole round trip")
                .isEqualTo(totalSnapshot);

        assertThat(reservation.getStatus())
                .as("reservation must end in RELEASED after the round trip")
                .isEqualTo(ReservationStatus.RELEASED);

        assertThatCode(product::validateStockInvariant)
                .as("full stock invariant must hold after the round trip")
                .doesNotThrowAnyException();

        log.info("✓ Round-trip verified: available {}->{}, reserved {}->{}, total conserved at {}",
                availableSnapshot, product.getAvailableStock(),
                reservedSnapshot, product.getReservedStock(), totalSnapshot);
    }

    /**
     * CONSERVATION PROPERTY (intermediate state)
     *
     * <p>Reinforces Property 8 by asserting total stock is conserved not just end-to-end
     * but also in the intermediate reserved state: after {@code reserveStock(q)} the units
     * have only moved from the available bucket into the reserved bucket, so
     * {@code available + reserved} still equals {@code totalStock} both mid-round-trip and
     * at the end.
     *
     * @param scenario a starting stock split with a reserve/release quantity
     */
    @ParameterizedTest(name = "Conservation: {0}")
    @MethodSource({"roundTripScenarios", "randomizedRoundTripScenarios"})
    void reserveThenRelease_atEveryStep_conservesTotalStock(RoundTripScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        long total = product.getTotalStock();

        // Act + Assert - total is conserved after the reserve step...
        Reservation reservation = createActiveReservation(product, scenario.quantity);
        product.reserveStock(reservation.getQuantity());

        assertThat(product.getAvailableStock() + product.getReservedStock())
                .as("available + reserved must equal total after reserving")
                .isEqualTo(total);
        assertThat(product.getAvailableStock())
                .as("reserving must move units out of available (available decreases by q)")
                .isEqualTo(scenario.availableBefore - scenario.quantity);

        // ...and still conserved after the release step.
        reservation.release(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        assertThat(product.getAvailableStock() + product.getReservedStock())
                .as("available + reserved must equal total after releasing")
                .isEqualTo(total);
        assertThat(product.getTotalStock())
                .as("total stock itself must never change during the round trip")
                .isEqualTo(total);

        log.info("✓ Conservation verified across round trip: total stays {}", total);
    }

    // ========== Scenario Generators ==========

    /**
     * Hand-picked edge-case scenarios: reserving the only available unit, reserving the
     * entire available pool, round-tripping from a fully available product, and
     * large-stock cases. Each scenario's quantity is always in {@code [1, availableBefore]}
     * so the reserve step's precondition ({@code q <= availableStock}) is satisfied.
     *
     * @return stream of round-trip scenarios
     */
    static Stream<RoundTripScenario> roundTripScenarios() {
        return Stream.of(
                // single available unit, reserve+release it
                new RoundTripScenario(1, 0, 1),
                // reserve the single available unit from a mixed product
                new RoundTripScenario(1, 99, 1),
                // reserve part of the available pool
                new RoundTripScenario(50, 50, 25),
                // reserve the entire available pool
                new RoundTripScenario(50, 50, 50),
                // fully available product, reserve all
                new RoundTripScenario(100, 0, 100),
                // fully available product, reserve one
                new RoundTripScenario(100, 0, 1),
                // large stock, small reserve
                new RoundTripScenario(95_000, 5_000, 1),
                // small available, reserve all of it
                new RoundTripScenario(999, 1, 999),
                // mid-range partial reserve
                new RoundTripScenario(700, 300, 150),
                // reserve the full available amount on a large product
                new RoundTripScenario(50_000, 50_000, 50_000)
        );
    }

    /**
     * Fixed-seed randomized generator covering the valid round-trip input space broadly.
     *
     * <p>For each scenario it samples a total stock, splits it into a valid
     * available/reserved pair, and picks a reserve/release quantity in
     * {@code [1, available]} so the reservation can actually be created (the reserve step
     * requires {@code q <= availableStock}). This mirrors the precondition the reservation
     * service enforces while probing many combinations of magnitudes and ratios.
     *
     * @return stream of 100 randomized round-trip scenarios
     */
    static Stream<RoundTripScenario> randomizedRoundTripScenarios() {
        Random random = new Random(SEED);
        int numberOfScenarios = 100;

        List<RoundTripScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Total in [1, 100_000].
            long total = 1 + (long) (random.nextDouble() * 100_000);
            // Available must be at least 1 so there is something to reserve; up to total.
            long available = 1 + (long) (random.nextDouble() * total);
            if (available > total) {
                available = total;
            }
            long reserved = total - available;
            // Reserve/release somewhere in [1, available].
            long quantity = 1 + (long) (random.nextDouble() * available);
            if (quantity > available) {
                quantity = available;
            }

            scenarios.add(new RoundTripScenario(available, reserved, quantity));
        }

        return scenarios.stream();
    }

    // ========== Test Data Class ==========

    /**
     * One round-trip case: the product's available/reserved split before the reservation,
     * and the quantity to reserve and then release. {@code quantity} is always in
     * {@code [1, availableBefore]}.
     */
    static class RoundTripScenario {
        final long availableBefore;
        final long reservedBefore;
        final long quantity;

        RoundTripScenario(long availableBefore, long reservedBefore, long quantity) {
            this.availableBefore = availableBefore;
            this.reservedBefore = reservedBefore;
            this.quantity = quantity;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, quantity=%d",
                    availableBefore, reservedBefore, quantity);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    static Reservation createActiveReservation(Product product, long quantity) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();
    }
}
