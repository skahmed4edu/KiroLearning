package com.hexaware.service;

import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Property-Based Tests for {@link ReservationService} metamorphic reservation behavior.
 *
 * <p>These tests follow the convention established by {@code StockUpdateServicePropertyTest}:
 * because there is no property-based testing library on the classpath (and the architecture
 * steering forbids adding dependencies without discussion), the "property" is expressed as a
 * JUnit 5 {@link ParameterizedTest} fed by a {@link MethodSource} that samples the input space
 * with a seeded {@link Random} generator. A fixed seed keeps every run deterministic and any
 * counterexample reproducible. The real {@link ReservationService} is exercised end to end;
 * only the database boundary ({@link ProductRepository}, {@link ReservationRepository},
 * {@link StockAuditLogRepository}) is faked via an {@link InMemoryProductStore}.
 *
 * <p>PROPERTIES TESTED:
 *
 * <p><b>Property 5: Metamorphic property - split vs combined reservation</b>
 * <br><b>Validates: Requirements 2.3</b>
 * <br>Reserving quantity {@code A} then quantity {@code B} against the same product (when stock
 * is sufficient for both) leaves the product in the same final stock state as reserving
 * {@code (A + B)} in a single operation. In both paths the stock decrement is additive, so:
 * <ul>
 *   <li>availableStock_final = totalStock - (A + B)</li>
 *   <li>reservedStock_final = A + B</li>
 * </ul>
 *
 * <p><b>Property 5b: Metamorphic property - order independence</b>
 * <br><b>Validates: Requirements 2.3</b>
 * <br>Reserving the sequence {@code [A, B]} and the sequence {@code [B, A]} against the same
 * starting product produces identical final aggregate totals (availableStock and reservedStock).
 * Reservation order does not change the aggregate stock outcome.
 */
@Slf4j
class ReservationServiceMetamorphicPropertyTest {

    /**
     * PROPERTY 5: Metamorphic property - split vs combined reservation.
     *
     * <p><b>Validates: Requirements 2.3</b>
     *
     * <p>Two reservations of A then B against a fresh copy of the same product must leave the
     * product in the identical final state as one reservation of (A + B) against another fresh
     * copy. This is a metamorphic relation: the follow-up input (two smaller reservations) is
     * derived from the source input (one combined reservation) and the resulting persisted stock
     * must agree.
     *
     * @param scenario a seeded, randomized product with two reservation quantities whose sum fits
     */
    @ParameterizedTest(name = "SplitVsCombined[{index}]: {0}")
    @MethodSource("splitVsCombinedScenarios")
    void createReservation_splitQuantitiesVersusCombined_producesIdenticalStockState(
            ReservationScenario scenario) {
        // Arrange
        UUID productId = scenario.productId();
        long quantityA = scenario.quantityA();
        long quantityB = scenario.quantityB();

        InMemoryProductStore splitStore = InMemoryProductStore.seededFrom(scenario.initialProduct());
        InMemoryProductStore combinedStore = InMemoryProductStore.seededFrom(scenario.initialProduct());

        // Act - split path: reserve A, then reserve B.
        runReservation(splitStore, reservationRequest(productId, quantityA));
        runReservation(splitStore, reservationRequest(productId, quantityB));

        // Act - combined path: reserve (A + B) in a single operation.
        runReservation(combinedStore, reservationRequest(productId, quantityA + quantityB));

        // Assert - both paths persist identical final stock state.
        Product afterSplit = splitStore.snapshot(productId);
        Product afterCombined = combinedStore.snapshot(productId);

        assertThat(afterSplit.getAvailableStock())
                .as("availableStock after split (A then B) equals combined (A+B) for product %s", productId)
                .isEqualTo(afterCombined.getAvailableStock())
                .isEqualTo(scenario.initialAvailableStock() - (quantityA + quantityB));

        assertThat(afterSplit.getReservedStock())
                .as("reservedStock after split (A then B) equals combined (A+B) for product %s", productId)
                .isEqualTo(afterCombined.getReservedStock())
                .isEqualTo(scenario.initialReservedStock() + (quantityA + quantityB));

        assertThat(afterSplit.getTotalStock())
                .as("totalStock is conserved for product %s", productId)
                .isEqualTo(afterCombined.getTotalStock())
                .isEqualTo(scenario.initialTotalStock());

        // The stock invariant must survive either path.
        assertThat(afterSplit.getAvailableStock())
                .as("invariant available = total - reserved after split for product %s", productId)
                .isEqualTo(afterSplit.getTotalStock() - afterSplit.getReservedStock());

        log.info("✓ Split/combined equivalence for {}: split(avail={}, reserved={}) == combined(avail={}, reserved={})",
                productId, afterSplit.getAvailableStock(), afterSplit.getReservedStock(),
                afterCombined.getAvailableStock(), afterCombined.getReservedStock());
    }

    /**
     * PROPERTY 5b: Metamorphic property - reservation order independence.
     *
     * <p><b>Validates: Requirements 2.3</b>
     *
     * <p>Reserving {@code [A, B]} and {@code [B, A]} against fresh copies of the same starting
     * product must produce identical final aggregate totals. Reordering the follow-up input must
     * not change the aggregate reserved/available outcome.
     *
     * @param scenario a seeded, randomized product with two reservation quantities whose sum fits
     */
    @ParameterizedTest(name = "OrderIndependence[{index}]: {0}")
    @MethodSource("orderIndependenceScenarios")
    void createReservation_reservationOrderReversed_producesIdenticalAggregateTotals(
            ReservationScenario scenario) {
        // Arrange
        UUID productId = scenario.productId();
        long quantityA = scenario.quantityA();
        long quantityB = scenario.quantityB();

        InMemoryProductStore forwardStore = InMemoryProductStore.seededFrom(scenario.initialProduct());
        InMemoryProductStore reversedStore = InMemoryProductStore.seededFrom(scenario.initialProduct());

        // Act - forward order: reserve A then B.
        runReservation(forwardStore, reservationRequest(productId, quantityA));
        runReservation(forwardStore, reservationRequest(productId, quantityB));

        // Act - reversed order: reserve B then A.
        runReservation(reversedStore, reservationRequest(productId, quantityB));
        runReservation(reversedStore, reservationRequest(productId, quantityA));

        // Assert - aggregate totals are identical regardless of reservation order.
        Product afterForward = forwardStore.snapshot(productId);
        Product afterReversed = reversedStore.snapshot(productId);

        assertThat(afterForward.getAvailableStock())
                .as("availableStock independent of reservation order for product %s", productId)
                .isEqualTo(afterReversed.getAvailableStock())
                .isEqualTo(scenario.initialAvailableStock() - (quantityA + quantityB));

        assertThat(afterForward.getReservedStock())
                .as("reservedStock independent of reservation order for product %s", productId)
                .isEqualTo(afterReversed.getReservedStock())
                .isEqualTo(scenario.initialReservedStock() + (quantityA + quantityB));

        log.info("✓ Order independence for {}: [A,B](avail={}, reserved={}) == [B,A](avail={}, reserved={})",
                productId, afterForward.getAvailableStock(), afterForward.getReservedStock(),
                afterReversed.getAvailableStock(), afterReversed.getReservedStock());
    }

    /**
     * Runs a single {@code createReservation} call against a fresh service instance whose
     * repositories are backed by the supplied in-memory store.
     *
     * <p>A fresh service/mocks per call keeps the stubbing simple and avoids leaking state between
     * paths; the shared mutable state lives entirely in the {@link InMemoryProductStore}.
     */
    private ReservationResponse runReservation(InMemoryProductStore store, CreateReservationRequest request) {
        ProductRepository productRepository = mock(ProductRepository.class);
        ReservationRepository reservationRepository = mock(ReservationRepository.class);
        StockAuditLogRepository stockAuditLogRepository = mock(StockAuditLogRepository.class);

        store.wireInto(productRepository, reservationRepository, stockAuditLogRepository);

        ReservationService service = new ReservationService(
                productRepository, reservationRepository, stockAuditLogRepository);
        ReflectionTestUtils.setField(service, "reservationTtlMinutes", 15);
        ReflectionTestUtils.setField(service, "lockTimeoutSeconds", 30);
        ReflectionTestUtils.setField(service, "maxRetries", 3);

        return service.createReservation(request);
    }

    /** Builds a reservation request (no idempotency key, so every call creates a reservation). */
    private static CreateReservationRequest reservationRequest(UUID productId, long quantity) {
        return CreateReservationRequest.builder()
                .orderId(UUID.randomUUID())
                .productId(productId)
                .quantity(quantity)
                .build();
    }

    /**
     * Generates randomized scenarios for the split-vs-combined metamorphic property.
     *
     * <p>Each scenario samples a product with a total stock large enough to accommodate two
     * reservations whose sum never exceeds available stock, so both paths succeed and the
     * additive relation can be asserted. A fixed seed keeps the run reproducible.
     *
     * @return stream of randomized reservation scenarios
     */
    static Stream<ReservationScenario> splitVsCombinedScenarios() {
        // Fixed seed → deterministic, reproducible counterexamples if one ever fails.
        return randomizedScenarios(new Random(20240115L), 80);
    }

    /**
     * Generates randomized scenarios for the order-independence metamorphic property.
     *
     * <p>Uses a distinct fixed seed from {@link #splitVsCombinedScenarios()} to broaden coverage
     * while remaining deterministic.
     *
     * @return stream of randomized reservation scenarios
     */
    static Stream<ReservationScenario> orderIndependenceScenarios() {
        return randomizedScenarios(new Random(99887766L), 80);
    }

    /**
     * Draws {@code count} valid scenarios: each has a positive total stock, a non-negative
     * pre-existing reserved amount, and two positive reservation quantities whose sum fits within
     * the currently available stock.
     */
    private static Stream<ReservationScenario> randomizedScenarios(Random random, int count) {
        List<ReservationScenario> scenarios = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            UUID productId = UUID.randomUUID();

            // Total stock in [10, 100_000].
            long totalStock = 10 + (long) (random.nextDouble() * 99_990);
            // Pre-existing reserved stock in [0, totalStock / 2] so there is room to reserve more.
            long preReserved = (long) (random.nextDouble() * (totalStock / 2));
            long available = totalStock - preReserved;

            // Two positive quantities whose sum stays within available stock.
            // Split available room into two positive parts.
            long room = available; // room >= totalStock/2 >= 5
            long quantityA = 1 + (long) (random.nextDouble() * (room - 1)); // 1 .. room-1 (at least 1)
            long maxB = room - quantityA; // remaining room, >= 1
            long quantityB = 1 + (long) (random.nextDouble() * Math.max(0, maxB - 1)); // 1 .. maxB

            Product initial = createTestProduct(productId, "PROD-RES-" + i, totalStock, preReserved, available);

            scenarios.add(new ReservationScenario(productId, initial, quantityA, quantityB));
        }
        return scenarios.stream();
    }

    /**
     * Immutable description of one reservation scenario: the initial product snapshot and the two
     * reservation quantities to apply. Both paths of each property are seeded from
     * {@link #initialProduct()} so they start identical.
     */
    static class ReservationScenario {
        private final UUID productId;
        private final Product initialProduct;
        private final long quantityA;
        private final long quantityB;

        ReservationScenario(UUID productId, Product initialProduct, long quantityA, long quantityB) {
            this.productId = productId;
            this.initialProduct = initialProduct;
            this.quantityA = quantityA;
            this.quantityB = quantityB;
        }

        UUID productId() {
            return productId;
        }

        Product initialProduct() {
            return initialProduct;
        }

        long quantityA() {
            return quantityA;
        }

        long quantityB() {
            return quantityB;
        }

        long initialTotalStock() {
            return initialProduct.getTotalStock();
        }

        long initialAvailableStock() {
            return initialProduct.getAvailableStock();
        }

        long initialReservedStock() {
            return initialProduct.getReservedStock();
        }

        @Override
        public String toString() {
            return String.format("total=%d, reserved=%d, A=%d, B=%d",
                    initialProduct.getTotalStock(), initialProduct.getReservedStock(), quantityA, quantityB);
        }
    }

    /**
     * Minimal in-memory stand-in for the products table that makes the mocked repositories behave
     * like a real store across multiple {@code createReservation} calls.
     *
     * <p>It supports exactly the repository interactions {@link ReservationService} relies on:
     * {@code ProductRepository.findByIdWithLock}, {@code ProductRepository.save},
     * {@code ReservationRepository.findByIdempotencyKeyAndOrderId} (always empty here, since no
     * idempotency key is used), {@code ReservationRepository.save}, and
     * {@code StockAuditLogRepository.save}. Products are deep-copied on seed and on read so the
     * service mutates detached copies and only {@code save} commits changes back, matching JPA
     * semantics closely enough for this property.
     */
    static class InMemoryProductStore {
        private final Map<UUID, Product> rows = new LinkedHashMap<>();

        static InMemoryProductStore seededFrom(Product product) {
            InMemoryProductStore store = new InMemoryProductStore();
            store.rows.put(product.getId(), copy(product));
            return store;
        }

        void wireInto(ProductRepository productRepository,
                      ReservationRepository reservationRepository,
                      StockAuditLogRepository stockAuditLogRepository) {

            when(productRepository.findByIdWithLock(any(UUID.class))).thenAnswer(invocation -> {
                UUID id = invocation.getArgument(0);
                Product found = rows.get(id);
                return found == null ? Optional.empty() : Optional.of(copy(found));
            });

            when(productRepository.save(any(Product.class))).thenAnswer(invocation -> {
                Product toSave = invocation.getArgument(0);
                Product persisted = copy(toSave);
                persisted.setLockVersion(
                        (persisted.getLockVersion() != null ? persisted.getLockVersion() : 0L) + 1L);
                rows.put(persisted.getId(), persisted);
                return copy(persisted);
            });

            // No idempotency key is supplied by the test, but stub defensively for completeness.
            when(reservationRepository.findByIdempotencyKeyAndOrderId(any(), any(UUID.class)))
                    .thenReturn(Optional.empty());

            when(reservationRepository.save(any(Reservation.class)))
                    .thenAnswer(invocation -> invocation.getArgument(0));

            when(stockAuditLogRepository.save(any(StockAuditLog.class)))
                    .thenAnswer(invocation -> invocation.getArgument(0));
        }

        Product snapshot(UUID productId) {
            return copy(rows.get(productId));
        }

        private static Product copy(Product source) {
            return Product.builder()
                    .id(source.getId())
                    .sku(source.getSku())
                    .name(source.getName())
                    .remark(source.getRemark())
                    .totalStock(source.getTotalStock())
                    .reservedStock(source.getReservedStock())
                    .availableStock(source.getAvailableStock())
                    .lockVersion(source.getLockVersion())
                    .createdAt(source.getCreatedAt())
                    .updatedAt(source.getUpdatedAt())
                    .build();
        }
    }

    /**
     * Factory method to create test Product instances.
     */
    private static Product createTestProduct(UUID id, String sku, long totalStock,
                                             long reservedStock, long availableStock) {
        return Product.builder()
                .id(id)
                .sku(sku)
                .name("Test Product " + sku)
                .remark("")
                .totalStock(totalStock)
                .reservedStock(reservedStock)
                .availableStock(availableStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }
}
