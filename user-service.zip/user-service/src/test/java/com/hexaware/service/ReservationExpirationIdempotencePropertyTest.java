package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

/**
 * Property-Based Test for idempotent reservation expiration.
 *
 * <p><b>Property 13 — Idempotence (Validates: Requirements 4.1).</b> Expiring the same
 * reservation multiple times produces the same final state as expiring it exactly once:
 * the reserved quantity is restored to available stock <em>once</em>, the reservation ends
 * in {@code EXPIRED}, and no double-restore ever occurs.
 *
 * <p>The {@code ReservationExpirationScheduler} (task 13) is not yet implemented — and this
 * test deliberately does not depend on or create any scheduler file (task 13.5 may add them
 * concurrently). Instead the property is exercised at the point where the behaviour actually
 * lives: the stock mutation {@link Product#releaseStock(Long)} plus the state transition
 * {@link Reservation#expire(LocalDateTime)}. Idempotence is enforced the same way the sibling
 * release-idempotence test models it (design step: "if already EXPIRED, skip processing"):
 * before restoring stock, the processor checks whether the reservation is already
 * {@code EXPIRED} and, if so, skips the stock mutation and succeeds. This guard is modelled
 * directly in {@link #expireOnce} so that repeated expirations never double-restore.
 *
 * <p>Properties verified for expiring an active reservation of quantity {@code q} a total of
 * {@code n >= 1} times:
 * <ul>
 *   <li><b>Property 13 — Idempotence:</b> the final product state after {@code n} expirations
 *       is identical to the state after exactly one expiration — in particular
 *       {@code availableStock_final = availableStock_before + q} regardless of {@code n}
 *       (<b>Validates: Requirements 4.1</b>)</li>
 *   <li><b>No double-restore:</b> {@code q} is added to available stock exactly once, never
 *       {@code n * q}</li>
 *   <li><b>Terminal status:</b> the reservation ends {@code EXPIRED} with a single stable
 *       {@code expiredAt} timestamp that does not change on subsequent expirations</li>
 *   <li><b>Conservation:</b> {@code available + reserved} equals {@code totalStock} throughout</li>
 * </ul>
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath, dependencies are governed by architecture steering), this is a JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} test driven by hand-picked edge-case
 * scenarios and a fixed-seed randomized generator. A fixed seed keeps runs deterministic and
 * any counterexample reproducible.
 */
@Slf4j
class ReservationExpirationIdempotencePropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if a property ever fails. */
    private static final long SEED = 20240115L;

    /**
     * PROPERTY 13: Idempotence
     *
     * <p><b>Validates: Requirements 4.1</b>
     *
     * <p>Expiring the same reservation {@code n >= 1} times leaves the product in the same
     * state as expiring it once: available stock grows by exactly the reserved quantity, the
     * reserved pool shrinks by exactly that quantity, and the reservation is {@code EXPIRED}.
     * Only the first expiration mutates stock; every later expiration is a no-op.
     *
     * @param scenario a product/reservation pair plus an expiration-attempt count {@code >= 1}
     */
    @ParameterizedTest(name = "Idempotent expiration: {0}")
    @MethodSource({"idempotenceScenarios", "randomizedIdempotenceScenarios"})
    void expireReservation_whenExpiredRepeatedly_matchesSingleExpirationAndRestoresStockOnce(
            IdempotenceScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.expireQuantity);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();

        // Act
        expireOnce(reservation, product);
        LocalDateTime expiredAtAfterFirst = reservation.getExpiredAt();
        long availableAfterFirst = product.getAvailableStock();
        long reservedAfterFirst = product.getReservedStock();

        for (int attempt = 2; attempt <= scenario.expireAttempts; attempt++) {
            expireOnce(reservation, product);
        }

        // Assert
        assertThat(product.getAvailableStock())
                .as("available stock after %d expirations must equal the single-expiration result "
                        + "(restored exactly once)", scenario.expireAttempts)
                .isEqualTo(availableAfterFirst)
                .isEqualTo(availableBefore + scenario.expireQuantity);

        assertThat(product.getReservedStock())
                .as("reserved stock after %d expirations must equal the single-expiration result "
                        + "(decremented exactly once)", scenario.expireAttempts)
                .isEqualTo(reservedAfterFirst)
                .isEqualTo(reservedBefore - scenario.expireQuantity);

        assertThat(reservation.getStatus())
                .as("reservation must remain EXPIRED after any number of expirations")
                .isEqualTo(ReservationStatus.EXPIRED);

        assertThat(reservation.getExpiredAt())
                .as("expiredAt must be set once and never change on repeated expirations")
                .isEqualTo(expiredAtAfterFirst)
                .isNotNull();

        log.info("✓ Idempotence verified over {} expirations: available {} -> {} (restored {} once), "
                        + "reserved {} -> {}", scenario.expireAttempts, availableBefore,
                product.getAvailableStock(), scenario.expireQuantity, reservedBefore,
                product.getReservedStock());
    }

    /**
     * CONSERVATION UNDER REPEATED EXPIRATION
     *
     * <p>No matter how many times a reservation is expired, stock is only ever moved between
     * the reserved and available buckets — never created or destroyed. So
     * {@code available + reserved} must stay equal to {@code totalStock} and the full stock
     * invariant must hold after every expiration attempt.
     *
     * @param scenario a product/reservation pair plus an expiration-attempt count {@code >= 1}
     */
    @ParameterizedTest(name = "Conservation under repeat: {0}")
    @MethodSource({"idempotenceScenarios", "randomizedIdempotenceScenarios"})
    void expireReservation_whenExpiredRepeatedly_conservesTotalStock(IdempotenceScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.expireQuantity);

        long totalBefore = product.getTotalStock();

        // Act
        for (int attempt = 1; attempt <= scenario.expireAttempts; attempt++) {
            expireOnce(reservation, product);

            // Assert (holds after every single attempt)
            assertThat(product.getAvailableStock() + product.getReservedStock())
                    .as("available + reserved must equal total stock after expiration attempt %d", attempt)
                    .isEqualTo(totalBefore);
            assertThatCode(product::validateStockInvariant)
                    .as("full stock invariant must hold after expiration attempt %d", attempt)
                    .doesNotThrowAnyException();
        }

        // Assert
        assertThat(product.getTotalStock())
                .as("total stock itself must be unchanged by any number of expirations")
                .isEqualTo(totalBefore);

        log.info("✓ Conservation verified across {} expirations: total={} preserved",
                scenario.expireAttempts, totalBefore);
    }

    // ========== Idempotent Expiration Model ==========

    /**
     * Models a single expiration attempt exactly as the expiration processor specifies its
     * idempotency guard ("if already EXPIRED, skip processing"): if the reservation is already
     * {@code EXPIRED}, the expiration is a successful no-op and stock is <b>not</b> mutated
     * again. Only an {@code ACTIVE} reservation transitions and restores stock.
     *
     * <p>This mirrors {@code ReservationReleaseIdempotencePropertyTest#releaseOnce} and does
     * not touch any scheduler class.
     *
     * @param reservation the reservation being expired
     * @param product     the owning product whose stock is restored on the first expiration
     */
    private static void expireOnce(Reservation reservation, Product product) {
        if (reservation.getStatus() == ReservationStatus.EXPIRED) {
            // Idempotent: already expired, skip the stock restore and succeed.
            return;
        }
        reservation.expire(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());
    }

    // ========== Scenario Generators ==========

    /**
     * Hand-picked edge-case scenarios covering the single-expiration boundary ({@code n == 1}),
     * typical retry counts, and large repeat counts — across small, mixed, and large stock
     * splits.
     *
     * @return stream of idempotence scenarios
     */
    static Stream<IdempotenceScenario> idempotenceScenarios() {
        return Stream.of(
                // n == 1: the baseline single expiration
                new IdempotenceScenario(0, 1, 1, 1),
                // expire the single reserved unit twice
                new IdempotenceScenario(99, 1, 1, 2),
                // partial expiration, repeated three times
                new IdempotenceScenario(50, 50, 25, 3),
                // expire the entire reserved pool, repeated
                new IdempotenceScenario(50, 50, 50, 5),
                // fully reserved product, expire all, many retries
                new IdempotenceScenario(0, 100, 100, 10),
                // fully reserved product, expire one, repeated
                new IdempotenceScenario(0, 100, 1, 4),
                // large stock, small expiration, repeated
                new IdempotenceScenario(95_000, 5_000, 1, 7),
                // large expiration, repeated
                new IdempotenceScenario(1, 999, 999, 3),
                // mid-range partial expiration, high retry count
                new IdempotenceScenario(700, 300, 150, 20),
                // large product, full reserved expiration, repeated
                new IdempotenceScenario(50_000, 50_000, 50_000, 6)
        );
    }

    /**
     * Fixed-seed randomized generator covering the valid expiration input space broadly, each
     * paired with a repeat count in {@code [1, 10]}. For each scenario it samples a total
     * stock, splits it into a valid available/reserved pair, and picks an expiration quantity
     * in {@code [1, reserved]} so the expiration always targets stock that is actually held —
     * the same precondition the stock mutation enforces.
     *
     * @return stream of 100 randomized idempotence scenarios
     */
    static Stream<IdempotenceScenario> randomizedIdempotenceScenarios() {
        Random random = new Random(SEED);
        int numberOfScenarios = 100;

        List<IdempotenceScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Total in [1, 100_000].
            long total = 1 + (long) (random.nextDouble() * 100_000);
            // Reserved must be at least 1 so there is something to expire; up to total.
            long reserved = 1 + (long) (random.nextDouble() * total);
            if (reserved > total) {
                reserved = total;
            }
            long available = total - reserved;
            // Expire somewhere in [1, reserved].
            long expire = 1 + (long) (random.nextDouble() * reserved);
            if (expire > reserved) {
                expire = reserved;
            }
            // Repeat the expiration between 1 and 10 times.
            int attempts = 1 + random.nextInt(10);

            scenarios.add(new IdempotenceScenario(available, reserved, expire, attempts));
        }

        return scenarios.stream();
    }

    // ========== Test Data Class ==========

    /**
     * One idempotence case: the product's available/reserved split before expiration, the
     * quantity to expire ({@code expireQuantity} is always in {@code [1, reservedBefore]}),
     * and how many times the expiration is attempted ({@code expireAttempts >= 1}).
     */
    static class IdempotenceScenario {
        final long availableBefore;
        final long reservedBefore;
        final long expireQuantity;
        final int expireAttempts;

        IdempotenceScenario(long availableBefore, long reservedBefore, long expireQuantity,
                            int expireAttempts) {
            this.availableBefore = availableBefore;
            this.reservedBefore = reservedBefore;
            this.expireQuantity = expireQuantity;
            this.expireAttempts = expireAttempts;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, expire=%d, attempts=%d",
                    availableBefore, reservedBefore, expireQuantity, expireAttempts);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    static Reservation createActiveReservation(Product product, long quantity) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();
    }
}
