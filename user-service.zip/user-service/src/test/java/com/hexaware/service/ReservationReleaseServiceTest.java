package com.hexaware.service;

import com.hexaware.dto.ReleaseResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationHistory;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationHistoryRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.LockTimeoutException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link ReservationReleaseService}.
 *
 * <p>These tests isolate the service from the persistence layer using Mockito-mocked
 * repositories, verifying the release algorithm's behaviour: stock restoration,
 * idempotent replay, invalid-state and not-found handling, lock-timeout propagation,
 * release-by-order lookup, and audit-trail writes (stock_audit_log + reservation_history).
 *
 * <p>Follows the project's testing standards: AAA structure with section comments,
 * {@code methodName_stateUnderTest_expectedBehaviour} naming, AssertJ assertions,
 * {@code @BeforeEach} fixture reset, and constructor-free {@code @InjectMocks} wiring.
 *
 * <p>Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7
 */
@ExtendWith(MockitoExtension.class)
class ReservationReleaseServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private ReservationHistoryRepository reservationHistoryRepository;

    @Mock
    private StockAuditLogRepository stockAuditLogRepository;

    @InjectMocks
    private ReservationReleaseService releaseService;

    private UUID productId;
    private UUID orderId;
    private UUID reservationId;

    @BeforeEach
    void setUp() {
        productId = UUID.randomUUID();
        orderId = UUID.randomUUID();
        reservationId = UUID.randomUUID();
    }

    @Test
    void releaseReservation_whenReservationActive_restoresStockAndMarksReleased() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.ACTIVE);

        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        ReleaseResponse response = releaseService.releaseReservation(reservationId, "idem-key-1");

        // Assert
        assertThat(product.getAvailableStock()).isEqualTo(100L);
        assertThat(product.getReservedStock()).isEqualTo(0L);
        assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.RELEASED);
        assertThat(reservation.getReleasedAt()).isNotNull();

        assertThat(response.getReservationId()).isEqualTo(reservationId);
        assertThat(response.getStatus()).isEqualTo("RELEASED");
        assertThat(response.getAvailableStock()).isEqualTo(100L);
        assertThat(response.isIdempotent()).isFalse();

        verify(productRepository).save(product);
        verify(reservationRepository).save(reservation);
    }

    @Test
    void releaseReservation_whenReservationActive_writesStockAuditLog() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.ACTIVE);

        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        releaseService.releaseReservation(reservationId, "req-123");

        // Assert
        ArgumentCaptor<StockAuditLog> auditCaptor = ArgumentCaptor.forClass(StockAuditLog.class);
        verify(stockAuditLogRepository).save(auditCaptor.capture());

        StockAuditLog audit = auditCaptor.getValue();
        assertThat(audit.getOperationType()).isEqualTo(StockOperationType.RELEASE);
        assertThat(audit.getQuantityChange()).isEqualTo(10L);
        assertThat(audit.getAvailableStockBefore()).isEqualTo(90L);
        assertThat(audit.getAvailableStockAfter()).isEqualTo(100L);
        assertThat(audit.getProduct()).isSameAs(product);
        assertThat(audit.getRequestId()).isEqualTo("req-123");
    }

    @Test
    void releaseReservation_whenReservationActive_writesReservationHistory() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.ACTIVE);

        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        releaseService.releaseReservation(reservationId, "req-123");

        // Assert
        ArgumentCaptor<ReservationHistory> historyCaptor = ArgumentCaptor.forClass(ReservationHistory.class);
        verify(reservationHistoryRepository).save(historyCaptor.capture());

        ReservationHistory history = historyCaptor.getValue();
        assertThat(history.getOldStatus()).isEqualTo("ACTIVE");
        assertThat(history.getNewStatus()).isEqualTo("RELEASED");
        assertThat(history.getOrderId()).isEqualTo(orderId);
        assertThat(history.getProductId()).isEqualTo(productId);
        assertThat(history.getQuantity()).isEqualTo(10L);
    }

    @Test
    void releaseReservation_whenReservationAlreadyReleased_returnsIdempotentSuccessWithoutRestockingStock() {
        // Arrange
        Product product = buildProduct(100L, 0L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.RELEASED);
        reservation.setReleasedAt(LocalDateTime.now().minusMinutes(1));

        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.of(reservation));

        // Act
        ReleaseResponse response = releaseService.releaseReservation(reservationId, "idem-key-1");

        // Assert
        assertThat(response.isIdempotent()).isTrue();
        assertThat(response.getStatus()).isEqualTo("RELEASED");
        assertThat(product.getAvailableStock()).isEqualTo(100L);
        assertThat(product.getReservedStock()).isEqualTo(0L);

        verify(productRepository, never()).findByIdWithLock(any());
        verify(productRepository, never()).save(any());
        verify(stockAuditLogRepository, never()).save(any());
        verify(reservationHistoryRepository, never()).save(any());
    }

    @Test
    void releaseReservation_whenReservationExpired_throwsIllegalStateException() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.EXPIRED);
        reservation.setExpiredAt(LocalDateTime.now().minusMinutes(1));

        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.of(reservation));

        // Act / Assert
        assertThatThrownBy(() -> releaseService.releaseReservation(reservationId, "idem-key-1"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("RESERVATION_ALREADY_PROCESSED");

        assertThat(product.getAvailableStock()).isEqualTo(90L);
        assertThat(product.getReservedStock()).isEqualTo(10L);
        verify(productRepository, never()).save(any());
        verify(stockAuditLogRepository, never()).save(any());
    }

    @Test
    void releaseReservation_whenReservationNotFound_throwsEntityNotFoundException() {
        // Arrange
        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.empty());

        // Act / Assert
        assertThatThrownBy(() -> releaseService.releaseReservation(reservationId, "idem-key-1"))
                .isInstanceOf(EntityNotFoundException.class)
                .hasMessageContaining(reservationId.toString());

        verify(productRepository, never()).save(any());
        verify(reservationRepository, never()).save(any());
    }

    @Test
    void releaseReservation_whenLockCannotBeAcquired_rethrowsLockTimeoutException() {
        // Arrange
        when(reservationRepository.findByIdWithLock(reservationId))
                .thenThrow(new LockTimeoutException("row is locked"));

        // Act / Assert
        assertThatThrownBy(() -> releaseService.releaseReservation(reservationId, "idem-key-1"))
                .isInstanceOf(LockTimeoutException.class);

        verify(productRepository, never()).save(any());
        verify(reservationRepository, never()).save(any());
    }

    @Test
    void releaseReservationByOrderId_whenActiveReservationExists_releasesCorrectReservation() {
        // Arrange
        Product product = buildProduct(90L, 10L);
        Reservation reservation = buildReservation(product, 10L, ReservationStatus.ACTIVE);

        when(reservationRepository.findByOrderIdWithLock(orderId)).thenReturn(Optional.of(reservation));
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));

        // Act
        ReleaseResponse response = releaseService.releaseReservationByOrderId(orderId, "idem-key-1");

        // Assert
        assertThat(response.getOrderId()).isEqualTo(orderId);
        assertThat(response.getReservationId()).isEqualTo(reservationId);
        assertThat(response.getStatus()).isEqualTo("RELEASED");
        assertThat(response.isIdempotent()).isFalse();
        assertThat(product.getAvailableStock()).isEqualTo(100L);

        verify(productRepository).save(product);
        verify(reservationRepository).save(reservation);
        verify(stockAuditLogRepository).save(any(StockAuditLog.class));
        verify(reservationHistoryRepository).save(any(ReservationHistory.class));
    }

    // ========== Test Data Builders ==========

    private Product buildProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(productId)
                .sku("SKU-" + productId)
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    private Reservation buildReservation(Product product, long quantity, ReservationStatus status) {
        return Reservation.builder()
                .id(reservationId)
                .orderId(orderId)
                .product(product)
                .quantity(quantity)
                .status(status)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();
    }
}
