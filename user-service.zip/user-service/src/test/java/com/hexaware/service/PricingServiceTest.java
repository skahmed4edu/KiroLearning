package com.hexaware.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link PricingService}.
 */
class PricingServiceTest {

    private PricingService pricingService;

    @BeforeEach
    void setUp() {
        pricingService = new PricingService();
    }

    @Test
    void calculateDiscount_withQuantityOverThreshold_returnsTenPercentOff() {
        // Arrange
        double price = 100.0;
        int quantity = 11;

        // Act
        double result = pricingService.calculateDiscount(price, quantity);

        // Assert
        assertThat(result).isEqualTo(90.0);
    }

    @Test
    void calculateDiscount_withQuantityWellAboveThreshold_returnsTenPercentOff() {
        // Arrange
        double price = 250.0;
        int quantity = 100;

        // Act
        double result = pricingService.calculateDiscount(price, quantity);

        // Assert
        assertThat(result).isEqualTo(225.0);
    }

    @Test
    void calculateDiscount_withQuantityEqualToThreshold_returnsFullPrice() {
        // Arrange
        double price = 100.0;
        int quantity = 10;

        // Act
        double result = pricingService.calculateDiscount(price, quantity);

        // Assert
        assertThat(result).isEqualTo(100.0);
    }

    @Test
    void calculateDiscount_withQuantityBelowThreshold_returnsFullPrice() {
        // Arrange
        double price = 100.0;
        int quantity = 5;

        // Act
        double result = pricingService.calculateDiscount(price, quantity);

        // Assert
        assertThat(result).isEqualTo(100.0);
    }

    @Test
    void calculateDiscount_withZeroQuantity_returnsFullPrice() {
        // Arrange
        double price = 100.0;
        int quantity = 0;

        // Act
        double result = pricingService.calculateDiscount(price, quantity);

        // Assert
        assertThat(result).isEqualTo(100.0);
    }

    @Test
    void calculateDiscount_withZeroPrice_returnsZero() {
        // Arrange
        double price = 0.0;
        int quantity = 20;

        // Act
        double result = pricingService.calculateDiscount(price, quantity);

        // Assert
        assertThat(result).isEqualTo(0.0);
    }
}
