package com.hexaware.service;

import com.hexaware.dto.StockLevelDTO;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit Tests for StockQueryService
 * 
 * **Validates: Requirements 1.1, 1.4**
 * 
 * These tests verify the StockQueryService correctly:
 * - Returns correct stock level calculations for single and multiple products
 * - Handles non-existent products with appropriate exceptions
 * - Meets response time requirements (< 100ms for 99th percentile)
 * - Implements caching correctly
 * - Tracks response time metrics accurately
 * 
 * Test Strategy:
 * - Unit tests with mocked repositories (no database)
 * - Arrange-Act-Assert pattern with clear test naming
 * - Each test focuses on a single scenario
 * - Comprehensive edge case coverage
 */
@ExtendWith(MockitoExtension.class)
class StockQueryServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ReservationRepository reservationRepository;

    private StockQueryService stockQueryService;

    @BeforeEach
    void setUp() {
        stockQueryService = new StockQueryService(productRepository, reservationRepository);
        // Clear cache and metrics before each test
        stockQueryService.clearCache();
        stockQueryService.clearMetrics();
    }

    // ==================== getStockLevel Tests ====================

    /**
     * Test: getStockLevel returns correct calculated values
     * 
     * **Requirement 1.1**: Return product ID, total stock, available stock, reserved stock
     * **Requirement 1.3**: Calculate available stock as totalStock - sum(activeReservations)
     * 
     * Scenario: Product with total stock 100 and 30 units reserved (2 active reservations)
     * Expected: available = 70, reserved = 30, activeReservations count = 2
     */
    @Test
    void getStockLevel_withValidProduct_returnsCorrectCalculatedValues() {
        // Arrange
        UUID productId = UUID.randomUUID();
        Product product = Product.builder()
                .id(productId)
                .sku("PROD-001")
                .name("Test Product")
                .totalStock(100L)
                .reservedStock(30L)
                .availableStock(70L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        List<Reservation> activeReservations = List.of(
                createReservation(20),
                createReservation(10)
        );

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(activeReservations);

        // Act
        StockLevelDTO result = stockQueryService.getStockLevel(productId);

        // Assert
        assertThat(result)
                .isNotNull()
                .satisfies(dto -> {
                    assertThat(dto.getProductId()).isEqualTo(productId);
                    assertThat(dto.getSku()).isEqualTo("PROD-001");
                    assertThat(dto.getName()).isEqualTo("Test Product");
                    assertThat(dto.getTotalStock()).isEqualTo(100L);
                    assertThat(dto.getAvailableStock()).isEqualTo(70L);
                    assertThat(dto.getReservedStock()).isEqualTo(30L);
                    assertThat(dto.getActiveReservations()).isEqualTo(2L);
                    assertThat(dto.getInvariantValid()).isTrue();
                });

        verify(productRepository).findById(productId);
        verify(reservationRepository).findActiveReservationsByProductId(productId);
    }

    /**
     * Test: getStockLevel with no active reservations
     * 
     * Scenario: Product with total stock 100 and no reservations
     * Expected: available = 100, reserved = 0, activeReservations count = 0
     */
    @Test
    void getStockLevel_withNoActiveReservations_returnsFullAvailableStock() {
        // Arrange
        UUID productId = UUID.randomUUID();
        Product product = Product.builder()
                .id(productId)
                .sku("PROD-002")
                .name("Available Product")
                .totalStock(100L)
                .reservedStock(0L)
                .availableStock(100L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(Collections.emptyList());

        // Act
        StockLevelDTO result = stockQueryService.getStockLevel(productId);

        // Assert
        assertThat(result.getAvailableStock()).isEqualTo(100L);
        assertThat(result.getReservedStock()).isEqualTo(0L);
        assertThat(result.getActiveReservations()).isEqualTo(0L);
        assertThat(result.getInvariantValid()).isTrue();
    }

    /**
     * Test: getStockLevel with all stock reserved
     * 
     * Scenario: Product with total stock 50 and all 50 units reserved
     * Expected: available = 0, reserved = 50, activeReservations = all reserved
     */
    @Test
    void getStockLevel_withAllStockReserved_returnsZeroAvailable() {
        // Arrange
        UUID productId = UUID.randomUUID();
        Product product = Product.builder()
                .id(productId)
                .sku("PROD-003")
                .name("Sold Out")
                .totalStock(50L)
                .reservedStock(50L)
                .availableStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        List<Reservation> activeReservations = List.of(
                createReservation(25),
                createReservation(25)
        );

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(activeReservations);

        // Act
        StockLevelDTO result = stockQueryService.getStockLevel(productId);

        // Assert
        assertThat(result.getAvailableStock()).isEqualTo(0L);
        assertThat(result.getReservedStock()).isEqualTo(50L);
        assertThat(result.getActiveReservations()).isEqualTo(2L);
        assertThat(result.getInvariantValid()).isTrue();
    }

    /**
     * Test: getStockLevel with non-existent product raises exception
     * 
     * Scenario: Query for product ID that doesn't exist
     * Expected: EntityNotFoundException thrown
     */
    @Test
    void getStockLevel_withNonExistentProduct_throwsEntityNotFoundException() {
        // Arrange
        UUID productId = UUID.randomUUID();
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> stockQueryService.getStockLevel(productId))
                .isInstanceOf(EntityNotFoundException.class)
                .hasMessageContaining("Product not found");

        verify(productRepository).findById(productId);
        verify(reservationRepository, never()).findActiveReservationsByProductId(any());
    }

    /**
     * Test: getStockLevel serves a repeated query from the cache
     *
     * Scenario: Query the same product twice while the cache entry is valid.
     * The product's updatedAt is pinned to a fixed time in the past so the
     * cache-validity check is deterministic and not dependent on where the two
     * calls fall relative to the wall-clock second boundary.
     *
     * Expected: The expensive reservation lookup runs only on the first call;
     * the second call is served from the cache and returns an equal DTO.
     */
    @Test
    void getStockLevel_withValidCacheEntry_servesSecondCallFromCache() {
        // Arrange
        UUID productId = UUID.randomUUID();
        // Pin updatedAt well in the past so productUpdatedAt.isBefore(cachedAt)
        // is reliably true regardless of test execution timing.
        LocalDateTime pastUpdatedAt = LocalDateTime.now().minusDays(1);
        Product product = Product.builder()
                .id(productId)
                .sku("PROD-CACHE")
                .name("Cached Product")
                .totalStock(100L)
                .reservedStock(30L)
                .availableStock(70L)
                .lockVersion(0L)
                .createdAt(pastUpdatedAt)
                .updatedAt(pastUpdatedAt)
                .build();

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(createReservation(30)));

        // Act
        StockLevelDTO first = stockQueryService.getStockLevel(productId);
        StockLevelDTO second = stockQueryService.getStockLevel(productId);

        // Assert
        assertThat(first).isEqualTo(second);
        assertThat(second.getAvailableStock()).isEqualTo(70L);
        // The expensive reservation query runs exactly once; the second call is
        // served from the cache. This assertion is independent of wall-clock timing.
        verify(reservationRepository, times(1)).findActiveReservationsByProductId(productId);
    }

    /**
     * Test: getStockLevel re-queries after the cache is cleared
     *
     * Scenario: Query a product (populating the cache), clear the cache, then
     * query again. This proves the earlier repeat call was genuinely served
     * from the cache rather than always hitting the database.
     *
     * Expected: Clearing the cache forces a fresh reservation lookup, so the
     * expensive query runs once per populated-cache cycle (twice total).
     */
    @Test
    void getStockLevel_whenCacheCleared_requeriesReservations() {
        // Arrange
        UUID productId = UUID.randomUUID();
        LocalDateTime pastUpdatedAt = LocalDateTime.now().minusDays(1);
        Product product = Product.builder()
                .id(productId)
                .sku("PROD-CACHE-CLEAR")
                .name("Cache Clear Product")
                .totalStock(100L)
                .reservedStock(30L)
                .availableStock(70L)
                .lockVersion(0L)
                .createdAt(pastUpdatedAt)
                .updatedAt(pastUpdatedAt)
                .build();

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(createReservation(30)));

        // Act
        stockQueryService.getStockLevel(productId); // populates cache (query 1)
        stockQueryService.getStockLevel(productId); // served from cache
        stockQueryService.clearCache();
        stockQueryService.getStockLevel(productId); // cache empty, re-queries (query 2)

        // Assert
        verify(reservationRepository, times(2)).findActiveReservationsByProductId(productId);
    }

    /**
     * Test: getStockLevel response time under 100ms
     * 
     * **Requirement 1.4**: Response time < 100ms for 99th percentile
     * 
     * Scenario: Measure response time for a normal query
     * Expected: Response time < 100ms
     */
    @Test
    void getStockLevel_respondTime_underOneHundredMilliseconds() {
        // Arrange
        UUID productId = UUID.randomUUID();
        Product product = Product.builder()
                .id(productId)
                .sku("PROD-PERF")
                .name("Performance Test")
                .totalStock(100L)
                .reservedStock(30L)
                .availableStock(70L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(createReservation(30)));

        // Act
        long startTime = System.currentTimeMillis();
        StockLevelDTO result = stockQueryService.getStockLevel(productId);
        long endTime = System.currentTimeMillis();
        long responseTime = endTime - startTime;

        // Assert
        assertThat(result).isNotNull();
        assertThat(responseTime)
                .as("Response time should be under 100ms for normal query")
                .isLessThan(100L);
    }

    // ==================== getStockLevels (Batch) Tests ====================

    /**
     * Test: getStockLevels returns accurate values for multiple products
     * 
     * **Requirement 1.5**: Support batch queries for multiple products
     * 
     * Scenario: Query stock levels for 3 products
     * Expected: All 3 products returned with correct calculations
     */
    @Test
    void getStockLevels_withMultipleProducts_returnsAccurateValuesForAll() {
        // Arrange
        UUID product1Id = UUID.randomUUID();
        UUID product2Id = UUID.randomUUID();
        UUID product3Id = UUID.randomUUID();

        Product product1 = createProductWithStock(product1Id, "PROD-1", 100, 30);
        Product product2 = createProductWithStock(product2Id, "PROD-2", 50, 10);
        Product product3 = createProductWithStock(product3Id, "PROD-3", 200, 80);

        when(productRepository.findByIdSet(Set.of(product1Id, product2Id, product3Id)))
                .thenReturn(List.of(product1, product2, product3));

        when(reservationRepository.findActiveReservationsByProductId(product1Id))
                .thenReturn(List.of(createReservation(30)));
        when(reservationRepository.findActiveReservationsByProductId(product2Id))
                .thenReturn(List.of(createReservation(10)));
        when(reservationRepository.findActiveReservationsByProductId(product3Id))
                .thenReturn(List.of(createReservation(40), createReservation(40)));
        
        when(reservationRepository.countActiveByProductId(product1Id)).thenReturn(1L);
        when(reservationRepository.countActiveByProductId(product2Id)).thenReturn(1L);
        when(reservationRepository.countActiveByProductId(product3Id)).thenReturn(2L);

        // Act
        List<StockLevelDTO> results = stockQueryService.getStockLevels(
                List.of(product1Id, product2Id, product3Id)
        );

        // Assert
        assertThat(results).hasSize(3);
        
        StockLevelDTO dto1 = results.stream()
                .filter(dto -> dto.getSku().equals("PROD-1"))
                .findFirst()
                .orElseThrow();
        assertThat(dto1.getTotalStock()).isEqualTo(100L);
        assertThat(dto1.getAvailableStock()).isEqualTo(70L);
        assertThat(dto1.getReservedStock()).isEqualTo(30L);

        StockLevelDTO dto2 = results.stream()
                .filter(dto -> dto.getSku().equals("PROD-2"))
                .findFirst()
                .orElseThrow();
        assertThat(dto2.getTotalStock()).isEqualTo(50L);
        assertThat(dto2.getAvailableStock()).isEqualTo(40L);
        assertThat(dto2.getReservedStock()).isEqualTo(10L);

        StockLevelDTO dto3 = results.stream()
                .filter(dto -> dto.getSku().equals("PROD-3"))
                .findFirst()
                .orElseThrow();
        assertThat(dto3.getTotalStock()).isEqualTo(200L);
        assertThat(dto3.getAvailableStock()).isEqualTo(120L);
        assertThat(dto3.getReservedStock()).isEqualTo(80L);
    }

    /**
     * Test: getStockLevels with empty product list
     * 
     * Scenario: Query with empty list of product IDs
     * Expected: Empty list returned
     */
    @Test
    void getStockLevels_withEmptyProductList_returnsEmptyList() {
        // Act
        List<StockLevelDTO> results = stockQueryService.getStockLevels(Collections.emptyList());

        // Assert
        assertThat(results).isEmpty();
        verify(productRepository, never()).findByIdSet(any());
    }

    /**
     * Test: getStockLevels with null product list
     * 
     * Scenario: Query with null list
     * Expected: Empty list returned (safe handling)
     */
    @Test
    void getStockLevels_withNullProductList_returnsEmptyList() {
        // Act
        List<StockLevelDTO> results = stockQueryService.getStockLevels(null);

        // Assert
        assertThat(results).isEmpty();
    }

    /**
     * Test: getStockLevels excludes non-existent products
     * 
     * Scenario: Query for 3 products, but only 2 exist in database
     * Expected: Only 2 products returned
     */
    @Test
    void getStockLevels_withSomeNonExistentProducts_returnsOnlyExisting() {
        // Arrange
        UUID product1Id = UUID.randomUUID();
        UUID product2Id = UUID.randomUUID();
        UUID product3Id = UUID.randomUUID();  // This one doesn't exist

        Product product1 = createProductWithStock(product1Id, "PROD-1", 100, 30);
        Product product2 = createProductWithStock(product2Id, "PROD-2", 50, 10);

        when(productRepository.findByIdSet(Set.of(product1Id, product2Id, product3Id)))
                .thenReturn(List.of(product1, product2));  // Only 2 exist

        when(reservationRepository.findActiveReservationsByProductId(product1Id))
                .thenReturn(List.of(createReservation(30)));
        when(reservationRepository.findActiveReservationsByProductId(product2Id))
                .thenReturn(List.of(createReservation(10)));
        
        when(reservationRepository.countActiveByProductId(product1Id)).thenReturn(1L);
        when(reservationRepository.countActiveByProductId(product2Id)).thenReturn(1L);

        // Act
        List<StockLevelDTO> results = stockQueryService.getStockLevels(
                List.of(product1Id, product2Id, product3Id)
        );

        // Assert
        assertThat(results).hasSize(2);
        assertThat(results).allSatisfy(dto -> 
                assertThat(dto.getSku()).isIn("PROD-1", "PROD-2")
        );
    }

    /**
     * Test: getStockLevels response time under 100ms for 99th percentile
     * 
     * Scenario: Batch query for 10 products
     * Expected: Total response time < 100ms
     */
    @Test
    void getStockLevels_responseTime_under100MillisecondsFor10Products() {
        // Arrange
        List<UUID> productIds = new ArrayList<>();
        List<Product> products = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            UUID productId = UUID.randomUUID();
            productIds.add(productId);
            products.add(createProductWithStock(productId, "PROD-" + i, 100, 30));

            when(reservationRepository.findActiveReservationsByProductId(productId))
                    .thenReturn(List.of(createReservation(30)));
            when(reservationRepository.countActiveByProductId(productId)).thenReturn(1L);
        }

        when(productRepository.findByIdSet(new HashSet<>(productIds)))
                .thenReturn(products);

        // Act
        long startTime = System.currentTimeMillis();
        List<StockLevelDTO> results = stockQueryService.getStockLevels(productIds);
        long endTime = System.currentTimeMillis();
        long responseTime = endTime - startTime;

        // Assert
        assertThat(results).hasSize(10);
        assertThat(responseTime)
                .as("Response time for 10 products should be under 100ms")
                .isLessThan(100L);
    }

    // ==================== Metrics Tests ====================

    /**
     * Test: Response time metrics are tracked accurately
     * 
     * **Requirement 8.5**: Track P50, P95, P99 percentiles
     * 
     * Scenario: Execute multiple queries and check metrics
     * Expected: Metrics contain p50, p95, p99 values
     */
    @Test
    void getResponseTimeMetrics_tracksPercentiles() {
        // Arrange
        UUID productId = UUID.randomUUID();
        Product product = createProductWithStock(productId, "PROD-METRIC", 100, 30);

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(createReservation(30)));

        // Act - Execute multiple queries to populate metrics
        for (int i = 0; i < 10; i++) {
            stockQueryService.getStockLevel(productId);
        }

        Map<String, Long> metrics = stockQueryService.getResponseTimeMetrics();

        // Assert
        assertThat(metrics).containsKeys("p50", "p95", "p99");
        assertThat(metrics.get("p50")).isGreaterThanOrEqualTo(0);
        assertThat(metrics.get("p95")).isGreaterThanOrEqualTo(0);
        assertThat(metrics.get("p99")).isGreaterThanOrEqualTo(0);
        assertThat(metrics.get("p50")).isLessThanOrEqualTo(metrics.get("p95"));
        assertThat(metrics.get("p95")).isLessThanOrEqualTo(metrics.get("p99"));
    }

    /**
     * Test: Metrics can be cleared
     * 
     * Scenario: Record metrics, clear them, verify they're reset
     * Expected: Metrics become zero after clear
     */
    @Test
    void clearMetrics_resetsResponseTimeMetrics() {
        // Arrange
        UUID productId = UUID.randomUUID();
        Product product = createProductWithStock(productId, "PROD-CLEAR", 100, 30);

        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(createReservation(30)));

        // Record some metrics
        stockQueryService.getStockLevel(productId);

        // Act
        stockQueryService.clearMetrics();
        Map<String, Long> metrics = stockQueryService.getResponseTimeMetrics();

        // Assert
        assertThat(metrics.get("p50")).isEqualTo(0L);
        assertThat(metrics.get("p95")).isEqualTo(0L);
        assertThat(metrics.get("p99")).isEqualTo(0L);
    }

    // ==================== Helper Methods ====================

    private Product createProductWithStock(UUID id, String sku, long total, long reserved) {
        return Product.builder()
                .id(id)
                .sku(sku)
                .name("Test Product")
                .totalStock(total)
                .reservedStock(reserved)
                .availableStock(total - reserved)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    private Reservation createReservation(long quantity) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();
    }
}
