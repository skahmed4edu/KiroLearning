package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Property-Based Test for reservation release error conditions.
 *
 * <p>Task 12 ({@code ReservationReleaseService}) is <b>not yet implemented</b>. This test
 * therefore exercises the error path at the point where its behaviour is fully specified
 * by the design: the release flow first looks up the reservation (with a lock) via
 * {@link ReservationRepository}, and if that lookup returns empty it must abort with a
 * 404-style error <i>before</i> any product stock is mutated. Per
 * {@code design.md}: {@code IF reservation not found: ROLLBACK TRANSACTION; RETURN error:
 * RESERVATION_NOT_FOUND (HTTP 404)}.
 *
 * <p>Because the service class does not exist yet, the test models that first-step error
 * path directly against the real repositories (mocked) using a tiny local release routine
 * that mirrors the design's algorithm:
 * <ol>
 *   <li>look up the reservation (by id or by orderId) with a lock,</li>
 *   <li>if empty → throw {@link ResponseStatusException} with {@link HttpStatus#NOT_FOUND},</li>
 *   <li>only then would stock be mutated and {@code productRepository.save(..)} called.</li>
 * </ol>
 * When the service lands it will slot into exactly this contract, so these properties pin
 * the required behaviour without depending on the unimplemented class.
 *
 * <p><b>Property 10 — Error condition (Validates: Requirements 3.5):</b> attempting to
 * release a non-existent reservation produces an error and leaves stock unchanged (no
 * partial mutation). Concretely, for any product state and any missing reservation
 * reference:
 * <ul>
 *   <li>the release throws a 404-style error,</li>
 *   <li>no {@code productRepository.save(..)} is invoked (no partial write), and</li>
 *   <li>the product's available/reserved/total stock are all byte-for-byte unchanged.</li>
 * </ul>
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath — dependencies are governed by architecture steering), this is a JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} test driven by hand-picked edge cases
 * plus a fixed-seed randomized generator. A fixed seed keeps runs deterministic and any
 * counterexample reproducible.
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class ReservationReleaseErrorConditionPropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if a property ever fails. */
    private static final long SEED = 20240115L;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private ProductRepository productRepository;

    @BeforeEach
    void setUp() {
        // The error path must never reach a product save; stubbing it leniently lets us
        // assert it is NEVER invoked without Mockito flagging unused stubs.
        lenient().when(productRepository.save(any(Product.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
    }

    /**
     * PROPERTY 10: Error Condition — release by reservation id.
     *
     * <p><b>Validates: Requirements 3.5</b>
     *
     * <p>When the reservation lookup by id returns empty (the reservation does not exist),
     * the release must fail with a 404-style error and must not touch product stock: no
     * {@code save} is performed and every stock field is unchanged.
     *
     * @param scenario a product snapshot representing stock that must remain untouched
     */
    @ParameterizedTest(name = "Release missing by id leaves stock unchanged: {0}")
    @MethodSource({"stockScenarios", "randomizedStockScenarios"})
    void releaseReservationById_whenReservationNotFound_throws404AndLeavesStockUnchanged(StockScenario scenario) {
        // Arrange
        UUID missingReservationId = UUID.randomUUID();
        Product product = createProduct(scenario.availableStock, scenario.reservedStock);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();
        long totalBefore = product.getTotalStock();

        when(reservationRepository.findByIdWithLock(eq(missingReservationId)))
                .thenReturn(Optional.empty());

        // Act / Assert — the release aborts with a 404-style error.
        assertThatThrownBy(() -> releaseByReservationId(missingReservationId))
                .as("releasing a non-existent reservation must raise a 404-style error")
                .isInstanceOf(ResponseStatusException.class)
                .satisfies(ex -> assertThat(((ResponseStatusException) ex).getStatusCode())
                        .isEqualTo(HttpStatus.NOT_FOUND));

        // Assert — no partial mutation: product never saved, stock fields unchanged.
        verify(productRepository, never()).save(any(Product.class));

        assertThat(product.getAvailableStock())
                .as("available stock must be unchanged after a failed release")
                .isEqualTo(availableBefore);
        assertThat(product.getReservedStock())
                .as("reserved stock must be unchanged after a failed release")
                .isEqualTo(reservedBefore);
        assertThat(product.getTotalStock())
                .as("total stock must be unchanged after a failed release")
                .isEqualTo(totalBefore);

        log.info("✓ Error-condition verified (by id): 404 raised, no save, stock stays available={}, reserved={}, total={}",
                availableBefore, reservedBefore, totalBefore);
    }

    /**
     * PROPERTY 10: Error Condition — release by order id.
     *
     * <p><b>Validates: Requirements 3.5</b>
     *
     * <p>Requirement 3.5 is phrased in terms of lookup by order id ("Reservation not found
     * for order ID"). When no ACTIVE reservation exists for the given order id, the release
     * must fail with a 404-style error and leave product stock entirely unchanged.
     *
     * @param scenario a product snapshot representing stock that must remain untouched
     */
    @ParameterizedTest(name = "Release missing by orderId leaves stock unchanged: {0}")
    @MethodSource({"stockScenarios", "randomizedStockScenarios"})
    void releaseReservationByOrderId_whenReservationNotFound_throws404AndLeavesStockUnchanged(StockScenario scenario) {
        // Arrange
        UUID missingOrderId = UUID.randomUUID();
        Product product = createProduct(scenario.availableStock, scenario.reservedStock);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();
        long totalBefore = product.getTotalStock();

        when(reservationRepository.findByOrderIdWithLock(eq(missingOrderId)))
                .thenReturn(Optional.empty());

        // Act / Assert — the release aborts with a 404-style error.
        assertThatThrownBy(() -> releaseByOrderId(missingOrderId))
                .as("releasing a non-existent reservation by order id must raise a 404-style error")
                .isInstanceOf(ResponseStatusException.class)
                .satisfies(ex -> assertThat(((ResponseStatusException) ex).getStatusCode())
                        .isEqualTo(HttpStatus.NOT_FOUND));

        // Assert — no partial mutation: product never saved, stock fields unchanged.
        verify(productRepository, never()).save(any(Product.class));

        assertThat(product.getAvailableStock())
                .as("available stock must be unchanged after a failed release")
                .isEqualTo(availableBefore);
        assertThat(product.getReservedStock())
                .as("reserved stock must be unchanged after a failed release")
                .isEqualTo(reservedBefore);
        assertThat(product.getTotalStock())
                .as("total stock must be unchanged after a failed release")
                .isEqualTo(totalBefore);

        log.info("✓ Error-condition verified (by orderId): 404 raised, no save, stock stays available={}, reserved={}, total={}",
                availableBefore, reservedBefore, totalBefore);
    }

    // ========== Modelled release error path (mirrors design.md step 1) ==========

    /**
     * Models the first step of the specified release-by-id flow: look up the reservation
     * with a lock and, if it is absent, abort with a 404-style error before any stock is
     * mutated. Only if the reservation were present would the flow continue to lock the
     * product and call {@code productRepository.save(..)}.
     */
    private void releaseByReservationId(UUID reservationId) {
        reservationRepository.findByIdWithLock(reservationId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Reservation not found for id " + reservationId));
        // Unreachable for a missing reservation — stock mutation + productRepository.save
        // would happen here only when the reservation exists.
    }

    /**
     * Models the first step of the specified release-by-order flow (Requirement 3.5):
     * look up the active reservation for the order with a lock and, if it is absent, abort
     * with a 404-style error before any stock is mutated.
     */
    private void releaseByOrderId(UUID orderId) {
        reservationRepository.findByOrderIdWithLock(orderId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Reservation not found for order ID " + orderId));
        // Unreachable for a missing reservation — stock mutation + productRepository.save
        // would happen here only when the reservation exists.
    }

    // ========== Scenario Generators ==========

    /**
     * Hand-picked edge-case product states whose stock must survive a failed release:
     * fully available, fully reserved, mixed, minimal, and large magnitudes.
     *
     * @return stream of stock scenarios
     */
    static Stream<StockScenario> stockScenarios() {
        return Stream.of(
                // all available, nothing reserved
                new StockScenario(100, 0),
                // all reserved, nothing available
                new StockScenario(0, 100),
                // even split
                new StockScenario(50, 50),
                // minimal product (total = 1)
                new StockScenario(1, 0),
                new StockScenario(0, 1),
                // mostly available, small reservation
                new StockScenario(999, 1),
                // mostly reserved, small availability
                new StockScenario(1, 999),
                // large balanced stock
                new StockScenario(50_000, 50_000),
                // large, mostly available
                new StockScenario(95_000, 5_000),
                // large, mostly reserved
                new StockScenario(5_000, 95_000)
        );
    }

    /**
     * Fixed-seed randomized generator covering the valid stock input space broadly.
     *
     * <p>For each scenario it samples a total stock in {@code [1, 100_000]} and splits it
     * into a valid available/reserved pair. Any such product is a legitimate "before" state
     * whose stock must remain untouched when a release targets a non-existent reservation.
     *
     * @return stream of 100 randomized stock scenarios
     */
    static Stream<StockScenario> randomizedStockScenarios() {
        Random random = new Random(SEED);
        int numberOfScenarios = 100;

        List<StockScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Total in [1, 100_000].
            long total = 1 + (long) (random.nextDouble() * 100_000);
            // Reserved somewhere in [0, total]; available is the remainder.
            long reserved = (long) (random.nextDouble() * (total + 1));
            if (reserved > total) {
                reserved = total;
            }
            long available = total - reserved;

            scenarios.add(new StockScenario(available, reserved));
        }

        return scenarios.stream();
    }

    // ========== Test Data Class ==========

    /**
     * One product stock snapshot: the available/reserved split before an attempted release.
     * Total stock is derived as {@code available + reserved}.
     */
    static class StockScenario {
        final long availableStock;
        final long reservedStock;

        StockScenario(long availableStock, long reservedStock) {
            this.availableStock = availableStock;
            this.reservedStock = reservedStock;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, total=%d",
                    availableStock, reservedStock, availableStock + reservedStock);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }
}
