package com.hexaware.service;

import com.hexaware.dto.OrderResponse;
import com.hexaware.dto.PlaceOrderRequest;
import com.hexaware.entity.Order;
import com.hexaware.entity.User;
import com.hexaware.repository.OrderRepository;
import com.hexaware.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * Unit tests for OrderService
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("OrderService Unit Tests")
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private OrderService orderService;

    private User testUser;
    private Order testOrder;
    private PlaceOrderRequest placeOrderRequest;
    private LocalDateTime now;
    private UUID userId;
    private UUID orderId;

    @BeforeEach
    void setUp() {
        now = LocalDateTime.now();
        userId = UUID.randomUUID();
        orderId = UUID.randomUUID();

        // Create test user
        testUser = User.builder()
                .id(userId)
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .password("encodedPassword")
                .createdAt(now)
                .updatedAt(now)
                .build();

        // Create test order
        testOrder = Order.builder()
                .id(orderId)
                .orderNumber("ORD-001")
                .user(testUser)
                .totalAmount(new BigDecimal("199.99"))
                .status(Order.OrderStatus.PENDING)
                .paymentStatus(Order.PaymentStatus.UNPAID)
                .paymentMethod("CREDIT_CARD")
                .shippingAddress("123 Main St, City, State 12345")
                .description("Test order description")
                .createdAt(now)
                .updatedAt(now)
                .paidAt(null)
                .build();

        // Create place order request
        placeOrderRequest = PlaceOrderRequest.builder()
                .userId(userId)
                .orderNumber("ORD-001")
                .totalAmount(new BigDecimal("199.99"))
                .paymentMethod("CREDIT_CARD")
                .shippingAddress("123 Main St, City, State 12345")
                .description("Test order description")
                .build();
    }

    // ==================== placeOrder Tests ====================

    @Test
    @DisplayName("placeOrder_withValidRequest_returnsOrderResponse")
    void placeOrder_withValidRequest_returnsOrderResponse() {
        // Arrange
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(orderRepository.existsByOrderNumber("ORD-001")).thenReturn(false);
        when(orderRepository.save(any(Order.class))).thenReturn(testOrder);

        // Act
        OrderResponse response = orderService.placeOrder(placeOrderRequest);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(orderId);
        assertThat(response.getOrderNumber()).isEqualTo("ORD-001");
        assertThat(response.getUserId()).isEqualTo(userId);
        assertThat(response.getTotalAmount()).isEqualByComparingTo(new BigDecimal("199.99"));
        assertThat(response.getStatus()).isEqualTo("PENDING");
        assertThat(response.getPaymentStatus()).isEqualTo("UNPAID");
        verify(userRepository).findById(userId);
        verify(orderRepository).existsByOrderNumber("ORD-001");
        verify(orderRepository).save(any(Order.class));
    }

    @Test
    @DisplayName("placeOrder_withUserNotFound_throwsIllegalArgumentException")
    void placeOrder_withUserNotFound_throwsIllegalArgumentException() {
        // Arrange
        UUID invalidUserId = UUID.randomUUID();
        when(userRepository.findById(invalidUserId)).thenReturn(Optional.empty());

        PlaceOrderRequest invalidRequest = PlaceOrderRequest.builder()
                .userId(invalidUserId)
                .orderNumber("ORD-002")
                .totalAmount(new BigDecimal("199.99"))
                .build();

        // Act & Assert
        assertThatThrownBy(() -> orderService.placeOrder(invalidRequest))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("User not found with id: " + invalidUserId);

        verify(userRepository).findById(invalidUserId);
        verify(orderRepository, never()).save(any(Order.class));
    }

    @Test
    @DisplayName("placeOrder_withDuplicateOrderNumber_throwsIllegalArgumentException")
    void placeOrder_withDuplicateOrderNumber_throwsIllegalArgumentException() {
        // Arrange
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(orderRepository.existsByOrderNumber("ORD-001")).thenReturn(true);

        // Act & Assert
        assertThatThrownBy(() -> orderService.placeOrder(placeOrderRequest))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Order number already exists: ORD-001");

        verify(userRepository).findById(userId);
        verify(orderRepository).existsByOrderNumber("ORD-001");
        verify(orderRepository, never()).save(any(Order.class));
    }

    @Test
    @DisplayName("placeOrder_withValidRequest_setsDefaultStatuses")
    void placeOrder_withValidRequest_setsDefaultStatuses() {
        // Arrange
        UUID newOrderId = UUID.randomUUID();
        Order orderWithDefaults = Order.builder()
                .id(newOrderId)
                .orderNumber("ORD-002")
                .user(testUser)
                .totalAmount(new BigDecimal("299.99"))
                .status(Order.OrderStatus.PENDING)
                .paymentStatus(Order.PaymentStatus.UNPAID)
                .createdAt(now)
                .updatedAt(now)
                .build();

        PlaceOrderRequest request = PlaceOrderRequest.builder()
                .userId(userId)
                .orderNumber("ORD-002")
                .totalAmount(new BigDecimal("299.99"))
                .build();

        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(orderRepository.existsByOrderNumber("ORD-002")).thenReturn(false);
        when(orderRepository.save(any(Order.class))).thenReturn(orderWithDefaults);

        // Act
        OrderResponse response = orderService.placeOrder(request);

        // Assert
        assertThat(response.getStatus()).isEqualTo("PENDING");
        assertThat(response.getPaymentStatus()).isEqualTo("UNPAID");
    }

    // ==================== getOrderById Tests ====================

    @Test
    @DisplayName("getOrderById_withValidOrderId_returnsOrderResponse")
    void getOrderById_withValidOrderId_returnsOrderResponse() {
        // Arrange
        when(orderRepository.findById(orderId)).thenReturn(Optional.of(testOrder));

        // Act
        OrderResponse response = orderService.getOrderById(orderId);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(orderId);
        assertThat(response.getOrderNumber()).isEqualTo("ORD-001");
        assertThat(response.getUserId()).isEqualTo(userId);
        assertThat(response.getTotalAmount()).isEqualByComparingTo(new BigDecimal("199.99"));
        verify(orderRepository).findById(orderId);
    }

    @Test
    @DisplayName("getOrderById_withOrderNotFound_throwsIllegalArgumentException")
    void getOrderById_withOrderNotFound_throwsIllegalArgumentException() {
        // Arrange
        UUID invalidOrderId = UUID.randomUUID();
        when(orderRepository.findById(invalidOrderId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> orderService.getOrderById(invalidOrderId))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Order not found with id: " + invalidOrderId);

        verify(orderRepository).findById(invalidOrderId);
    }

    @Test
    @DisplayName("getOrderById_withValidOrderId_mapsAllFields")
    void getOrderById_withValidOrderId_mapsAllFields() {
        // Arrange
        Order orderWithAllFields = Order.builder()
                .id(orderId)
                .orderNumber("ORD-001")
                .user(testUser)
                .totalAmount(new BigDecimal("199.99"))
                .status(Order.OrderStatus.SHIPPED)
                .paymentStatus(Order.PaymentStatus.PAID)
                .paymentMethod("DEBIT_CARD")
                .shippingAddress("456 Oak Ave, Town, State 54321")
                .description("Complete order")
                .createdAt(now)
                .updatedAt(now)
                .paidAt(now)
                .build();

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(orderWithAllFields));

        // Act
        OrderResponse response = orderService.getOrderById(orderId);

        // Assert
        assertThat(response.getStatus()).isEqualTo("SHIPPED");
        assertThat(response.getPaymentStatus()).isEqualTo("PAID");
        assertThat(response.getPaymentMethod()).isEqualTo("DEBIT_CARD");
        assertThat(response.getShippingAddress()).isEqualTo("456 Oak Ave, Town, State 54321");
        assertThat(response.getDescription()).isEqualTo("Complete order");
        assertThat(response.getPaidAt()).isNotNull();
    }

    // ==================== getOrderByOrderNumber Tests ====================

    @Test
    @DisplayName("getOrderByOrderNumber_withValidOrderNumber_returnsOrderResponse")
    void getOrderByOrderNumber_withValidOrderNumber_returnsOrderResponse() {
        // Arrange
        when(orderRepository.findByOrderNumber("ORD-001")).thenReturn(Optional.of(testOrder));

        // Act
        OrderResponse response = orderService.getOrderByOrderNumber("ORD-001");

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getOrderNumber()).isEqualTo("ORD-001");
        assertThat(response.getId()).isEqualTo(orderId);
        verify(orderRepository).findByOrderNumber("ORD-001");
    }

    @Test
    @DisplayName("getOrderByOrderNumber_withOrderNotFound_throwsIllegalArgumentException")
    void getOrderByOrderNumber_withOrderNotFound_throwsIllegalArgumentException() {
        // Arrange
        when(orderRepository.findByOrderNumber("INVALID")).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> orderService.getOrderByOrderNumber("INVALID"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Order not found with orderNumber: INVALID");

        verify(orderRepository).findByOrderNumber("INVALID");
    }

    // ==================== deleteOrderById Tests ====================

    @Test
    @DisplayName("deleteOrderById_withValidOrderId_deletesSuccessfully")
    void deleteOrderById_withValidOrderId_deletesSuccessfully() {
        // Arrange
        when(orderRepository.findById(orderId)).thenReturn(Optional.of(testOrder));

        // Act
        orderService.deleteOrderById(orderId);

        // Assert
        verify(orderRepository).findById(orderId);
        verify(orderRepository).delete(testOrder);
    }

    @Test
    @DisplayName("deleteOrderById_withOrderNotFound_throwsIllegalArgumentException")
    void deleteOrderById_withOrderNotFound_throwsIllegalArgumentException() {
        // Arrange
        UUID invalidOrderId = UUID.randomUUID();
        when(orderRepository.findById(invalidOrderId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> orderService.deleteOrderById(invalidOrderId))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Order not found with id: " + invalidOrderId);

        verify(orderRepository).findById(invalidOrderId);
        verify(orderRepository, never()).delete(any(Order.class));
    }

    @Test
    @DisplayName("deleteOrderById_withValidOrderId_doesNotInvokeDeleteIfNotFound")
    void deleteOrderById_withValidOrderId_doesNotInvokeDeleteIfNotFound() {
        // Arrange
        UUID invalidOrderId = UUID.randomUUID();
        when(orderRepository.findById(invalidOrderId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> orderService.deleteOrderById(invalidOrderId))
                .isInstanceOf(IllegalArgumentException.class);

        verify(orderRepository, never()).delete(any(Order.class));
    }
}
