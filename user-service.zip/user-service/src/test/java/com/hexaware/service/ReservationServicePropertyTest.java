package com.hexaware.service;

import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Property-Based Tests for ReservationService
 * 
 * These tests verify fundamental invariants of the reservation system:
 * - Stock decrement invariant: availableStock decreases by exactly the reserved quantity
 * - Metamorphic property: Sequential reservations produce consistent stock levels
 * - Error idempotence: Failed reservations don't change stock
 * 
 * **Validates: Requirements 2.2, 2.3, 2.4**
 * 
 * Property-based testing generates multiple scenarios to ensure the invariants hold
 * across a wide range of inputs and edge cases.
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class ReservationServicePropertyTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private StockAuditLogRepository stockAuditLogRepository;

    private ReservationService reservationService;

    @BeforeEach
    void setUp() {
        reservationService = new ReservationService(productRepository, reservationRepository, stockAuditLogRepository);
        
        // Set configuration values via reflection
        try {
            var field = ReservationService.class.getDeclaredField("reservationTtlMinutes");
            field.setAccessible(true);
            field.set(reservationService, 15);
            
            field = ReservationService.class.getDeclaredField("maxRetries");
            field.setAccessible(true);
            field.set(reservationService, 3);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException("Failed to set test configuration", e);
        }
    }

    /**
     * PROPERTY 4: Stock Decrement Invariant
     * 
     * **Validates: Requirements 2.3, 2.4**
     * 
     * When a reservation is created, the available stock must decrease by exactly
     * the reserved quantity:
     * 
     *   availableStock_after = availableStock_before - reservedQuantity
     * 
     * This is the fundamental invariant ensuring stock is properly reserved.
     * The test verifies this holds for all quantity and stock combinations.
     * 
     * @param scenario Test scenario with specific stock and quantity levels
     */
    @ParameterizedTest(name = "Stock Decrement: {0}")
    @MethodSource({"stockDecrementScenarios", "randomizedStockDecrementScenarios"})
    void createReservation_withSufficientStock_decrementsAvailableAndConservesTotal(StockDecrementScenario scenario) {
        // Arrange
        UUID productId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();
        Long quantity = scenario.reservedQuantity;
        String idempotencyKey = UUID.randomUUID().toString();
        
        Product product = createProduct(
                productId,
                scenario.availableStockBefore,
                scenario.reservedStockBefore
        );
        
        Reservation savedReservation = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.save(any(Reservation.class))).thenReturn(savedReservation);
        when(reservationRepository.findByIdempotencyKeyAndOrderId(any(), any())).thenReturn(Optional.empty());
        when(stockAuditLogRepository.save(any(StockAuditLog.class)))
                .thenReturn(StockAuditLog.builder().id(UUID.randomUUID()).build());

        CreateReservationRequest request = CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(quantity)
                .idempotencyKey(idempotencyKey)
                .build();

        // Act
        ReservationResponse response = reservationService.createReservation(request);

        // Assert - Stock decrement invariant
        ArgumentCaptor<Product> productCaptor = ArgumentCaptor.forClass(Product.class);
        verify(productRepository).save(productCaptor.capture());
        Product savedProduct = productCaptor.getValue();

        long expectedAvailableStockAfter = scenario.availableStockBefore - quantity;
        long expectedReservedStockAfter = scenario.reservedStockBefore + quantity;

        assertThat(savedProduct.getAvailableStock())
                .as("Available stock must decrease by exactly the reserved quantity")
                .isEqualTo(expectedAvailableStockAfter);

        assertThat(savedProduct.getReservedStock())
                .as("Reserved stock must increase by exactly the reserved quantity")
                .isEqualTo(expectedReservedStockAfter);

        // Invariant: available stock never goes negative after a reservation is created
        assertThat(savedProduct.getAvailableStock())
                .as("Available stock must never go negative after a reservation")
                .isGreaterThanOrEqualTo(0L);

        // Invariant: total stock is conserved (available + reserved stays equal to total)
        long totalStockBefore = scenario.availableStockBefore + scenario.reservedStockBefore;
        long totalStockAfter = savedProduct.getAvailableStock() + savedProduct.getReservedStock();
        assertThat(totalStockAfter)
                .as("Total stock (available + reserved) must remain constant")
                .isEqualTo(totalStockBefore);
        assertThat(savedProduct.getTotalStock())
                .as("totalStock field must equal available + reserved (conservation)")
                .isEqualTo(totalStockAfter);

        // Invariant: a reservation is only created when sufficient stock exists
        verify(reservationRepository).save(any(Reservation.class));

        log.info("✓ Stock decrement invariant verified: available {} -> {}, reserved {} -> {}",
                scenario.availableStockBefore, expectedAvailableStockAfter,
                scenario.reservedStockBefore, expectedReservedStockAfter);
    }

    /**
     * Generates scenarios for stock decrement invariant testing.
     * Covers: zero available, minimal available, partial available, maximum available.
     * 
     * @return stream of test scenarios
     */
    static Stream<StockDecrementScenario> stockDecrementScenarios() {
        return Stream.of(
                // Scenario 1: Reserve 1 from 100 available, 0 reserved
                new StockDecrementScenario(100, 0, 1, 99, 1),
                
                // Scenario 2: Reserve 50 from 100 available, 0 reserved
                new StockDecrementScenario(100, 0, 50, 50, 50),
                
                // Scenario 3: Reserve exactly all available stock
                new StockDecrementScenario(100, 0, 100, 0, 100),
                
                // Scenario 4: Reserve from partially-already-reserved product
                new StockDecrementScenario(50, 50, 25, 25, 75),
                
                // Scenario 5: Reserve minimum quantity
                new StockDecrementScenario(1, 0, 1, 0, 1),
                
                // Scenario 6: Reserve from large stock
                new StockDecrementScenario(100000, 0, 5000, 95000, 5000),
                
                // Scenario 7: Reserve small quantity from large stock
                new StockDecrementScenario(10000, 5000, 1, 9999, 5001),
                
                // Scenario 8: Reserve medium quantity
                new StockDecrementScenario(1000, 200, 300, 700, 500),
                
                // Scenario 9: Reserve large quantity
                new StockDecrementScenario(1000, 0, 999, 1, 999),
                
                // Scenario 10: Multiple products with different levels
                new StockDecrementScenario(500, 250, 100, 400, 350)
        );
    }

    /**
     * Generates a large set of randomized-but-valid reservation scenarios.
     *
     * <p>This is the property-based core: rather than a handful of hand-picked
     * examples, it samples the input space broadly so the creation invariants are
     * exercised against many combinations of available stock, pre-existing reserved
     * stock, and requested quantity. Every generated case keeps the request
     * satisfiable (1 &lt;= requestedQuantity &lt;= availableStockBefore) so that a
     * reservation is actually created and the three invariants can be asserted on the
     * resulting state:
     * <ul>
     *   <li>availableStock_after &gt;= 0 (never negative)</li>
     *   <li>availableStock_after + reservedStock_after == totalStock (conservation)</li>
     *   <li>a reservation is persisted (creation only happens with sufficient stock)</li>
     * </ul>
     *
     * <p>A fixed seed keeps the run deterministic and reproducible, mirroring the
     * convention used by the stock-update property tests.
     *
     * @return stream of randomized stock-decrement scenarios
     */
    static Stream<StockDecrementScenario> randomizedStockDecrementScenarios() {
        // Fixed seed → deterministic, reproducible counterexamples if one ever fails.
        Random random = new Random(20240115L);
        int numberOfScenarios = 100;

        List<StockDecrementScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Available stock in [1, 100_000] so at least one unit can be reserved.
            long availableBefore = 1 + (long) (random.nextDouble() * 100_000);
            // Pre-existing reserved stock in [0, 100_000].
            long reservedBefore = (long) (random.nextDouble() * 100_001);
            // Requested quantity in [1, availableBefore] so the request is satisfiable.
            long quantity = 1 + (long) (random.nextDouble() * availableBefore);
            if (quantity > availableBefore) {
                quantity = availableBefore;
            }

            long expectedAvailableAfter = availableBefore - quantity;
            long expectedReservedAfter = reservedBefore + quantity;

            scenarios.add(new StockDecrementScenario(
                    availableBefore, reservedBefore, quantity,
                    expectedAvailableAfter, expectedReservedAfter));
        }

        return scenarios.stream();
    }

    /**
     * PROPERTY 5: Metamorphic Reservation Property
     * 
     * **Validates: Requirements 2.3**
     * 
     * When two reservations are created sequentially for the same product,
     * the available stock after the second reservation equals the available stock
     * after the first reservation minus the second reservation's quantity:
     * 
     *   available_after_reservation_2 = available_after_reservation_1 - quantity_2
     * 
     * This metamorphic property verifies that sequential reservations are
     * composable and consistent.
     * 
     * @param scenario Test scenario with two reservation quantities
     */
    @ParameterizedTest(name = "Metamorphic: {0}")
    @MethodSource("metamorphicReservationScenarios")
    void createReservation_appliedSequentiallyForSameProduct_chainsAvailableStock(MetamorphicScenario scenario) {
        // Arrange
        UUID productId = UUID.randomUUID();
        UUID orderId1 = UUID.randomUUID();
        UUID orderId2 = UUID.randomUUID();

        long initialAvailable = scenario.initialAvailable;
        long quantity1 = scenario.quantity1;
        long quantity2 = scenario.quantity2;

        Product product1 = createProduct(productId, initialAvailable, 0);
        
        // After first reservation
        long availableAfter1 = initialAvailable - quantity1;
        Product product2 = createProduct(productId, initialAvailable, quantity1);
        product2.setAvailableStock(availableAfter1);
        product2.setReservedStock(quantity1);

        // Setup mocks for first reservation
        when(productRepository.findByIdWithLock(productId))
                .thenReturn(Optional.of(product1))
                .thenReturn(Optional.of(product2));
        
        when(reservationRepository.findByIdempotencyKeyAndOrderId(any(), eq(orderId1)))
                .thenReturn(Optional.empty());
        when(reservationRepository.findByIdempotencyKeyAndOrderId(any(), eq(orderId2)))
                .thenReturn(Optional.empty());

        Reservation reservation1 = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId1)
                .product(product1)
                .quantity(quantity1)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();

        Reservation reservation2 = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId2)
                .product(product2)
                .quantity(quantity2)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();

        when(reservationRepository.save(any(Reservation.class)))
                .thenReturn(reservation1)
                .thenReturn(reservation2);

        when(stockAuditLogRepository.save(any(StockAuditLog.class)))
                .thenReturn(StockAuditLog.builder().id(UUID.randomUUID()).build());

        // Act - First reservation
        CreateReservationRequest request1 = CreateReservationRequest.builder()
                .orderId(orderId1)
                .productId(productId)
                .quantity(quantity1)
                .idempotencyKey(UUID.randomUUID().toString())
                .build();

        ReservationResponse response1 = reservationService.createReservation(request1);
        
        // Capture state after first reservation
        ArgumentCaptor<Product> product1Captor = ArgumentCaptor.forClass(Product.class);
        verify(productRepository, times(1)).save(product1Captor.capture());
        Product savedProduct1 = product1Captor.getValue();
        long availableAfter1Actual = savedProduct1.getAvailableStock();

        // Reset mock for second reservation
        reset(productRepository);
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product2));

        // Act - Second reservation
        CreateReservationRequest request2 = CreateReservationRequest.builder()
                .orderId(orderId2)
                .productId(productId)
                .quantity(quantity2)
                .idempotencyKey(UUID.randomUUID().toString())
                .build();

        ReservationResponse response2 = reservationService.createReservation(request2);

        // Assert - Metamorphic property
        ArgumentCaptor<Product> product2Captor = ArgumentCaptor.forClass(Product.class);
        verify(productRepository).save(product2Captor.capture());
        Product savedProduct2 = product2Captor.getValue();
        long availableAfter2Actual = savedProduct2.getAvailableStock();

        // Verify metamorphic relationship
        long expectedAvailableAfter2 = availableAfter1Actual - quantity2;
        assertThat(availableAfter2Actual)
                .as("Available stock after second reservation must equal available after first minus quantity2")
                .isEqualTo(expectedAvailableAfter2);

        // Verify both responses have correct values
        assertThat(response1.getAvailableStock()).isEqualTo(availableAfter1Actual);
        assertThat(response2.getAvailableStock()).isEqualTo(availableAfter2Actual);

        log.info("✓ Metamorphic property verified: {} -> {} -> {}",
                initialAvailable, availableAfter1Actual, availableAfter2Actual);
    }

    static Stream<MetamorphicScenario> metamorphicReservationScenarios() {
        return Stream.of(
                // Scenario 1: Two small reservations
                new MetamorphicScenario(100, 10, 10),
                
                // Scenario 2: Two medium reservations
                new MetamorphicScenario(100, 30, 30),
                
                // Scenario 3: First large, then small
                new MetamorphicScenario(100, 80, 15),
                
                // Scenario 4: First small, then large
                new MetamorphicScenario(100, 20, 50),
                
                // Scenario 5: Reserve exactly half each time
                new MetamorphicScenario(100, 50, 50),
                
                // Scenario 6: Large stock with small reservations
                new MetamorphicScenario(10000, 100, 50),
                
                // Scenario 7: Minimal available after first reservation
                new MetamorphicScenario(100, 99, 1),
                
                // Scenario 8: Complex quantities
                new MetamorphicScenario(250, 75, 125)
        );
    }

    /**
     * PROPERTY 6: Error Condition Idempotence
     * 
     * **Validates: Requirements 2.2**
     * 
     * When attempting to reserve more stock than available, the operation should:
     * 1. Fail with an error
     * 2. Leave the product stock unchanged
     * 
     * This idempotence property ensures that failed operations don't corrupt state.
     * 
     * @param scenario Test scenario with insufficient stock
     */
    @ParameterizedTest(name = "Error Idempotence: {0}")
    @MethodSource({"errorIdempotenceScenarios", "randomizedErrorIdempotenceScenarios"})
    void createReservation_withInsufficientStock_failsAndLeavesStockUnchanged(ErrorIdempotenceScenario scenario) {
        // Arrange
        UUID productId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();

        Product product = createProduct(
                productId,
                scenario.availableStock,
                scenario.reservedStock
        );

        long availableStockBefore = product.getAvailableStock();
        long reservedStockBefore = product.getReservedStock();

        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(product));
        when(reservationRepository.findByIdempotencyKeyAndOrderId(any(), any()))
                .thenReturn(Optional.empty());

        CreateReservationRequest request = CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(scenario.requestedQuantity)
                .idempotencyKey(UUID.randomUUID().toString())
                .build();

        // Act & Assert
        assertThatThrownBy(() -> reservationService.createReservation(request))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("INSUFFICIENT_STOCK");

        // Verify that product stock was NOT updated (idempotence)
        // When insufficient stock, the save should not be called, or if it is, with original values
        verify(productRepository, never()).save(any(Product.class));
        
        // Verify no reservation was created
        verify(reservationRepository, never()).save(any(Reservation.class));
        
        // Verify no audit log was created
        verify(stockAuditLogRepository, never()).save(any(StockAuditLog.class));

        // Verify product state is unchanged
        assertThat(product.getAvailableStock())
                .as("Available stock must not change on failed reservation")
                .isEqualTo(availableStockBefore);

        assertThat(product.getReservedStock())
                .as("Reserved stock must not change on failed reservation")
                .isEqualTo(reservedStockBefore);

        log.info("✓ Error idempotence verified: stock unchanged after failed reservation");
    }

    static Stream<ErrorIdempotenceScenario> errorIdempotenceScenarios() {
        return Stream.of(
                // Scenario 1: Request 1 when 0 available
                new ErrorIdempotenceScenario(0, 100, 1),
                
                // Scenario 2: Request 101 when 100 available
                new ErrorIdempotenceScenario(100, 0, 101),
                
                // Scenario 3: Request 51 when 50 available
                new ErrorIdempotenceScenario(50, 50, 51),
                
                // Scenario 4: Request 1001 when 1000 available
                new ErrorIdempotenceScenario(1000, 0, 1001),
                
                // Scenario 5: Request large quantity when minimal available
                new ErrorIdempotenceScenario(1, 10000, 100),
                
                // Scenario 6: Complex case
                new ErrorIdempotenceScenario(25, 75, 26)
        );
    }

    /**
     * Generates a large set of randomized insufficient-stock scenarios.
     *
     * <p>Each generated case requests strictly more than the available stock
     * (requestedQuantity &gt; availableStock), so the service must reject the request.
     * This probes the "a reservation is only created when sufficient stock exists"
     * invariant from the failure side across many stock/request combinations: the
     * operation must fail and leave both available and reserved stock untouched.
     *
     * <p>A fixed seed keeps the run deterministic and reproducible.
     *
     * @return stream of randomized insufficient-stock scenarios
     */
    static Stream<ErrorIdempotenceScenario> randomizedErrorIdempotenceScenarios() {
        Random random = new Random(20240115L);
        int numberOfScenarios = 100;

        List<ErrorIdempotenceScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Available stock in [0, 100_000].
            long availableStock = (long) (random.nextDouble() * 100_001);
            // Pre-existing reserved stock in [0, 100_000].
            long reservedStock = (long) (random.nextDouble() * 100_001);
            // Requested quantity strictly greater than available so it must be rejected.
            long overBy = 1 + (long) (random.nextDouble() * 100_000);
            long requestedQuantity = availableStock + overBy;

            scenarios.add(new ErrorIdempotenceScenario(availableStock, reservedStock, requestedQuantity));
        }

        return scenarios.stream();
    }

    // ========== Test Data Classes ==========

    static class StockDecrementScenario {
        final long availableStockBefore;
        final long reservedStockBefore;
        final long reservedQuantity;
        final long expectedAvailableAfter;
        final long expectedReservedAfter;

        StockDecrementScenario(long availableStockBefore, long reservedStockBefore,
                              long reservedQuantity, long expectedAvailableAfter,
                              long expectedReservedAfter) {
            this.availableStockBefore = availableStockBefore;
            this.reservedStockBefore = reservedStockBefore;
            this.reservedQuantity = reservedQuantity;
            this.expectedAvailableAfter = expectedAvailableAfter;
            this.expectedReservedAfter = expectedReservedAfter;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, qty=%d",
                    availableStockBefore, reservedStockBefore, reservedQuantity);
        }
    }

    static class MetamorphicScenario {
        final long initialAvailable;
        final long quantity1;
        final long quantity2;

        MetamorphicScenario(long initialAvailable, long quantity1, long quantity2) {
            this.initialAvailable = initialAvailable;
            this.quantity1 = quantity1;
            this.quantity2 = quantity2;
        }

        @Override
        public String toString() {
            return String.format("initial=%d, qty1=%d, qty2=%d",
                    initialAvailable, quantity1, quantity2);
        }
    }

    static class ErrorIdempotenceScenario {
        final long availableStock;
        final long reservedStock;
        final long requestedQuantity;

        ErrorIdempotenceScenario(long availableStock, long reservedStock, long requestedQuantity) {
            this.availableStock = availableStock;
            this.reservedStock = reservedStock;
            this.requestedQuantity = requestedQuantity;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, requested=%d",
                    availableStock, reservedStock, requestedQuantity);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(UUID id, long availableStock, long reservedStock) {
        return Product.builder()
                .id(id)
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }
}

