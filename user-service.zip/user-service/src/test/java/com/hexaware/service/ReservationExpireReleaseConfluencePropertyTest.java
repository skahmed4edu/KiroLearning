package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Property-Based Test for confluence of concurrent expiration and release.
 *
 * <p><b>Property 14 — Confluence (Validates: Requirements 6.4).</b> When an expiration and a
 * release race on the <em>same</em> {@code ACTIVE} reservation, exactly one of them wins and
 * restores the reserved stock; the loser is rejected and performs no stock mutation. The
 * reserved quantity is therefore restored to available stock <b>exactly once</b> regardless of
 * which operation wins or in which order they interleave, and the stock invariant
 * ({@code available + reserved == total}, both non-negative) always holds afterwards.
 *
 * <p>Task 13 ({@code ReservationExpirationScheduler}) is not yet implemented, so this property
 * is exercised at the point where the confluent behaviour actually lives: the reservation
 * state machine ({@link Reservation#release(LocalDateTime)} /
 * {@link Reservation#expire(LocalDateTime)}) plus the stock mutation
 * {@link Product#releaseStock(Long)}. Both the release path and the expiration path transition
 * the reservation out of {@code ACTIVE} and restore stock. The scheduler and release service
 * both specify a terminal-state guard: a reservation that is no longer {@code ACTIVE} must not
 * restore stock again. The entity enforces that guard by throwing {@link IllegalStateException}
 * from {@code release}/{@code expire} when the reservation is not {@code ACTIVE}; this test
 * drives both operations against the same reservation through that guard so the second
 * (losing) operation is rejected and never double-restores stock.
 *
 * <p>Because the two operations are commutative on the final state — whichever runs first wins,
 * the other is a no-op — the system is confluent: both interleavings
 * (release-then-expire and expire-then-release) reach a terminal state with stock restored
 * exactly once.
 *
 * <p>Properties verified for a single {@code ACTIVE} reservation of quantity {@code q} subject
 * to both an expire attempt and a release attempt, in either order:
 * <ul>
 *   <li><b>Property 14 — Confluence / restore-exactly-once:</b>
 *       {@code availableStock_final == availableStock_before + q} regardless of interleaving
 *       (<b>Validates: Requirements 6.4</b>)</li>
 *   <li><b>Winner / loser:</b> the first operation succeeds and sets the terminal status; the
 *       second operation is rejected with {@link IllegalStateException} and mutates nothing</li>
 *   <li><b>Invariant preserved:</b> {@code available + reserved == total} with both
 *       non-negative holds after every step of either interleaving</li>
 *   <li><b>Deterministic terminal state for a fixed winner:</b> the final stock figures are
 *       identical across the two interleavings when the same operation wins</li>
 * </ul>
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath, dependencies are governed by architecture steering), this is a JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} test driven by hand-picked edge-case
 * scenarios and a fixed-seed randomized generator. A fixed seed keeps runs deterministic and
 * any counterexample reproducible.
 */
@Slf4j
class ReservationExpireReleaseConfluencePropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if a property ever fails. */
    private static final long SEED = 20240115L;

    /**
     * PROPERTY 14: Confluence — release wins, expire loses.
     *
     * <p><b>Validates: Requirements 6.4</b>
     *
     * <p>Interleaving A (release-then-expire): the release transitions the reservation to
     * {@code RELEASED} and restores stock once; the subsequent expire attempt finds a
     * non-{@code ACTIVE} reservation, is rejected, and restores nothing. Stock is restored
     * exactly once and the invariant holds throughout.
     *
     * @param scenario a product/reservation pair where the reservation holds {@code q} units
     */
    @ParameterizedTest(name = "Confluence (release wins): {0}")
    @MethodSource({"confluenceScenarios", "randomizedConfluenceScenarios"})
    void concurrentExpireAndRelease_whenReleaseWins_restoresStockExactlyOnceAndRejectsExpire(
            ConfluenceScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.reservedQuantity);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();
        long totalBefore = product.getTotalStock();

        // Act — release wins the race, expire arrives second and loses.
        boolean releaseRestored = applyRelease(reservation, product);

        assertThatThrownBy(() -> applyExpireOrThrow(reservation, product))
                .as("expire arriving after a terminal release must be rejected")
                .isInstanceOf(IllegalStateException.class);

        // Assert
        assertThat(releaseRestored)
                .as("the winning release must be the operation that restored stock")
                .isTrue();

        assertThat(reservation.getStatus())
                .as("the winner is release, so the terminal status must be RELEASED")
                .isEqualTo(ReservationStatus.RELEASED);
        assertThat(reservation.getReleasedAt()).as("releasedAt set by the winning release").isNotNull();
        assertThat(reservation.getExpiredAt()).as("losing expire must not stamp expiredAt").isNull();

        assertThat(product.getAvailableStock())
                .as("stock restored exactly once: available grows by exactly the reserved quantity")
                .isEqualTo(availableBefore + scenario.reservedQuantity);
        assertThat(product.getReservedStock())
                .as("stock restored exactly once: reserved shrinks by exactly the reserved quantity")
                .isEqualTo(reservedBefore - scenario.reservedQuantity);

        assertInvariantHolds(product, totalBefore);

        log.info("✓ Confluence (release wins) over qty {}: available {} -> {} (restored once), "
                        + "reserved {} -> {}", scenario.reservedQuantity, availableBefore,
                product.getAvailableStock(), reservedBefore, product.getReservedStock());
    }

    /**
     * PROPERTY 14: Confluence — expire wins, release loses.
     *
     * <p><b>Validates: Requirements 6.4</b>
     *
     * <p>Interleaving B (expire-then-release): the expire transitions the reservation to
     * {@code EXPIRED} and restores stock once; the subsequent release attempt finds a
     * non-{@code ACTIVE} reservation, is rejected, and restores nothing. Stock is restored
     * exactly once and the invariant holds throughout.
     *
     * @param scenario a product/reservation pair where the reservation holds {@code q} units
     */
    @ParameterizedTest(name = "Confluence (expire wins): {0}")
    @MethodSource({"confluenceScenarios", "randomizedConfluenceScenarios"})
    void concurrentExpireAndRelease_whenExpireWins_restoresStockExactlyOnceAndRejectsRelease(
            ConfluenceScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.reservedQuantity);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();
        long totalBefore = product.getTotalStock();

        // Act — expire wins the race, release arrives second and loses.
        boolean expireRestored = applyExpire(reservation, product);

        assertThatThrownBy(() -> applyReleaseOrThrow(reservation, product))
                .as("release arriving after a terminal expire must be rejected")
                .isInstanceOf(IllegalStateException.class);

        // Assert
        assertThat(expireRestored)
                .as("the winning expire must be the operation that restored stock")
                .isTrue();

        assertThat(reservation.getStatus())
                .as("the winner is expire, so the terminal status must be EXPIRED")
                .isEqualTo(ReservationStatus.EXPIRED);
        assertThat(reservation.getExpiredAt()).as("expiredAt set by the winning expire").isNotNull();
        assertThat(reservation.getReleasedAt()).as("losing release must not stamp releasedAt").isNull();

        assertThat(product.getAvailableStock())
                .as("stock restored exactly once: available grows by exactly the reserved quantity")
                .isEqualTo(availableBefore + scenario.reservedQuantity);
        assertThat(product.getReservedStock())
                .as("stock restored exactly once: reserved shrinks by exactly the reserved quantity")
                .isEqualTo(reservedBefore - scenario.reservedQuantity);

        assertInvariantHolds(product, totalBefore);

        log.info("✓ Confluence (expire wins) over qty {}: available {} -> {} (restored once), "
                        + "reserved {} -> {}", scenario.reservedQuantity, availableBefore,
                product.getAvailableStock(), reservedBefore, product.getReservedStock());
    }

    /**
     * PROPERTY 14: Confluence — order independence of the final stock state.
     *
     * <p><b>Validates: Requirements 6.4</b>
     *
     * <p>The two interleavings are run on two independent-but-identical copies of the same
     * starting state. Whichever operation wins, the final available/reserved figures are
     * identical across both orderings — the reserved quantity is restored exactly once in each.
     * This is the defining confluence property: the end state does not depend on the order in
     * which the racing operations are applied.
     *
     * @param scenario a product/reservation pair where the reservation holds {@code q} units
     */
    @ParameterizedTest(name = "Confluence (order independence): {0}")
    @MethodSource({"confluenceScenarios", "randomizedConfluenceScenarios"})
    void concurrentExpireAndRelease_whenInterleavedEitherWay_reachesSameStockState(
            ConfluenceScenario scenario) {
        // Arrange — two identical copies of the same starting world.
        Product releaseFirstProduct = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation releaseFirstReservation =
                createActiveReservation(releaseFirstProduct, scenario.reservedQuantity);

        Product expireFirstProduct = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation expireFirstReservation =
                createActiveReservation(expireFirstProduct, scenario.reservedQuantity);

        long totalBefore = releaseFirstProduct.getTotalStock();

        // Act — interleaving A: release then expire; interleaving B: expire then release.
        applyRelease(releaseFirstReservation, releaseFirstProduct);
        assertThatThrownBy(() -> applyExpireOrThrow(releaseFirstReservation, releaseFirstProduct))
                .isInstanceOf(IllegalStateException.class);

        applyExpire(expireFirstReservation, expireFirstProduct);
        assertThatThrownBy(() -> applyReleaseOrThrow(expireFirstReservation, expireFirstProduct))
                .isInstanceOf(IllegalStateException.class);

        // Assert — stock figures match regardless of interleaving (restored exactly once each).
        assertThat(expireFirstProduct.getAvailableStock())
                .as("available stock must be identical regardless of operation order")
                .isEqualTo(releaseFirstProduct.getAvailableStock())
                .isEqualTo(scenario.availableBefore + scenario.reservedQuantity);
        assertThat(expireFirstProduct.getReservedStock())
                .as("reserved stock must be identical regardless of operation order")
                .isEqualTo(releaseFirstProduct.getReservedStock())
                .isEqualTo(scenario.reservedBefore - scenario.reservedQuantity);

        assertInvariantHolds(releaseFirstProduct, totalBefore);
        assertInvariantHolds(expireFirstProduct, totalBefore);

        log.info("✓ Order independence over qty {}: both interleavings reach available={}, reserved={}",
                scenario.reservedQuantity, releaseFirstProduct.getAvailableStock(),
                releaseFirstProduct.getReservedStock());
    }

    // ========== Confluent Operation Model ==========

    /**
     * Applies a release the way {@code ReservationReleaseService} specifies it: transition the
     * reservation to {@code RELEASED} (which throws if it is no longer {@code ACTIVE}) and then
     * restore the reserved stock. Returns {@code true} when stock was restored.
     *
     * @param reservation the reservation being released
     * @param product     the owning product whose stock is restored
     * @return {@code true} if this call restored stock
     */
    private static boolean applyRelease(Reservation reservation, Product product) {
        reservation.release(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());
        return true;
    }

    /**
     * Applies an expiration the way {@code ReservationExpirationScheduler} specifies it:
     * transition the reservation to {@code EXPIRED} (which throws if it is no longer
     * {@code ACTIVE}) and then restore the reserved stock. Returns {@code true} when stock was
     * restored.
     *
     * @param reservation the reservation being expired
     * @param product     the owning product whose stock is restored
     * @return {@code true} if this call restored stock
     */
    private static boolean applyExpire(Reservation reservation, Product product) {
        reservation.expire(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());
        return true;
    }

    /**
     * Release path invoked as the losing (second) operation. The terminal-state guard in
     * {@link Reservation#release(LocalDateTime)} throws before any stock mutation is attempted,
     * so a rejected release never double-restores stock.
     */
    private static void applyReleaseOrThrow(Reservation reservation, Product product) {
        reservation.release(LocalDateTime.now());
        // Unreachable when the reservation is already terminal — the guard above throws first.
        product.releaseStock(reservation.getQuantity());
    }

    /**
     * Expire path invoked as the losing (second) operation. The terminal-state guard in
     * {@link Reservation#expire(LocalDateTime)} throws before any stock mutation is attempted,
     * so a rejected expire never double-restores stock.
     */
    private static void applyExpireOrThrow(Reservation reservation, Product product) {
        reservation.expire(LocalDateTime.now());
        // Unreachable when the reservation is already terminal — the guard above throws first.
        product.releaseStock(reservation.getQuantity());
    }

    /**
     * Asserts the full stock invariant: {@code available + reserved == total} (unchanged), both
     * buckets non-negative, and {@link Product#validateStockInvariant()} passes.
     *
     * @param product     the product to check
     * @param totalBefore the total stock before any operation (must be unchanged)
     */
    private static void assertInvariantHolds(Product product, long totalBefore) {
        assertThat(product.getAvailableStock())
                .as("available stock must never go negative").isGreaterThanOrEqualTo(0);
        assertThat(product.getReservedStock())
                .as("reserved stock must never go negative").isGreaterThanOrEqualTo(0);
        assertThat(product.getAvailableStock() + product.getReservedStock())
                .as("available + reserved must equal the unchanged total stock")
                .isEqualTo(totalBefore)
                .isEqualTo(product.getTotalStock());
        assertThatCode(product::validateStockInvariant)
                .as("full stock invariant must hold after the confluent operations")
                .doesNotThrowAnyException();
    }

    // ========== Scenario Generators ==========

    /**
     * Hand-picked edge-case scenarios: a single reserved unit, partial reservations, the
     * entire reserved pool held by this one reservation, and large stock splits — the boundary
     * cases where a double-restore would most obviously corrupt the invariant.
     *
     * @return stream of confluence scenarios
     */
    static Stream<ConfluenceScenario> confluenceScenarios() {
        return Stream.of(
                // single reserved unit, nothing else available
                new ConfluenceScenario(0, 1, 1),
                // single reserved unit with ample available stock
                new ConfluenceScenario(99, 1, 1),
                // this reservation holds part of the reserved pool
                new ConfluenceScenario(50, 50, 25),
                // this reservation holds the entire reserved pool
                new ConfluenceScenario(50, 50, 50),
                // fully reserved product, this reservation holds all of it
                new ConfluenceScenario(0, 100, 100),
                // fully reserved product, this reservation holds one unit
                new ConfluenceScenario(0, 100, 1),
                // large stock, small reserved quantity
                new ConfluenceScenario(95_000, 5_000, 1),
                // large reserved quantity held by this reservation
                new ConfluenceScenario(1, 999, 999),
                // mid-range partial hold
                new ConfluenceScenario(700, 300, 150),
                // large product, this reservation holds the full reserved pool
                new ConfluenceScenario(50_000, 50_000, 50_000)
        );
    }

    /**
     * Fixed-seed randomized generator covering the valid input space broadly. For each scenario
     * it samples a total stock, splits it into a valid available/reserved pair (reserved at
     * least 1 so there is something to restore), and picks the quantity this reservation holds
     * in {@code [1, reserved]} so the restore always targets stock that is actually held — the
     * same precondition the release/expiration paths enforce.
     *
     * @return stream of 100 randomized confluence scenarios
     */
    static Stream<ConfluenceScenario> randomizedConfluenceScenarios() {
        Random random = new Random(SEED);
        int numberOfScenarios = 100;

        List<ConfluenceScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Total in [1, 100_000].
            long total = 1 + (long) (random.nextDouble() * 100_000);
            // Reserved must be at least 1 so this reservation can hold something; up to total.
            long reserved = 1 + (long) (random.nextDouble() * total);
            if (reserved > total) {
                reserved = total;
            }
            long available = total - reserved;
            // This reservation holds somewhere in [1, reserved].
            long held = 1 + (long) (random.nextDouble() * reserved);
            if (held > reserved) {
                held = reserved;
            }

            scenarios.add(new ConfluenceScenario(available, reserved, held));
        }

        return scenarios.stream();
    }

    // ========== Test Data Class ==========

    /**
     * One confluence case: the product's available/reserved split before any operation, and the
     * quantity held by the single {@code ACTIVE} reservation that both the release and the
     * expire target ({@code reservedQuantity} is always in {@code [1, reservedBefore]}).
     */
    static class ConfluenceScenario {
        final long availableBefore;
        final long reservedBefore;
        final long reservedQuantity;

        ConfluenceScenario(long availableBefore, long reservedBefore, long reservedQuantity) {
            this.availableBefore = availableBefore;
            this.reservedBefore = reservedBefore;
            this.reservedQuantity = reservedQuantity;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, held=%d",
                    availableBefore, reservedBefore, reservedQuantity);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    static Reservation createActiveReservation(Product product, long quantity) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();
    }
}
