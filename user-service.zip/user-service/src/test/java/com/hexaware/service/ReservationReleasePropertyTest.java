package com.hexaware.service;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

/**
 * Property-Based Tests for reservation release stock invariants.
 *
 * <p>Task 12 ({@code ReservationReleaseService}) delegates all stock mutation to
 * {@link Product#releaseStock(Long)} — the release flow restores the reserved quantity
 * to available stock on the owning product and transitions the reservation to
 * {@code RELEASED}. These properties therefore exercise the release of an {@code ACTIVE}
 * reservation at the point where the stock invariants actually live: the product's
 * stock-mutation logic plus the reservation state transition.
 *
 * <p>Properties verified for releasing an active reservation of quantity {@code q}:
 * <ul>
 *   <li><b>Property 7 — Stock restore invariant:</b>
 *       {@code availableStock_after = availableStock_before + q}
 *       (<b>Validates: Requirements 3.3</b>)</li>
 *   <li><b>Conservation:</b> {@code available + reserved} stays equal to {@code totalStock}
 *       before and after release</li>
 *   <li><b>Available ≤ total:</b> available stock never exceeds total stock after release</li>
 *   <li><b>Reserved ≥ 0:</b> reserved stock never goes negative after release</li>
 * </ul>
 *
 * <p>Following the established project convention (no property-based testing library on the
 * classpath, dependencies are governed by architecture steering), these are JUnit 5
 * {@code @ParameterizedTest} + {@code @MethodSource} tests driven by a mix of hand-picked
 * edge-case scenarios and a fixed-seed randomized generator. A fixed seed keeps runs
 * deterministic and any counterexample reproducible.
 */
@Slf4j
class ReservationReleasePropertyTest {

    /** Fixed seed → deterministic, reproducible counterexamples if a property ever fails. */
    private static final long SEED = 20240115L;

    /**
     * PROPERTY 7: Stock Restore Invariant
     *
     * <p><b>Validates: Requirements 3.3</b>
     *
     * <p>Releasing an {@code ACTIVE} reservation of quantity {@code q} returns exactly
     * {@code q} units to available stock:
     *
     * <pre>availableStock_after = availableStock_before + q</pre>
     *
     * <p>and symmetrically removes {@code q} from reserved stock. This is the core
     * guarantee that released stock becomes available again for new reservations.
     *
     * @param scenario a product/reservation pair with a releasable quantity
     */
    @ParameterizedTest(name = "Stock restore: {0}")
    @MethodSource({"releaseScenarios", "randomizedReleaseScenarios"})
    void releaseReservation_whenActive_restoresReservedQuantityToAvailable(ReleaseScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.releaseQuantity);

        long availableBefore = product.getAvailableStock();
        long reservedBefore = product.getReservedStock();

        // Act
        reservation.release(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        // Assert
        assertThat(product.getAvailableStock())
                .as("available stock must increase by exactly the released quantity")
                .isEqualTo(availableBefore + scenario.releaseQuantity);

        assertThat(product.getReservedStock())
                .as("reserved stock must decrease by exactly the released quantity")
                .isEqualTo(reservedBefore - scenario.releaseQuantity);

        assertThat(reservation.getStatus())
                .as("reservation must transition ACTIVE -> RELEASED")
                .isEqualTo(ReservationStatus.RELEASED);
        assertThat(reservation.getReleasedAt())
                .as("released reservation must record its release timestamp")
                .isNotNull();

        log.info("✓ Stock restore verified: available {} -> {}, reserved {} -> {}",
                availableBefore, product.getAvailableStock(),
                reservedBefore, product.getReservedStock());
    }

    /**
     * CONSERVATION PROPERTY
     *
     * <p>Releasing a reservation only moves units between the reserved and available
     * buckets — it never creates or destroys stock. Therefore
     * {@code available + reserved} must equal {@code totalStock} both before and after
     * the release.
     *
     * @param scenario a product/reservation pair with a releasable quantity
     */
    @ParameterizedTest(name = "Conservation: {0}")
    @MethodSource({"releaseScenarios", "randomizedReleaseScenarios"})
    void releaseReservation_whenActive_conservesTotalStock(ReleaseScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.releaseQuantity);

        long totalBefore = product.getTotalStock();
        long sumBefore = product.getAvailableStock() + product.getReservedStock();

        // Act
        reservation.release(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        // Assert
        long sumAfter = product.getAvailableStock() + product.getReservedStock();

        assertThat(sumBefore)
                .as("available + reserved must equal total stock before release")
                .isEqualTo(totalBefore);
        assertThat(sumAfter)
                .as("available + reserved must equal total stock after release")
                .isEqualTo(totalBefore);
        assertThat(product.getTotalStock())
                .as("total stock itself must be unchanged by a release")
                .isEqualTo(totalBefore);

        log.info("✓ Conservation verified: total={} stays equal to available+reserved={}",
                totalBefore, sumAfter);
    }

    /**
     * BOUNDS PROPERTY
     *
     * <p>After releasing an {@code ACTIVE} reservation the product must stay within valid
     * stock bounds:
     * <ul>
     *   <li>available stock never exceeds total stock</li>
     *   <li>reserved stock never goes negative</li>
     * </ul>
     *
     * <p>The product's own {@link Product#validateStockInvariant()} is also asserted to not
     * throw, confirming the full stock invariant holds after release.
     *
     * @param scenario a product/reservation pair with a releasable quantity
     */
    @ParameterizedTest(name = "Bounds: {0}")
    @MethodSource({"releaseScenarios", "randomizedReleaseScenarios"})
    void releaseReservation_whenActive_keepsStockWithinValidBounds(ReleaseScenario scenario) {
        // Arrange
        Product product = createProduct(scenario.availableBefore, scenario.reservedBefore);
        Reservation reservation = createActiveReservation(product, scenario.releaseQuantity);

        // Act
        reservation.release(LocalDateTime.now());
        product.releaseStock(reservation.getQuantity());

        // Assert
        assertThat(product.getAvailableStock())
                .as("available stock must never exceed total stock after release")
                .isLessThanOrEqualTo(product.getTotalStock());

        assertThat(product.getReservedStock())
                .as("reserved stock must never go negative after release")
                .isGreaterThanOrEqualTo(0L);

        assertThat(product.getAvailableStock())
                .as("available stock must never go negative after release")
                .isGreaterThanOrEqualTo(0L);

        assertThatCode(product::validateStockInvariant)
                .as("full stock invariant must hold after release")
                .doesNotThrowAnyException();

        log.info("✓ Bounds verified: available={} <= total={}, reserved={} >= 0",
                product.getAvailableStock(), product.getTotalStock(), product.getReservedStock());
    }

    // ========== Scenario Generators ==========

    /**
     * Hand-picked edge-case scenarios: releasing the only reserved unit, releasing the
     * entire reserved pool, releasing from a fully reserved product, and large-stock cases.
     *
     * @return stream of release scenarios
     */
    static Stream<ReleaseScenario> releaseScenarios() {
        return Stream.of(
                // available=0, reserved=1, release 1 -> everything becomes available
                new ReleaseScenario(0, 1, 1),
                // release the single reserved unit from a mixed product
                new ReleaseScenario(99, 1, 1),
                // release part of the reserved pool
                new ReleaseScenario(50, 50, 25),
                // release the entire reserved pool
                new ReleaseScenario(50, 50, 50),
                // fully reserved product, release all
                new ReleaseScenario(0, 100, 100),
                // fully reserved product, release one
                new ReleaseScenario(0, 100, 1),
                // large stock, small release
                new ReleaseScenario(95_000, 5_000, 1),
                // large stock, large release
                new ReleaseScenario(1, 999, 999),
                // mid-range partial release
                new ReleaseScenario(700, 300, 150),
                // release equal to the full reserved amount on a large product
                new ReleaseScenario(50_000, 50_000, 50_000)
        );
    }

    /**
     * Fixed-seed randomized generator covering the valid release input space broadly.
     *
     * <p>For each scenario it samples a total stock, splits it into a valid
     * available/reserved pair, and picks a release quantity in {@code [1, reserved]} so the
     * release always targets stock that is actually held. This mirrors the precondition the
     * release service enforces (you can only release up to what is reserved) while probing
     * many combinations of magnitudes and ratios.
     *
     * @return stream of 100 randomized release scenarios
     */
    static Stream<ReleaseScenario> randomizedReleaseScenarios() {
        Random random = new Random(SEED);
        int numberOfScenarios = 100;

        List<ReleaseScenario> scenarios = new ArrayList<>(numberOfScenarios);
        for (int i = 0; i < numberOfScenarios; i++) {
            // Total in [1, 100_000].
            long total = 1 + (long) (random.nextDouble() * 100_000);
            // Reserved must be at least 1 so there is something to release; up to total.
            long reserved = 1 + (long) (random.nextDouble() * total);
            if (reserved > total) {
                reserved = total;
            }
            long available = total - reserved;
            // Release somewhere in [1, reserved].
            long release = 1 + (long) (random.nextDouble() * reserved);
            if (release > reserved) {
                release = reserved;
            }

            scenarios.add(new ReleaseScenario(available, reserved, release));
        }

        return scenarios.stream();
    }

    // ========== Test Data Class ==========

    /**
     * One release case: the product's available/reserved split before release and the
     * quantity to release. {@code releaseQuantity} is always in {@code [1, reservedBefore]}.
     */
    static class ReleaseScenario {
        final long availableBefore;
        final long reservedBefore;
        final long releaseQuantity;

        ReleaseScenario(long availableBefore, long reservedBefore, long releaseQuantity) {
            this.availableBefore = availableBefore;
            this.reservedBefore = reservedBefore;
            this.releaseQuantity = releaseQuantity;
        }

        @Override
        public String toString() {
            return String.format("available=%d, reserved=%d, release=%d",
                    availableBefore, reservedBefore, releaseQuantity);
        }
    }

    // ========== Test Utilities ==========

    static Product createProduct(long availableStock, long reservedStock) {
        return Product.builder()
                .id(UUID.randomUUID())
                .sku("TEST-" + UUID.randomUUID())
                .name("Test Product")
                .remark("")
                .totalStock(availableStock + reservedStock)
                .availableStock(availableStock)
                .reservedStock(reservedStock)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    static Reservation createActiveReservation(Product product, long quantity) {
        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(quantity)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .createdAt(LocalDateTime.now())
                .build();
    }
}
