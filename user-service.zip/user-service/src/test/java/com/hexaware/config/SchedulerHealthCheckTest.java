package com.hexaware.config;

import com.hexaware.service.ReservationExpirationScheduler;
import com.hexaware.service.ReservationExpirationScheduler.SchedulerExecutionStats;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.Status;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link SchedulerHealthCheck}.
 *
 * <p>The scheduler is mocked so each test drives the health indicator with a specific
 * {@link SchedulerExecutionStats} snapshot, isolating the status-decision and detail-mapping
 * logic from the persistence layer and the real scheduling infrastructure.
 *
 * <p>Follows the project's testing standards: AAA structure with section comments,
 * {@code methodName_stateUnderTest_expectedBehaviour} naming, AssertJ assertions,
 * {@code @BeforeEach} fixture reset and {@code @InjectMocks} wiring.
 *
 * <p>Validates: Requirements 8.7
 */
@ExtendWith(MockitoExtension.class)
class SchedulerHealthCheckTest {

    @Mock
    private ReservationExpirationScheduler scheduler;

    @InjectMocks
    private SchedulerHealthCheck healthCheck;

    private LocalDateTime now;

    @BeforeEach
    void setUp() {
        now = LocalDateTime.now();
    }

    @Test
    void health_whenSchedulerNeverRan_returnsUp() {
        // Arrange
        SchedulerExecutionStats stats = new SchedulerExecutionStats(
                null, null, null, 0L, 0L, 0L, 0L, 0L);
        when(scheduler.getExecutionStats()).thenReturn(stats);

        // Act
        Health health = healthCheck.health();

        // Assert
        assertThat(health.getStatus()).isEqualTo(Status.UP);
        assertThat(health.getDetails()).containsEntry("lastExecutionTime", "N/A");
        assertThat(health.getDetails()).containsEntry("nextExecutionTime", "N/A");
        assertThat(health.getDetails()).containsEntry("successRate", "100.0%");
    }

    @Test
    void health_whenRecentSuccessfulRunAndHighSuccessRate_returnsUp() {
        // Arrange
        LocalDateTime lastRun = now.minusSeconds(10);
        SchedulerExecutionStats stats = new SchedulerExecutionStats(
                lastRun, lastRun, lastRun.plusSeconds(60), 999L, 1L, 5L, 2L, 42L);
        when(scheduler.getExecutionStats()).thenReturn(stats);

        // Act
        Health health = healthCheck.health();

        // Assert
        assertThat(health.getStatus()).isEqualTo(Status.UP);
        assertThat(health.getDetails()).containsEntry("successRate", "99.9%");
        assertThat(health.getDetails()).containsEntry("errorRate", "0.1%");
        assertThat(health.getDetails()).containsEntry("lastBatchExpiredCount", 5L);
        assertThat(health.getDetails()).containsEntry("lastBatchProductsAffected", 2L);
        assertThat(health.getDetails()).containsEntry("lastBatchDurationMs", 42L);
    }

    @Test
    void health_whenSuccessRateBelowThreshold_returnsDown() {
        // Arrange
        LocalDateTime lastRun = now.minusSeconds(10);
        // 5 successes out of 10 cycles = 50% success rate, below the 90% threshold.
        SchedulerExecutionStats stats = new SchedulerExecutionStats(
                lastRun, lastRun, lastRun.plusSeconds(60), 5L, 5L, 0L, 0L, 10L);
        when(scheduler.getExecutionStats()).thenReturn(stats);

        // Act
        Health health = healthCheck.health();

        // Assert
        assertThat(health.getStatus()).isEqualTo(Status.DOWN);
        assertThat(health.getDetails()).containsEntry("successRate", "50.0%");
        assertThat(health.getDetails()).containsEntry("errorRate", "50.0%");
    }

    @Test
    void health_whenLastSuccessfulRunIsStale_returnsDown() {
        // Arrange: last successful run was 10 minutes ago with a 60s interval (> 5 intervals).
        LocalDateTime lastSuccess = now.minusMinutes(10);
        LocalDateTime lastRun = now.minusSeconds(5);
        SchedulerExecutionStats stats = new SchedulerExecutionStats(
                lastSuccess, lastRun, lastRun.plusSeconds(60), 100L, 0L, 0L, 0L, 3L);
        when(scheduler.getExecutionStats()).thenReturn(stats);

        // Act
        Health health = healthCheck.health();

        // Assert
        assertThat(health.getStatus()).isEqualTo(Status.DOWN);
    }

    @Test
    void health_whenRanButNeverSucceeded_returnsDown() {
        // Arrange: cycles executed but none completed successfully (lastSuccess == null).
        LocalDateTime lastRun = now.minusSeconds(5);
        SchedulerExecutionStats stats = new SchedulerExecutionStats(
                null, lastRun, lastRun.plusSeconds(60), 0L, 3L, 0L, 0L, 7L);
        when(scheduler.getExecutionStats()).thenReturn(stats);

        // Act
        Health health = healthCheck.health();

        // Assert
        assertThat(health.getStatus()).isEqualTo(Status.DOWN);
        assertThat(health.getDetails()).containsEntry("errorRate", "100.0%");
        assertThat(health.getDetails()).containsEntry("lastSuccessfulExecutionTime", "N/A");
    }

    @Test
    void health_whenHealthy_includesExecutionTimestampDetails() {
        // Arrange
        LocalDateTime lastRun = now.minusSeconds(15);
        LocalDateTime nextRun = lastRun.plusSeconds(60);
        SchedulerExecutionStats stats = new SchedulerExecutionStats(
                lastRun, lastRun, nextRun, 10L, 0L, 1L, 1L, 20L);
        when(scheduler.getExecutionStats()).thenReturn(stats);

        // Act
        Health health = healthCheck.health();

        // Assert
        assertThat(health.getStatus()).isEqualTo(Status.UP);
        assertThat(health.getDetails()).containsEntry("lastExecutionTime", lastRun);
        assertThat(health.getDetails()).containsEntry("nextExecutionTime", nextRun);
        assertThat(health.getDetails()).containsEntry("totalExecutions", 10L);
    }
}
