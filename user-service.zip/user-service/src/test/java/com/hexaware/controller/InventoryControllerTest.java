package com.hexaware.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hexaware.dto.BulkUpdateRequest;
import com.hexaware.dto.BulkUpdateResponse;
import com.hexaware.dto.CreateReservationRequest;
import com.hexaware.dto.ReleaseResponse;
import com.hexaware.dto.ReservationResponse;
import com.hexaware.dto.StockLevelDTO;
import com.hexaware.exception.GlobalExceptionHandler;
import com.hexaware.exception.InsufficientStockException;
import com.hexaware.exception.LockTimeoutException;
import com.hexaware.repository.ProductRepository;
import com.hexaware.service.ReservationReleaseService;
import com.hexaware.service.ReservationService;
import com.hexaware.service.StockQueryService;
import com.hexaware.service.StockUpdateService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit tests for {@link InventoryController} using MockMvc with a mocked service
 * layer (no real database, no full application context).
 *
 * <p>These are controller slice tests: they exercise the HTTP adapter behaviour
 * (status codes, Location header, request/response JSON shaping, Idempotency-Key
 * and X-Request-ID header handling, and error mapping through
 * {@link GlobalExceptionHandler}) while all business logic is stubbed out on the
 * four collaborating services.
 *
 * <p>The {@link ProductRepository} is mocked because the {@code @ValidProductExists}
 * constraint on {@link CreateReservationRequest#getProductId()} resolves a
 * Spring-aware validator that queries it during request binding.
 *
 * <p>Security filters are disabled so tests target controller behaviour directly
 * rather than authentication.
 *
 * <p>Validates: Requirements 2.1, 3.1, 1.1, 1.5, 5.1
 */
@WebMvcTest(InventoryController.class)
@AutoConfigureMockMvc(addFilters = false)
@Import(GlobalExceptionHandler.class)
class InventoryControllerTest {

    private static final String BASE = "/api/v1/inventory";
    private static final String IDEMPOTENCY_KEY_HEADER = "Idempotency-Key";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private ReservationService reservationService;

    @MockitoBean
    private ReservationReleaseService reservationReleaseService;

    @MockitoBean
    private StockQueryService stockQueryService;

    @MockitoBean
    private StockUpdateService stockUpdateService;

    // Required so the @ValidProductExists validator on CreateReservationRequest
    // can resolve its repository dependency during @Valid binding.
    @MockitoBean
    private ProductRepository productRepository;

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private CreateReservationRequest reservationRequest(UUID orderId, UUID productId, long quantity) {
        return CreateReservationRequest.builder()
                .orderId(orderId)
                .productId(productId)
                .quantity(quantity)
                .build();
    }

    private ReservationResponse reservationResponse(UUID reservationId, UUID orderId, UUID productId, long quantity) {
        return ReservationResponse.builder()
                .reservationId(reservationId)
                .orderId(orderId)
                .productId(productId)
                .quantity(quantity)
                .status("ACTIVE")
                .statusLabel("Active")
                .createdAt(LocalDateTime.now())
                .expirationTime(LocalDateTime.now().plusMinutes(15))
                .availableStock(95L)
                .totalStock(150L)
                .build();
    }

    // ---------------------------------------------------------------------
    // POST /reservations
    // ---------------------------------------------------------------------

    @Test
    void createReservation_withValidRequest_returns201WithLocationHeader() throws Exception {
        // Arrange
        UUID orderId = UUID.randomUUID();
        UUID productId = UUID.randomUUID();
        UUID reservationId = UUID.randomUUID();
        CreateReservationRequest request = reservationRequest(orderId, productId, 5L);
        ReservationResponse response = reservationResponse(reservationId, orderId, productId, 5L);

        when(productRepository.existsById(productId)).thenReturn(true);
        when(reservationService.createReservation(any(CreateReservationRequest.class))).thenReturn(response);

        // Act
        var result = mockMvc.perform(post(BASE + "/reservations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isCreated())
                .andExpect(header().string("Location",
                        BASE + "/reservations/" + reservationId))
                .andExpect(jsonPath("$.reservationId").value(reservationId.toString()))
                .andExpect(jsonPath("$.orderId").value(orderId.toString()))
                .andExpect(jsonPath("$.status").value("ACTIVE"))
                .andExpect(jsonPath("$.quantity").value(5));
        verify(reservationService).createReservation(any(CreateReservationRequest.class));
    }

    @Test
    void createReservation_withInsufficientStock_returns409WithAvailableStock() throws Exception {
        // Arrange
        UUID orderId = UUID.randomUUID();
        UUID productId = UUID.randomUUID();
        CreateReservationRequest request = reservationRequest(orderId, productId, 50L);

        when(productRepository.existsById(productId)).thenReturn(true);
        when(reservationService.createReservation(any(CreateReservationRequest.class)))
                .thenThrow(new InsufficientStockException(productId, 10L, 50L));

        // Act
        var result = mockMvc.perform(post(BASE + "/reservations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isConflict())
                .andExpect(jsonPath("$.error").value("INSUFFICIENT_STOCK"))
                .andExpect(jsonPath("$.httpStatus").value(409))
                .andExpect(jsonPath("$.details.availableStock").value(10))
                .andExpect(jsonPath("$.details.requestedQuantity").value(50))
                .andExpect(jsonPath("$.details.productId").value(productId.toString()));
    }

    @Test
    void createReservation_whenLockTimeout_returns503WithRetryHint() throws Exception {
        // Arrange
        UUID orderId = UUID.randomUUID();
        UUID productId = UUID.randomUUID();
        CreateReservationRequest request = reservationRequest(orderId, productId, 5L);

        when(productRepository.existsById(productId)).thenReturn(true);
        when(reservationService.createReservation(any(CreateReservationRequest.class)))
                .thenThrow(new LockTimeoutException("Could not acquire lock on product", 250L));

        // Act
        var result = mockMvc.perform(post(BASE + "/reservations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.error").value("LOCK_TIMEOUT"))
                .andExpect(jsonPath("$.httpStatus").value(503))
                .andExpect(jsonPath("$.retryAfter").value(250));
    }

    @Test
    void createReservation_withIdempotencyKeyHeader_appliesKeyToRequest() throws Exception {
        // Arrange
        UUID orderId = UUID.randomUUID();
        UUID productId = UUID.randomUUID();
        UUID reservationId = UUID.randomUUID();
        String idempotencyKey = "f47ac10b-58cc-4372-a567-0e02b2c3d479";
        CreateReservationRequest request = reservationRequest(orderId, productId, 5L);
        ReservationResponse response = reservationResponse(reservationId, orderId, productId, 5L);

        when(productRepository.existsById(productId)).thenReturn(true);
        when(reservationService.createReservation(any(CreateReservationRequest.class))).thenReturn(response);

        // Act
        var result = mockMvc.perform(post(BASE + "/reservations")
                .header(IDEMPOTENCY_KEY_HEADER, idempotencyKey)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isCreated());
        org.mockito.ArgumentCaptor<CreateReservationRequest> captor =
                org.mockito.ArgumentCaptor.forClass(CreateReservationRequest.class);
        verify(reservationService).createReservation(captor.capture());
        org.assertj.core.api.Assertions.assertThat(captor.getValue().getIdempotencyKey())
                .isEqualTo(idempotencyKey);
    }

    @Test
    void createReservation_withMissingOrderId_returns400() throws Exception {
        // Arrange
        UUID productId = UUID.randomUUID();
        CreateReservationRequest request = reservationRequest(null, productId, 5L);

        when(productRepository.existsById(productId)).thenReturn(true);

        // Act
        var result = mockMvc.perform(post(BASE + "/reservations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isBadRequest());
    }

    // ---------------------------------------------------------------------
    // DELETE /reservations/{reservationId}
    // ---------------------------------------------------------------------

    @Test
    void releaseReservation_withActiveReservation_returns200AndReleasesStock() throws Exception {
        // Arrange
        UUID reservationId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();
        UUID productId = UUID.randomUUID();
        ReleaseResponse response = ReleaseResponse.builder()
                .reservationId(reservationId)
                .orderId(orderId)
                .productId(productId)
                .quantity(5L)
                .status("RELEASED")
                .releasedAt(LocalDateTime.now())
                .availableStock(100L)
                .idempotent(false)
                .build();

        when(reservationReleaseService.releaseReservation(eq(reservationId), isNull())).thenReturn(response);

        // Act
        var result = mockMvc.perform(delete(BASE + "/reservations/{reservationId}", reservationId));

        // Assert
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.reservationId").value(reservationId.toString()))
                .andExpect(jsonPath("$.status").value("RELEASED"))
                .andExpect(jsonPath("$.idempotent").value(false));
        verify(reservationReleaseService).releaseReservation(eq(reservationId), isNull());
    }

    @Test
    void releaseReservation_whenAlreadyReleased_returns200WithIdempotentTrue() throws Exception {
        // Arrange
        UUID reservationId = UUID.randomUUID();
        ReleaseResponse response = ReleaseResponse.builder()
                .reservationId(reservationId)
                .status("RELEASED")
                .releasedAt(LocalDateTime.now())
                .availableStock(100L)
                .idempotent(true)
                .build();

        when(reservationReleaseService.releaseReservation(eq(reservationId), isNull())).thenReturn(response);

        // Act
        var result = mockMvc.perform(delete(BASE + "/reservations/{reservationId}", reservationId));

        // Assert
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.idempotent").value(true))
                .andExpect(jsonPath("$.status").value("RELEASED"));
    }

    @Test
    void releaseReservation_withIdempotencyKeyHeader_passesKeyToService() throws Exception {
        // Arrange
        UUID reservationId = UUID.randomUUID();
        String idempotencyKey = "release-key-123";
        ReleaseResponse response = ReleaseResponse.builder()
                .reservationId(reservationId)
                .status("RELEASED")
                .idempotent(false)
                .build();

        when(reservationReleaseService.releaseReservation(eq(reservationId), eq(idempotencyKey)))
                .thenReturn(response);

        // Act
        var result = mockMvc.perform(delete(BASE + "/reservations/{reservationId}", reservationId)
                .header(IDEMPOTENCY_KEY_HEADER, idempotencyKey));

        // Assert
        result.andExpect(status().isOk());
        verify(reservationReleaseService).releaseReservation(eq(reservationId), eq(idempotencyKey));
    }

    // ---------------------------------------------------------------------
    // DELETE /reservations/by-order/{orderId}
    // ---------------------------------------------------------------------

    @Test
    void releaseReservationByOrder_withActiveReservation_returns200AndReleasesStock() throws Exception {
        // Arrange
        UUID orderId = UUID.randomUUID();
        UUID reservationId = UUID.randomUUID();
        ReleaseResponse response = ReleaseResponse.builder()
                .reservationId(reservationId)
                .orderId(orderId)
                .quantity(3L)
                .status("RELEASED")
                .releasedAt(LocalDateTime.now())
                .availableStock(50L)
                .idempotent(false)
                .build();

        when(reservationReleaseService.releaseReservationByOrderId(eq(orderId), isNull())).thenReturn(response);

        // Act
        var result = mockMvc.perform(delete(BASE + "/reservations/by-order/{orderId}", orderId));

        // Assert
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.orderId").value(orderId.toString()))
                .andExpect(jsonPath("$.reservationId").value(reservationId.toString()))
                .andExpect(jsonPath("$.status").value("RELEASED"));
        verify(reservationReleaseService).releaseReservationByOrderId(eq(orderId), isNull());
    }

    @Test
    void releaseReservationByOrder_withIdempotencyKeyHeader_passesKeyToService() throws Exception {
        // Arrange
        UUID orderId = UUID.randomUUID();
        String idempotencyKey = "order-release-key-456";
        ReleaseResponse response = ReleaseResponse.builder()
                .orderId(orderId)
                .status("RELEASED")
                .idempotent(false)
                .build();

        when(reservationReleaseService.releaseReservationByOrderId(eq(orderId), eq(idempotencyKey)))
                .thenReturn(response);

        // Act
        var result = mockMvc.perform(delete(BASE + "/reservations/by-order/{orderId}", orderId)
                .header(IDEMPOTENCY_KEY_HEADER, idempotencyKey));

        // Assert
        result.andExpect(status().isOk());
        verify(reservationReleaseService).releaseReservationByOrderId(eq(orderId), eq(idempotencyKey));
    }

    // ---------------------------------------------------------------------
    // GET /products/{productId}/stock
    // ---------------------------------------------------------------------

    @Test
    void getStockLevel_withExistingProduct_returns200WithStockLevel() throws Exception {
        // Arrange
        UUID productId = UUID.randomUUID();
        StockLevelDTO dto = StockLevelDTO.builder()
                .productId(productId)
                .sku("PROD-001")
                .name("Test Product")
                .totalStock(150L)
                .availableStock(95L)
                .reservedStock(55L)
                .activeReservations(3L)
                .lastUpdatedAt(LocalDateTime.now())
                .invariantValid(true)
                .build();

        when(stockQueryService.getStockLevel(productId)).thenReturn(dto);

        // Act
        var result = mockMvc.perform(get(BASE + "/products/{productId}/stock", productId));

        // Assert
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.productId").value(productId.toString()))
                .andExpect(jsonPath("$.sku").value("PROD-001"))
                .andExpect(jsonPath("$.totalStock").value(150))
                .andExpect(jsonPath("$.availableStock").value(95))
                .andExpect(jsonPath("$.reservedStock").value(55));
        verify(stockQueryService).getStockLevel(productId);
    }

    // ---------------------------------------------------------------------
    // POST /products/stock/batch
    // ---------------------------------------------------------------------

    @Test
    void getStockLevels_withMultipleProducts_returns200WithLevelsForEach() throws Exception {
        // Arrange
        UUID productIdA = UUID.randomUUID();
        UUID productIdB = UUID.randomUUID();
        StockLevelDTO dtoA = StockLevelDTO.builder()
                .productId(productIdA).sku("PROD-001").totalStock(100L)
                .availableStock(60L).reservedStock(40L).build();
        StockLevelDTO dtoB = StockLevelDTO.builder()
                .productId(productIdB).sku("PROD-002").totalStock(200L)
                .availableStock(150L).reservedStock(50L).build();

        when(stockQueryService.getStockLevels(anyList())).thenReturn(List.of(dtoA, dtoB));

        // Act
        var result = mockMvc.perform(post(BASE + "/products/stock/batch")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(List.of(productIdA, productIdB))));

        // Assert
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].productId").value(productIdA.toString()))
                .andExpect(jsonPath("$[1].productId").value(productIdB.toString()));
        verify(stockQueryService).getStockLevels(anyList());
    }

    // ---------------------------------------------------------------------
    // POST /bulk-update
    // ---------------------------------------------------------------------

    @Test
    void bulkUpdateStock_withValidRequest_returns200WithAllProductsUpdated() throws Exception {
        // Arrange
        UUID productIdA = UUID.randomUUID();
        UUID productIdB = UUID.randomUUID();
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(List.of(
                        BulkUpdateRequest.BulkStockUpdateEntry.builder()
                                .productId(productIdA).newTotalStock(150L)
                                .reason("Restock shipment S-2024-001").build(),
                        BulkUpdateRequest.BulkStockUpdateEntry.builder()
                                .productId(productIdB).newTotalStock(250L)
                                .reason("Restock shipment S-2024-001").build()))
                .build();

        BulkUpdateResponse response = BulkUpdateResponse.builder()
                .status("SUCCESS")
                .updatedProducts(List.of(
                        BulkUpdateResponse.BulkUpdateResultEntry.builder()
                                .productId(productIdA).sku("PROD-001")
                                .previousTotalStock(100L).newTotalStock(150L)
                                .availableStock(95L).reservedStock(55L).build(),
                        BulkUpdateResponse.BulkUpdateResultEntry.builder()
                                .productId(productIdB).sku("PROD-002")
                                .previousTotalStock(200L).newTotalStock(250L)
                                .availableStock(170L).reservedStock(80L).build()))
                .timestamp(LocalDateTime.now())
                .requestId("bulk-req-789")
                .build();

        when(stockUpdateService.bulkUpdateStock(any(BulkUpdateRequest.class))).thenReturn(response);

        // Act
        var result = mockMvc.perform(post(BASE + "/bulk-update")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("SUCCESS"))
                .andExpect(jsonPath("$.updatedProducts.length()").value(2))
                .andExpect(jsonPath("$.updatedProducts[0].productId").value(productIdA.toString()))
                .andExpect(jsonPath("$.updatedProducts[1].productId").value(productIdB.toString()));
        verify(stockUpdateService).bulkUpdateStock(any(BulkUpdateRequest.class));
    }

    @Test
    void bulkUpdateStock_whenStockBelowReserved_returns409AndAppliesNothing() throws Exception {
        // Arrange
        UUID productId = UUID.randomUUID();
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(List.of(
                        BulkUpdateRequest.BulkStockUpdateEntry.builder()
                                .productId(productId).newTotalStock(50L)
                                .reason("Inventory correction").build()))
                .build();

        when(stockUpdateService.bulkUpdateStock(any(BulkUpdateRequest.class)))
                .thenThrow(new com.hexaware.exception.InvalidStockAfterReservationsException(
                        productId, 50L, 55L));

        // Act
        var result = mockMvc.perform(post(BASE + "/bulk-update")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isConflict())
                .andExpect(jsonPath("$.error").value("INVALID_STOCK_AFTER_RESERVATIONS"))
                .andExpect(jsonPath("$.details.productId").value(productId.toString()));
    }

    @Test
    void bulkUpdateStock_withEmptyUpdates_returns400() throws Exception {
        // Arrange
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(List.of())
                .build();

        // Act
        var result = mockMvc.perform(post(BASE + "/bulk-update")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isBadRequest());
    }

    @Test
    void bulkUpdateStock_withIdempotencyKeyHeader_isAccepted() throws Exception {
        // Arrange
        UUID productId = UUID.randomUUID();
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(List.of(
                        BulkUpdateRequest.BulkStockUpdateEntry.builder()
                                .productId(productId).newTotalStock(150L)
                                .reason("Restock").build()))
                .build();
        BulkUpdateResponse response = BulkUpdateResponse.builder()
                .status("SUCCESS")
                .updatedProducts(List.of())
                .timestamp(LocalDateTime.now())
                .requestId("bulk-req-999")
                .build();

        when(stockUpdateService.bulkUpdateStock(any(BulkUpdateRequest.class))).thenReturn(response);

        // Act
        var result = mockMvc.perform(post(BASE + "/bulk-update")
                .header(IDEMPOTENCY_KEY_HEADER, "bulk-idem-key-1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)));

        // Assert
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("SUCCESS"));
        verify(stockUpdateService).bulkUpdateStock(any(BulkUpdateRequest.class));
    }
}
