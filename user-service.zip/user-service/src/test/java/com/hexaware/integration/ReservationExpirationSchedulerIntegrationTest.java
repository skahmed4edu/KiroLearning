package com.hexaware.integration;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationHistory;
import com.hexaware.entity.ReservationStatus;
import com.hexaware.entity.StockAuditLog;
import com.hexaware.entity.StockOperationType;
import com.hexaware.repository.ProductRepository;
import com.hexaware.repository.ReservationHistoryRepository;
import com.hexaware.repository.ReservationRepository;
import com.hexaware.repository.StockAuditLogRepository;
import com.hexaware.service.ReservationExpirationScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.DockerClientFactory;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Full-stack integration tests for {@link ReservationExpirationScheduler}.
 *
 * <p>Unlike the mock-based unit tests (task 13.5), these tests wire the real scheduler
 * against a throwaway PostgreSQL instance so the entire expiration pipeline runs end to
 * end: the real {@code findExpiredReservations} JPQL query, pessimistic product locking,
 * the {@link Product#releaseStock(Long)} stock mutation, the reservation state transition,
 * and the audit writes to both {@code stock_audit_log} and {@code reservation_history}.
 * A mocked repository cannot prove that stock is actually restored or that the audit rows
 * are persisted, which is exactly what task 13.6 asks us to verify.
 *
 * <p>The schema is built by the project's real Flyway migrations and Hibernate stays on
 * {@code ddl-auto=validate} (never generating DDL), matching production. The container's
 * JDBC URL is injected via {@link DynamicPropertySource} using
 * {@link PostgreSQLContainer#getJdbcUrl()} so the randomly-assigned host port is never
 * hardcoded.
 *
 * <p><strong>Docker is required.</strong> These tests start a real container via
 * Testcontainers. When no Docker daemon is available (for example a restricted CI image or
 * a developer sandbox without Docker) the {@code @EnabledIf("dockerAvailable")} guard causes
 * the whole class to be reported as <em>skipped</em> rather than failing the build. With
 * Docker present the suite runs in full. In the environment where this test was authored
 * Docker was NOT available, so the class was observed to be skipped; it is intended to run
 * fully in CI/dev where Docker is present.
 *
 * <p>The processing logic is driven directly via
 * {@link ReservationExpirationScheduler#processExpiredReservations()} rather than waiting
 * for the {@code @Scheduled} trigger (default interval 60s), so the assertions are
 * deterministic and do not depend on wall-clock timing.
 *
 * <p>Requirements: 4.1, 4.2
 */
@SpringBootTest
@Testcontainers
@EnabledIf("dockerAvailable")
@DisplayName("ReservationExpirationScheduler Integration Tests (Testcontainers)")
class ReservationExpirationSchedulerIntegrationTest {

    /**
     * Guard evaluated by JUnit before the Testcontainers extension starts the container.
     * When no Docker environment is present the whole class is skipped instead of failing;
     * with Docker available the full suite runs normally.
     */
    static boolean dockerAvailable() {
        try {
            return DockerClientFactory.instance().isDockerAvailable();
        } catch (Throwable t) {
            return false;
        }
    }

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15-alpine")
            .withDatabaseName("inventory_test")
            .withUsername("test")
            .withPassword("test");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // Never hardcode the mapped port — Testcontainers assigns a random host port.
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        registry.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");

        // Let Flyway build the real inventory schema; Hibernate only validates against it.
        registry.add("spring.flyway.enabled", () -> "true");
        registry.add("spring.jpa.hibernate.ddl-auto", () -> "validate");
    }

    @Autowired
    private ReservationExpirationScheduler scheduler;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private ReservationHistoryRepository reservationHistoryRepository;

    @Autowired
    private StockAuditLogRepository stockAuditLogRepository;

    private Product product;
    private UUID productId;
    private LocalDateTime now;

    @BeforeEach
    void setUp() {
        // Start every test from a clean slate so counts and stock levels are deterministic.
        // Delete children before parents to respect FK constraints.
        reservationHistoryRepository.deleteAll();
        stockAuditLogRepository.deleteAll();
        reservationRepository.deleteAll();
        productRepository.deleteAll();

        now = LocalDateTime.now();

        // Realistic fake product: 100 total units, 20 already reserved by two 10-unit holds.
        product = productRepository.saveAndFlush(Product.builder()
                .sku("WIDGET-" + UUID.randomUUID())
                .name("Aluminium Travel Mug")
                .remark("expiration-job integration fixture")
                .totalStock(100L)
                .availableStock(80L)
                .reservedStock(20L)
                .build());
        productId = product.getId();
    }

    /**
     * Persists a reservation directly. {@code @PrePersist} overwrites {@code createdAt} with
     * wall-clock time, so callers that care about expiry rely on the explicit {@code status}
     * and {@code expirationTime} rather than {@code createdAt}.
     */
    private Reservation persistReservation(ReservationStatus status, LocalDateTime expirationTime) {
        Reservation reservation = Reservation.builder()
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(10L)
                .status(status)
                .expirationTime(expirationTime)
                .createdAt(expirationTime.minusMinutes(15))
                .expiredAt(status == ReservationStatus.EXPIRED ? now : null)
                .build();
        return reservationRepository.saveAndFlush(reservation);
    }

    @Test
    @DisplayName("processExpiredReservations_withTwoExpiredActiveReservations_marksExpiredAndRestoresStock")
    void processExpiredReservations_withTwoExpiredActiveReservations_marksExpiredAndRestoresStock() {
        // Arrange — two ACTIVE reservations (10 units each) whose TTL has already elapsed.
        Reservation firstExpired = persistReservation(ReservationStatus.ACTIVE, now.minusMinutes(5));
        Reservation secondExpired = persistReservation(ReservationStatus.ACTIVE, now.minusMinutes(1));

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert — both reservations transitioned to EXPIRED.
        assertThat(expiredCount).isEqualTo(2);
        assertThat(reservationRepository.findById(firstExpired.getId()))
                .get()
                .satisfies(r -> {
                    assertThat(r.getStatus()).isEqualTo(ReservationStatus.EXPIRED);
                    assertThat(r.getExpiredAt()).isNotNull();
                });
        assertThat(reservationRepository.findById(secondExpired.getId()))
                .get()
                .satisfies(r -> assertThat(r.getStatus()).isEqualTo(ReservationStatus.EXPIRED));

        // Assert — 20 units restored: available 80 -> 100, reserved 20 -> 0.
        Product refreshed = productRepository.findById(productId).orElseThrow();
        assertThat(refreshed.getAvailableStock()).isEqualTo(100L);
        assertThat(refreshed.getReservedStock()).isZero();
        assertThat(refreshed.getTotalStock()).isEqualTo(100L);

        // Assert — one EXPIRE audit row per product carrying the total restored quantity.
        List<StockAuditLog> auditLogs =
                stockAuditLogRepository.findByProductIdAndOperationType(productId, StockOperationType.EXPIRE);
        assertThat(auditLogs).hasSize(1);
        assertThat(auditLogs.get(0).getQuantityChange()).isEqualTo(20L);
        assertThat(auditLogs.get(0).getAvailableStockBefore()).isEqualTo(80L);
        assertThat(auditLogs.get(0).getAvailableStockAfter()).isEqualTo(100L);

        // Assert — one reservation_history row per expired reservation (ACTIVE -> EXPIRED).
        List<ReservationHistory> history = reservationHistoryRepository.findByProductId(productId);
        assertThat(history)
                .hasSize(2)
                .allSatisfy(h -> {
                    assertThat(h.getOldStatus()).isEqualTo(ReservationStatus.ACTIVE.name());
                    assertThat(h.getNewStatus()).isEqualTo(ReservationStatus.EXPIRED.name());
                    assertThat(h.getQuantity()).isEqualTo(10L);
                });
    }

    @Test
    @DisplayName("processExpiredReservations_withNotYetExpiredActiveReservation_leavesItUntouched")
    void processExpiredReservations_withNotYetExpiredActiveReservation_leavesItUntouched() {
        // Arrange — one expired reservation and one that is still well within its TTL.
        Reservation expired = persistReservation(ReservationStatus.ACTIVE, now.minusMinutes(5));
        Reservation notYetExpired = persistReservation(ReservationStatus.ACTIVE, now.plusMinutes(30));

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert — only the past-TTL reservation was expired.
        assertThat(expiredCount).isEqualTo(1);
        assertThat(reservationRepository.findById(expired.getId()))
                .get()
                .satisfies(r -> assertThat(r.getStatus()).isEqualTo(ReservationStatus.EXPIRED));
        assertThat(reservationRepository.findById(notYetExpired.getId()))
                .get()
                .satisfies(r -> {
                    assertThat(r.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
                    assertThat(r.getExpiredAt()).isNull();
                });

        // Assert — only the 10 units from the expired reservation were restored.
        Product refreshed = productRepository.findById(productId).orElseThrow();
        assertThat(refreshed.getAvailableStock()).isEqualTo(90L);
        assertThat(refreshed.getReservedStock()).isEqualTo(10L);

        // Assert — the still-ACTIVE reservation produced no history row.
        List<ReservationHistory> history = reservationHistoryRepository.findByProductId(productId);
        assertThat(history)
                .hasSize(1)
                .allSatisfy(h -> assertThat(h.getQuantity()).isEqualTo(10L));
    }

    @Test
    @DisplayName("processExpiredReservations_whenRunTwice_isIdempotentAndDoesNotDoubleRestoreStock")
    void processExpiredReservations_whenRunTwice_isIdempotentAndDoesNotDoubleRestoreStock() {
        // Arrange — a single ACTIVE reservation past its TTL.
        Reservation expired = persistReservation(ReservationStatus.ACTIVE, now.minusMinutes(5));

        // Act — run the expiration cycle twice; the second run must be a no-op.
        int firstRun = scheduler.processExpiredReservations();
        int secondRun = scheduler.processExpiredReservations();

        // Assert — first run expires one reservation, second run finds nothing to do.
        assertThat(firstRun).isEqualTo(1);
        assertThat(secondRun).isZero();

        // Assert — reservation is EXPIRED exactly once.
        Optional<Reservation> reloaded = reservationRepository.findById(expired.getId());
        assertThat(reloaded)
                .get()
                .satisfies(r -> assertThat(r.getStatus()).isEqualTo(ReservationStatus.EXPIRED));

        // Assert — stock restored exactly once (no double-restoration): available 80 -> 90.
        Product refreshed = productRepository.findById(productId).orElseThrow();
        assertThat(refreshed.getAvailableStock()).isEqualTo(90L);
        assertThat(refreshed.getReservedStock()).isEqualTo(10L);

        // Assert — exactly one EXPIRE audit row and one history row were written across both runs.
        assertThat(stockAuditLogRepository.findByProductIdAndOperationType(productId, StockOperationType.EXPIRE))
                .hasSize(1);
        assertThat(reservationHistoryRepository.findByProductId(productId))
                .hasSize(1);
    }

    @Test
    @DisplayName("processExpiredReservations_whenNoReservationsAreExpired_restoresNothing")
    void processExpiredReservations_whenNoReservationsAreExpired_restoresNothing() {
        // Arrange — only future-dated ACTIVE reservations exist.
        persistReservation(ReservationStatus.ACTIVE, now.plusMinutes(10));
        persistReservation(ReservationStatus.ACTIVE, now.plusMinutes(45));

        // Act
        int expiredCount = scheduler.processExpiredReservations();

        // Assert — nothing expired, stock unchanged, no audit/history rows written.
        assertThat(expiredCount).isZero();
        Product refreshed = productRepository.findById(productId).orElseThrow();
        assertThat(refreshed.getAvailableStock()).isEqualTo(80L);
        assertThat(refreshed.getReservedStock()).isEqualTo(20L);
        assertThat(stockAuditLogRepository.findByProductIdAndOperationType(productId, StockOperationType.EXPIRE))
                .isEmpty();
        assertThat(reservationHistoryRepository.findByProductId(productId)).isEmpty();
    }
}
