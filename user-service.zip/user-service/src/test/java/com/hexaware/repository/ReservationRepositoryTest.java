package com.hexaware.repository;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ReservationRepository with status-aware queries and pessimistic locking.
 * 
 * Tests verify:
 * 1. findByIdWithLock() correctly acquires pessimistic write locks on reservations
 * 2. findByOrderId() retrieves reservations by order ID
 * 3. findByOrderIdWithLock() atomically finds and locks by order ID
 * 4. findExpiredReservations() returns only ACTIVE reservations past TTL
 * 5. findActiveReservationsByProductId() filters by status and product
 * 6. findByIdempotencyKeyAndOrderId() prevents duplicate reservations
 * 7. findAllActiveReservations() returns all active reservations
 * 8. countByProductIdAndStatus() aggregates by product and status
 * 9. findByCreatedAtBetween() queries time ranges
 * 10. findReleasedByOrderId() finds released reservations
 * 
 * INTEGRATION TESTING NOTE:
 * Actual lock timeout testing (LockAcquisitionFailedException) and time-based
 * expiration filtering require:
 * - Real database connections
 * - Multiple concurrent transactions
 * - Controlled clock/time for expiration testing
 * - Use of Testcontainers with PostgreSQL
 * - These tests are in ReservationRepositoryIntegrationTest
 * 
 * Requirements: 2.5, 3.1, 4.1, 4.6
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ReservationRepository Unit Tests")
class ReservationRepositoryTest {

    @Mock
    private ReservationRepository reservationRepository;

    private Reservation testReservation;
    private UUID testReservationId;
    private UUID testOrderId;
    private UUID testProductId;
    private Product testProduct;
    private LocalDateTime testCreatedAt;
    private LocalDateTime testExpirationTime;

    @BeforeEach
    void setUp() {
        // Setup test data
        testReservationId = UUID.randomUUID();
        testOrderId = UUID.randomUUID();
        testProductId = UUID.randomUUID();
        testCreatedAt = LocalDateTime.now().minusMinutes(5);
        testExpirationTime = testCreatedAt.plusMinutes(15);

        // Create test product
        testProduct = Product.builder()
                .id(testProductId)
                .sku("TEST-SKU-001")
                .name("Test Product")
                .totalStock(100L)
                .availableStock(95L)
                .reservedStock(5L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now().minusHours(1))
                .updatedAt(LocalDateTime.now())
                .build();

        // Create test reservation
        testReservation = Reservation.builder()
                .id(testReservationId)
                .orderId(testOrderId)
                .product(testProduct)
                .quantity(5L)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(testExpirationTime)
                .createdAt(testCreatedAt)
                .releasedAt(null)
                .expiredAt(null)
                .idempotencyKey("idempotency-key-001")
                .build();
    }

    // ==================== findByIdWithLock Tests ====================

    @Test
    @DisplayName("findByIdWithLock_withValidId_returnsLockedReservation")
    void findByIdWithLock_withValidId_returnsLockedReservation() {
        // Arrange
        UUID reservationId = testReservationId;
        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.of(testReservation));

        // Act
        Optional<Reservation> result = reservationRepository.findByIdWithLock(reservationId);

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(reservation -> {
                    assertThat(reservation.getId()).isEqualTo(reservationId);
                    assertThat(reservation.getOrderId()).isEqualTo(testOrderId);
                    assertThat(reservation.getProduct().getId()).isEqualTo(testProductId);
                    assertThat(reservation.getQuantity()).isEqualTo(5L);
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
                });
        verify(reservationRepository).findByIdWithLock(reservationId);
    }

    @Test
    @DisplayName("findByIdWithLock_withInvalidId_returnsEmpty")
    void findByIdWithLock_withInvalidId_returnsEmpty() {
        // Arrange
        UUID nonExistentId = UUID.randomUUID();
        when(reservationRepository.findByIdWithLock(nonExistentId)).thenReturn(Optional.empty());

        // Act
        Optional<Reservation> result = reservationRepository.findByIdWithLock(nonExistentId);

        // Assert
        assertThat(result).isEmpty();
        verify(reservationRepository).findByIdWithLock(nonExistentId);
    }

    @Test
    @DisplayName("findByIdWithLock_acquiresPessimisticWriteLock")
    void findByIdWithLock_acquiresPessimisticWriteLock() {
        // Arrange
        UUID reservationId = testReservationId;
        when(reservationRepository.findByIdWithLock(reservationId)).thenReturn(Optional.of(testReservation));

        // Act
        Optional<Reservation> result = reservationRepository.findByIdWithLock(reservationId);

        // Assert
        assertThat(result).isPresent();
        verify(reservationRepository).findByIdWithLock(eq(reservationId));
    }

    // ==================== findByOrderId Tests ====================

    @Test
    @DisplayName("findByOrderId_withValidOrderId_returnsReservations")
    void findByOrderId_withValidOrderId_returnsReservations() {
        // Arrange
        UUID orderId = testOrderId;
        when(reservationRepository.findByOrderId(orderId)).thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findByOrderId(orderId);

        // Assert
        assertThat(results)
                .hasSize(1)
                .extracting(Reservation::getOrderId)
                .containsExactly(orderId);
        verify(reservationRepository).findByOrderId(orderId);
    }

    @Test
    @DisplayName("findByOrderId_withInvalidOrderId_returnsEmptyList")
    void findByOrderId_withInvalidOrderId_returnsEmptyList() {
        // Arrange
        UUID nonExistentOrderId = UUID.randomUUID();
        when(reservationRepository.findByOrderId(nonExistentOrderId)).thenReturn(List.of());

        // Act
        List<Reservation> results = reservationRepository.findByOrderId(nonExistentOrderId);

        // Assert
        assertThat(results).isEmpty();
        verify(reservationRepository).findByOrderId(nonExistentOrderId);
    }

    @Test
    @DisplayName("findByOrderId_withMultipleReservations_returnsAll")
    void findByOrderId_withMultipleReservations_returnsAll() {
        // Arrange
        UUID orderId = testOrderId;
        UUID product2Id = UUID.randomUUID();
        Product product2 = Product.builder()
                .id(product2Id)
                .sku("TEST-SKU-002")
                .name("Test Product 2")
                .totalStock(50L)
                .availableStock(45L)
                .reservedStock(5L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Reservation reservation2 = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(product2)
                .quantity(5L)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(testExpirationTime)
                .createdAt(testCreatedAt)
                .build();

        when(reservationRepository.findByOrderId(orderId))
                .thenReturn(List.of(testReservation, reservation2));

        // Act
        List<Reservation> results = reservationRepository.findByOrderId(orderId);

        // Assert
        assertThat(results)
                .hasSize(2)
                .extracting(Reservation::getOrderId)
                .allMatch(id -> id.equals(orderId));
    }

    // ==================== findByOrderIdWithLock Tests ====================

    @Test
    @DisplayName("findByOrderIdWithLock_withValidOrderId_returnsLockedActiveReservation")
    void findByOrderIdWithLock_withValidOrderId_returnsLockedActiveReservation() {
        // Arrange
        UUID orderId = testOrderId;
        when(reservationRepository.findByOrderIdWithLock(orderId)).thenReturn(Optional.of(testReservation));

        // Act
        Optional<Reservation> result = reservationRepository.findByOrderIdWithLock(orderId);

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(reservation -> {
                    assertThat(reservation.getOrderId()).isEqualTo(orderId);
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
                });
        verify(reservationRepository).findByOrderIdWithLock(orderId);
    }

    @Test
    @DisplayName("findByOrderIdWithLock_withInvalidOrderId_returnsEmpty")
    void findByOrderIdWithLock_withInvalidOrderId_returnsEmpty() {
        // Arrange
        UUID nonExistentOrderId = UUID.randomUUID();
        when(reservationRepository.findByOrderIdWithLock(nonExistentOrderId)).thenReturn(Optional.empty());

        // Act
        Optional<Reservation> result = reservationRepository.findByOrderIdWithLock(nonExistentOrderId);

        // Assert
        assertThat(result).isEmpty();
        verify(reservationRepository).findByOrderIdWithLock(nonExistentOrderId);
    }

    @Test
    @DisplayName("findByOrderIdWithLock_filtersOnlyActiveReservations")
    void findByOrderIdWithLock_filtersOnlyActiveReservations() {
        // Arrange
        UUID orderId = testOrderId;
        Reservation releasedReservation = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(testProduct)
                .quantity(5L)
                .status(ReservationStatus.RELEASED)
                .expirationTime(testExpirationTime)
                .createdAt(testCreatedAt)
                .releasedAt(LocalDateTime.now())
                .build();

        // When looking for active reservation, should not find released one
        when(reservationRepository.findByOrderIdWithLock(orderId)).thenReturn(Optional.empty());

        // Act
        Optional<Reservation> result = reservationRepository.findByOrderIdWithLock(orderId);

        // Assert
        assertThat(result).isEmpty();
        verify(reservationRepository).findByOrderIdWithLock(orderId);
    }

    // ==================== findExpiredReservations Tests ====================

    @Test
    @DisplayName("findExpiredReservations_withExpiredReservations_returnsExpired")
    void findExpiredReservations_withExpiredReservations_returnsExpired() {
        // Arrange
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expiredTime = now.minusMinutes(1);
        Reservation expiredReservation = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(testProduct)
                .quantity(5L)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(expiredTime)
                .createdAt(now.minusMinutes(20))
                .build();

        when(reservationRepository.findExpiredReservations(now))
                .thenReturn(List.of(expiredReservation));

        // Act
        List<Reservation> results = reservationRepository.findExpiredReservations(now);

        // Assert
        assertThat(results)
                .hasSize(1)
                .allSatisfy(reservation -> {
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
                    assertThat(reservation.getExpirationTime()).isBeforeOrEqualTo(now);
                });
        verify(reservationRepository).findExpiredReservations(now);
    }

    @Test
    @DisplayName("findExpiredReservations_withNoExpiredReservations_returnsEmptyList")
    void findExpiredReservations_withNoExpiredReservations_returnsEmptyList() {
        // Arrange
        LocalDateTime now = LocalDateTime.now();
        when(reservationRepository.findExpiredReservations(now)).thenReturn(List.of());

        // Act
        List<Reservation> results = reservationRepository.findExpiredReservations(now);

        // Assert
        assertThat(results).isEmpty();
        verify(reservationRepository).findExpiredReservations(now);
    }

    @Test
    @DisplayName("findExpiredReservations_excludesReleasedReservations")
    void findExpiredReservations_excludesReleasedReservations() {
        // Arrange
        LocalDateTime now = LocalDateTime.now();
        Reservation releasedReservation = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(testProduct)
                .quantity(5L)
                .status(ReservationStatus.RELEASED)
                .expirationTime(now.minusMinutes(1))
                .createdAt(now.minusMinutes(16))
                .releasedAt(now)
                .build();

        // Should only return active reservations
        when(reservationRepository.findExpiredReservations(now)).thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findExpiredReservations(now);

        // Assert
        assertThat(results)
                .allSatisfy(reservation -> 
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE)
                );
        verify(reservationRepository).findExpiredReservations(now);
    }

    @Test
    @DisplayName("findExpiredReservations_returnsOrderedByExpirationTime")
    void findExpiredReservations_returnsOrderedByExpirationTime() {
        // Arrange
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime time1 = now.minusMinutes(10);
        LocalDateTime time2 = now.minusMinutes(5);

        Reservation reservation1 = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(testProduct)
                .quantity(5L)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(time1)
                .createdAt(time1.minusMinutes(15))
                .build();

        Reservation reservation2 = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(testProduct)
                .quantity(3L)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(time2)
                .createdAt(time2.minusMinutes(15))
                .build();

        when(reservationRepository.findExpiredReservations(now))
                .thenReturn(List.of(reservation1, reservation2));

        // Act
        List<Reservation> results = reservationRepository.findExpiredReservations(now);

        // Assert
        assertThat(results)
                .extracting(Reservation::getExpirationTime)
                .isSorted();
        verify(reservationRepository).findExpiredReservations(now);
    }

    // ==================== findActiveReservationsByProductId Tests ====================

    @Test
    @DisplayName("findActiveReservationsByProductId_withActiveReservations_returnsActive")
    void findActiveReservationsByProductId_withActiveReservations_returnsActive() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findActiveReservationsByProductId(productId);

        // Assert
        assertThat(results)
                .hasSize(1)
                .allSatisfy(reservation -> {
                    assertThat(reservation.getProduct().getId()).isEqualTo(productId);
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
                });
        verify(reservationRepository).findActiveReservationsByProductId(productId);
    }

    @Test
    @DisplayName("findActiveReservationsByProductId_withNoActiveReservations_returnsEmptyList")
    void findActiveReservationsByProductId_withNoActiveReservations_returnsEmptyList() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.findActiveReservationsByProductId(productId)).thenReturn(List.of());

        // Act
        List<Reservation> results = reservationRepository.findActiveReservationsByProductId(productId);

        // Assert
        assertThat(results).isEmpty();
        verify(reservationRepository).findActiveReservationsByProductId(productId);
    }

    @Test
    @DisplayName("findActiveReservationsByProductId_excludesReleasedReservations")
    void findActiveReservationsByProductId_excludesReleasedReservations() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findActiveReservationsByProductId(productId);

        // Assert
        assertThat(results)
                .allSatisfy(reservation -> 
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE)
                );
        verify(reservationRepository).findActiveReservationsByProductId(productId);
    }

    @Test
    @DisplayName("findActiveReservationsByProductId_excludesExpiredReservations")
    void findActiveReservationsByProductId_excludesExpiredReservations() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findActiveReservationsByProductId(productId);

        // Assert
        assertThat(results)
                .allSatisfy(reservation -> 
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE)
                );
        verify(reservationRepository).findActiveReservationsByProductId(productId);
    }

    @Test
    @DisplayName("findActiveReservationsByProductId_withMultipleProductIds_returnsOnlyMatching")
    void findActiveReservationsByProductId_withMultipleProductIds_returnsOnlyMatching() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.findActiveReservationsByProductId(productId))
                .thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findActiveReservationsByProductId(productId);

        // Assert
        assertThat(results)
                .allSatisfy(reservation -> 
                    assertThat(reservation.getProduct().getId()).isEqualTo(productId)
                );
        verify(reservationRepository).findActiveReservationsByProductId(productId);
    }

    // ==================== findByIdempotencyKeyAndOrderId Tests ====================

    @Test
    @DisplayName("findByIdempotencyKeyAndOrderId_withValidKeyAndOrderId_returnsReservation")
    void findByIdempotencyKeyAndOrderId_withValidKeyAndOrderId_returnsReservation() {
        // Arrange
        String idempotencyKey = "idempotency-key-001";
        UUID orderId = testOrderId;
        when(reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId))
                .thenReturn(Optional.of(testReservation));

        // Act
        Optional<Reservation> result = reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId);

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(reservation -> {
                    assertThat(reservation.getIdempotencyKey()).isEqualTo(idempotencyKey);
                    assertThat(reservation.getOrderId()).isEqualTo(orderId);
                });
        verify(reservationRepository).findByIdempotencyKeyAndOrderId(idempotencyKey, orderId);
    }

    @Test
    @DisplayName("findByIdempotencyKeyAndOrderId_withInvalidKey_returnsEmpty")
    void findByIdempotencyKeyAndOrderId_withInvalidKey_returnsEmpty() {
        // Arrange
        String invalidKey = "invalid-key";
        UUID orderId = testOrderId;
        when(reservationRepository.findByIdempotencyKeyAndOrderId(invalidKey, orderId))
                .thenReturn(Optional.empty());

        // Act
        Optional<Reservation> result = reservationRepository.findByIdempotencyKeyAndOrderId(invalidKey, orderId);

        // Assert
        assertThat(result).isEmpty();
        verify(reservationRepository).findByIdempotencyKeyAndOrderId(invalidKey, orderId);
    }

    @Test
    @DisplayName("findByIdempotencyKeyAndOrderId_preventsDuplicateReservations")
    void findByIdempotencyKeyAndOrderId_preventsDuplicateReservations() {
        // Arrange
        String idempotencyKey = "idempotency-key-001";
        UUID orderId = testOrderId;
        when(reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId))
                .thenReturn(Optional.of(testReservation));

        // Act - First call should find the reservation (deduplication)
        Optional<Reservation> firstCall = reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId);
        Optional<Reservation> secondCall = reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId);

        // Assert
        assertThat(firstCall).isPresent();
        assertThat(secondCall).isPresent();
        assertThat(firstCall.get().getId()).isEqualTo(secondCall.get().getId());
        verify(reservationRepository, times(2)).findByIdempotencyKeyAndOrderId(idempotencyKey, orderId);
    }

    @Test
    @DisplayName("findByIdempotencyKeyAndOrderId_allowsSameKeyForDifferentOrders")
    void findByIdempotencyKeyAndOrderId_allowsSameKeyForDifferentOrders() {
        // Arrange
        String idempotencyKey = "idempotency-key-001";
        UUID orderId1 = UUID.randomUUID();
        UUID orderId2 = UUID.randomUUID();

        Reservation reservation1 = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId1)
                .product(testProduct)
                .quantity(5L)
                .status(ReservationStatus.ACTIVE)
                .expirationTime(testExpirationTime)
                .createdAt(testCreatedAt)
                .idempotencyKey(idempotencyKey)
                .build();

        when(reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId1))
                .thenReturn(Optional.of(reservation1));
        when(reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId2))
                .thenReturn(Optional.empty());

        // Act
        Optional<Reservation> result1 = reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId1);
        Optional<Reservation> result2 = reservationRepository.findByIdempotencyKeyAndOrderId(idempotencyKey, orderId2);

        // Assert
        assertThat(result1).isPresent();
        assertThat(result2).isEmpty();
    }

    // ==================== findAllActiveReservations Tests ====================

    @Test
    @DisplayName("findAllActiveReservations_withActiveReservations_returnsAll")
    void findAllActiveReservations_withActiveReservations_returnsAll() {
        // Arrange
        when(reservationRepository.findAllActiveReservations()).thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findAllActiveReservations();

        // Assert
        assertThat(results)
                .hasSize(1)
                .allSatisfy(reservation -> 
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.ACTIVE)
                );
        verify(reservationRepository).findAllActiveReservations();
    }

    @Test
    @DisplayName("findAllActiveReservations_withNoActiveReservations_returnsEmptyList")
    void findAllActiveReservations_withNoActiveReservations_returnsEmptyList() {
        // Arrange
        when(reservationRepository.findAllActiveReservations()).thenReturn(List.of());

        // Act
        List<Reservation> results = reservationRepository.findAllActiveReservations();

        // Assert
        assertThat(results).isEmpty();
        verify(reservationRepository).findAllActiveReservations();
    }

    // ==================== countByProductIdAndStatus Tests ====================

    @Test
    @DisplayName("countByProductIdAndStatus_withActiveReservations_returnsCount")
    void countByProductIdAndStatus_withActiveReservations_returnsCount() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.countByProductIdAndStatus(productId, ReservationStatus.ACTIVE))
                .thenReturn(1L);

        // Act
        long count = reservationRepository.countByProductIdAndStatus(productId, ReservationStatus.ACTIVE);

        // Assert
        assertThat(count).isEqualTo(1L);
        verify(reservationRepository).countByProductIdAndStatus(productId, ReservationStatus.ACTIVE);
    }

    @Test
    @DisplayName("countByProductIdAndStatus_withNoReservations_returnsZero")
    void countByProductIdAndStatus_withNoReservations_returnsZero() {
        // Arrange
        UUID productId = UUID.randomUUID();
        when(reservationRepository.countByProductIdAndStatus(productId, ReservationStatus.ACTIVE))
                .thenReturn(0L);

        // Act
        long count = reservationRepository.countByProductIdAndStatus(productId, ReservationStatus.ACTIVE);

        // Assert
        assertThat(count).isZero();
        verify(reservationRepository).countByProductIdAndStatus(productId, ReservationStatus.ACTIVE);
    }

    @Test
    @DisplayName("countByProductIdAndStatus_countsReleased_separately")
    void countByProductIdAndStatus_countsReleased_separately() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.countByProductIdAndStatus(productId, ReservationStatus.RELEASED))
                .thenReturn(2L);

        // Act
        long count = reservationRepository.countByProductIdAndStatus(productId, ReservationStatus.RELEASED);

        // Assert
        assertThat(count).isEqualTo(2L);
        verify(reservationRepository).countByProductIdAndStatus(productId, ReservationStatus.RELEASED);
    }

    // ==================== findByCreatedAtBetween Tests ====================

    @Test
    @DisplayName("findByCreatedAtBetween_withReservationsInRange_returnsMatching")
    void findByCreatedAtBetween_withReservationsInRange_returnsMatching() {
        // Arrange
        LocalDateTime startTime = testCreatedAt.minusMinutes(1);
        LocalDateTime endTime = testCreatedAt.plusMinutes(1);
        when(reservationRepository.findByCreatedAtBetween(startTime, endTime))
                .thenReturn(List.of(testReservation));

        // Act
        List<Reservation> results = reservationRepository.findByCreatedAtBetween(startTime, endTime);

        // Assert
        assertThat(results)
                .hasSize(1)
                .allSatisfy(reservation -> {
                    assertThat(reservation.getCreatedAt()).isAfterOrEqualTo(startTime);
                    assertThat(reservation.getCreatedAt()).isBeforeOrEqualTo(endTime);
                });
        verify(reservationRepository).findByCreatedAtBetween(startTime, endTime);
    }

    @Test
    @DisplayName("findByCreatedAtBetween_withNoReservationsInRange_returnsEmptyList")
    void findByCreatedAtBetween_withNoReservationsInRange_returnsEmptyList() {
        // Arrange
        LocalDateTime startTime = testCreatedAt.minusHours(2);
        LocalDateTime endTime = testCreatedAt.minusHours(1);
        when(reservationRepository.findByCreatedAtBetween(startTime, endTime)).thenReturn(List.of());

        // Act
        List<Reservation> results = reservationRepository.findByCreatedAtBetween(startTime, endTime);

        // Assert
        assertThat(results).isEmpty();
        verify(reservationRepository).findByCreatedAtBetween(startTime, endTime);
    }

    // ==================== findReleasedByOrderId Tests ====================

    @Test
    @DisplayName("findReleasedByOrderId_withReleasedReservations_returnsReleased")
    void findReleasedByOrderId_withReleasedReservations_returnsReleased() {
        // Arrange
        UUID orderId = testOrderId;
        Reservation releasedReservation = Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(orderId)
                .product(testProduct)
                .quantity(5L)
                .status(ReservationStatus.RELEASED)
                .expirationTime(testExpirationTime)
                .createdAt(testCreatedAt)
                .releasedAt(LocalDateTime.now())
                .build();

        when(reservationRepository.findReleasedByOrderId(orderId))
                .thenReturn(List.of(releasedReservation));

        // Act
        List<Reservation> results = reservationRepository.findReleasedByOrderId(orderId);

        // Assert
        assertThat(results)
                .hasSize(1)
                .allSatisfy(reservation -> {
                    assertThat(reservation.getOrderId()).isEqualTo(orderId);
                    assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.RELEASED);
                });
        verify(reservationRepository).findReleasedByOrderId(orderId);
    }

    @Test
    @DisplayName("findReleasedByOrderId_withNoReleasedReservations_returnsEmptyList")
    void findReleasedByOrderId_withNoReleasedReservations_returnsEmptyList() {
        // Arrange
        UUID orderId = UUID.randomUUID();
        when(reservationRepository.findReleasedByOrderId(orderId)).thenReturn(List.of());

        // Act
        List<Reservation> results = reservationRepository.findReleasedByOrderId(orderId);

        // Assert
        assertThat(results).isEmpty();
        verify(reservationRepository).findReleasedByOrderId(orderId);
    }

    // ==================== countActiveByProductId Tests ====================

    @Test
    @DisplayName("countActiveByProductId_withActiveReservations_returnsCount")
    void countActiveByProductId_withActiveReservations_returnsCount() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.countActiveByProductId(productId)).thenReturn(1L);

        // Act
        long count = reservationRepository.countActiveByProductId(productId);

        // Assert
        assertThat(count).isEqualTo(1L);
        verify(reservationRepository).countActiveByProductId(productId);
    }

    @Test
    @DisplayName("countActiveByProductId_withNoReservations_returnsZero")
    void countActiveByProductId_withNoReservations_returnsZero() {
        // Arrange
        UUID productId = UUID.randomUUID();
        when(reservationRepository.countActiveByProductId(productId)).thenReturn(0L);

        // Act
        long count = reservationRepository.countActiveByProductId(productId);

        // Assert
        assertThat(count).isZero();
        verify(reservationRepository).countActiveByProductId(productId);
    }

    // ==================== sumActiveQuantityByProductId Tests ====================

    @Test
    @DisplayName("sumActiveQuantityByProductId_withActiveReservations_returnsSummedQuantity")
    void sumActiveQuantityByProductId_withActiveReservations_returnsSummedQuantity() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.sumActiveQuantityByProductId(productId)).thenReturn(5L);

        // Act
        long sum = reservationRepository.sumActiveQuantityByProductId(productId);

        // Assert
        assertThat(sum).isEqualTo(5L);
        verify(reservationRepository).sumActiveQuantityByProductId(productId);
    }

    @Test
    @DisplayName("sumActiveQuantityByProductId_withNoReservations_returnsZero")
    void sumActiveQuantityByProductId_withNoReservations_returnsZero() {
        // Arrange
        UUID productId = UUID.randomUUID();
        when(reservationRepository.sumActiveQuantityByProductId(productId)).thenReturn(0L);

        // Act
        long sum = reservationRepository.sumActiveQuantityByProductId(productId);

        // Assert
        assertThat(sum).isZero();
        verify(reservationRepository).sumActiveQuantityByProductId(productId);
    }

    @Test
    @DisplayName("sumActiveQuantityByProductId_withMultipleReservations_sumsTotalQuantity")
    void sumActiveQuantityByProductId_withMultipleReservations_sumsTotalQuantity() {
        // Arrange
        UUID productId = testProductId;
        when(reservationRepository.sumActiveQuantityByProductId(productId)).thenReturn(15L);

        // Act
        long sum = reservationRepository.sumActiveQuantityByProductId(productId);

        // Assert
        assertThat(sum).isEqualTo(15L);
        verify(reservationRepository).sumActiveQuantityByProductId(productId);
    }
}
