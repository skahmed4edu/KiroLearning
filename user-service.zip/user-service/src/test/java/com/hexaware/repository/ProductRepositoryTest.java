package com.hexaware.repository;

import com.hexaware.entity.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ProductRepository with pessimistic locking queries.
 * 
 * Tests verify:
 * 1. findByIdWithLock() correctly acquires pessimistic write locks
 * 2. findByIdWithLockSkipLocked() skips locked products appropriately
 * 3. findBySku() retrieves products by SKU
 * 4. findByIdSet() retrieves multiple products
 * 5. findByIdSetWithLock() acquires locks on multiple products in consistent order
 * 
 * INTEGRATION TESTING NOTE:
 * Actual lock timeout testing (LockAcquisitionFailedException) requires:
 * - Real database connections
 * - Multiple concurrent transactions
 * - Use of Testcontainers with PostgreSQL
 * - These tests are in ProductRepositoryIntegrationTest
 * 
 * Requirements: 1.1, 6.1, 6.6, 6.8
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ProductRepository Unit Tests")
class ProductRepositoryTest {

    @Mock
    private ProductRepository productRepository;

    private Product testProduct;
    private UUID testProductId;
    private String testSku;

    @BeforeEach
    void setUp() {
        // Create test product
        testSku = "TEST-SKU-001";
        testProductId = UUID.randomUUID();
        testProduct = Product.builder()
                .id(testProductId)
                .sku(testSku)
                .name("Test Product")
                .totalStock(100L)
                .availableStock(100L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    // ==================== findByIdWithLock Tests ====================

    @Test
    @DisplayName("findByIdWithLock_withValidId_returnsLockedProduct")
    void findByIdWithLock_withValidId_returnsLockedProduct() {
        // Arrange
        UUID productId = testProductId;
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(testProduct));

        // Act
        Optional<Product> result = productRepository.findByIdWithLock(productId);

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(product -> {
                    assertThat(product.getId()).isEqualTo(productId);
                    assertThat(product.getSku()).isEqualTo(testSku);
                    assertThat(product.getTotalStock()).isEqualTo(100L);
                    assertThat(product.getAvailableStock()).isEqualTo(100L);
                });
        
        verify(productRepository).findByIdWithLock(productId);
    }

    @Test
    @DisplayName("findByIdWithLock_withInvalidId_returnsEmpty")
    void findByIdWithLock_withInvalidId_returnsEmpty() {
        // Arrange
        UUID nonExistentId = UUID.randomUUID();
        when(productRepository.findByIdWithLock(nonExistentId)).thenReturn(Optional.empty());

        // Act
        Optional<Product> result = productRepository.findByIdWithLock(nonExistentId);

        // Assert
        assertThat(result).isEmpty();
        verify(productRepository).findByIdWithLock(nonExistentId);
    }

    @Test
    @DisplayName("findByIdWithLock_callsRepositoryMethod")
    void findByIdWithLock_callsRepositoryMethod() {
        // Arrange
        UUID productId = testProductId;
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(testProduct));

        // Act
        productRepository.findByIdWithLock(productId);

        // Assert
        verify(productRepository).findByIdWithLock(eq(productId));
    }

    // ==================== findByIdWithLockSkipLocked Tests ====================

    @Test
    @DisplayName("findByIdWithLockSkipLocked_withValidId_returnsProduct")
    void findByIdWithLockSkipLocked_withValidId_returnsProduct() {
        // Arrange
        UUID productId = testProductId;
        when(productRepository.findByIdWithLockSkipLocked(productId)).thenReturn(Optional.of(testProduct));

        // Act
        Optional<Product> result = productRepository.findByIdWithLockSkipLocked(productId);

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(product -> {
                    assertThat(product.getId()).isEqualTo(productId);
                    assertThat(product.getSku()).isEqualTo(testSku);
                });
        verify(productRepository).findByIdWithLockSkipLocked(productId);
    }

    @Test
    @DisplayName("findByIdWithLockSkipLocked_withInvalidId_returnsEmpty")
    void findByIdWithLockSkipLocked_withInvalidId_returnsEmpty() {
        // Arrange
        UUID nonExistentId = UUID.randomUUID();
        when(productRepository.findByIdWithLockSkipLocked(nonExistentId)).thenReturn(Optional.empty());

        // Act
        Optional<Product> result = productRepository.findByIdWithLockSkipLocked(nonExistentId);

        // Assert
        assertThat(result).isEmpty();
        verify(productRepository).findByIdWithLockSkipLocked(nonExistentId);
    }

    // ==================== findBySku Tests ====================

    @Test
    @DisplayName("findBySku_withValidSku_returnsProduct")
    void findBySku_withValidSku_returnsProduct() {
        // Arrange
        String sku = testSku;
        when(productRepository.findBySku(sku)).thenReturn(Optional.of(testProduct));

        // Act
        Optional<Product> result = productRepository.findBySku(sku);

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(product -> {
                    assertThat(product.getId()).isEqualTo(testProductId);
                    assertThat(product.getSku()).isEqualTo(sku);
                    assertThat(product.getName()).isEqualTo("Test Product");
                });
        verify(productRepository).findBySku(sku);
    }

    @Test
    @DisplayName("findBySku_withInvalidSku_returnsEmpty")
    void findBySku_withInvalidSku_returnsEmpty() {
        // Arrange
        String invalidSku = "NONEXISTENT-SKU";
        when(productRepository.findBySku(invalidSku)).thenReturn(Optional.empty());

        // Act
        Optional<Product> result = productRepository.findBySku(invalidSku);

        // Assert
        assertThat(result).isEmpty();
        verify(productRepository).findBySku(invalidSku);
    }

    @Test
    @DisplayName("findBySku_returnsProductWithCompleteData")
    void findBySku_returnsProductWithCompleteData() {
        // Arrange
        String sku = testSku;
        when(productRepository.findBySku(sku)).thenReturn(Optional.of(testProduct));

        // Act
        Optional<Product> result = productRepository.findBySku(sku);

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(product -> {
                    assertThat(product.getId()).isNotNull();
                    assertThat(product.getSku()).isEqualTo(sku);
                    assertThat(product.getName()).isNotNull();
                    assertThat(product.getTotalStock()).isPositive();
                    assertThat(product.getAvailableStock()).isNotNull();
                    assertThat(product.getReservedStock()).isNotNull();
                    assertThat(product.getCreatedAt()).isNotNull();
                    assertThat(product.getUpdatedAt()).isNotNull();
                });
    }

    // ==================== findByIdSet Tests ====================

    @Test
    @DisplayName("findByIdSet_withValidIds_returnsAllProducts")
    void findByIdSet_withValidIds_returnsAllProducts() {
        // Arrange
        UUID product2Id = UUID.randomUUID();
        Product product2 = Product.builder()
                .id(product2Id)
                .sku("TEST-SKU-002")
                .name("Test Product 2")
                .totalStock(50L)
                .availableStock(50L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Set<UUID> ids = Set.of(testProductId, product2Id);
        List<Product> expectedProducts = List.of(testProduct, product2);
        
        when(productRepository.findByIdSet(ids)).thenReturn(expectedProducts);

        // Act
        List<Product> results = productRepository.findByIdSet(ids);

        // Assert
        assertThat(results)
                .hasSize(2)
                .extracting(Product::getId)
                .containsExactlyInAnyOrder(testProductId, product2Id);
        verify(productRepository).findByIdSet(ids);
    }

    @Test
    @DisplayName("findByIdSet_withEmptySet_returnsEmptyList")
    void findByIdSet_withEmptySet_returnsEmptyList() {
        // Arrange
        Set<UUID> emptyIds = Set.of();
        when(productRepository.findByIdSet(emptyIds)).thenReturn(List.of());

        // Act
        List<Product> results = productRepository.findByIdSet(emptyIds);

        // Assert
        assertThat(results).isEmpty();
        verify(productRepository).findByIdSet(emptyIds);
    }

    @Test
    @DisplayName("findByIdSet_withPartialValidIds_returnsOnlyExistingProducts")
    void findByIdSet_withPartialValidIds_returnsOnlyExistingProducts() {
        // Arrange
        UUID nonExistentId = UUID.randomUUID();
        Set<UUID> ids = Set.of(testProductId, nonExistentId);
        
        when(productRepository.findByIdSet(ids)).thenReturn(List.of(testProduct));

        // Act
        List<Product> results = productRepository.findByIdSet(ids);

        // Assert
        assertThat(results)
                .hasSize(1)
                .extracting(Product::getId)
                .containsExactly(testProductId);
        verify(productRepository).findByIdSet(ids);
    }

    @Test
    @DisplayName("findByIdSet_returnsProductsWithAllFields")
    void findByIdSet_returnsProductsWithAllFields() {
        // Arrange
        Set<UUID> ids = Set.of(testProductId);
        when(productRepository.findByIdSet(ids)).thenReturn(List.of(testProduct));

        // Act
        List<Product> results = productRepository.findByIdSet(ids);

        // Assert
        assertThat(results)
                .hasSize(1)
                .allSatisfy(product -> {
                    assertThat(product.getId()).isNotNull();
                    assertThat(product.getSku()).isNotNull();
                    assertThat(product.getName()).isNotNull();
                    assertThat(product.getTotalStock()).isPositive();
                    assertThat(product.getAvailableStock()).isNotNull();
                    assertThat(product.getReservedStock()).isNotNull();
                });
    }

    // ==================== findByIdSetWithLock Tests ====================

    @Test
    @DisplayName("findByIdSetWithLock_withValidIds_returnsLockedProductsOrderedById")
    void findByIdSetWithLock_withValidIds_returnsLockedProductsOrderedById() {
        // Arrange - Use fixed UUIDs for deterministic sorting
        UUID product1Id = UUID.fromString("00000000-0000-0000-0000-000000000001");
        UUID product2Id = UUID.fromString("00000000-0000-0000-0000-000000000002");
        
        Product product1 = Product.builder()
                .id(product1Id)
                .sku("TEST-SKU-001")
                .name("Test Product 1")
                .totalStock(100L)
                .availableStock(100L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        
        Product product2 = Product.builder()
                .id(product2Id)
                .sku("TEST-SKU-002")
                .name("Test Product 2")
                .totalStock(50L)
                .availableStock(50L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Set<UUID> ids = Set.of(product1Id, product2Id);
        List<Product> orderedProducts = List.of(product1, product2);
        
        when(productRepository.findByIdSetWithLock(ids)).thenReturn(orderedProducts);

        // Act
        List<Product> results = productRepository.findByIdSetWithLock(ids);

        // Assert
        assertThat(results)
                .hasSize(2)
                .extracting(Product::getId)
                .isSorted();
        verify(productRepository).findByIdSetWithLock(ids);
    }

    @Test
    @DisplayName("findByIdSetWithLock_maintainConsistentLockOrder")
    void findByIdSetWithLock_maintainConsistentLockOrder() {
        // Arrange - Create products with IDs that we control for sorting
        // Generate UUIDs that will be sortable for test purposes
        UUID smallerId = UUID.fromString("00000000-0000-0000-0000-000000000001");
        UUID middleId = UUID.fromString("00000000-0000-0000-0000-000000000002");
        UUID largerId = UUID.fromString("00000000-0000-0000-0000-000000000003");
        
        Product product1 = Product.builder()
                .id(smallerId)
                .sku("TEST-SKU-001")
                .name("Test Product 1")
                .totalStock(100L)
                .availableStock(100L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        
        Product product2 = Product.builder()
                .id(middleId)
                .sku("TEST-SKU-002")
                .name("Test Product 2")
                .totalStock(50L)
                .availableStock(50L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        
        Product product3 = Product.builder()
                .id(largerId)
                .sku("TEST-SKU-003")
                .name("Test Product 3")
                .totalStock(25L)
                .availableStock(25L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Set<UUID> ids = Set.of(largerId, smallerId, middleId);

        // Create sorted list (by ID ascending) - this is what the repository should return
        List<Product> sortedProducts = List.of(product1, product2, product3);
        when(productRepository.findByIdSetWithLock(ids)).thenReturn(sortedProducts);

        // Act
        List<Product> results = productRepository.findByIdSetWithLock(ids);

        // Assert
        // Verify consistent ordering (by ID ascending)
        assertThat(results)
                .hasSize(3)
                .extracting(Product::getId)
                .isSorted();
        
        // Verify all products are returned
        assertThat(results)
                .extracting(Product::getId)
                .containsExactlyInAnyOrder(smallerId, middleId, largerId);
    }

    @Test
    @DisplayName("findByIdSetWithLock_withEmptySet_returnsEmptyList")
    void findByIdSetWithLock_withEmptySet_returnsEmptyList() {
        // Arrange
        Set<UUID> emptyIds = Set.of();
        when(productRepository.findByIdSetWithLock(emptyIds)).thenReturn(List.of());

        // Act
        List<Product> results = productRepository.findByIdSetWithLock(emptyIds);

        // Assert
        assertThat(results).isEmpty();
        verify(productRepository).findByIdSetWithLock(emptyIds);
    }

    // ==================== Pessimistic Lock Behavior Tests ====================

    @Test
    @DisplayName("findByIdWithLock_multipleQueriesReturnSameProduct")
    void findByIdWithLock_multipleQueriesReturnSameProduct() {
        // Arrange
        UUID productId = testProductId;
        when(productRepository.findByIdWithLock(productId)).thenReturn(Optional.of(testProduct));

        // Act
        Optional<Product> firstQuery = productRepository.findByIdWithLock(productId);
        Optional<Product> secondQuery = productRepository.findByIdWithLock(productId);

        // Assert
        assertThat(firstQuery).isPresent();
        assertThat(secondQuery).isPresent();
        assertThat(firstQuery.get().getId()).isEqualTo(secondQuery.get().getId());
        verify(productRepository, times(2)).findByIdWithLock(productId);
    }

    @Test
    @DisplayName("findByIdSet_withMultipleCallsToSameIds_returnsSameProducts")
    void findByIdSet_withMultipleCallsToSameIds_returnsSameProducts() {
        // Arrange
        Set<UUID> ids = Set.of(testProductId);
        when(productRepository.findByIdSet(ids))
                .thenReturn(List.of(testProduct))
                .thenReturn(List.of(testProduct));

        // Act
        List<Product> firstCall = productRepository.findByIdSet(ids);
        List<Product> secondCall = productRepository.findByIdSet(ids);

        // Assert
        assertThat(firstCall).isEqualTo(secondCall);
        verify(productRepository, times(2)).findByIdSet(ids);
    }

    @Test
    @DisplayName("findByIdSetWithLock_ensuresAllProductsAreLocked")
    void findByIdSetWithLock_ensuresAllProductsAreLocked() {
        // Arrange
        UUID product2Id = UUID.randomUUID();
        Product product2 = Product.builder()
                .id(product2Id)
                .sku("TEST-SKU-002")
                .name("Test Product 2")
                .totalStock(50L)
                .availableStock(50L)
                .reservedStock(0L)
                .lockVersion(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Set<UUID> ids = Set.of(testProductId, product2Id);
        List<Product> lockedProducts = List.of(testProduct, product2);
        
        when(productRepository.findByIdSetWithLock(ids)).thenReturn(lockedProducts);

        // Act
        List<Product> results = productRepository.findByIdSetWithLock(ids);

        // Assert - All products should be returned (indicating all were locked)
        assertThat(results).hasSize(2);
        assertThat(results.stream().map(Product::getId))
                .containsExactlyInAnyOrder(testProductId, product2Id);
    }
}
