package com.hexaware.repository;

import com.hexaware.entity.Product;
import com.hexaware.entity.Reservation;
import com.hexaware.entity.ReservationStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.junit.jupiter.api.condition.EnabledIf;
import org.testcontainers.DockerClientFactory;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration tests for {@link ReservationRepository} status-aware queries.
 *
 * <p>Unlike {@code ReservationRepositoryTest} (which mocks the repository and can only
 * assert that stubbed values are returned), these tests exercise the <em>real</em> JPQL
 * queries against a throwaway PostgreSQL instance. This is the only way to verify the
 * behaviour that task 6.1 cares about:
 * <ul>
 *   <li>the expiration query returns only ACTIVE reservations whose TTL has elapsed;</li>
 *   <li>the active-reservations query filters strictly by status;</li>
 *   <li>the idempotency-key lookup is scoped by (key, orderId) and prevents duplicates;</li>
 *   <li>the pessimistic-lock lookups return the correct rows.</li>
 * </ul>
 *
 * <p>The schema is created by the project's real Flyway migrations (ddl-auto stays on
 * {@code validate}); {@code @AutoConfigureTestDatabase(replace = NONE)} keeps
 * {@code @DataJpaTest} from swapping in an embedded database.
 *
 * <p><strong>Docker required.</strong> These tests spin up a real container via
 * Testcontainers and are skipped automatically when no Docker environment is available.
 *
 * Requirements: 2.5, 3.1, 4.1, 4.6
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Testcontainers
@EnabledIf("dockerAvailable")
@DisplayName("ReservationRepository Integration Tests (Testcontainers)")
class ReservationRepositoryIntegrationTest {

    /**
     * Guard evaluated by JUnit <em>before</em> the Testcontainers extension starts the
     * container. When no Docker environment is present (e.g. a CI image or workstation
     * without a Docker daemon) the whole class is reported as <em>skipped</em> rather
     * than failing the build. With Docker available the full suite runs normally.
     */
    static boolean dockerAvailable() {
        return DockerClientFactory.instance().isDockerAvailable();
    }

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15-alpine")
            .withDatabaseName("testdb")
            .withUsername("test")
            .withPassword("test");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        // The V2 fixture migration seeds a few PROD-* rows; that is harmless, but we
        // scope every assertion to products we create here so the fixtures never
        // interfere with counts or lookups.
    }

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private ProductRepository productRepository;

    private Product product;
    private UUID productId;
    private LocalDateTime now;

    @BeforeEach
    void setUp() {
        // Start every test from a clean reservation table so counts are deterministic.
        reservationRepository.deleteAll();

        now = LocalDateTime.of(2024, 1, 15, 9, 45, 0);

        product = productRepository.saveAndFlush(Product.builder()
                .sku("SKU-" + UUID.randomUUID())
                .name("Integration Widget")
                .remark("integration-test fixture")
                .totalStock(100L)
                .availableStock(100L)
                .reservedStock(0L)
                .build());
        productId = product.getId();
    }

    /**
     * Persists a reservation. Because {@code @PrePersist} overwrites {@code createdAt}
     * with the wall-clock time, callers that care about status/expiration should rely on
     * the explicitly set {@code status} and {@code expirationTime} rather than createdAt.
     */
    private Reservation persistReservation(UUID orderId,
                                           ReservationStatus status,
                                           LocalDateTime expirationTime,
                                           String idempotencyKey) {
        Reservation reservation = Reservation.builder()
                .orderId(orderId)
                .product(product)
                .quantity(5L)
                .status(status)
                .expirationTime(expirationTime)
                .createdAt(expirationTime.minusMinutes(15))
                .releasedAt(status == ReservationStatus.RELEASED ? now : null)
                .expiredAt(status == ReservationStatus.EXPIRED ? now : null)
                .idempotencyKey(idempotencyKey)
                .build();
        return reservationRepository.saveAndFlush(reservation);
    }

    @Nested
    @DisplayName("findExpiredReservations")
    class FindExpiredReservations {

        @Test
        void findExpiredReservations_withActivePastTtl_returnsOnlyThoseReservations() {
            // Arrange
            Reservation expiredActive =
                    persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.minusMinutes(1), null);
            // Not yet expired (expiration in the future) -> excluded
            persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.plusMinutes(10), null);

            // Act
            List<Reservation> expired = reservationRepository.findExpiredReservations(now);

            // Assert
            assertThat(expired)
                    .extracting(Reservation::getId)
                    .containsExactly(expiredActive.getId());
        }

        @Test
        void findExpiredReservations_whenReservationReleasedOrExpired_excludesNonActiveStatuses() {
            // Arrange: both have an elapsed TTL but are no longer ACTIVE
            persistReservation(UUID.randomUUID(), ReservationStatus.RELEASED, now.minusMinutes(5), null);
            persistReservation(UUID.randomUUID(), ReservationStatus.EXPIRED, now.minusMinutes(5), null);

            // Act
            List<Reservation> expired = reservationRepository.findExpiredReservations(now);

            // Assert
            assertThat(expired).isEmpty();
        }

        @Test
        void findExpiredReservations_atExactTtlBoundary_includesReservation() {
            // Arrange: expirationTime == now, query uses expirationTime <= :now
            Reservation boundary =
                    persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now, null);

            // Act
            List<Reservation> expired = reservationRepository.findExpiredReservations(now);

            // Assert
            assertThat(expired)
                    .extracting(Reservation::getId)
                    .containsExactly(boundary.getId());
        }

        @Test
        void findExpiredReservations_withMultipleExpired_returnsOrderedByExpirationTimeAscending() {
            // Arrange
            Reservation older =
                    persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.minusMinutes(30), null);
            Reservation newer =
                    persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.minusMinutes(5), null);

            // Act
            List<Reservation> expired = reservationRepository.findExpiredReservations(now);

            // Assert
            assertThat(expired)
                    .extracting(Reservation::getId)
                    .containsExactly(older.getId(), newer.getId());
            assertThat(expired)
                    .extracting(Reservation::getExpirationTime)
                    .isSorted();
        }
    }

    @Nested
    @DisplayName("findActiveReservationsByProductId")
    class FindActiveReservationsByProductId {

        @Test
        void findActiveReservationsByProductId_withMixedStatuses_returnsOnlyActive() {
            // Arrange
            Reservation active =
                    persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.plusMinutes(15), null);
            persistReservation(UUID.randomUUID(), ReservationStatus.RELEASED, now.plusMinutes(15), null);
            persistReservation(UUID.randomUUID(), ReservationStatus.EXPIRED, now.minusMinutes(1), null);

            // Act
            List<Reservation> result = reservationRepository.findActiveReservationsByProductId(productId);

            // Assert
            assertThat(result)
                    .extracting(Reservation::getId)
                    .containsExactly(active.getId());
            assertThat(result)
                    .allSatisfy(r -> assertThat(r.getStatus()).isEqualTo(ReservationStatus.ACTIVE));
        }

        @Test
        void findActiveReservationsByProductId_whenNoActiveReservations_returnsEmptyList() {
            // Arrange
            persistReservation(UUID.randomUUID(), ReservationStatus.RELEASED, now.plusMinutes(15), null);

            // Act
            List<Reservation> result = reservationRepository.findActiveReservationsByProductId(productId);

            // Assert
            assertThat(result).isEmpty();
        }

        @Test
        void sumActiveQuantityByProductId_withTwoActiveReservations_sumsOnlyActiveQuantities() {
            // Arrange: two ACTIVE (5 + 5) plus one RELEASED that must be ignored
            persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.plusMinutes(15), null);
            persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.plusMinutes(15), null);
            persistReservation(UUID.randomUUID(), ReservationStatus.RELEASED, now.plusMinutes(15), null);

            // Act
            long sum = reservationRepository.sumActiveQuantityByProductId(productId);

            // Assert
            assertThat(sum).isEqualTo(10L);
        }

        @Test
        void countActiveByProductId_withNoReservations_returnsZero() {
            // Arrange
            UUID unknownProductId = UUID.randomUUID();

            // Act
            long count = reservationRepository.countActiveByProductId(unknownProductId);

            // Assert
            assertThat(count).isZero();
        }
    }

    @Nested
    @DisplayName("findByIdempotencyKeyAndOrderId")
    class FindByIdempotencyKeyAndOrderId {

        @Test
        void findByIdempotencyKeyAndOrderId_whenKeyAndOrderMatch_returnsExistingReservation() {
            // Arrange
            UUID orderId = UUID.randomUUID();
            String key = "idem-key-abc";
            Reservation existing =
                    persistReservation(orderId, ReservationStatus.ACTIVE, now.plusMinutes(15), key);

            // Act
            Optional<Reservation> result =
                    reservationRepository.findByIdempotencyKeyAndOrderId(key, orderId);

            // Assert
            assertThat(result)
                    .isPresent()
                    .get()
                    .satisfies(r -> assertThat(r.getId()).isEqualTo(existing.getId()));
        }

        @Test
        void findByIdempotencyKeyAndOrderId_whenSameKeyButDifferentOrder_returnsEmpty() {
            // Arrange: key is scoped per (key, orderId) pair
            UUID orderId = UUID.randomUUID();
            UUID otherOrderId = UUID.randomUUID();
            String key = "idem-key-shared";
            persistReservation(orderId, ReservationStatus.ACTIVE, now.plusMinutes(15), key);

            // Act
            Optional<Reservation> result =
                    reservationRepository.findByIdempotencyKeyAndOrderId(key, otherOrderId);

            // Assert
            assertThat(result).isEmpty();
        }

        @Test
        void findByIdempotencyKeyAndOrderId_whenKeyUnknown_returnsEmpty() {
            // Arrange
            UUID orderId = UUID.randomUUID();
            persistReservation(orderId, ReservationStatus.ACTIVE, now.plusMinutes(15), "stored-key");

            // Act
            Optional<Reservation> result =
                    reservationRepository.findByIdempotencyKeyAndOrderId("missing-key", orderId);

            // Assert
            assertThat(result).isEmpty();
        }
    }

    @Nested
    @DisplayName("Order-scoped and locking lookups")
    class OrderScopedLookups {

        @Test
        void findByIdWithLock_whenReservationExists_returnsLockedReservation() {
            // Arrange
            Reservation saved =
                    persistReservation(UUID.randomUUID(), ReservationStatus.ACTIVE, now.plusMinutes(15), null);

            // Act
            Optional<Reservation> result = reservationRepository.findByIdWithLock(saved.getId());

            // Assert
            assertThat(result)
                    .isPresent()
                    .get()
                    .satisfies(r -> assertThat(r.getId()).isEqualTo(saved.getId()));
        }

        @Test
        void findByIdWithLock_whenReservationMissing_returnsEmpty() {
            // Arrange
            UUID unknownId = UUID.randomUUID();

            // Act
            Optional<Reservation> result = reservationRepository.findByIdWithLock(unknownId);

            // Assert
            assertThat(result).isEmpty();
        }

        @Test
        void findByOrderIdWithLock_whenActiveReservationExists_returnsOnlyActiveOne() {
            // Arrange: one order with a RELEASED and an ACTIVE reservation
            UUID orderId = UUID.randomUUID();
            persistReservation(orderId, ReservationStatus.RELEASED, now.plusMinutes(15), null);
            Reservation active =
                    persistReservation(orderId, ReservationStatus.ACTIVE, now.plusMinutes(15), null);

            // Act
            Optional<Reservation> result = reservationRepository.findByOrderIdWithLock(orderId);

            // Assert
            assertThat(result)
                    .isPresent()
                    .get()
                    .satisfies(r -> {
                        assertThat(r.getId()).isEqualTo(active.getId());
                        assertThat(r.getStatus()).isEqualTo(ReservationStatus.ACTIVE);
                    });
        }

        @Test
        void findByOrderId_whenOrderHasReservations_returnsAllRegardlessOfStatus() {
            // Arrange
            UUID orderId = UUID.randomUUID();
            persistReservation(orderId, ReservationStatus.ACTIVE, now.plusMinutes(15), null);
            persistReservation(orderId, ReservationStatus.RELEASED, now.plusMinutes(15), null);

            // Act
            List<Reservation> result = reservationRepository.findByOrderId(orderId);

            // Assert
            assertThat(result)
                    .hasSize(2)
                    .allSatisfy(r -> assertThat(r.getOrderId()).isEqualTo(orderId));
        }

        @Test
        void findReleasedByOrderId_whenOrderHasReleasedReservation_returnsOnlyReleased() {
            // Arrange
            UUID orderId = UUID.randomUUID();
            persistReservation(orderId, ReservationStatus.ACTIVE, now.plusMinutes(15), null);
            Reservation released =
                    persistReservation(orderId, ReservationStatus.RELEASED, now.plusMinutes(15), null);

            // Act
            List<Reservation> result = reservationRepository.findReleasedByOrderId(orderId);

            // Assert
            assertThat(result)
                    .extracting(Reservation::getId)
                    .containsExactly(released.getId());
        }
    }
}
