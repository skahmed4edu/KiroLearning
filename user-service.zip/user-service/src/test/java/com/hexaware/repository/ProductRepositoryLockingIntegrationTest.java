package com.hexaware.repository;

import com.hexaware.entity.Product;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.testcontainers.DockerClientFactory;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Integration tests for {@link ProductRepository} pessimistic locking queries.
 *
 * <p>Unlike the mock-based {@link ProductRepositoryTest}, these tests run against a
 * real PostgreSQL instance (via Testcontainers) because the behaviour under test —
 * {@code SELECT ... FOR UPDATE NOWAIT} and {@code SKIP LOCKED} — only manifests when
 * two genuine concurrent transactions contend for the same row. A mocked repository
 * cannot exercise database row-level locking.
 *
 * <p>Covers task 5.1:
 * <ul>
 *   <li>NOWAIT behaviour raises a lock-acquisition failure when the row is already locked</li>
 *   <li>SKIP LOCKED returns empty (skips) a row that is locked by another transaction</li>
 *   <li>Concurrent access to the same product via the locking methods</li>
 * </ul>
 *
 * <p>Requirements: 6.6, 6.8
 */
@SpringBootTest
@Testcontainers
@EnabledIf("dockerAvailable")
@DisplayName("ProductRepository Locking Integration Tests")
class ProductRepositoryLockingIntegrationTest {

    /**
     * These tests require a Docker runtime so Testcontainers can start PostgreSQL.
     * Where Docker is absent (e.g. restricted CI/dev sandboxes) the class is skipped
     * rather than reported as an error — the pessimistic-locking behaviour under test
     * genuinely cannot be exercised without a real database.
     */
    static boolean dockerAvailable() {
        try {
            return DockerClientFactory.instance().isDockerAvailable();
        } catch (Throwable t) {
            return false;
        }
    }

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15-alpine")
            .withDatabaseName("inventory_test")
            .withUsername("test")
            .withPassword("test");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // Never hardcode the mapped port — Testcontainers assigns a random host port.
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        registry.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");

        // Let Flyway build the real inventory schema; Hibernate only validates against it.
        registry.add("spring.flyway.enabled", () -> "true");
        registry.add("spring.jpa.hibernate.ddl-auto", () -> "validate");
    }

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private PlatformTransactionManager transactionManager;

    private TransactionTemplate transactionTemplate;

    private UUID productId;

    @BeforeEach
    void setUp() {
        // Each lock interaction needs its own real, committed/rolled-back transaction,
        // so drive transactions explicitly rather than relying on a test-managed one.
        transactionTemplate = new TransactionTemplate(transactionManager);

        // Reset state between tests so no mutable data leaks across methods.
        productRepository.deleteAll();

        Product product = Product.builder()
                .sku("LOCK-SKU-" + UUID.randomUUID())
                .name("Pessimistic Lock Widget")
                .remark("")
                .totalStock(100L)
                .reservedStock(0L)
                .availableStock(100L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        productId = productRepository.saveAndFlush(product).getId();
    }

    @AfterEach
    void tearDown() {
        productRepository.deleteAll();
    }

    // ==================== findByIdWithLock — NOWAIT contention ====================

    @Test
    @DisplayName("findByIdWithLock_whenRowAlreadyLockedByAnotherTransaction_throwsPessimisticLockingFailure")
    void findByIdWithLock_whenRowAlreadyLockedByAnotherTransaction_throwsPessimisticLockingFailure()
            throws InterruptedException {
        // Arrange — hold a FOR UPDATE lock on the product in a separate transaction/thread.
        CountDownLatch lockHeld = new CountDownLatch(1);
        CountDownLatch releaseLock = new CountDownLatch(1);
        ExecutorService lockHolder = Executors.newSingleThreadExecutor();
        lockHolder.submit(() -> transactionTemplate.execute(status -> {
            productRepository.findByIdWithLock(productId); // acquires the row lock
            lockHeld.countDown();
            await(releaseLock); // keep the transaction (and lock) open
            return null;
        }));
        assertThat(lockHeld.await(10, TimeUnit.SECONDS))
                .as("competing transaction should have acquired the lock")
                .isTrue();

        // Act / Assert — a second NOWAIT acquisition must fail fast rather than block.
        try {
            assertThatThrownBy(() ->
                    transactionTemplate.execute(status -> productRepository.findByIdWithLock(productId)))
                    .isInstanceOf(PessimisticLockingFailureException.class);
        } finally {
            releaseLock.countDown();
            lockHolder.shutdown();
            assertThat(lockHolder.awaitTermination(10, TimeUnit.SECONDS)).isTrue();
        }
    }

    @Test
    @DisplayName("findByIdWithLock_whenRowIsFree_returnsLockedProduct")
    void findByIdWithLock_whenRowIsFree_returnsLockedProduct() {
        // Arrange — no competing transaction holds the lock.

        // Act
        Optional<Product> result = transactionTemplate.execute(status ->
                productRepository.findByIdWithLock(productId));

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(product -> {
                    assertThat(product.getId()).isEqualTo(productId);
                    assertThat(product.getAvailableStock()).isEqualTo(100L);
                });
    }

    // ==================== findByIdWithLockSkipLocked — SKIP LOCKED ====================

    @Test
    @DisplayName("findByIdWithLockSkipLocked_whenRowAlreadyLocked_skipsAndReturnsEmpty")
    void findByIdWithLockSkipLocked_whenRowAlreadyLocked_skipsAndReturnsEmpty() throws InterruptedException {
        // Arrange — hold a lock on the only matching product.
        CountDownLatch lockHeld = new CountDownLatch(1);
        CountDownLatch releaseLock = new CountDownLatch(1);
        ExecutorService lockHolder = Executors.newSingleThreadExecutor();
        lockHolder.submit(() -> transactionTemplate.execute(status -> {
            productRepository.findByIdWithLock(productId);
            lockHeld.countDown();
            await(releaseLock);
            return null;
        }));
        assertThat(lockHeld.await(10, TimeUnit.SECONDS)).isTrue();

        // Act — SKIP LOCKED should skip the locked row instead of blocking or failing.
        Optional<Product> result;
        try {
            result = transactionTemplate.execute(status ->
                    productRepository.findByIdWithLockSkipLocked(productId));
        } finally {
            releaseLock.countDown();
            lockHolder.shutdown();
            assertThat(lockHolder.awaitTermination(10, TimeUnit.SECONDS)).isTrue();
        }

        // Assert — the single matching row was locked, so SKIP LOCKED yields nothing.
        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("findByIdWithLockSkipLocked_whenRowIsFree_returnsProduct")
    void findByIdWithLockSkipLocked_whenRowIsFree_returnsProduct() {
        // Arrange — no competing lock.

        // Act
        Optional<Product> result = transactionTemplate.execute(status ->
                productRepository.findByIdWithLockSkipLocked(productId));

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(product -> assertThat(product.getId()).isEqualTo(productId));
    }

    // ==================== Concurrent access via locking methods ====================

    @Test
    @DisplayName("findByIdWithLock_whenTwoTransactionsContendConcurrently_onlyOneAcquiresLock")
    void findByIdWithLock_whenTwoTransactionsContendConcurrently_onlyOneAcquiresLock()
            throws InterruptedException {
        // Arrange — transaction A takes and holds the lock.
        CountDownLatch lockHeld = new CountDownLatch(1);
        CountDownLatch releaseLock = new CountDownLatch(1);
        ExecutorService executor = Executors.newFixedThreadPool(2);
        executor.submit(() -> transactionTemplate.execute(status -> {
            productRepository.findByIdWithLock(productId);
            lockHeld.countDown();
            await(releaseLock);
            return null;
        }));
        assertThat(lockHeld.await(10, TimeUnit.SECONDS)).isTrue();

        // Act — transaction B tries to grab the same row with NOWAIT while A holds it.
        AtomicReference<Throwable> contenderFailure = new AtomicReference<>();
        CountDownLatch contenderDone = new CountDownLatch(1);
        executor.submit(() -> {
            try {
                transactionTemplate.execute(status -> productRepository.findByIdWithLock(productId));
            } catch (Throwable t) {
                contenderFailure.set(t);
            } finally {
                contenderDone.countDown();
            }
        });

        // Assert
        try {
            assertThat(contenderDone.await(10, TimeUnit.SECONDS))
                    .as("NOWAIT contender must fail fast, not block indefinitely")
                    .isTrue();
            assertThat(contenderFailure.get())
                    .as("the second concurrent locker should be rejected")
                    .isInstanceOf(PessimisticLockingFailureException.class);
        } finally {
            releaseLock.countDown();
            executor.shutdown();
            assertThat(executor.awaitTermination(10, TimeUnit.SECONDS)).isTrue();
        }
    }

    @Test
    @DisplayName("findByIdWithLock_whenLockReleased_subsequentAcquisitionSucceeds")
    void findByIdWithLock_whenLockReleased_subsequentAcquisitionSucceeds() throws InterruptedException {
        // Arrange — hold then release the lock in a separate transaction.
        CountDownLatch lockHeld = new CountDownLatch(1);
        CountDownLatch releaseLock = new CountDownLatch(1);
        ExecutorService lockHolder = Executors.newSingleThreadExecutor();
        lockHolder.submit(() -> transactionTemplate.execute(status -> {
            productRepository.findByIdWithLock(productId);
            lockHeld.countDown();
            await(releaseLock);
            return null;
        }));
        assertThat(lockHeld.await(10, TimeUnit.SECONDS)).isTrue();

        // Act — release the first lock, then the main thread acquires it cleanly.
        releaseLock.countDown();
        lockHolder.shutdown();
        assertThat(lockHolder.awaitTermination(10, TimeUnit.SECONDS)).isTrue();

        Optional<Product> result = transactionTemplate.execute(status ->
                productRepository.findByIdWithLock(productId));

        // Assert
        assertThat(result)
                .isPresent()
                .get()
                .satisfies(product -> assertThat(product.getId()).isEqualTo(productId));
    }

    @Test
    @DisplayName("findByIdSetWithLock_whenOneRowLockedByAnotherTransaction_throwsPessimisticLockingFailure")
    void findByIdSetWithLock_whenOneRowLockedByAnotherTransaction_throwsPessimisticLockingFailure()
            throws InterruptedException {
        // Arrange — a second product plus a competing transaction holding one row.
        Product second = productRepository.saveAndFlush(Product.builder()
                .sku("LOCK-SKU-" + UUID.randomUUID())
                .name("Second Widget")
                .remark("")
                .totalStock(10L)
                .reservedStock(0L)
                .availableStock(10L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build());
        Set<UUID> ids = Set.of(productId, second.getId());

        CountDownLatch lockHeld = new CountDownLatch(1);
        CountDownLatch releaseLock = new CountDownLatch(1);
        ExecutorService lockHolder = Executors.newSingleThreadExecutor();
        lockHolder.submit(() -> transactionTemplate.execute(status -> {
            productRepository.findByIdWithLock(productId);
            lockHeld.countDown();
            await(releaseLock);
            return null;
        }));
        assertThat(lockHeld.await(10, TimeUnit.SECONDS)).isTrue();

        // Act / Assert — batch NOWAIT lock cannot acquire the contended row.
        try {
            assertThatThrownBy(() ->
                    transactionTemplate.execute(status -> productRepository.findByIdSetWithLock(ids)))
                    .isInstanceOf(PessimisticLockingFailureException.class);
        } finally {
            releaseLock.countDown();
            lockHolder.shutdown();
            assertThat(lockHolder.awaitTermination(10, TimeUnit.SECONDS)).isTrue();
        }
    }

    private static void await(CountDownLatch latch) {
        try {
            if (!latch.await(15, TimeUnit.SECONDS)) {
                throw new IllegalStateException("Timed out waiting on latch");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting on latch", e);
        }
    }
}
