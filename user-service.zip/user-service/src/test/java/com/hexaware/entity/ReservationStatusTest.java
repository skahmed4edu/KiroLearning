package com.hexaware.entity;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit tests for ReservationStatus enum.
 */
@DisplayName("ReservationStatus Enum Tests")
class ReservationStatusTest {

    @Test
    @DisplayName("Should have correct label for ACTIVE status")
    void shouldHaveCorrectLabelForActive() {
        assertThat(ReservationStatus.ACTIVE.getLabel()).isEqualTo("Active");
    }

    @Test
    @DisplayName("Should have correct label for RELEASED status")
    void shouldHaveCorrectLabelForReleased() {
        assertThat(ReservationStatus.RELEASED.getLabel()).isEqualTo("Released");
    }

    @Test
    @DisplayName("Should have correct label for EXPIRED status")
    void shouldHaveCorrectLabelForExpired() {
        assertThat(ReservationStatus.EXPIRED.getLabel()).isEqualTo("Expired");
    }

    @Test
    @DisplayName("Should have correct label for CANCELLED status")
    void shouldHaveCorrectLabelForCancelled() {
        assertThat(ReservationStatus.CANCELLED.getLabel()).isEqualTo("Cancelled");
    }

    @Test
    @DisplayName("ACTIVE should not be terminal")
    void activeShouldNotBeTerminal() {
        assertThat(ReservationStatus.ACTIVE.isTerminal()).isFalse();
    }

    @Test
    @DisplayName("RELEASED should be terminal")
    void releasedShouldBeTerminal() {
        assertThat(ReservationStatus.RELEASED.isTerminal()).isTrue();
    }

    @Test
    @DisplayName("EXPIRED should be terminal")
    void expiredShouldBeTerminal() {
        assertThat(ReservationStatus.EXPIRED.isTerminal()).isTrue();
    }

    @Test
    @DisplayName("CANCELLED should be terminal")
    void cancelledShouldBeTerminal() {
        assertThat(ReservationStatus.CANCELLED.isTerminal()).isTrue();
    }

    @Test
    @DisplayName("ACTIVE should allow release")
    void activeShouldAllowRelease() {
        assertThat(ReservationStatus.ACTIVE.canBeReleased()).isTrue();
    }

    @Test
    @DisplayName("RELEASED should allow release (for idempotency)")
    void releasedShouldAllowRelease() {
        assertThat(ReservationStatus.RELEASED.canBeReleased()).isTrue();
    }

    @Test
    @DisplayName("EXPIRED should not allow release")
    void expiredShouldNotAllowRelease() {
        assertThat(ReservationStatus.EXPIRED.canBeReleased()).isFalse();
    }

    @Test
    @DisplayName("CANCELLED should not allow release")
    void cancelledShouldNotAllowRelease() {
        assertThat(ReservationStatus.CANCELLED.canBeReleased()).isFalse();
    }

    @Test
    @DisplayName("ACTIVE should allow expiration")
    void activeShouldAllowExpiration() {
        assertThat(ReservationStatus.ACTIVE.canExpire()).isTrue();
    }

    @Test
    @DisplayName("RELEASED should not allow expiration")
    void releasedShouldNotAllowExpiration() {
        assertThat(ReservationStatus.RELEASED.canExpire()).isFalse();
    }

    @Test
    @DisplayName("EXPIRED should not allow expiration")
    void expiredShouldNotAllowExpiration() {
        assertThat(ReservationStatus.EXPIRED.canExpire()).isFalse();
    }

    @Test
    @DisplayName("CANCELLED should not allow expiration")
    void cancelledShouldNotAllowExpiration() {
        assertThat(ReservationStatus.CANCELLED.canExpire()).isFalse();
    }

    @Test
    @DisplayName("Should have all four status values")
    void shouldHaveAllFourStatusValues() {
        assertThat(ReservationStatus.values())
            .hasSize(4)
            .contains(
                ReservationStatus.ACTIVE,
                ReservationStatus.RELEASED,
                ReservationStatus.EXPIRED,
                ReservationStatus.CANCELLED
            );
    }

    @Test
    @DisplayName("Should be able to parse status by name")
    void shouldBeAbleToParseStatusByName() {
        assertThat(ReservationStatus.valueOf("ACTIVE")).isEqualTo(ReservationStatus.ACTIVE);
        assertThat(ReservationStatus.valueOf("RELEASED")).isEqualTo(ReservationStatus.RELEASED);
        assertThat(ReservationStatus.valueOf("EXPIRED")).isEqualTo(ReservationStatus.EXPIRED);
        assertThat(ReservationStatus.valueOf("CANCELLED")).isEqualTo(ReservationStatus.CANCELLED);
    }
}
