package com.hexaware.entity;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for the {@link Reservation} entity.
 *
 * Covers:
 * - Status transitions (ACTIVE -> RELEASED, ACTIVE -> EXPIRED)
 * - Expiration time calculation / detection
 * - Immutability of orderId and productId (enforced at the JPA mapping level)
 *
 * Requirements: 3.2, 3.3
 */
class ReservationTest {

    private static final LocalDateTime FIXED_NOW = LocalDateTime.of(2024, 1, 15, 9, 45, 0);

    private Reservation activeReservation(LocalDateTime createdAt, LocalDateTime expirationTime) {
        Product product = Product.builder()
                .id(UUID.randomUUID())
                .sku("SKU-123")
                .name("Test Widget")
                .remark("")
                .totalStock(100L)
                .availableStock(90L)
                .reservedStock(10L)
                .build();

        return Reservation.builder()
                .id(UUID.randomUUID())
                .orderId(UUID.randomUUID())
                .product(product)
                .quantity(5L)
                .status(ReservationStatus.ACTIVE)
                .createdAt(createdAt)
                .expirationTime(expirationTime)
                .build();
    }

    @Nested
    @DisplayName("Status transitions")
    class StatusTransitions {

        @Test
        void release_whenReservationActive_transitionsToReleased() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            LocalDateTime releasedTime = FIXED_NOW.plusMinutes(5);

            // Act
            reservation.release(releasedTime);

            // Assert
            assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.RELEASED);
            assertThat(reservation.getReleasedAt()).isEqualTo(releasedTime);
            assertThat(reservation.getExpiredAt()).isNull();
        }

        @Test
        void expire_whenReservationActive_transitionsToExpired() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            LocalDateTime expiredTime = FIXED_NOW.plusMinutes(15);

            // Act
            reservation.expire(expiredTime);

            // Assert
            assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.EXPIRED);
            assertThat(reservation.getExpiredAt()).isEqualTo(expiredTime);
            assertThat(reservation.getReleasedAt()).isNull();
        }

        @Test
        void release_whenReservationAlreadyReleased_throwsIllegalStateException() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            reservation.release(FIXED_NOW.plusMinutes(5));

            // Act / Assert
            assertThatThrownBy(() -> reservation.release(FIXED_NOW.plusMinutes(6)))
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("not ACTIVE");
        }

        @Test
        void expire_whenReservationAlreadyReleased_throwsIllegalStateException() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            reservation.release(FIXED_NOW.plusMinutes(5));

            // Act / Assert
            assertThatThrownBy(() -> reservation.expire(FIXED_NOW.plusMinutes(15)))
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("not ACTIVE");
        }

        @Test
        void release_whenReservationAlreadyExpired_throwsIllegalStateException() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            reservation.expire(FIXED_NOW.plusMinutes(15));

            // Act / Assert
            assertThatThrownBy(() -> reservation.release(FIXED_NOW.plusMinutes(16)))
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("not ACTIVE");
        }

        @Test
        void canBeReleased_whenReservationActive_returnsTrue() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));

            // Act
            boolean canBeReleased = reservation.canBeReleased();

            // Assert
            assertThat(canBeReleased).isTrue();
        }

        @Test
        void canBeExpired_whenReservationReleased_returnsFalse() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            reservation.release(FIXED_NOW.plusMinutes(5));

            // Act
            boolean canBeExpired = reservation.canBeExpired();

            // Assert
            assertThat(canBeExpired).isFalse();
        }
    }

    @Nested
    @DisplayName("Expiration time calculation")
    class ExpirationTimeCalculation {

        @Test
        void isExpired_whenNowBeforeExpirationTime_returnsFalse() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            LocalDateTime now = FIXED_NOW.plusMinutes(14);

            // Act
            boolean expired = reservation.isExpired(now);

            // Assert
            assertThat(expired).isFalse();
        }

        @Test
        void isExpired_whenNowEqualsExpirationTime_returnsTrue() {
            // Arrange
            LocalDateTime expirationTime = FIXED_NOW.plusMinutes(15);
            Reservation reservation = activeReservation(FIXED_NOW, expirationTime);

            // Act
            boolean expired = reservation.isExpired(expirationTime);

            // Assert
            assertThat(expired).isTrue();
        }

        @Test
        void isExpired_whenNowAfterExpirationTime_returnsTrue() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            LocalDateTime now = FIXED_NOW.plusMinutes(16);

            // Act
            boolean expired = reservation.isExpired(now);

            // Assert
            assertThat(expired).isTrue();
        }

        @Test
        void isExpired_whenReservationNotActive_returnsFalse() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.plusMinutes(15));
            reservation.release(FIXED_NOW.plusMinutes(5));
            LocalDateTime now = FIXED_NOW.plusMinutes(20);

            // Act
            boolean expired = reservation.isExpired(now);

            // Assert
            assertThat(expired).isFalse();
        }

        @Test
        void validate_whenExpirationTimeBeforeCreatedAt_throwsIllegalStateException() {
            // Arrange
            Reservation reservation = activeReservation(FIXED_NOW, FIXED_NOW.minusMinutes(1));

            // Act / Assert
            assertThatThrownBy(reservation::validate)
                    .isInstanceOf(IllegalStateException.class)
                    .hasMessageContaining("before created_at");
        }

        @Test
        void validate_whenExpirationTimeIsCreatedAtPlusTtl_doesNotThrow() {
            // Arrange
            LocalDateTime createdAt = FIXED_NOW;
            LocalDateTime expirationTime = createdAt.plusMinutes(15);
            Reservation reservation = activeReservation(createdAt, expirationTime);

            // Act / Assert
            assertThat(reservation.getExpirationTime())
                    .isEqualTo(reservation.getCreatedAt().plusMinutes(15));
            reservation.validate();
        }
    }

    @Nested
    @DisplayName("Immutability of orderId and productId")
    class Immutability {

        @Test
        void orderIdColumn_isMappedAsNonUpdatable() throws NoSuchFieldException {
            // Arrange
            Field orderIdField = Reservation.class.getDeclaredField("orderId");

            // Act
            Column column = orderIdField.getAnnotation(Column.class);

            // Assert
            assertThat(column).isNotNull();
            assertThat(column.name()).isEqualTo("order_id");
            assertThat(column.updatable()).isFalse();
        }

        @Test
        void productIdJoinColumn_isMappedAsNonUpdatable() throws NoSuchFieldException {
            // Arrange
            Field productField = Reservation.class.getDeclaredField("product");

            // Act
            JoinColumn joinColumn = productField.getAnnotation(JoinColumn.class);

            // Assert
            assertThat(joinColumn).isNotNull();
            assertThat(joinColumn.name()).isEqualTo("product_id");
            assertThat(joinColumn.updatable()).isFalse();
        }

        @Test
        void quantityColumn_isMappedAsNonUpdatable() throws NoSuchFieldException {
            // Arrange
            Field quantityField = Reservation.class.getDeclaredField("quantity");

            // Act
            Column column = quantityField.getAnnotation(Column.class);

            // Assert
            assertThat(column).isNotNull();
            assertThat(column.name()).isEqualTo("quantity");
            assertThat(column.updatable()).isFalse();
        }
    }
}
