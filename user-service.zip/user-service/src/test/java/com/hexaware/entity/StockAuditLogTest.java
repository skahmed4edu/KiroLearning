package com.hexaware.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for StockAuditLog entity.
 * 
 * Tests the following:
 * 1. Immutability of all audit fields
 * 2. Operation type recording (RESERVE, RELEASE, EXPIRE, BULK_UPDATE)
 * 3. Stock level snapshots (before and after)
 * 4. Quantity change calculation and validation
 * 5. Audit trail invariants (after = before + change)
 * 6. Request ID correlation for tracing
 * 7. Entity validation and constraint checking
 */
@DisplayName("StockAuditLog Entity Tests")
class StockAuditLogTest {

    private StockAuditLog auditLog;
    private Product product;
    private UUID productId;

    @BeforeEach
    void setUp() {
        productId = UUID.randomUUID();
        product = Product.builder()
            .id(productId)
            .sku("TEST-SKU")
            .name("Test Product")
            .totalStock(100L)
            .availableStock(100L)
            .reservedStock(0L)
            .lockVersion(0L)
            .updatedAt(LocalDateTime.now())
            .createdAt(LocalDateTime.now())
            .build();

        auditLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.RESERVE)
            .quantityChange(-10L)
            .availableStockBefore(100L)
            .availableStockAfter(90L)
            .executedAt(LocalDateTime.now())
            .requestId(UUID.randomUUID().toString())
            .build();
    }

    // ============================================================================
    // Field Immutability Tests
    // ============================================================================

    @Test
    @DisplayName("product should not be null and immutable")
    void testProductImmutable() {
        // Assert
        assertNotNull(auditLog.getProduct());
        assertEquals(productId, auditLog.getProduct().getId());
    }

    @Test
    @DisplayName("operationType should not be null and immutable")
    void testOperationTypeImmutable() {
        // Assert
        assertNotNull(auditLog.getOperationType());
        assertEquals(StockOperationType.RESERVE, auditLog.getOperationType());
    }

    @Test
    @DisplayName("quantityChange should not be null")
    void testQuantityChangeNotNull() {
        // Assert
        assertNotNull(auditLog.getQuantityChange());
    }

    @Test
    @DisplayName("executedAt should not be null")
    void testExecutedAtNotNull() {
        // Assert
        assertNotNull(auditLog.getExecutedAt());
    }

    @Test
    @DisplayName("availableStockBefore should not be null")
    void testAvailableStockBeforeNotNull() {
        // Assert
        assertNotNull(auditLog.getAvailableStockBefore());
    }

    @Test
    @DisplayName("availableStockAfter should not be null")
    void testAvailableStockAfterNotNull() {
        // Assert
        assertNotNull(auditLog.getAvailableStockAfter());
    }

    // ============================================================================
    // Operation Type Tests
    // ============================================================================

    @Test
    @DisplayName("should record RESERVE operation")
    void testRecordReserveOperation() {
        // Assert
        assertEquals(StockOperationType.RESERVE, auditLog.getOperationType());
        assertEquals(-10L, auditLog.getQuantityChange()); // Negative for reserve
        assertEquals(100L, auditLog.getAvailableStockBefore());
        assertEquals(90L, auditLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("should record RELEASE operation")
    void testRecordReleaseOperation() {
        // Arrange
        StockAuditLog releaseLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.RELEASE)
            .quantityChange(10L) // Positive for release
            .availableStockBefore(90L)
            .availableStockAfter(100L)
            .executedAt(LocalDateTime.now())
            .requestId(UUID.randomUUID().toString())
            .build();

        // Assert
        assertEquals(StockOperationType.RELEASE, releaseLog.getOperationType());
        assertEquals(10L, releaseLog.getQuantityChange());
        assertEquals(90L, releaseLog.getAvailableStockBefore());
        assertEquals(100L, releaseLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("should record EXPIRE operation")
    void testRecordExpireOperation() {
        // Arrange
        StockAuditLog expireLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.EXPIRE)
            .quantityChange(5L) // Positive for expire (releasing stock)
            .availableStockBefore(95L)
            .availableStockAfter(100L)
            .executedAt(LocalDateTime.now())
            .requestId("SCHEDULED-EXPIRATION-1234567890")
            .build();

        // Assert
        assertEquals(StockOperationType.EXPIRE, expireLog.getOperationType());
        assertEquals(5L, expireLog.getQuantityChange());
        assertEquals(95L, expireLog.getAvailableStockBefore());
        assertEquals(100L, expireLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("should record BULK_UPDATE operation with positive change")
    void testRecordBulkUpdateOperationPositive() {
        // Arrange: Restocking scenario
        StockAuditLog bulkLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.BULK_UPDATE)
            .quantityChange(50L) // Positive when restocking
            .availableStockBefore(50L)
            .availableStockAfter(100L)
            .executedAt(LocalDateTime.now())
            .requestId(UUID.randomUUID().toString())
            .build();

        // Assert
        assertEquals(StockOperationType.BULK_UPDATE, bulkLog.getOperationType());
        assertEquals(50L, bulkLog.getQuantityChange());
        assertEquals(50L, bulkLog.getAvailableStockBefore());
        assertEquals(100L, bulkLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("should record BULK_UPDATE operation with negative change")
    void testRecordBulkUpdateOperationNegative() {
        // Arrange: Stock correction scenario
        StockAuditLog bulkLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.BULK_UPDATE)
            .quantityChange(-20L) // Negative when correcting downward
            .availableStockBefore(100L)
            .availableStockAfter(80L)
            .executedAt(LocalDateTime.now())
            .requestId(UUID.randomUUID().toString())
            .build();

        // Assert
        assertEquals(StockOperationType.BULK_UPDATE, bulkLog.getOperationType());
        assertEquals(-20L, bulkLog.getQuantityChange());
        assertEquals(100L, bulkLog.getAvailableStockBefore());
        assertEquals(80L, bulkLog.getAvailableStockAfter());
    }

    // ============================================================================
    // Stock Level Snapshot Tests
    // ============================================================================

    @Test
    @DisplayName("should capture available stock before and after")
    void testStockLevelSnapshots() {
        // Assert
        assertEquals(100L, auditLog.getAvailableStockBefore());
        assertEquals(90L, auditLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("should support zero available stock values")
    void testZeroStockValues() {
        // Arrange
        StockAuditLog zeroLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.RESERVE)
            .quantityChange(-100L)
            .availableStockBefore(100L)
            .availableStockAfter(0L)
            .executedAt(LocalDateTime.now())
            .build();

        // Assert
        assertEquals(100L, zeroLog.getAvailableStockBefore());
        assertEquals(0L, zeroLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("should support large stock quantities")
    void testLargeStockQuantities() {
        // Arrange
        StockAuditLog largeLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.BULK_UPDATE)
            .quantityChange(900_000L)
            .availableStockBefore(100_000L)
            .availableStockAfter(1_000_000L)
            .executedAt(LocalDateTime.now())
            .build();

        // Assert
        assertEquals(100_000L, largeLog.getAvailableStockBefore());
        assertEquals(1_000_000L, largeLog.getAvailableStockAfter());
        assertEquals(900_000L, largeLog.getQuantityChange());
    }

    // ============================================================================
    // Quantity Change Tests
    // ============================================================================

    @Test
    @DisplayName("should support positive quantity change")
    void testPositiveQuantityChange() {
        // Arrange
        auditLog.setOperationType(StockOperationType.RELEASE);
        auditLog.setQuantityChange(10L);

        // Assert
        assertTrue(auditLog.getQuantityChange() > 0);
        assertEquals(10L, auditLog.getQuantityChange());
    }

    @Test
    @DisplayName("should support negative quantity change")
    void testNegativeQuantityChange() {
        // Assert
        assertTrue(auditLog.getQuantityChange() < 0);
        assertEquals(-10L, auditLog.getQuantityChange());
    }

    @Test
    @DisplayName("should support zero quantity change")
    void testZeroQuantityChange() {
        // Arrange
        StockAuditLog zeroChangeLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.BULK_UPDATE)
            .quantityChange(0L) // No change
            .availableStockBefore(100L)
            .availableStockAfter(100L)
            .executedAt(LocalDateTime.now())
            .build();

        // Assert
        assertEquals(0L, zeroChangeLog.getQuantityChange());
    }

    // ============================================================================
    // Audit Invariant Tests
    // ============================================================================

    @Test
    @DisplayName("availableStockAfter should equal availableStockBefore plus quantityChange")
    void testAuditInvariant() {
        // Assert: Verify invariant
        long expectedAfter = auditLog.getAvailableStockBefore() + auditLog.getQuantityChange();
        assertEquals(expectedAfter, auditLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("invariant should hold for RESERVE operation")
    void testInvariantForReserveOperation() {
        // Assert
        assertEquals(100L, auditLog.getAvailableStockBefore());
        assertEquals(-10L, auditLog.getQuantityChange());
        assertEquals(90L, auditLog.getAvailableStockAfter());
        assertEquals(100L - 10L, auditLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("invariant should hold for RELEASE operation")
    void testInvariantForReleaseOperation() {
        // Arrange
        auditLog.setOperationType(StockOperationType.RELEASE);
        auditLog.setQuantityChange(10L);
        auditLog.setAvailableStockBefore(90L);
        auditLog.setAvailableStockAfter(100L);

        // Assert
        assertEquals(90L + 10L, auditLog.getAvailableStockAfter());
    }

    @Test
    @DisplayName("invariant should hold for BULK_UPDATE operation")
    void testInvariantForBulkUpdateOperation() {
        // Arrange
        auditLog.setOperationType(StockOperationType.BULK_UPDATE);
        auditLog.setQuantityChange(50L);
        auditLog.setAvailableStockBefore(50L);
        auditLog.setAvailableStockAfter(100L);

        // Assert
        assertEquals(50L + 50L, auditLog.getAvailableStockAfter());
    }

    // ============================================================================
    // Request ID Tests
    // ============================================================================

    @Test
    @DisplayName("requestId should support UUID format")
    void testRequestIdUuid() {
        // Arrange
        String requestId = UUID.randomUUID().toString();
        auditLog.setRequestId(requestId);

        // Assert
        assertEquals(requestId, auditLog.getRequestId());
    }

    @Test
    @DisplayName("requestId should support custom format")
    void testRequestIdCustomFormat() {
        // Arrange
        auditLog.setRequestId("SCHEDULED-EXPIRATION-1704067200");

        // Assert
        assertEquals("SCHEDULED-EXPIRATION-1704067200", auditLog.getRequestId());
    }

    @Test
    @DisplayName("requestId can be null for system operations")
    void testRequestIdNull() {
        // Arrange
        auditLog.setRequestId(null);

        // Assert
        assertNull(auditLog.getRequestId());
    }

    @Test
    @DisplayName("requestId should support bulk update format")
    void testRequestIdBulkUpdateFormat() {
        // Arrange
        auditLog.setRequestId("BULK-UPDATE-batch-" + UUID.randomUUID());

        // Assert
        assertTrue(auditLog.getRequestId().startsWith("BULK-UPDATE-"));
    }

    // ============================================================================
    // Timestamp Tests
    // ============================================================================

    @Test
    @DisplayName("executedAt should record exact operation time")
    void testExecutedAtTimestamp() {
        // Arrange
        LocalDateTime now = LocalDateTime.now();
        auditLog.setExecutedAt(now);

        // Assert
        assertEquals(now, auditLog.getExecutedAt());
    }

    @Test
    @DisplayName("should preserve timestamp precision")
    void testTimestampPrecision() {
        // Arrange
        LocalDateTime precisetime = LocalDateTime.of(2024, 1, 15, 14, 30, 45, 123456789);
        auditLog.setExecutedAt(precisetime);

        // Assert
        assertEquals(precisetime, auditLog.getExecutedAt());
    }

    // ============================================================================
    // Entity Validation Tests
    // ============================================================================

    @Test
    @DisplayName("validate should pass with all required fields")
    void testValidateSuccess() {
        // Act & Assert: No exception should be thrown
        assertDoesNotThrow(() -> auditLog.validate());
    }

    @Test
    @DisplayName("validate should fail when id is null")
    void testValidateFailNullId() {
        // Arrange
        auditLog.setId(null);

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("ID is null"));
    }

    @Test
    @DisplayName("validate should fail when product is null")
    void testValidateFailNullProduct() {
        // Arrange
        auditLog.setProduct(null);

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("null product"));
    }

    @Test
    @DisplayName("validate should fail when operationType is null")
    void testValidateFailNullOperationType() {
        // Arrange
        auditLog.setOperationType(null);

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("null operation_type"));
    }

    @Test
    @DisplayName("validate should fail when quantityChange is null")
    void testValidateFailNullQuantityChange() {
        // Arrange
        auditLog.setQuantityChange(null);

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("null quantity_change"));
    }

    @Test
    @DisplayName("validate should fail when availableStockBefore is null")
    void testValidateFailNullAvailableStockBefore() {
        // Arrange
        auditLog.setAvailableStockBefore(null);

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("invalid available_stock_before"));
    }

    @Test
    @DisplayName("validate should fail when availableStockAfter is null")
    void testValidateFailNullAvailableStockAfter() {
        // Arrange
        auditLog.setAvailableStockAfter(null);

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("invalid available_stock_after"));
    }

    @Test
    @DisplayName("validate should fail when executedAt is null")
    void testValidateFailNullExecutedAt() {
        // Arrange
        auditLog.setExecutedAt(null);

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("null executed_at"));
    }

    @Test
    @DisplayName("validate should fail when invariant is violated")
    void testValidateFailInvariantViolation() {
        // Arrange: Violate invariant: after != before + change
        auditLog.setAvailableStockBefore(100L);
        auditLog.setQuantityChange(-10L);
        auditLog.setAvailableStockAfter(85L); // Should be 90L

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("invariant violated"));
    }

    @Test
    @DisplayName("validate should fail when availableStockBefore is negative")
    void testValidateFailNegativeAvailableStockBefore() {
        // Arrange: Negative before should fail
        auditLog.setAvailableStockBefore(-10L);
        auditLog.setQuantityChange(0L);
        auditLog.setAvailableStockAfter(-10L); // Match invariant but still invalid

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("invalid available_stock_before"));
    }

    @Test
    @DisplayName("validate should fail when availableStockAfter is negative")
    void testValidateFailNegativeAvailableStockAfter() {
        // Arrange: Negative after should fail
        auditLog.setAvailableStockBefore(5L);
        auditLog.setQuantityChange(-20L);
        auditLog.setAvailableStockAfter(-15L); // Negative after stock

        // Act & Assert
        IllegalStateException exception = assertThrows(
            IllegalStateException.class,
            () -> auditLog.validate()
        );
        assertTrue(exception.getMessage().contains("invalid available_stock_after"));
    }

    @Test
    @DisplayName("validate should pass with zero stock values")
    void testValidateZeroStock() {
        // Arrange: All zeros (edge case)
        auditLog.setAvailableStockBefore(0L);
        auditLog.setQuantityChange(0L);
        auditLog.setAvailableStockAfter(0L);

        // Act & Assert
        assertDoesNotThrow(() -> auditLog.validate());
    }

    // ============================================================================
    // Builder Pattern Tests
    // ============================================================================

    @Test
    @DisplayName("should build audit log with all fields")
    void testBuilderWithAllFields() {
        // Act
        StockAuditLog builtLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.RELEASE)
            .quantityChange(15L)
            .availableStockBefore(85L)
            .availableStockAfter(100L)
            .executedAt(LocalDateTime.now())
            .requestId(UUID.randomUUID().toString())
            .build();

        // Assert
        assertNotNull(builtLog.getId());
        assertNotNull(builtLog.getProduct());
        assertEquals(StockOperationType.RELEASE, builtLog.getOperationType());
        assertEquals(15L, builtLog.getQuantityChange());
        assertEquals(85L, builtLog.getAvailableStockBefore());
        assertEquals(100L, builtLog.getAvailableStockAfter());
        assertNotNull(builtLog.getExecutedAt());
        assertNotNull(builtLog.getRequestId());
    }

    @Test
    @DisplayName("should build audit log without requestId")
    void testBuilderWithoutRequestId() {
        // Act
        StockAuditLog builtLog = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.EXPIRE)
            .quantityChange(5L)
            .availableStockBefore(95L)
            .availableStockAfter(100L)
            .executedAt(LocalDateTime.now())
            .build();

        // Assert
        assertNotNull(builtLog.getId());
        assertNull(builtLog.getRequestId());
        assertEquals(StockOperationType.EXPIRE, builtLog.getOperationType());
    }

    // ============================================================================
    // Edge Case Tests
    // ============================================================================

    @Test
    @DisplayName("should handle all operation types")
    void testAllOperationTypes() {
        // Test each operation type
        for (StockOperationType opType : StockOperationType.values()) {
            StockAuditLog log = StockAuditLog.builder()
                .id(UUID.randomUUID())
                .product(product)
                .operationType(opType)
                .quantityChange(10L)
                .availableStockBefore(100L)
                .availableStockAfter(110L)
                .executedAt(LocalDateTime.now())
                .build();

            assertNotNull(log.getOperationType());
            assertEquals(opType, log.getOperationType());
        }
    }

    @Test
    @DisplayName("should handle multiple audit logs for same product")
    void testMultipleAuditLogsPerProduct() {
        // Arrange: Create multiple logs for same product
        StockAuditLog log1 = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.RESERVE)
            .quantityChange(-10L)
            .availableStockBefore(100L)
            .availableStockAfter(90L)
            .executedAt(LocalDateTime.now())
            .build();

        StockAuditLog log2 = StockAuditLog.builder()
            .id(UUID.randomUUID())
            .product(product)
            .operationType(StockOperationType.RELEASE)
            .quantityChange(10L)
            .availableStockBefore(90L)
            .availableStockAfter(100L)
            .executedAt(LocalDateTime.now().plusMinutes(1))
            .build();

        // Assert
        assertDoesNotThrow(() -> log1.validate());
        assertDoesNotThrow(() -> log2.validate());
        assertNotEquals(log1.getId(), log2.getId());
        assertTrue(log2.getExecutedAt().isAfter(log1.getExecutedAt()));
    }

    @Test
    @DisplayName("should handle very large quantity changes")
    void testVeryLargeQuantityChanges() {
        // Arrange
        long largeChange = 1_000_000_000L; // 1 billion
        auditLog.setQuantityChange(-largeChange);
        auditLog.setAvailableStockBefore(1_000_000_000L);
        auditLog.setAvailableStockAfter(0L);

        // Act & Assert
        assertDoesNotThrow(() -> auditLog.validate());
    }
}
