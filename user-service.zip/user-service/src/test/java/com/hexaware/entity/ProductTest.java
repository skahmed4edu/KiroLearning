package com.hexaware.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for the {@link Product} entity.
 *
 * Covers the entity-level invariants and lifecycle behaviour that do not require
 * a running Spring context or a database:
 * <ul>
 *   <li>Stock invariant validation (availableStock >= 0, reservedStock >= 0,
 *       totalStock = availableStock + reservedStock)</li>
 *   <li>Immutability of the createdAt field across update lifecycle hooks</li>
 *   <li>Optimistic-locking version field increments on update</li>
 * </ul>
 *
 * Validates: Requirements 1.3
 */
class ProductTest {

    private Product product;

    @BeforeEach
    void setUp() {
        // Reset to a known-good product before every test to avoid shared mutable state
        product = Product.builder()
                .id(UUID.randomUUID())
                .sku("SKU-1001")
                .name("Mechanical Keyboard")
                .remark("")
                .totalStock(100L)
                .availableStock(70L)
                .reservedStock(30L)
                .lockVersion(0L)
                .build();
    }

    // ---------------------------------------------------------------------
    // Stock invariant validation
    // ---------------------------------------------------------------------

    @Test
    @DisplayName("validateStockInvariant with consistent stock passes")
    void validateStockInvariant_withConsistentStock_doesNotThrow() {
        // Arrange
        // product from setUp: 100 = 70 + 30

        // Act & Assert
        assertThatCode(() -> product.validateStockInvariant())
                .doesNotThrowAnyException();
    }

    @Test
    @DisplayName("validateStockInvariant with mismatched totals throws")
    void validateStockInvariant_whenTotalDoesNotMatchSum_throwsIllegalStateException() {
        // Arrange
        product.setAvailableStock(50L);
        product.setReservedStock(30L);
        // totalStock stays 100, but 50 + 30 = 80

        // Act & Assert
        assertThatThrownBy(() -> product.validateStockInvariant())
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Stock invariant violated");
    }

    @Test
    @DisplayName("validateStockInvariant with negative available stock throws")
    void validateStockInvariant_whenAvailableStockNegative_throwsIllegalStateException() {
        // Arrange
        product.setAvailableStock(-10L);
        product.setReservedStock(110L);
        // 100 = -10 + 110 keeps the sum invariant, isolating the non-negative check

        // Act & Assert
        assertThatThrownBy(() -> product.validateStockInvariant())
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Available stock cannot be negative");
    }

    @Test
    @DisplayName("validateStockInvariant with negative reserved stock throws")
    void validateStockInvariant_whenReservedStockNegative_throwsIllegalStateException() {
        // Arrange
        product.setAvailableStock(110L);
        product.setReservedStock(-10L);
        // 100 = 110 + (-10) keeps the sum invariant, isolating the non-negative check

        // Act & Assert
        assertThatThrownBy(() -> product.validateStockInvariant())
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Reserved stock cannot be negative");
    }

    @Test
    @DisplayName("validateStockInvariant with zero total stock throws")
    void validateStockInvariant_whenTotalStockZero_throwsIllegalStateException() {
        // Arrange
        product.setTotalStock(0L);
        product.setAvailableStock(0L);
        product.setReservedStock(0L);

        // Act & Assert
        assertThatThrownBy(() -> product.validateStockInvariant())
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Total stock must be positive");
    }

    @Test
    @DisplayName("reserveStock keeps availableStock and reservedStock non-negative")
    void reserveStock_withValidQuantity_keepsStockNonNegativeAndInvariantHeld() {
        // Arrange
        long quantity = 70L;

        // Act
        product.reserveStock(quantity);

        // Assert
        assertThat(product.getAvailableStock()).isEqualTo(0L);
        assertThat(product.getReservedStock()).isEqualTo(100L);
        assertThat(product.getAvailableStock()).isGreaterThanOrEqualTo(0L);
        assertThat(product.getReservedStock()).isGreaterThanOrEqualTo(0L);
        assertThatCode(() -> product.validateStockInvariant()).doesNotThrowAnyException();
    }

    @Test
    @DisplayName("reserveStock beyond availableStock throws and leaves stock unchanged")
    void reserveStock_whenQuantityExceedsAvailable_throwsAndLeavesStockUnchanged() {
        // Arrange
        long quantity = 71L; // only 70 available

        // Act & Assert
        assertThatThrownBy(() -> product.reserveStock(quantity))
                .isInstanceOf(IllegalStateException.class);
        assertThat(product.getAvailableStock()).isEqualTo(70L);
        assertThat(product.getReservedStock()).isEqualTo(30L);
    }

    @Test
    @DisplayName("releaseStock keeps availableStock and reservedStock non-negative")
    void releaseStock_withValidQuantity_keepsStockNonNegativeAndInvariantHeld() {
        // Arrange
        long quantity = 30L;

        // Act
        product.releaseStock(quantity);

        // Assert
        assertThat(product.getAvailableStock()).isEqualTo(100L);
        assertThat(product.getReservedStock()).isEqualTo(0L);
        assertThat(product.getAvailableStock()).isGreaterThanOrEqualTo(0L);
        assertThat(product.getReservedStock()).isGreaterThanOrEqualTo(0L);
        assertThatCode(() -> product.validateStockInvariant()).doesNotThrowAnyException();
    }

    // ---------------------------------------------------------------------
    // Immutability of createdAt
    // ---------------------------------------------------------------------

    @Test
    @DisplayName("onUpdate lifecycle hook leaves createdAt unchanged")
    void onUpdate_afterCreate_leavesCreatedAtUnchanged() throws Exception {
        // Arrange
        invokeLifecycle("onCreate");
        LocalDateTime originalCreatedAt = product.getCreatedAt();
        assertThat(originalCreatedAt).isNotNull();
        // Ensure the clock advances so any accidental reassignment would be observable
        Thread.sleep(5);

        // Act
        invokeLifecycle("onUpdate");

        // Assert
        assertThat(product.getCreatedAt()).isEqualTo(originalCreatedAt);
        assertThat(product.getUpdatedAt()).isAfterOrEqualTo(originalCreatedAt);
    }

    @Test
    @DisplayName("onCreate lifecycle hook sets createdAt and updatedAt")
    void onCreate_whenPersisted_setsCreatedAtAndUpdatedAt() throws Exception {
        // Arrange
        Product fresh = Product.builder()
                .sku("SKU-2002")
                .name("Wireless Mouse")
                .remark("")
                .totalStock(10L)
                .availableStock(10L)
                .reservedStock(0L)
                .build();

        // Act
        invokeLifecycle(fresh, "onCreate");

        // Assert
        assertThat(fresh.getCreatedAt()).isNotNull();
        assertThat(fresh.getUpdatedAt()).isNotNull();
    }

    // ---------------------------------------------------------------------
    // Optimistic-locking version field
    // ---------------------------------------------------------------------

    @Test
    @DisplayName("lockVersion increments when simulating a persistence update")
    void lockVersion_onSimulatedUpdate_incrementsByOne() {
        // Arrange
        Long versionBefore = product.getLockVersion();

        // Act
        // JPA/Hibernate increments @Version on flush; at the unit level we simulate
        // that provider behaviour to assert the field participates in optimistic locking.
        product.setLockVersion(versionBefore + 1);

        // Assert
        assertThat(product.getLockVersion()).isEqualTo(versionBefore + 1);
    }

    @Test
    @DisplayName("new product starts with a null lockVersion before first persist")
    void lockVersion_onNewUnpersistedProduct_isNull() {
        // Arrange
        Product fresh = Product.builder()
                .sku("SKU-3003")
                .name("USB-C Cable")
                .remark("")
                .totalStock(5L)
                .availableStock(5L)
                .reservedStock(0L)
                .build();

        // Act
        Long version = fresh.getLockVersion();

        // Assert
        assertThat(version).isNull();
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private void invokeLifecycle(String methodName) throws Exception {
        invokeLifecycle(product, methodName);
    }

    private void invokeLifecycle(Product target, String methodName) throws Exception {
        var method = Product.class.getDeclaredMethod(methodName);
        method.setAccessible(true);
        method.invoke(target);
    }
}
