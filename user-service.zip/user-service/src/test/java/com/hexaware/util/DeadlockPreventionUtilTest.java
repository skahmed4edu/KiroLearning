package com.hexaware.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for DeadlockPreventionUtil class.
 * 
 * Tests verify:
 * 1. Products are sorted by ID in ascending order
 * 2. Multiple calls produce consistent (idempotent) ordering
 * 3. Handles edge cases: empty sets, single products, large sets
 * 4. Correct validation of sorted order
 */
@DisplayName("DeadlockPreventionUtil Tests")
class DeadlockPreventionUtilTest {

    /**
     * Validates: Requirements 6.8 (Deadlock prevention)
     * 
     * Tests for basic sorting functionality.
     */
    @Nested
    @DisplayName("Sorting Functionality")
    class SortingFunctionality {

        @Test
        @DisplayName("Should sort products by ID in ascending order")
        void shouldSortProductsAscending() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
            UUID id3 = UUID.fromString("00000000-0000-0000-0000-000000000003");

            Collection<UUID> unsortedIds = Arrays.asList(id3, id1, id2);

            // Act
            List<UUID> sortedIds = DeadlockPreventionUtil.sortProductsByIdForLocking(unsortedIds);

            // Assert
            assertEquals(3, sortedIds.size());
            assertEquals(id1, sortedIds.get(0));
            assertEquals(id2, sortedIds.get(1));
            assertEquals(id3, sortedIds.get(2));
        }

        @Test
        @DisplayName("Should handle already sorted list")
        void shouldHandleAlreadySortedList() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
            UUID id3 = UUID.fromString("00000000-0000-0000-0000-000000000003");

            Collection<UUID> sortedIds = Arrays.asList(id1, id2, id3);

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(sortedIds);

            // Assert
            assertEquals(sortedIds, result);
        }

        @Test
        @DisplayName("Should handle reverse sorted list")
        void shouldHandleReverseSortedList() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
            UUID id3 = UUID.fromString("00000000-0000-0000-0000-000000000003");

            Collection<UUID> reverseSortedIds = Arrays.asList(id3, id2, id1);

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(reverseSortedIds);

            // Assert
            assertEquals(id1, result.get(0));
            assertEquals(id2, result.get(1));
            assertEquals(id3, result.get(2));
        }

        @Test
        @DisplayName("Should sort products with random UUIDs correctly")
        void shouldSortRandomUuids() {
            // Arrange
            Set<UUID> randomIds = new HashSet<>();
            randomIds.add(UUID.randomUUID());
            randomIds.add(UUID.randomUUID());
            randomIds.add(UUID.randomUUID());
            randomIds.add(UUID.randomUUID());
            randomIds.add(UUID.randomUUID());

            // Act
            List<UUID> sortedIds = DeadlockPreventionUtil.sortProductsByIdForLocking(randomIds);

            // Assert
            assertTrue(DeadlockPreventionUtil.isSortedAscending(sortedIds));
            assertEquals(5, sortedIds.size());
        }
    }

    /**
     * Validates: Requirements 6.8 (Deadlock prevention - consistency)
     * 
     * Tests for consistency and idempotence of sorting.
     */
    @Nested
    @DisplayName("Consistency and Idempotence")
    class ConsistencyAndIdempotence {

        @Test
        @DisplayName("Multiple calls should produce consistent order")
        void multiplCallsShouldProduceConsistentOrder() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
            UUID id3 = UUID.fromString("00000000-0000-0000-0000-000000000003");

            Collection<UUID> productIds = Arrays.asList(id3, id1, id2);

            // Act
            List<UUID> firstCall = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);
            List<UUID> secondCall = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);
            List<UUID> thirdCall = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);

            // Assert
            assertEquals(firstCall, secondCall);
            assertEquals(secondCall, thirdCall);
        }

        @Test
        @DisplayName("Should produce same order regardless of input collection type")
        void shouldProduceSameOrderForDifferentCollectionTypes() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
            UUID id3 = UUID.fromString("00000000-0000-0000-0000-000000000003");

            Collection<UUID> listVersion = Arrays.asList(id3, id1, id2);
            Collection<UUID> setVersion = new HashSet<>(Arrays.asList(id3, id1, id2));
            Collection<UUID> linkedListVersion = new LinkedList<>(Arrays.asList(id3, id1, id2));

            // Act
            List<UUID> resultFromList = DeadlockPreventionUtil.sortProductsByIdForLocking(listVersion);
            List<UUID> resultFromSet = DeadlockPreventionUtil.sortProductsByIdForLocking(setVersion);
            List<UUID> resultFromLinkedList = DeadlockPreventionUtil.sortProductsByIdForLocking(linkedListVersion);

            // Assert
            assertEquals(resultFromList, resultFromSet);
            assertEquals(resultFromSet, resultFromLinkedList);
        }

        @Test
        @DisplayName("Should maintain idempotency across multiple sorts")
        void shouldMaintainIdempotencyAcrossMultipleSorts() {
            // Arrange
            Set<UUID> productIds = new HashSet<>();
            for (int i = 0; i < 10; i++) {
                productIds.add(UUID.randomUUID());
            }

            // Act
            List<UUID> sort1 = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);
            List<UUID> sort2 = DeadlockPreventionUtil.sortProductsByIdForLocking(sort1);
            List<UUID> sort3 = DeadlockPreventionUtil.sortProductsByIdForLocking(sort2);

            // Assert
            assertEquals(sort1, sort2);
            assertEquals(sort2, sort3);
        }
    }

    /**
     * Validates: Requirements 6.8 (Deadlock prevention - edge cases)
     * 
     * Tests for handling edge cases: empty, single, large sets.
     */
    @Nested
    @DisplayName("Edge Cases")
    class EdgeCases {

        @Test
        @DisplayName("Should handle empty collection")
        void shouldHandleEmptyCollection() {
            // Arrange
            Collection<UUID> emptyIds = new ArrayList<>();

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(emptyIds);

            // Assert
            assertTrue(result.isEmpty());
        }

        @Test
        @DisplayName("Should handle single product ID")
        void shouldHandleSingleProductId() {
            // Arrange
            UUID id = UUID.fromString("00000000-0000-0000-0000-000000000001");
            Collection<UUID> singleId = Collections.singleton(id);

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(singleId);

            // Assert
            assertEquals(1, result.size());
            assertEquals(id, result.get(0));
        }

        @Test
        @DisplayName("Should handle duplicate product IDs")
        void shouldHandleDuplicateProductIds() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");

            Collection<UUID> idsWithDuplicates = Arrays.asList(id2, id1, id2, id1, id2);

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(idsWithDuplicates);

            // Assert
            assertEquals(5, result.size()); // Duplicates are preserved
            assertEquals(id1, result.get(0));
            assertEquals(id1, result.get(1));
            assertEquals(id2, result.get(2));
            assertEquals(id2, result.get(3));
            assertEquals(id2, result.get(4));
        }

        @ParameterizedTest
        @ValueSource(ints = {1, 10, 100, 500, 1000})
        @DisplayName("Should handle various set sizes")
        void shouldHandleVariousSetSizes(int size) {
            // Arrange
            Set<UUID> productIds = new HashSet<>();
            for (int i = 0; i < size; i++) {
                productIds.add(UUID.randomUUID());
            }

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);

            // Assert
            assertEquals(size, result.size());
            assertTrue(DeadlockPreventionUtil.isSortedAscending(result));
        }

        @Test
        @DisplayName("Should handle set with 1000 products (max bulk update size)")
        void shouldHandleMaxBulkUpdateSize() {
            // Arrange
            Set<UUID> productIds = new HashSet<>();
            for (int i = 0; i < 1000; i++) {
                productIds.add(UUID.randomUUID());
            }

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);

            // Assert
            assertEquals(1000, result.size());
            assertTrue(DeadlockPreventionUtil.isSortedAscending(result));
        }

        @Test
        @DisplayName("Should return unmodifiable list to prevent accidental mutations")
        void shouldReturnUnmodifiableList() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            Collection<UUID> productIds = Collections.singleton(id1);

            // Act
            List<UUID> result = DeadlockPreventionUtil.sortProductsByIdForLocking(productIds);

            // Assert
            assertThrows(UnsupportedOperationException.class, () -> result.add(UUID.randomUUID()));
            assertThrows(UnsupportedOperationException.class, () -> result.remove(0));
        }
    }

    /**
     * Validates: Requirements 6.8 (Deadlock prevention - error handling)
     * 
     * Tests for proper error handling with invalid inputs.
     */
    @Nested
    @DisplayName("Error Handling")
    class ErrorHandling {

        @Test
        @DisplayName("Should throw NullPointerException for null collection")
        void shouldThrowNullPointerExceptionForNullCollection() {
            // Act & Assert
            assertThrows(NullPointerException.class, () -> {
                DeadlockPreventionUtil.sortProductsByIdForLocking(null);
            });
        }

        @Test
        @DisplayName("Should throw NullPointerException for null UUID in collection")
        void shouldThrowNullPointerExceptionForNullUuidInCollection() {
            // Arrange
            Collection<UUID> idsWithNull = new ArrayList<>();
            idsWithNull.add(UUID.randomUUID());
            idsWithNull.add(null);

            // Act & Assert
            assertThrows(NullPointerException.class, () -> {
                DeadlockPreventionUtil.sortProductsByIdForLocking(idsWithNull);
            });
        }
    }

    /**
     * Tests for the validation helper method.
     */
    @Nested
    @DisplayName("Validation Helper (isSortedAscending)")
    class ValidationHelper {

        @Test
        @DisplayName("Should validate that list is sorted in ascending order")
        void shouldValidateSortedAscending() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
            UUID id3 = UUID.fromString("00000000-0000-0000-0000-000000000003");

            List<UUID> sortedIds = Arrays.asList(id1, id2, id3);

            // Act & Assert
            assertTrue(DeadlockPreventionUtil.isSortedAscending(sortedIds));
        }

        @Test
        @DisplayName("Should detect unsorted list")
        void shouldDetectUnsortedList() {
            // Arrange
            UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
            UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
            UUID id3 = UUID.fromString("00000000-0000-0000-0000-000000000003");

            List<UUID> unsortedIds = Arrays.asList(id3, id1, id2);

            // Act & Assert
            assertFalse(DeadlockPreventionUtil.isSortedAscending(unsortedIds));
        }

        @Test
        @DisplayName("Should return true for empty list")
        void shouldReturnTrueForEmptyList() {
            // Act & Assert
            assertTrue(DeadlockPreventionUtil.isSortedAscending(new ArrayList<>()));
        }

        @Test
        @DisplayName("Should return true for single element list")
        void shouldReturnTrueForSingleElementList() {
            // Arrange
            List<UUID> singleElement = Arrays.asList(UUID.randomUUID());

            // Act & Assert
            assertTrue(DeadlockPreventionUtil.isSortedAscending(singleElement));
        }

        @Test
        @DisplayName("Should handle null list")
        void shouldHandleNullList() {
            // Act & Assert
            assertTrue(DeadlockPreventionUtil.isSortedAscending(null));
        }
    }

    /**
     * Integration-style tests demonstrating deadlock prevention in realistic scenarios.
     */
    @Nested
    @DisplayName("Deadlock Prevention Scenarios")
    class DeadlockPreventionScenarios {

        @Test
        @DisplayName("Should ensure consistent ordering for bulk stock update scenario")
        void shouldEnsureConsistentOrderingForBulkUpdate() {
            // Arrange: Simulate bulk update with multiple products
            Set<UUID> productIdsFromRequest = new HashSet<>();
            UUID productA = UUID.randomUUID();
            UUID productB = UUID.randomUUID();
            UUID productC = UUID.randomUUID();
            productIdsFromRequest.add(productA);
            productIdsFromRequest.add(productB);
            productIdsFromRequest.add(productC);

            // Act: Sort products for locking
            List<UUID> lockOrder1 = DeadlockPreventionUtil.sortProductsByIdForLocking(productIdsFromRequest);
            List<UUID> lockOrder2 = DeadlockPreventionUtil.sortProductsByIdForLocking(productIdsFromRequest);

            // Assert: Both threads would lock in the same order
            assertEquals(lockOrder1, lockOrder2);
            assertTrue(DeadlockPreventionUtil.isSortedAscending(lockOrder1));
        }

        @Test
        @DisplayName("Should maintain order consistency even with large concurrent sets")
        void shouldMaintainOrderConsistencyWithLargeSets() {
            // Arrange: Simulate two concurrent bulk updates with overlapping products
            Set<UUID> bulkUpdateAProducts = new HashSet<>();
            Set<UUID> bulkUpdateBProducts = new HashSet<>();

            for (int i = 0; i < 500; i++) {
                bulkUpdateAProducts.add(UUID.randomUUID());
            }

            for (int i = 0; i < 300; i++) {
                bulkUpdateBProducts.add(UUID.randomUUID());
            }

            // Add 100 overlapping products
            bulkUpdateAProducts.stream().limit(100).forEach(bulkUpdateBProducts::add);

            // Act
            List<UUID> lockOrderA = DeadlockPreventionUtil.sortProductsByIdForLocking(bulkUpdateAProducts);
            List<UUID> lockOrderB = DeadlockPreventionUtil.sortProductsByIdForLocking(bulkUpdateBProducts);

            // Assert: Both are sorted
            assertTrue(DeadlockPreventionUtil.isSortedAscending(lockOrderA));
            assertTrue(DeadlockPreventionUtil.isSortedAscending(lockOrderB));

            // For overlapping products, they should appear in same order
            List<UUID> overlappingFromA = lockOrderA.stream()
                    .filter(lockOrderB::contains)
                    .collect(Collectors.toList());
            List<UUID> overlappingFromB = lockOrderB.stream()
                    .filter(lockOrderA::contains)
                    .collect(Collectors.toList());

            assertEquals(overlappingFromA, overlappingFromB);
        }
    }
}
