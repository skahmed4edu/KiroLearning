package com.hexaware.exception;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for GlobalExceptionHandler constraint violation handling.
 * 
 * Tests validate:
 * - ConstraintViolationException returns HTTP 400
 * - Error response includes all violations
 * - Field names and messages are extracted correctly
 * - Multiple violations are reported together
 * - Error message structure is correct
 * 
 * Requirements: 5.2, 5.3, 5.6
 */
@DisplayName("GlobalExceptionHandler ConstraintViolation Tests")
public class GlobalExceptionHandlerTest {
    
    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();
    
    /**
     * Test that single constraint violation returns HTTP 400 with error details.
     */
    @Test
    @DisplayName("Should handle single constraint violation with HTTP 400")
    public void testSingleConstraintViolation() {
        ConstraintViolation<?> violation = createMockViolation("productId", "Product does not exist");
        Set<ConstraintViolation<?>> violations = Set.of(violation);
        
        ConstraintViolationException exception = new ConstraintViolationException("Validation failed", violations);
        
        ResponseEntity<ErrorResponse> response = handler.handleConstraintViolationException(exception);
        
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().getStatus());
        assertEquals("Validation failed", response.getBody().getMessage());
        assertNotNull(response.getBody().getErrors());
        assertTrue(response.getBody().getErrors().containsKey("productId"));
        assertEquals("Product does not exist", response.getBody().getErrors().get("productId"));
    }
    
    /**
     * Test that multiple constraint violations are all reported together.
     */
    @Test
    @DisplayName("Should report multiple constraint violations together")
    public void testMultipleConstraintViolations() {
        ConstraintViolation<?> violation1 = createMockViolation("productId", "Product does not exist");
        ConstraintViolation<?> violation2 = createMockViolation("quantity", "Quantity must be positive");
        ConstraintViolation<?> violation3 = createMockViolation("updates", "Updates list exceeds maximum size");
        
        Set<ConstraintViolation<?>> violations = Set.of(violation1, violation2, violation3);
        
        ConstraintViolationException exception = new ConstraintViolationException("Validation failed", violations);
        
        ResponseEntity<ErrorResponse> response = handler.handleConstraintViolationException(exception);
        
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().getErrors());
        assertEquals(3, response.getBody().getErrors().size());
        
        assertTrue(response.getBody().getErrors().containsKey("productId"));
        assertTrue(response.getBody().getErrors().containsKey("quantity"));
        assertTrue(response.getBody().getErrors().containsKey("updates"));
    }
    
    /**
     * Test that error response includes timestamp.
     */
    @Test
    @DisplayName("Should include timestamp in error response")
    public void testTimestampInErrorResponse() {
        ConstraintViolation<?> violation = createMockViolation("productId", "Product does not exist");
        Set<ConstraintViolation<?>> violations = Set.of(violation);
        
        ConstraintViolationException exception = new ConstraintViolationException("Validation failed", violations);
        
        ResponseEntity<ErrorResponse> response = handler.handleConstraintViolationException(exception);
        
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().getTimestamp());
    }
    
    /**
     * Test that error response structure is correct for field validation.
     */
    @Test
    @DisplayName("Should return well-structured error response")
    public void testErrorResponseStructure() {
        ConstraintViolation<?> violation = createMockViolation("newTotalStock", "New total stock must be positive");
        Set<ConstraintViolation<?>> violations = Set.of(violation);
        
        ConstraintViolationException exception = new ConstraintViolationException("Validation failed", violations);
        
        ResponseEntity<ErrorResponse> response = handler.handleConstraintViolationException(exception);
        
        assertNotNull(response.getBody());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().getStatus());
        assertEquals("Validation failed", response.getBody().getMessage());
        assertNotNull(response.getBody().getErrors());
        
        Map<String, String> errors = response.getBody().getErrors();
        assertEquals(1, errors.size());
        assertTrue(errors.containsKey("newTotalStock"));
    }
    
    /**
     * Test that validation errors for bulk update batch size are reported clearly.
     */
    @Test
    @DisplayName("Should clearly report bulk update batch size validation errors")
    public void testBulkUpdateBatchSizeError() {
        ConstraintViolation<?> violation = createMockViolation("updates", 
                "Bulk update list exceeds maximum size of 1000 items");
        Set<ConstraintViolation<?>> violations = Set.of(violation);
        
        ConstraintViolationException exception = new ConstraintViolationException("Validation failed", violations);
        
        ResponseEntity<ErrorResponse> response = handler.handleConstraintViolationException(exception);
        
        assertNotNull(response.getBody());
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        
        String errorMessage = response.getBody().getErrors().get("updates");
        assertTrue(errorMessage.contains("exceeds maximum size"));
        assertTrue(errorMessage.contains("1000"));
    }
    
    /**
     * Test that validation errors for product existence are reported clearly.
     */
    @Test
    @DisplayName("Should clearly report product existence validation errors")
    public void testProductExistenceError() {
        ConstraintViolation<?> violation = createMockViolation("productId", 
                "Product with ID 6ba7b810-9dad-11d1-80b4-00c04fd430c8 does not exist");
        Set<ConstraintViolation<?>> violations = Set.of(violation);
        
        ConstraintViolationException exception = new ConstraintViolationException("Validation failed", violations);
        
        ResponseEntity<ErrorResponse> response = handler.handleConstraintViolationException(exception);
        
        assertNotNull(response.getBody());
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        
        String errorMessage = response.getBody().getErrors().get("productId");
        assertTrue(errorMessage.contains("does not exist"));
    }
    
    /**
     * Test that validation errors for quantity are reported clearly.
     */
    @Test
    @DisplayName("Should clearly report quantity validation errors")
    public void testQuantityError() {
        ConstraintViolation<?> violation = createMockViolation("quantity", 
                "Product quantity must be positive (greater than 0)");
        Set<ConstraintViolation<?>> violations = Set.of(violation);
        
        ConstraintViolationException exception = new ConstraintViolationException("Validation failed", violations);
        
        ResponseEntity<ErrorResponse> response = handler.handleConstraintViolationException(exception);
        
        assertNotNull(response.getBody());
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        
        String errorMessage = response.getBody().getErrors().get("quantity");
        assertTrue(errorMessage.contains("positive"));
    }
    
    /**
     * Helper method to create a mock ConstraintViolation.
     */
    @SuppressWarnings("unchecked")
    private ConstraintViolation<?> createMockViolation(String propertyPath, String message) {
        ConstraintViolation<?> violation = mock(ConstraintViolation.class);
        
        // Mock the property path
        jakarta.validation.Path path = mock(jakarta.validation.Path.class);
        when(path.toString()).thenReturn(propertyPath);
        when(violation.getPropertyPath()).thenReturn(path);
        
        // Mock the message
        when(violation.getMessage()).thenReturn(message);
        
        // Mock the invalid value
        when(violation.getInvalidValue()).thenReturn("someValue");
        
        return violation;
    }
}
