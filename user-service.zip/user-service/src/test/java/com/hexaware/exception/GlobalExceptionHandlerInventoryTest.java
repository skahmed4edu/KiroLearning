package com.hexaware.exception;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for the inventory / stock-reservation exception handlers in
 * {@link GlobalExceptionHandler}.
 *
 * <p>These tests verify, in isolation (no Spring context, no MockMvc):
 * <ul>
 *   <li>each custom inventory exception maps to the correct HTTP status;</li>
 *   <li>the standardized {@link InventoryErrorResponse} body carries all required
 *       fields (error code, message, timestamp, requestId, httpStatus);</li>
 *   <li>retryable errors (LOCK_TIMEOUT &rarr; 503) include a retry hint;</li>
 *   <li>non-retryable errors omit the retry hint.</li>
 * </ul>
 *
 * Requirements: 2.2, 3.5, 5.2, 5.3, 6.7
 */
@DisplayName("GlobalExceptionHandler Inventory Exception Tests")
class GlobalExceptionHandlerInventoryTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @AfterEach
    void clearMdc() {
        MDC.clear();
    }

    // -----------------------------------------------------------------
    // HTTP status mapping per custom exception type
    // -----------------------------------------------------------------

    @Test
    @DisplayName("InsufficientStockException maps to 409 with INSUFFICIENT_STOCK code")
    void handleInsufficientStockException_whenThrown_returns409Conflict() {
        // Arrange
        UUID productId = UUID.randomUUID();
        InsufficientStockException ex = new InsufficientStockException(productId, 3L, 10L);

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleInsufficientStockException(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("INSUFFICIENT_STOCK");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(HttpStatus.CONFLICT.value());
    }

    @Test
    @DisplayName("ReservationNotFoundException maps to 404 with RESERVATION_NOT_FOUND code")
    void handleReservationNotFoundException_whenThrown_returns404NotFound() {
        // Arrange
        ReservationNotFoundException ex = new ReservationNotFoundException("Reservation not found");

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleReservationNotFoundException(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("RESERVATION_NOT_FOUND");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(HttpStatus.NOT_FOUND.value());
    }

    @Test
    @DisplayName("ReservationAlreadyReleasedException maps to 409 with RESERVATION_ALREADY_RELEASED code")
    void handleReservationAlreadyReleasedException_whenThrown_returns409Conflict() {
        // Arrange
        ReservationAlreadyReleasedException ex =
                new ReservationAlreadyReleasedException("Reservation already processed");

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleReservationAlreadyReleasedException(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("RESERVATION_ALREADY_RELEASED");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(HttpStatus.CONFLICT.value());
    }

    @Test
    @DisplayName("LockTimeoutException maps to 503 with LOCK_TIMEOUT code")
    void handleLockTimeoutException_whenThrown_returns503ServiceUnavailable() {
        // Arrange
        LockTimeoutException ex = new LockTimeoutException("Could not acquire lock on product", 250L);

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleLockTimeoutException(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("LOCK_TIMEOUT");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE.value());
    }

    @Test
    @DisplayName("InvalidBulkUpdateException maps to 400 with INVALID_BULK_UPDATE code")
    void handleInvalidBulkUpdateException_whenThrown_returns400BadRequest() {
        // Arrange
        InvalidBulkUpdateException ex =
                new InvalidBulkUpdateException("Bulk update failed validation", List.of("item 0: negative quantity"));

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleInvalidBulkUpdateException(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("INVALID_BULK_UPDATE");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @DisplayName("InvalidStockAfterReservationsException maps to 409 with INVALID_STOCK_AFTER_RESERVATIONS code")
    void handleInvalidStockAfterReservationsException_whenThrown_returns409Conflict() {
        // Arrange
        UUID productId = UUID.randomUUID();
        InvalidStockAfterReservationsException ex =
                new InvalidStockAfterReservationsException(productId, 5L, 8L);

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleInvalidStockAfterReservationsException(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("INVALID_STOCK_AFTER_RESERVATIONS");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(HttpStatus.CONFLICT.value());
    }

    // -----------------------------------------------------------------
    // Required fields present in the error response body
    // -----------------------------------------------------------------

    @Test
    @DisplayName("Error response includes status, error, message, timestamp, and requestId")
    void handleInsufficientStockException_withRequestId_includesAllRequiredFields() {
        // Arrange
        MDC.put("requestId", "req-12345");
        UUID productId = UUID.randomUUID();
        InsufficientStockException ex = new InsufficientStockException(productId, 3L, 10L);

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleInsufficientStockException(ex);

        // Assert
        InventoryErrorResponse body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getHttpStatus()).isEqualTo(HttpStatus.CONFLICT.value());
        assertThat(body.getError()).isEqualTo("INSUFFICIENT_STOCK");
        assertThat(body.getMessage()).isEqualTo(ex.getMessage());
        assertThat(body.getTimestamp()).isNotNull();
        assertThat(body.getRequestId()).isEqualTo("req-12345");
    }

    @Test
    @DisplayName("InsufficientStockException surfaces product and quantity details")
    void handleInsufficientStockException_whenThrown_includesStockDetails() {
        // Arrange
        UUID productId = UUID.randomUUID();
        InsufficientStockException ex = new InsufficientStockException(productId, 3L, 10L);

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleInsufficientStockException(ex);

        // Assert
        Map<String, Object> details = response.getBody().getDetails();
        assertThat(details).isNotNull();
        assertThat(details.get("productId")).isEqualTo(productId);
        assertThat(details.get("availableStock")).isEqualTo(3L);
        assertThat(details.get("requestedQuantity")).isEqualTo(10L);
    }

    // -----------------------------------------------------------------
    // Retry hint: present for retryable, absent for non-retryable
    // -----------------------------------------------------------------

    @Test
    @DisplayName("Retryable LockTimeoutException includes the retry hint from the exception")
    void handleLockTimeoutException_whenRetryable_includesRetryHint() {
        // Arrange
        LockTimeoutException ex = new LockTimeoutException("Could not acquire lock on product", 250L);

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleLockTimeoutException(ex);

        // Assert
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getRetryAfter()).isEqualTo(250L);
    }

    @Test
    @DisplayName("Non-retryable InsufficientStockException omits the retry hint")
    void handleInsufficientStockException_whenNonRetryable_omitsRetryHint() {
        // Arrange
        InsufficientStockException ex = new InsufficientStockException(UUID.randomUUID(), 3L, 10L);

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleInsufficientStockException(ex);

        // Assert
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getRetryAfter()).isNull();
    }

    @Test
    @DisplayName("Non-retryable ReservationNotFoundException omits the retry hint")
    void handleReservationNotFoundException_whenNonRetryable_omitsRetryHint() {
        // Arrange
        ReservationNotFoundException ex = new ReservationNotFoundException("Reservation not found");

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleReservationNotFoundException(ex);

        // Assert
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getRetryAfter()).isNull();
    }

    @Test
    @DisplayName("Non-retryable ReservationAlreadyReleasedException omits the retry hint")
    void handleReservationAlreadyReleasedException_whenNonRetryable_omitsRetryHint() {
        // Arrange
        ReservationAlreadyReleasedException ex =
                new ReservationAlreadyReleasedException("Reservation already processed");

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleReservationAlreadyReleasedException(ex);

        // Assert
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getRetryAfter()).isNull();
    }

    @Test
    @DisplayName("Non-retryable InvalidBulkUpdateException omits the retry hint")
    void handleInvalidBulkUpdateException_whenNonRetryable_omitsRetryHint() {
        // Arrange
        InvalidBulkUpdateException ex = new InvalidBulkUpdateException("Bulk update failed validation");

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleInvalidBulkUpdateException(ex);

        // Assert
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getRetryAfter()).isNull();
    }

    @Test
    @DisplayName("Non-retryable InvalidStockAfterReservationsException omits the retry hint")
    void handleInvalidStockAfterReservationsException_whenNonRetryable_omitsRetryHint() {
        // Arrange
        InvalidStockAfterReservationsException ex =
                new InvalidStockAfterReservationsException(UUID.randomUUID(), 5L, 8L);

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleInvalidStockAfterReservationsException(ex);

        // Assert
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getRetryAfter()).isNull();
    }

    @Test
    @DisplayName("requestId is null in the response when no correlation id is set in MDC")
    void handleReservationNotFoundException_withoutMdcRequestId_leavesRequestIdNull() {
        // Arrange
        ReservationNotFoundException ex = new ReservationNotFoundException("Reservation not found");

        // Act
        ResponseEntity<InventoryErrorResponse> response = handler.handleReservationNotFoundException(ex);

        // Assert
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getRequestId()).isNull();
    }
}
