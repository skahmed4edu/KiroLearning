package com.hexaware.exception;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for the inventory / stock-reservation exception handling added to
 * {@link GlobalExceptionHandler} (task 16).
 *
 * <p>These tests exercise the handler directly (no Spring context) and verify:
 * <ul>
 *   <li>each custom exception maps to the correct HTTP status</li>
 *   <li>the {@link InventoryErrorResponse} body includes all required fields</li>
 *   <li>non-retryable errors omit the retry hint ({@code retryAfter == null})</li>
 *   <li>the retryable error (503 LOCK_TIMEOUT) includes the retry hint</li>
 * </ul>
 *
 * Requirements: 2.2, 3.5, 5.2, 5.3, 6.7
 */
@DisplayName("GlobalExceptionHandler inventory exception handling")
class InventoryExceptionHandlingTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    @DisplayName("InsufficientStockException maps to 409 Conflict")
    void handleInsufficientStockException_whenRaised_returns409Conflict() {
        // Arrange
        UUID productId = UUID.randomUUID();
        InsufficientStockException exception =
                new InsufficientStockException(productId, 25L, 50L);

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleInsufficientStockException(exception);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("INSUFFICIENT_STOCK");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(409);
        assertThat(response.getBody().getDetails())
                .containsEntry("availableStock", 25L)
                .containsEntry("requestedQuantity", 50L)
                .containsEntry("productId", productId);
    }

    @Test
    @DisplayName("ReservationNotFoundException maps to 404 Not Found")
    void handleReservationNotFoundException_whenRaised_returns404NotFound() {
        // Arrange
        ReservationNotFoundException exception =
                new ReservationNotFoundException("Reservation not found: abc");

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleReservationNotFoundException(exception);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("RESERVATION_NOT_FOUND");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(404);
        assertThat(response.getBody().getMessage()).isEqualTo("Reservation not found: abc");
    }

    @Test
    @DisplayName("ReservationAlreadyReleasedException maps to 409 Conflict")
    void handleReservationAlreadyReleasedException_whenRaised_returns409Conflict() {
        // Arrange
        ReservationAlreadyReleasedException exception =
                new ReservationAlreadyReleasedException("Reservation already processed: EXPIRED");

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleReservationAlreadyReleasedException(exception);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("RESERVATION_ALREADY_RELEASED");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(409);
    }

    @Test
    @DisplayName("LockTimeoutException maps to 503 Service Unavailable")
    void handleLockTimeoutException_whenRaised_returns503ServiceUnavailable() {
        // Arrange
        LockTimeoutException exception =
                new LockTimeoutException("Could not acquire lock on product; please retry", 150L);

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleLockTimeoutException(exception);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("LOCK_TIMEOUT");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(503);
    }

    @Test
    @DisplayName("InvalidBulkUpdateException maps to 400 Bad Request")
    void handleInvalidBulkUpdateException_whenRaised_returns400BadRequest() {
        // Arrange
        InvalidBulkUpdateException exception = new InvalidBulkUpdateException(
                "Bulk update list exceeds maximum size of 1000 items",
                List.of("item[0]: product does not exist"));

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleInvalidBulkUpdateException(exception);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("INVALID_BULK_UPDATE");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(400);
        assertThat(response.getBody().getDetails())
                .containsEntry("failures", List.of("item[0]: product does not exist"));
    }

    @Test
    @DisplayName("InvalidStockAfterReservationsException maps to 409 Conflict")
    void handleInvalidStockAfterReservationsException_whenRaised_returns409Conflict() {
        // Arrange
        UUID productId = UUID.randomUUID();
        InvalidStockAfterReservationsException exception =
                new InvalidStockAfterReservationsException(productId, 5L, 20L);

        // Act
        ResponseEntity<InventoryErrorResponse> response =
                handler.handleInvalidStockAfterReservationsException(exception);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getError()).isEqualTo("INVALID_STOCK_AFTER_RESERVATIONS");
        assertThat(response.getBody().getHttpStatus()).isEqualTo(409);
        assertThat(response.getBody().getDetails())
                .containsEntry("newTotalStock", 5L)
                .containsEntry("reservedStock", 20L);
    }

    @Test
    @DisplayName("Error response includes all required standardized fields")
    void handleInsufficientStockException_whenRaised_includesAllRequiredFields() {
        // Arrange
        InsufficientStockException exception =
                new InsufficientStockException(UUID.randomUUID(), 0L, 10L);

        // Act
        InventoryErrorResponse body =
                handler.handleInsufficientStockException(exception).getBody();

        // Assert
        assertThat(body).isNotNull();
        assertThat(body.getError()).isNotBlank();
        assertThat(body.getMessage()).isNotBlank();
        assertThat(body.getTimestamp()).isNotNull();
        assertThat(body.getHttpStatus()).isPositive();
        assertThat(body.getDetails()).isNotNull();
    }

    @Test
    @DisplayName("Non-retryable errors omit the retry hint")
    void handleNonRetryableErrors_whenRaised_omitRetryHint() {
        // Arrange
        UUID productId = UUID.randomUUID();

        // Act
        InventoryErrorResponse insufficientStock =
                handler.handleInsufficientStockException(
                        new InsufficientStockException(productId, 1L, 2L)).getBody();
        InventoryErrorResponse notFound =
                handler.handleReservationNotFoundException(
                        new ReservationNotFoundException("missing")).getBody();
        InventoryErrorResponse alreadyReleased =
                handler.handleReservationAlreadyReleasedException(
                        new ReservationAlreadyReleasedException("released")).getBody();
        InventoryErrorResponse invalidBulk =
                handler.handleInvalidBulkUpdateException(
                        new InvalidBulkUpdateException("bad batch")).getBody();
        InventoryErrorResponse invalidStock =
                handler.handleInvalidStockAfterReservationsException(
                        new InvalidStockAfterReservationsException(productId, 1L, 5L)).getBody();

        // Assert
        assertThat(insufficientStock).isNotNull();
        assertThat(insufficientStock.getRetryAfter()).isNull();
        assertThat(notFound.getRetryAfter()).isNull();
        assertThat(alreadyReleased.getRetryAfter()).isNull();
        assertThat(invalidBulk.getRetryAfter()).isNull();
        assertThat(invalidStock.getRetryAfter()).isNull();
    }

    @Test
    @DisplayName("Retryable 503 error includes the retry hint")
    void handleLockTimeoutException_whenRaised_includesRetryHint() {
        // Arrange
        LockTimeoutException exception =
                new LockTimeoutException("Could not acquire lock on product; please retry", 250L);

        // Act
        InventoryErrorResponse body =
                handler.handleLockTimeoutException(exception).getBody();

        // Assert
        assertThat(body).isNotNull();
        assertThat(body.getRetryAfter()).isEqualTo(250L);
    }
}
