package com.hexaware.validation;

import com.hexaware.dto.BulkUpdateRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for @BulkUpdateMaxSize validator.
 * 
 * Tests validate:
 * - Batch size validation works correctly
 * - Empty lists fail validation
 * - Lists at maximum size pass validation
 * - Lists exceeding maximum size fail validation
 * - Error messages are clear
 * 
 * Requirements: 5.2, 5.6
 */
@DisplayName("BulkUpdateMaxSize Validator Tests")
public class BulkUpdateMaxSizeValidatorTest {
    
    private final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    private final Validator validator = validatorFactory.getValidator();
    
    /**
     * Test that a bulk update request with empty updates list fails validation.
     */
    @Test
    @DisplayName("Should fail validation when updates list is empty")
    public void testEmptyUpdatesList() {
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(new ArrayList<>())
                .build();
        
        Set<ConstraintViolation<BulkUpdateRequest>> violations = validator.validate(request);
        
        assertFalse(violations.isEmpty(), "Expected validation violations for empty list");
        assertTrue(violations.stream()
                .anyMatch(v -> v.getMessage().contains("must not be empty")),
                "Expected @NotEmpty violation");
    }
    
    /**
     * Test that a bulk update request with single update passes validation.
     */
    @Test
    @DisplayName("Should pass validation with single update entry")
    public void testSingleUpdateEntry() {
        List<BulkUpdateRequest.BulkStockUpdateEntry> updates = new ArrayList<>();
        updates.add(BulkUpdateRequest.BulkStockUpdateEntry.builder()
                .productId(UUID.randomUUID())
                .newTotalStock(100L)
                .reason("Restock")
                .build());
        
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(updates)
                .build();
        
        Set<ConstraintViolation<BulkUpdateRequest>> violations = validator.validate(request);
        
        // Filter out violations from nested entries (we're testing batch size here)
        long batchSizeViolations = violations.stream()
                .filter(v -> v.getPropertyPath().toString().equals("updates"))
                .count();
        
        assertEquals(0, batchSizeViolations, "Should not have batch size violation for 1 item");
    }
    
    /**
     * Test that a bulk update request with maximum size (1000) passes validation.
     */
    @Test
    @DisplayName("Should pass validation with exactly 1000 updates")
    public void testMaximumBatchSize() {
        List<BulkUpdateRequest.BulkStockUpdateEntry> updates = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            updates.add(BulkUpdateRequest.BulkStockUpdateEntry.builder()
                    .productId(UUID.randomUUID())
                    .newTotalStock(100L)
                    .reason("Restock")
                    .build());
        }
        
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(updates)
                .build();
        
        Set<ConstraintViolation<BulkUpdateRequest>> violations = validator.validate(request);
        
        // Filter out violations from nested entries
        long batchSizeViolations = violations.stream()
                .filter(v -> v.getPropertyPath().toString().equals("updates"))
                .count();
        
        assertEquals(0, batchSizeViolations, "Should not have batch size violation for 1000 items");
    }
    
    /**
     * Test that a bulk update request exceeding maximum size (1001) fails validation.
     */
    @Test
    @DisplayName("Should fail validation with 1001 updates (exceeds limit)")
    public void testExceedingMaximumBatchSize() {
        List<BulkUpdateRequest.BulkStockUpdateEntry> updates = new ArrayList<>();
        for (int i = 0; i < 1001; i++) {
            updates.add(BulkUpdateRequest.BulkStockUpdateEntry.builder()
                    .productId(UUID.randomUUID())
                    .newTotalStock(100L)
                    .reason("Restock")
                    .build());
        }
        
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(updates)
                .build();
        
        Set<ConstraintViolation<BulkUpdateRequest>> violations = validator.validate(request);
        
        // Filter violations from nested entries only
        long batchSizeViolations = violations.stream()
                .filter(v -> v.getPropertyPath().toString().equals("updates"))
                .count();
        
        assertEquals(1, batchSizeViolations, "Should have exactly one batch size violation");
    }
    
    /**
     * Test that error message for oversized batch is clear and informative.
     */
    @Test
    @DisplayName("Should provide clear error message for batch size limit exceeded")
    public void testErrorMessageClarity() {
        List<BulkUpdateRequest.BulkStockUpdateEntry> updates = new ArrayList<>();
        for (int i = 0; i < 1500; i++) {
            updates.add(BulkUpdateRequest.BulkStockUpdateEntry.builder()
                    .productId(UUID.randomUUID())
                    .newTotalStock(100L)
                    .reason("Restock")
                    .build());
        }
        
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(updates)
                .build();
        
        Set<ConstraintViolation<BulkUpdateRequest>> violations = validator.validate(request);
        
        String errorMessage = violations.stream()
                .filter(v -> v.getPropertyPath().toString().equals("updates"))
                .map(ConstraintViolation::getMessage)
                .findFirst()
                .orElse("");
        
        assertTrue(errorMessage.toLowerCase().contains("exceed"),
                "Error message should mention exceeding limit");
        assertTrue(errorMessage.contains("1000"),
                "Error message should include max size of 1000");
    }
    
    /**
     * Test that null updates list passes batch size validation (handled by @NotNull).
     */
    @Test
    @DisplayName("Should pass batch size validation for null list (handled by @NotNull)")
    public void testNullUpdatesList() {
        BulkUpdateRequest request = BulkUpdateRequest.builder()
                .updates(null)
                .build();
        
        Set<ConstraintViolation<BulkUpdateRequest>> violations = validator.validate(request);
        
        // Should have @NotNull violation, not batch size violation
        boolean hasNullViolation = violations.stream()
                .anyMatch(v -> v.getMessage().contains("must not be empty"));
        
        assertTrue(hasNullViolation, "Should have @NotEmpty or @NotNull violation");
    }
}
