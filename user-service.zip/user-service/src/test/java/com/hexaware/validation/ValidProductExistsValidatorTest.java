package com.hexaware.validation;

import com.hexaware.repository.ProductRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for @ValidProductExists validator.
 * 
 * Tests validate:
 * - Product existence check works correctly
 * - Existing products pass validation
 * - Non-existing products fail validation
 * - Database queries are performed efficiently
 * 
 * Requirements: 5.2, 5.3, 5.6
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ValidProductExists Validator Tests")
public class ValidProductExistsValidatorTest {
    
    @Mock
    private ProductRepository productRepository;
    
    @InjectMocks
    private ValidProductExistsValidator validator;
    
    /**
     * Test that validation passes when product exists in database.
     */
    @Test
    @DisplayName("Should pass validation when product exists")
    public void testProductExists() {
        // Arrange
        UUID productId = UUID.randomUUID();
        when(productRepository.existsById(productId)).thenReturn(true);
        
        // Inject the mock repository using reflection (since it's @Autowired)
        ReflectionTestUtils.setField(validator, "productRepository", productRepository);
        
        // Act
        boolean isValid = validator.isValid(productId, null);
        
        // Assert
        assertTrue(isValid, "Should be valid when product exists");
        verify(productRepository, times(1)).existsById(productId);
    }
    
    /**
     * Test that validation fails when product does not exist in database.
     */
    @Test
    @DisplayName("Should fail validation when product does not exist")
    public void testProductDoesNotExist() {
        // Arrange
        UUID productId = UUID.randomUUID();
        when(productRepository.existsById(productId)).thenReturn(false);
        
        // Inject the mock repository using reflection (since it's @Autowired)
        ReflectionTestUtils.setField(validator, "productRepository", productRepository);
        
        // Act
        boolean isValid = validator.isValid(productId, null);
        
        // Assert
        assertFalse(isValid, "Should be invalid when product does not exist");
        verify(productRepository, times(1)).existsById(productId);
    }
    /**
     * Test that validation passes when product ID is null (handled by @NotNull separately).
     */
    @Test
    @DisplayName("Should pass product existence validation for null ID (handled by @NotNull)")
    public void testNullProductId() {
        // Arrange
        ReflectionTestUtils.setField(validator, "productRepository", productRepository);
        
        // Act
        boolean isValid = validator.isValid(null, null);
        
        // Assert
        assertTrue(isValid, "Should pass null (handled by @NotNull)");
        verify(productRepository, times(0)).existsById(any());
    }
    
    /**
     * Test that the validator queries the database exactly once per validation.
     */
    @Test
    @DisplayName("Should query database exactly once per validation")
    public void testDatabaseQueryCount() {
        // Arrange
        UUID productId = UUID.randomUUID();
        when(productRepository.existsById(productId)).thenReturn(true);
        ReflectionTestUtils.setField(validator, "productRepository", productRepository);
        
        // Act
        validator.isValid(productId, null);
        
        // Assert
        verify(productRepository, times(1)).existsById(productId);
    }
    
    /**
     * Test that multiple validations create separate database queries.
     */
    @Test
    @DisplayName("Should create separate database queries for multiple validations")
    public void testMultipleValidations() {
        // Arrange
        UUID productId1 = UUID.randomUUID();
        UUID productId2 = UUID.randomUUID();
        
        when(productRepository.existsById(productId1)).thenReturn(true);
        when(productRepository.existsById(productId2)).thenReturn(false);
        
        ReflectionTestUtils.setField(validator, "productRepository", productRepository);
        
        // Act
        validator.isValid(productId1, null);
        validator.isValid(productId2, null);
        
        // Assert
        verify(productRepository, times(1)).existsById(productId1);
        verify(productRepository, times(1)).existsById(productId2);
    }
}
