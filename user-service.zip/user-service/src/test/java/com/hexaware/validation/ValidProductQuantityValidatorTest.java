package com.hexaware.validation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Direct unit tests for @ValidProductQuantity validator.
 * 
 * These tests focus only on the quantity validator logic, testing it in isolation
 * without the @ValidProductExists validator which requires database access.
 * 
 * Tests validate:
 * - Positive quantity values pass validation
 * - Zero and negative quantities fail validation
 * - Error messages are clear
 * - Edge cases are handled correctly
 * 
 * Requirements: 5.3, 5.6
 */
@DisplayName("ValidProductQuantity Validator Unit Tests")
public class ValidProductQuantityValidatorTest {
    
    private final ValidProductQuantityValidator quantityValidator = new ValidProductQuantityValidator();
    private final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    
    /**
     * Test that positive quantity (1 unit) passes validation.
     */
    @Test
    @DisplayName("Should pass validation with quantity = 1")
    public void testMinimumPositiveQuantity() {
        assertTrue(quantityValidator.isValid(1L, null), "Should accept quantity = 1");
    }
    
    /**
     * Test that normal positive quantity (e.g., 100) passes validation.
     */
    @Test
    @DisplayName("Should pass validation with normal positive quantity")
    public void testNormalPositiveQuantity() {
        assertTrue(quantityValidator.isValid(100L, null), "Should accept quantity = 100");
    }
    
    /**
     * Test that large positive quantity (max Long value) passes validation.
     */
    @Test
    @DisplayName("Should pass validation with very large positive quantity")
    public void testLargePositiveQuantity() {
        assertTrue(quantityValidator.isValid(Long.MAX_VALUE, null), "Should accept very large quantities");
    }
    
    /**
     * Test that zero quantity fails validation.
     */
    @Test
    @DisplayName("Should fail validation with quantity = 0")
    public void testZeroQuantity() {
        assertFalse(quantityValidator.isValid(0L, null), "Should reject quantity = 0");
    }
    
    /**
     * Test that negative quantity fails validation.
     */
    @Test
    @DisplayName("Should fail validation with negative quantity")
    public void testNegativeQuantity() {
        assertFalse(quantityValidator.isValid(-10L, null), "Should reject negative quantity");
    }
    
    /**
     * Test that minimum negative quantity (-1) fails validation.
     */
    @Test
    @DisplayName("Should fail validation with quantity = -1")
    public void testMinimumNegativeQuantity() {
        assertFalse(quantityValidator.isValid(-1L, null), "Should reject quantity = -1");
    }
    
    /**
     * Test that null quantity passes validation (handled by @NotNull).
     */
    @Test
    @DisplayName("Should pass quantity validation for null value (handled by @NotNull)")
    public void testNullQuantity() {
        assertTrue(quantityValidator.isValid(null, null), "Should pass null (handled by @NotNull)");
    }
    
    /**
     * Test with Integer type (should work for any Number subclass).
     */
    @Test
    @DisplayName("Should accept Integer type for quantity")
    public void testIntegerQuantity() {
        assertTrue(quantityValidator.isValid(50, null), "Should accept Integer(50)");
        assertFalse(quantityValidator.isValid(0, null), "Should reject Integer(0)");
        assertFalse(quantityValidator.isValid(-5, null), "Should reject Integer(-5)");
    }
    
    /**
     * Test boundary condition at positive/non-positive boundary.
     */
    @Test
    @DisplayName("Should correctly handle boundary at zero")
    public void testBoundaryCondition() {
        assertTrue(quantityValidator.isValid(1L, null), "quantity=1 should be valid");
        assertFalse(quantityValidator.isValid(0L, null), "quantity=0 should be invalid");
    }
}
