# Stock Reservation Feature - Database Schema Documentation

## Overview

This document describes the PostgreSQL database schema for the Stock Reservation Feature. The schema implements atomic reservation handling, concurrent-safe operations, and complete audit trails for inventory management.

## Database Migrations

The project uses **Flyway** for version-controlled database migrations. Migrations are located in `src/main/resources/db/migration/` with the naming convention `V{version}__{description}.sql`.

### Migration Files

1. **V1__Create_inventory_schema.sql** - Initial schema creation
   - Creates all core tables (products, reservations, reservation_history, stock_audit_log)
   - Adds all constraints and indexes
   - Implements row-level locking support

2. **V2__Add_inventory_test_fixtures.sql** - Test data
   - Adds sample products for development and testing
   - Optional for development environment

## Schema Design

### Tables

#### 1. Products Table

Stores product definitions and current stock levels.

```sql
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    total_stock BIGINT NOT NULL CHECK (total_stock > 0),
    reserved_stock BIGINT NOT NULL DEFAULT 0 CHECK (reserved_stock >= 0),
    available_stock BIGINT NOT NULL CHECK (available_stock >= 0),
    version BIGINT NOT NULL DEFAULT 0,
    lock_version BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stock_invariant CHECK (total_stock = available_stock + reserved_stock)
);
```

**Columns:**
- `id`: Unique identifier (UUID)
- `sku`: Stock Keeping Unit - unique product identifier
- `name`: Human-readable product name
- `total_stock`: Total quantity of product in inventory
- `reserved_stock`: Quantity held by active reservations
- `available_stock`: Quantity available for new reservations
- `version`: Optimistic locking version counter
- `lock_version`: Used by Hibernate for pessimistic locking
- `updated_at`: Last modification timestamp
- `created_at`: Creation timestamp (immutable)

**Constraints:**
- `CHECK (total_stock > 0)` - At least 1 unit must exist
- `CHECK (reserved_stock >= 0)` - Cannot have negative reservations
- `CHECK (available_stock >= 0)` - Cannot have negative available stock
- **INVARIANT**: `total_stock = available_stock + reserved_stock` - Stock conservation law

**Indexes:**
- `idx_product_sku` - Fast lookup by SKU for product queries
- `idx_product_updated_at` - Time-based queries for sorting and expiration logic

**Lock Strategy:**
- Row-level locking via `SELECT ... FOR UPDATE NOWAIT`
- Optimistic locking via `version` field for retry logic
- Isolation Level: READ_COMMITTED

---

#### 2. Reservations Table

Stores reservation records linked to orders with full lifecycle tracking.

```sql
CREATE TABLE reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    quantity BIGINT NOT NULL CHECK (quantity > 0),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    expiration_time TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    released_at TIMESTAMP,
    expired_at TIMESTAMP,
    idempotency_key VARCHAR(100),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
);
```

**Columns:**
- `id`: Unique reservation identifier (UUID)
- `order_id`: Associated order ID (links to Order Service)
- `product_id`: FK to products table
- `quantity`: Number of units reserved
- `status`: Reservation state (ACTIVE, RELEASED, EXPIRED, CANCELLED)
- `expiration_time`: When reservation auto-expires (now + TTL)
- `created_at`: Reservation creation timestamp
- `released_at`: When manually released (nullable)
- `expired_at`: When auto-expired (nullable)
- `idempotency_key`: Unique key for deduplication of retry requests

**Constraints:**
- `CHECK (quantity > 0)` - At least 1 unit must be reserved
- Foreign Key to products with ON DELETE RESTRICT (prevent orphaning)

**Statuses:**
- `ACTIVE` - Reservation is valid, stock is reserved
- `RELEASED` - Manually released, stock restored
- `EXPIRED` - Auto-expired after TTL, stock restored
- `CANCELLED` - Reserved for future use

**Indexes:**
- `idx_reservation_order_id` - Lookup reservation by order ID for release operations
- `idx_reservation_product_id` - Find all reservations for a product
- `idx_reservation_status` - Filter reservations by status (e.g., ACTIVE only)
- `idx_reservation_expiration_time` - Batch expiration queries by TTL
- `idx_reservation_created_at` - Time-based analytics queries
- `idx_reservation_idempotency_key` - Detect duplicate requests

**Row-Level Locking:**
- Uses pessimistic locking: `SELECT ... FOR UPDATE NOWAIT`
- Prevents concurrent conflicts on same reservation
- Lock timeout returns HTTP 503 for client retry

---

#### 3. Reservation History Table (Audit Log)

Tracks all status changes to reservations for compliance, debugging, and analytics.

```sql
CREATE TABLE reservation_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reservation_id UUID NOT NULL,
    order_id UUID NOT NULL,
    product_id UUID NOT NULL,
    quantity BIGINT NOT NULL,
    old_status VARCHAR(20),
    new_status VARCHAR(20) NOT NULL,
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reason VARCHAR(255),
    FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
);
```

**Columns:**
- `id`: Unique history record ID
- `reservation_id`: FK to reservations (CASCADE delete)
- `order_id`: Order ID for cross-reference
- `product_id`: Product ID for cross-reference
- `quantity`: Quantity reserved (denormalized for audit trail)
- `old_status`: Previous status (nullable for creation)
- `new_status`: New status after change
- `changed_at`: When the change occurred
- `reason`: Human-readable reason for change (e.g., "Manual release", "TTL expired")

**Indexes:**
- `idx_reservation_history_reservation_id` - Lookup all history for a reservation
- `idx_reservation_history_changed_at` - Time-based analytics and retention queries

**Purpose:**
- Complete audit trail for compliance
- Debug problematic reservations
- Analytics on reservation lifecycle
- Retention policy enforcement (e.g., delete records >30 days old)

---

#### 4. Stock Audit Log Table

Tracks all stock operations (reserve, release, bulk update) with before/after values.

```sql
CREATE TABLE stock_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    operation_type VARCHAR(50) NOT NULL,
    quantity_change BIGINT NOT NULL,
    available_stock_before BIGINT NOT NULL,
    available_stock_after BIGINT NOT NULL,
    executed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    request_id VARCHAR(100),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);
```

**Columns:**
- `id`: Unique log entry ID
- `product_id`: FK to products (CASCADE delete)
- `operation_type`: Type of operation (RESERVE, RELEASE, BULK_UPDATE, EXPIRE)
- `quantity_change`: Change amount (positive for release/expiration, negative for reserve)
- `available_stock_before`: Stock level before operation
- `available_stock_after`: Stock level after operation
- `executed_at`: When operation was executed
- `request_id`: Correlation ID for tracing request flow

**Operation Types:**
- `RESERVE` - Stock reserved for order
- `RELEASE` - Stock released from order cancellation
- `EXPIRE` - Stock released from reservation expiration
- `BULK_UPDATE` - Stock added via bulk update operation

**Indexes:**
- `idx_stock_audit_log_product_id` - Lookup operations for a product
- `idx_stock_audit_log_executed_at` - Time-based queries for reconciliation

**Purpose:**
- Complete audit trail for all stock changes
- Reconciliation and stock discrepancy debugging
- Performance analytics (operations per product/time)
- Compliance reporting

---

## Stock Invariants

The schema enforces the following invariants at the database level:

### Primary Invariant
```
totalStock = availableStock + reservedStock
```

This ensures that the sum of available and reserved stock always equals the total stock. Any operation that would violate this invariant is rejected at the database level via the CHECK constraint.

### Stock Non-Negativity
```
availableStock >= 0
reservedStock >= 0
totalStock > 0
```

No field can have negative values, and at least one unit of stock must be defined per product.

### Quantity Constraints
```
reservation.quantity > 0
```

Reservations must reserve at least one unit.

---

## Concurrency and Locking

### Row-Level Locking Strategy

The system uses **pessimistic row-level locking** for critical operations:

**Reservation Creation:**
```sql
BEGIN TRANSACTION
    SELECT * FROM products WHERE id = ?
    FOR UPDATE NOWAIT;  -- Exclusive lock, fail immediately if unavailable
    
    -- Check stock availability
    -- Update product stock
    -- Insert reservation
COMMIT
```

**Lock Timeout Behavior:**
- If lock cannot be acquired immediately, operation fails with exception
- Application catches this and returns HTTP 503 Service Unavailable
- Client retries with exponential backoff

**Preventing Deadlocks in Bulk Updates:**
- Always acquire locks in consistent order (by product ID ascending)
- Prevents circular wait conditions
- Ensures deterministic lock acquisition

### Isolation Level

**Required: READ_COMMITTED**

This level prevents dirty reads while allowing non-repeatable reads and phantom reads. Combined with explicit row-level locking, it provides sufficient safety for the inventory system without the performance cost of SERIALIZABLE isolation.

---

## Performance Considerations

### Indexes for High-Throughput Scenarios

1. **Product Queries**
   - `idx_product_sku` - O(log n) SKU lookups
   - `idx_product_updated_at` - Efficient time-range queries

2. **Reservation Lookups**
   - `idx_reservation_order_id` - Fast order-based release operations
   - `idx_reservation_product_id` - Efficient stock level calculations
   - `idx_reservation_status` - Fast filtering for expiration batches
   - `idx_reservation_expiration_time` - Efficient TTL-based queries

3. **Audit Queries**
   - `idx_reservation_history_changed_at` - Time-range analytics
   - `idx_stock_audit_log_executed_at` - Retention policy queries

### Expected Performance

- **Stock Level Query**: <100ms (99th percentile)
- **Reservation Creation**: <200ms (99th percentile, including lock acquisition)
- **Bulk Update (1000 products)**: <5 seconds (99th percentile)
- **Reservation Expiration Batch**: <5 seconds for 10,000 reservations

---

## Migration Strategy

### Running Migrations

Migrations are automatically applied by Spring Boot on application startup when Flyway is enabled:

```properties
spring.flyway.enabled=true
spring.flyway.baseline-on-migrate=true
spring.flyway.validate-on-migrate=true
```

### Manual Migration Verification

To verify migrations work on a clean database:

```bash
# 1. Reset database (development only)
psql -U postgres -d user_service_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"

# 2. Start application - migrations will run automatically
./mvnw spring-boot:run

# 3. Verify schema was created
psql -U postgres -d user_service_db -c "\dt"
psql -U postgres -d user_service_db -c "\di"
```

### Version Control

Flyway tracks migration history in the `flyway_schema_history` table:

```sql
SELECT * FROM flyway_schema_history;
```

Each migration is immutable once applied. To make a change:
1. Create a new migration file with next version number
2. Document the change in the new file
3. Deploy with the new migration

---

## Constraints and Validation

### Database-Level Constraints

All constraints are enforced at the database level, not just the application:

1. **Stock Invariant Check**
   ```sql
   CHECK (total_stock = available_stock + reserved_stock)
   ```
   
2. **Non-Negative Stock**
   ```sql
   CHECK (available_stock >= 0)
   CHECK (reserved_stock >= 0)
   CHECK (total_stock > 0)
   ```

3. **Positive Quantity**
   ```sql
   CHECK (quantity > 0)  -- on reservations
   ```

4. **Referential Integrity**
   ```sql
   FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
   ```

### Application-Level Validation

The application layer adds additional validation:
- Product ID existence
- Bulk update batch size limits
- Business logic validation

---

## Future Enhancements

1. **Partitioning**: As data grows, consider time-based partitioning of audit tables
2. **Archival**: Implement retention policies to archive old reservation history
3. **Replication**: Configure read replicas for analytics queries
4. **Monitoring**: Add database-level monitoring for lock contention and query performance
5. **Hot Standby**: Configure streaming replication for disaster recovery

---

## References

- [Flyway Documentation](https://flywaydb.org/documentation/)
- [PostgreSQL DDL](https://www.postgresql.org/docs/current/ddl.html)
- [Row-Level Locking in PostgreSQL](https://www.postgresql.org/docs/current/explicit-locking.html)
- Design Document: `INVENTORY_DESIGN.md`
- Requirements Document: `INVENTORY_REQUIREMENTS.md`
