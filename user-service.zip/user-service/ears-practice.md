# EARS Practice

## Part 2 — Name that pattern
A

THE SYSTEM SHALL hash every wallet PIN with bcrypt before storing it.

B

WHEN a user confirms a top-up THE SYSTEM SHALL credit the wallet by the top-up amount.

C

WHILE a wallet is FROZEN THE SYSTEM SHALL reject every debit request.

D

IF a transfer amount exceeds the sender's balance, THEN THE SYSTEM SHALL reject the transfer and leave both balances unchanged.

E

WHERE international transfers are enabled for an account THE SYSTEM SHALL apply the currency conversion fee.

F

WHILE a wallet is ACTIVE, WHEN a user submits a transfer, THE SYSTEM SHALL create a PENDING transaction.

G

WHEN a wallet becomes FROZEN THE SYSTEM SHALL reject debit requests.

H

WHERE a wallet balance is below 100 INR THE SYSTEM SHALL send a low-balance alert.

## Part 3 — Fix the vague requirement

IF the payment gateway returns a decline for a top-up,
THEN THE SYSTEM SHALL set the top-up status to FAILED, store the gateway
decline code, and leave the wallet balance unchanged.

WHEN a user submits a valid transfer
THE SYSTEM SHALL respond within 2 seconds for at least 95% of requests
at a load of 100 concurrent users.

WHEN a user requests a statement for a date range
THE SYSTEM SHALL return a PDF listing every transaction in that range,
newest first.


IF a user submits a sixth top-up within any 10-minute window,
THEN THE SYSTEM SHALL reject it with 429 Too Many Requests and leave
the balance unchanged.

WHEN a user submits a transfer between two ACTIVE wallets with sufficient balance
THE SYSTEM SHALL debit the sender, credit the receiver, and record a SUCCESS transaction.


## Part 4 — Missing rainy days

IF the transfer amount is zero or negative,
THEN THE SYSTEM SHALL reject the request with 400 Bad Request and a field-level error.

IF the receiver wallet does not exist,
THEN THE SYSTEM SHALL reject the transfer with 404 Not Found and leave the sender's balance unchanged.

IF the sender and receiver are the same wallet,
THEN THE SYSTEM SHALL reject the transfer with 400 Bad Request.

IF the sender's wallet is FROZEN,
THEN THE SYSTEM SHALL reject the transfer with 409 Conflict.

IF the transfer amount exceeds the sender's balance,
THEN THE SYSTEM SHALL reject the transfer with 409 Conflict and leave both balances unchanged.

IF the same transfer is submitted twice with the same idempotency key,
THEN THE SYSTEM SHALL return the result of the first request and SHALL NOT debit the sender a second time.

IF two transfers are processed at the same time from the same wallet,
THEN THE SYSTEM SHALL ensure the total debited never exceeds the balance the wallet held
before either transfer, and SHALL reject any transfer that would exceed it.

## Part 5 — Test names
methodName_stateUnderTest_expectedBehaviour